/*! RESOURCE: /scripts/app.filter_widget.js */
angular.module('sn.filter_widget', [
	'sn.common.util',
	'sn.common.table_data',
	'sn.common.notification',
	'sn.common.controls',
	'sn.common.glide',
	'sn.common.i18n',
	'sn.common.messaging',
	'sn.ngform.elements',
	'sn.ngform.components',
	'ngSanitize',
	'sn.filter_widget.data',
	'sn.filter_widget.dot_walk'
]);
;
/*! RESOURCE: /scripts/sn/filter_widget/data/_module.js */
angular.module('sn.filter_widget.data', [
]);
;
/*! RESOURCE: /scripts/sn/filter_widget/data/constants.js */
angular.module('sn.filter_widget.data').constant('KEYWORD_FIELD', '123TEXTQUERY321');
;
/*! RESOURCE: /scripts/sn/filter_widget/data/factory.snFilterAPI.js */
angular.module('sn.filter_widget.data').factory('filterAPI', function ($http, $q, $window) {
	"use strict";
var FILTER_ENDPOINT = "/api/now/ui/saved_filters/";
var QUERY_PARSE_ENDPOINT = "/api/now/ui/query_parse/";
var BREADCRUMBS_ENDPOINT = "/api/now/ui/breadcrumbs";
var RECORD_COUNT_ENDPOINT = "/api/now/ui/filter/";
var RELATED_LIST_ENDPOINT = "/api/now/ui/related_list/related/";
var TINY_URL_ENDPOINT = "/api/now/tinyurl";
	return {
		parseQuery : parseQuery,
		getBreadcrumbs: getBreadcrumbs,
		testFilter : testFilter,
		getFilters : getFilters,
		getRelatedLists: getRelatedLists,
		saveFilter : saveFilter,
		deleteFilter : deleteFilter
	};
	function isValidTableName (tableName) {
return !/[.%]/.test(tableName);
	}
	function useTinyURLService(query) {
		return $window.g_tiny_url && $window.g_tiny_url.use_tiny && query.length >= $window.g_tiny_url.min_length;
	}
	function getAPIResponse(query, resolveCallback) {
		if (useTinyURLService(query)) {
			return $http.post(TINY_URL_ENDPOINT, {url: query}).then(function(tinyResponse) {
				return $http.get(tinyResponse.data.result).then(resolveCallback);
			});
		}
		return $http.get(query).then(resolveCallback);
	}
	function parseQuery(encodedQuery, table, tinyUrl){
		if(!isValidTableName(table)) {
			return $q.reject("invalid table name");
		}
		var parms = tinyUrl ? "sysparm_tiny_url=" + tinyUrl : "sysparm_query="
			+ encodeURIComponent(encodedQuery);
var query = QUERY_PARSE_ENDPOINT + table + "/map?" + parms;
		return getAPIResponse(query, function(response) {
			return response.data.result;
		});
	}
	function getBreadcrumbs(table, encodedQuery){
		var query = BREADCRUMBS_ENDPOINT + "?table=" + table + "&query=" + encodeURIComponent(encodedQuery);
		return getAPIResponse(query,function(response) {
			return response.data.result.breadcrumb;
		});
	}
	function testFilter(encodedQuery, table){
		if(!isValidTableName(table)) {
			return $q.reject("invalid table name");
		}
var query = RECORD_COUNT_ENDPOINT + table + "/recordcount?sysparm_query=" + encodeURIComponent(encodedQuery);
		return getAPIResponse(query, function(response) {
			return response.data.result.stats.count;
		});
	}
	function getFilters(table){
		if(!isValidTableName(table)) {
			return $q.reject("invalid table name");
		}
		return $http.get(FILTER_ENDPOINT + table)
			.success(function(response){
				return response.result;
			})
			.error(function(reason){
				console.warn(reason);
				return reason;
			})
	}
	function getRelatedLists(table){
		if(!isValidTableName(table)) {
			return $q.reject("invalid table name");
		}
return $http.get(RELATED_LIST_ENDPOINT + table + "/all")
			.then(function(response){
				return response.data.result;
			})
	}
	function saveFilter(table, newFilter){
		if(!isValidTableName(table)) {
			return $q.reject("invalid table name");
		}
		return $http.post(FILTER_ENDPOINT + table, newFilter )
			.success(function(response){
				return response.result;
			})
			.error(function(reason){
				console.warn(reason);
				return reason;
			});
	}
	function deleteFilter(table, sysId){
		if(!isValidTableName(table)) {
			return $q.reject("invalid table name");
		}
		return $http.delete(FILTER_ENDPOINT + table + "?sys_id=" + sysId)
			.then(function(response){
				return response;
			});
	}
});
;
/*! RESOURCE: /scripts/sn/filter_widget/data/factory.snFilterComparisonFactory.js */
angular.module('sn.filter_widget.data').factory('snFilterComparisonFactory', function ($q, $timeout, i18n, snFilterInstanceErrors, snCustomEvent, snDotWalkTableData, snDotWalkUtilities) {
	'use strict';
	var EMPTY_TYPES = ["ISEMPTY", "ISNOTEMPTY", "ANYTHING", "max", "descending", "EMPTYSTRING", "SINCE", "min", "sum", "VALCHANGES"];
	var VARIABLE_TASK = "variable_task";
	var VARIABLE_REQUEST = "variable_request";
	var eventHandler;
	var FilterComparison = function(comparison, table, wantKeywords, extendedOperatorOptions, fieldList, includeVariables) {
		this.debounceDuration = 500;
		this.displayValue = this.display_value;
		angular.extend(this, comparison);
		this.type = "comparison";
		this.wantKeywords = typeof wantKeywords === 'undefined' ? true : wantKeywords;
		this.fieldList = typeof fieldList === 'undefined' ? [] : fieldList;
		if (extendedOperatorOptions)
			this.extendedOperatorOptions = extendedOperatorOptions;
		this.includeVariables =  includeVariables !== undefined ? includeVariables : true;
		if (table){
			this.table = table;
			this.initialize();
		}
	};
	FilterComparison.prototype = {
		initialize : function() {
			this._initializing = true;
			this.baseFields = [];
			this._updateRemoveButtonAriaLabel();
			if (this._isVariable())
				this.fieldsListsPromises = snDotWalkTableData.getVariablesLists(this, this.fieldList, this.table);
			else
				this.fieldsListsPromises = this.fieldsListsPromises ? this.fieldsListsPromises.slice() : snDotWalkTableData.getFieldsLists(this, this.wantKeywords,
					this.extendedOperatorOptions, this.fieldList, this.includeVariables);
			$q.all(this.fieldsListsPromises).then(function(fieldListsPromises) {
				var lastFieldList = fieldListsPromises[fieldListsPromises.length - 1];
				this.topFields = lastFieldList.fields;
				this.baseFields = this.baseFields.length === 0 ? this.topFields : this.baseFields;
				this.topField = lastFieldList.field;
				this._update();
				this._initializing = false;
				if (this.value === '' && this.advancedEditor === 'choice') {
					snCustomEvent.fire('snfilter:conditionChange');
				}
			}.bind(this));
		},
		toQueryString: function(){
			throw new snFilterInstanceErrors.FilterComparisonToStringError();
		},
		comparisonChange : function(field, fields, index){
			index = Number(index);
			this._setColumnType(field.column_type);
			var item = {
				field_label: field.label,
				field: field.name,
				fields: fields
			};
			this.fieldsListsPromises.length = index;
			this.fieldsListsPromises.splice(index, 1, $q.when(item));
			this._syncPromises().then(function(){
				this.topField = field.name;
				this.topFields = fields;
				this.fieldSelectChange();
			}.bind(this));
		},
		updateTable : function(table){
			this.table = table;
			this.initialize();
		},
		addFieldsModel : function(field, index, extendedOperatorOptions){
			var newList;
			index = Number(index);
			var item = this.fieldsListsPromises[index];
			if (item){
				$q.when(item).then(function(item){
					item.field = field.name;
					item.field_label = field.label;
					return item;
				});
			}
			newList = snDotWalkTableData.getDataByField(field, this.table).then(function(response){
				return {
					fields : snDotWalkUtilities.removeUnwantedColumnsFromDotwalkedMetadata(index + 1, response)
				}
			});
			this.fieldsListsPromises.splice(index + 1, 1, newList );
			this.fieldsListsPromises.length = index + 2;
			this._syncPromises();
		},
		fieldSelectChange : function() {
			this._reset();
			this._populateOperators();
			this._selectFirstOperator();
			this._populateEditor();
			this._initFieldType();
			this._checkBetween();
			this._updateRemoveButtonAriaLabel();
			if (eventHandler && !this._initializing) {
				eventHandler('snfilter:conditionChange', this);
			}
		},
		operatorSelectChange: function() {
			this._reset();
			this._populateEditor();
			this._initFieldType();
			this._checkBetween();
			this._updateRemoveButtonAriaLabel();
			if (eventHandler && !this._initializing) {
				eventHandler('snfilter:conditionChange', this);
			}
		},
		onChange: function() {
			this.display_value = this.displayValue;
			if (eventHandler && !this._initializing) {
				eventHandler('snfilter:conditionChange', this);
			}
			this._updateRemoveButtonAriaLabel();
		},
		isEmpty: function(){
			return (!this.value &&  !(EMPTY_TYPES.indexOf(this.operator) > -1));
		},
		hasField: function(){
			return !!this.field;
		},
		getFieldsListByIndex: function(index){
			return this.fieldsListsPromises[index];
		},
		getOperator: function(){
			return this.operator
		},
		getOperatorLabel : function(){
			return this._findOperatorObject().label;
		},
		getFieldLabel : function(){
			return this.field_label;
		},
		getField: function(){
			return this.field;
		},
		getValue: function(){
			return this.value;
		},
		getDisplayValue: function(){
			return this.displayValue || this.display_value || this.value;
		},
		getError : function () {
			return this.error;
		},
		_setColumnType : function(type){
			if (typeof type === "undefined")
				throw "Invalid Column Type";
			this.column_type = type;
		},
		getColumnType : function(){
			return this.column_type;
		},
		_update : function(){
			if (!this.topFields[this.topField]){
				this._noField();
				return;
			}
			this._populateOperators();
			this._populateEditor();
			this._initFieldType();
			this._checkBetween();
		},
		_syncPromises : function(){
			return $q.all(this.fieldsListsPromises).then(function(values){
				if (this._isVariable() && values.length === 3)
					this.field = values[2].field;
				 else
					this.field = values.map(function(item){return item.field;}).join(".");
				this.field_label = values.map(function(item){return item.field_label;}).join(' . ');
				return values;
			}.bind(this))
		},
		_reset: function(){
			this.targetTable = undefined;
			this.reference_display_field = undefined;
			this.referenceKey = undefined;
			this.betweenType = undefined;
			this.value = undefined;
			this.displayValue = "";
			this.display_value = "";
		},
		_populateOperators : function(){
			var currentField = this.topFields[this.topField];
			var hasDynamicChoices = currentField.dynamic_choices && currentField.dynamic_choices.length;
			this.operators = currentField.operators;
			if (!hasDynamicChoices) {
				this.operators = this.operators.filter(function(operator) {
					return operator.operator !== "DYNAMIC";
				});
			}
		},
		_selectFirstOperator : function(){
			this.operator = this.operators[0].operator;
		},
		_populateEditor: function() {
			var operatorObject = this._findOperatorObject();
			if (operatorObject) {
				this.advancedEditor = operatorObject.advancedEditor;
				this.operator = operatorObject.operator;
				this.operator_label = operatorObject.label;
			} else
				this.advancedEditor = "string";
		},
		_initFieldType : function(){
			try {
				switch (this.advancedEditor) {
					case "boolean":
						this._initBoolean();
						break;
					case "reference":
					case "glide_list":
						this._initReferenceField();
						break;
					case "choice":
					case "ChoiceField":
					case "choice_multiple":
					case "choice_dynamic":
					case "days_of_week":
						this._initChoiceField();
						break;
					case "choice_field_names":
						this._initChoiceFieldNames();
						break;
					case "glide_duration":
						this._initDuration();
				}
			} catch(ex){
				console.warn("error setting editor type", ex);
				this.advancedEditor = "string";
			}
		},
		_initBoolean : function(){
			if (typeof this.value === "undefined" || typeof this.value === "null")
				this.value = "true";
		},
		_initReferenceField : function(){
			var _field = this.topFields[this.topField];
			this.targetTable = _field.reference;
			this.reference_display_field = _field.reference_display_field;
			this.referenceKey = _field.reference_attributes ? _field.reference_attributes.reference_key : null;
			if (_field.ed && "qualifier" in _field.ed)
				this.qualifier = _field.ed.qualifier;
		},
		_initChoiceField : function(){
			var _field = this.topFields[this.topField];
			if ("dynamic_choices" in _field && this.operator === "DYNAMIC")
				this.choices = _field.dynamic_choices;
			else if (this.advancedEditor === "choice_multiple")
				this.choices = _field.choices.filter(function (choice) {
					return choice.value !== '';
				});
			else
				this.choices = _field.choices;
			if (!this.value && this.choices[0])
				this.value = this.choices[0].value;
		},
		_initChoiceFieldNames : function(){
			var self = this;
			var _field = this.topFields[this.topField];
			var fields = snDotWalkUtilities.makeFieldsArray(this.topFields);
			this.choices = fields
				.filter(function(item) {
					var valid = _field.type === self.topFields[item.field].type;
					if (_field.type === "reference")
						valid = valid && _field.reference === self.topFields[item.field].reference;
					return valid;
				})
				.map(function(item){
					var topLevel;
					var splitLevels = self.field.split('.')
					if (splitLevels.length > 1) {
						splitLevels.pop();
						topLevel = splitLevels.join('.')
					}
					return {
						label: item.field_label,
						value: topLevel ? topLevel + '.' + item.field : item.field,
					}
				});
			if (this.choices.length === 0)
				this.choices.push({ label : i18n.getMessage("-- None --"), value : undefined });
			if (!this.value && this.choices[0])
				this.value = this.choices[0].value;
			this._valueNotInFieldNames();
		},
		_valueNotInFieldNames: function() {
			var values = this.choices.map(function(choice) {
				return choice.value;
			});
			if (values.indexOf(this.value) === -1) {
				this.choices.push({
					label : this.display_value,
					value: this.value
				});
			}
		},
		_initDuration: function() {
			this.maxUnit = this.topFields[this.topField].max_unit;
		},
		_checkBetween : function(){
			if (this._findOperatorObject() && 'betweenType' in this._findOperatorObject())
				this.betweenType = this._findOperatorObject().betweenType;
		},
		_findOperatorObject: function(){
			if (!this.operators)
				return {};
			for (var i = 0; i < this.operators.length; i++) {
				if (this.operators[i].operator == this.operator) {
					return this.operators[i];
				}
			}
			return "";
		},
		_isVariable : function(){
			return this.column_type === VARIABLE_REQUEST || this.column_type === VARIABLE_TASK || this.column_type === 'questions';
		},
		_noField : function(){
			this._reset();
			this.field = "";
			this.operator = "";
			this.operator_label = "";
			this.field_label = i18n.getMessage("-- Choose Field --");
			this.column_type = "element";
		},
		_updateRemoveButtonAriaLabel: function() {
			var displayValue = this.getDisplayValue() || '';
			var hasFieldAriaLabel = i18n.getMessage("Remove condition: {0} {1} {2}").withValues([this.getFieldLabel(), this.getOperatorLabel(), displayValue]);
			var emptyConditionAriaLabel = i18n.getMessage('Remove empty condition');
			var newAriaLabel = this.hasField() ? hasFieldAriaLabel : emptyConditionAriaLabel;
			this.removeButtonAriaLabel = newAriaLabel;
		}
	};
	return {
		create: create,
		setEventHandler: setEventHandler
	};
	function create(comparison, table, wantKeywords, extendedOperatorOptions, fieldList, includeVariables) {
		return new FilterComparison(comparison, table, wantKeywords, extendedOperatorOptions, fieldList, includeVariables);
	}
	function setEventHandler(handler) {
		eventHandler = handler;
	}
});
;
/*! RESOURCE: /scripts/sn/filter_widget/data/factory.snFilterPredicateWrapper.js */
angular.module('sn.filter_widget.data').factory('snFilterPredicateWrapper', function ($timeout, i18n, snFilterComparisonFactory, GlideQuery, snFilterUtilities, snCustomEvent, KEYWORD_FIELD) {
	'use strict';
	var AND = "and";
	var OR = "or";
	function create (table) {
		return new SnFilterPredicateWrapper(table);
	}
	function SnFilterPredicateWrapper(table) {
		this.table = snFilterUtilities.normalizeTable(table);
	}
	SnFilterPredicateWrapper.prototype = {
		updateTable: function(predicate, table) {
			this.table = table;
			this.reset(predicate, true);
			this.addCompound(predicate);
		},
		reset: function(predicate, dontUpdate) {
			var compound;
			for (var iPSP = predicate.subpredicates.length -1; iPSP >= 0; iPSP--) {
				compound = predicate.subpredicates[iPSP];
				this._removeCompound(predicate, compound, dontUpdate)
			}
		},
		setFilterConfig: function (filterConfig) {
			this.filterConfig = filterConfig;
		},
		addCompound: function (predicate) {
			var compound = predicate.addAnd();
			var compoundIndex = predicate.subpredicates.indexOf(compound);
			var subCompound = compound.addAnd();
			this._addComparison(predicate, subCompound, this._getEmptyComparison());
		},
		toQueryString: function(predicate) {
			var compound = new GlideQuery._Compound(predicate);
			return compound.toQueryString({isPredicate : true });
		},
		_removeCompound: function (predicate, queryCompound, noEmptyCheck) {
			predicate.removeSubpredicate(queryCompound);
			if (predicate.isEmpty() && !noEmptyCheck)
				this.addCompound(predicate);
		},
		_addSubcompound: function(predicate, compoundIndex, type, dontAddComparison) {
			var compound = predicate.subpredicates[compoundIndex];
			var subCompound;
			if (type) {
				subCompound = (type == 'and') ? compound.addAnd() : compound.addOr();
			} else {
				subCompound = (compound.isEmpty()) ? compound.addAnd() : compound.addOr();
			}
			if (!dontAddComparison)
				this._addComparison(predicate, subCompound, this._getEmptyComparison());
			return subCompound;
		},
		_removeSubcompound: function (predicate, compoundIndex, subCompoundIndex, noEmptyCheck) {
			var compound = predicate.subpredicates[compoundIndex];
			var subCompound = compound.subpredicates[subCompoundIndex];
			compound.removeSubpredicate(subCompound);
			if (!noEmptyCheck) {}
				this._checkEmptyCompound(predicate, compoundIndex, subCompoundIndex);
		},
		addComparisonRow: function(predicate, compoundIndex, subCompoundIndex, comparisonIndex, type) {
			var compound = predicate.subpredicates[compoundIndex];
			var subCompound = compound.subpredicates[subCompoundIndex];
			var comparison = subCompound.subpredicates[comparisonIndex];
			var emptyComparison = this._getEmptyComparison();
			this._checkGroupingLogic(predicate);
			if (subCompound.compound_type === AND && type === OR)
				this._splitCompound(predicate, compound, subCompound, compoundIndex, subCompoundIndex, comparisonIndex, type);
			else if (subCompound.compound_type === OR && type === AND) {
				var nextSubCompound = compound.subpredicates[subCompoundIndex + 1];
				var lastSubCompound = compound.subpredicates[compound.subpredicates.length - 1];
				if (nextSubCompound && nextSubCompound.compound_type === AND) {
					this._addComparison(predicate, nextSubCompound, emptyComparison);
				} else if (lastSubCompound && lastSubCompound.compound_type === AND) {
					this._addComparison(predicate, lastSubCompound, emptyComparison);
				} else {
					this._addSubcompound(predicate, compoundIndex, type)
				}
			} else if ( subCompound.compound_type === OR && type === OR ) {
				this._addComparison(predicate, subCompound, angular.extend({}, comparison, {value : undefined, display_value : undefined}));
			} else {
				this._addComparison(predicate, subCompound, emptyComparison);
			}
			$timeout(function() {
				snCustomEvent.fire('snfilter:conditionChange');
			});
		},
		removeComparisonRow: function (predicate, compoundIndex, subCompoundIndex, comparisonIndex, noEmptyCheck) {
			var compound = predicate.subpredicates[compoundIndex];
			var subCompound = compound.subpredicates[subCompoundIndex];
			var comparison = subCompound.subpredicates[comparisonIndex];
			subCompound.removeSubpredicate(comparison);
			if (subCompound.isEmpty() && !noEmptyCheck) {
				this._removeSubcompound(predicate, compoundIndex, subCompoundIndex);
			}
			this._checkGroupingLogic(predicate);
			snCustomEvent.fire('snfilter:conditionChange');
		},
		getTable: function() {
			return this.table;
		},
		_checkEmptyCompound: function (predicate, compoundIndex) {
			var compound = predicate.subpredicates[compoundIndex];
			if (!compound)
				throw "Invalid Compound index";
			if (compound.isEmpty())
				this._removeCompound(predicate, compound);
			if (predicate.subpredicates.length === 0)
				this.addCompound(predicate);
		},
		 _checkGroupingLogic: function(predicate) {
			var splicedComparison;
			for (var i = 0; i < predicate.subpredicates.length; i++) {
				var compound = predicate.subpredicates[i];
				for (var j = 0; j < compound.subpredicates.length; j++) {
					var subCompound = compound.subpredicates[j];
					if (subCompound.compound_type === OR &&
						subCompound.subpredicates.length === 1 &&
						compound.subpredicates[ j + 1] &&
						compound.subpredicates[ j + 1].compound_type === AND &&
						compound.subpredicates[ j - 1] &&
						compound.subpredicates[ j - 1].compound_type === AND ) {
						splicedComparison = subCompound.subpredicates.splice(0,1);
						for (var k = 0; k < compound.subpredicates[ j + 1].subpredicates.length; k++) {
							var comparisonToRemove = compound.subpredicates[ j + 1].subpredicates[k];
							splicedComparison.push(comparisonToRemove);
						}
						for (var l = 0; l < splicedComparison.length; l++) {
							this._addComparison(predicate, compound.subpredicates[ j - 1], splicedComparison[l]);
						}
						this._removeSubcompound(predicate, i, j + 1);
						this._removeSubcompound(predicate, i, j);
					}
					if (subCompound.compound_type === OR &&
						subCompound.subpredicates.length === 1 &&
						j > 0 &&
						compound.subpredicates[ j - 1] &&
						compound.subpredicates[ j - 1].compound_type === AND ) {
						splicedComparison = subCompound.subpredicates.splice(0, 1)[0];
						this._addComparison(predicate, compound.subpredicates[ j - 1], splicedComparison);
						this._removeSubcompound(predicate, i, j);
					}
					if (subCompound.compound_type === OR &&
						subCompound.subpredicates.length === 1 &&
						j < compound.subpredicates.length &&
						compound.subpredicates[ j + 1] &&
						compound.subpredicates[ j + 1].compound_type === AND ) {
						splicedComparison = subCompound.subpredicates.splice(0,1)[0];
						this._addComparison(predicate, compound.subpredicates[ j + 1], splicedComparison);
						this._removeSubcompound(predicate, i, j);
					}
					if (subCompound.compound_type === OR &&
						subCompound.subpredicates.length === 1) {
						subCompound.setCompoundType(AND);
					}
				}
			}
		},
		_addComparison: function(predicate, queryCompound, queryComparison, insertAtIndex) {
			var wantKeywords = typeof predicate.is_related === 'undefined' ? true : !predicate.is_related;
			var extendedOps = this.filterConfig ? this.filterConfig.extendedOperatorOptions : null;
			var fieldList = this.filterConfig ? this.filterConfig.fieldList : [];
			var filterComparison = snFilterComparisonFactory.create(queryComparison, this.table, wantKeywords, extendedOps, fieldList);
			var index = typeof insertAtIndex === 'undefined' ? queryCompound.subpredicates.length : insertAtIndex;
			var comparison = queryCompound.subpredicates.splice(index, 0, filterComparison);
			return comparison;
		},
		 _splitCompound: function(predicate, queryCompound, subCompound, compoundIndex, subCompoundIndex, comparisonIndex, type) {
			var subpredicates = subCompound.subpredicates.slice();
			var previousComparisons = subpredicates.slice(0, comparisonIndex);
			var selectedComparison = subpredicates.slice().splice(comparisonIndex, 1)[0];
			var nextComparisons = subpredicates.slice().splice(comparisonIndex + 1);
			var newSubCompoundIndex = (!previousComparisons.length) ? subCompoundIndex : subCompoundIndex + 1;
			var newSubCompound = (type === AND) ? queryCompound.addAnd(newSubCompoundIndex) : queryCompound.addOr(newSubCompoundIndex);
			newSubCompound.subpredicates.push(selectedComparison);
			this._addComparison(predicate, newSubCompound, angular.extend({},selectedComparison, {value : undefined, display_value : undefined}));
			subCompound.subpredicates = previousComparisons;
			if (nextComparisons.length) {
				var secondNewSubCompound = (subCompound.compound_type === 'and') ? queryCompound.addAnd(newSubCompoundIndex + 1) : queryCompound.addOr(newSubCompoundIndex + 1);
				angular.forEach(nextComparisons, function(comparison) {
					this._addComparison(predicate, secondNewSubCompound, comparison);
				}.bind(this))
			}
			if (subCompound.isEmpty())
				queryCompound.removeSubpredicate(subCompound);
		},
		_getEmptyComparison: function () {
			return {
				value : undefined,
				field : "",
				term : "",
				operator : "",
				field_label : i18n.getMessage("-- Choose Field --"),
				term_label : "",
				operator_label : "",
				column_type : "element"
			};
		}
	};
	return {
		create: create
	};
});
;
/*! RESOURCE: /scripts/sn/filter_widget/data/factory.snFilterDate.js */
angular.module('sn.filter_widget.data').factory('filterDateService', function (snFilterGlobals) {
	return {
		processData: processData,
		processBetweenData: processBetweenData,
		dateValueLookup: dateValueLookup,
		dateLabelLookup: dateLabelLookup,
		formatDate: formatDate
	};
	function processData(filterComparison){
		return dateValueLookup(filterComparison.operator, filterComparison.value)
	}
	function processBetweenData(filterComparison){
		if (filterComparison.betweenType !== 'glide_date_choice')
			return filterComparison.value;
		var tempValue = filterComparison.value.split("@");
		if (tempValue.length < 2)
			return;
		return dateValueLookup("BETWEEN_A", tempValue[0]) + "@" + dateValueLookup("BETWEEN_B", tempValue[1]);
	}
	function dateValueLookup(operator, value, tableName){
		if (operator.toUpperCase && value.toLowerCase){
			var keys = snFilterGlobals.getOperatorKeys(operator.toUpperCase());
			var lookupValue = snFilterGlobals.getCalendarValues("timeAgoDates", tableName)[value.toLowerCase()];
			return _reduceArray(keys, lookupValue, true);
		}
		return false;
	}
	function dateLabelLookup(field, value, tableName) {
value = (value || "").replace(/ /g,'');
		var result = null;
		var operatorKeys = snFilterGlobals.getOperatorKeys(field.operator);
		var dateValues = snFilterGlobals.getCalendarValues("timeAgoDates", tableName);
		var string;
		for (var date in dateValues) {
			string = _reduceArray(operatorKeys, dateValues[date]);
			if ((string || "").toLowerCase() === (value || "").toLowerCase()) {
				result = date;
				break;
			}
		}
		return result;
	}
	function formatDate (date, format) {
		if (!(date instanceof Date))
			date = new Date(date);
		var z = {
			M: date.getMonth() + 1,
			d: date.getUTCDate(),
			h: date.getHours(),
			m: date.getMinutes(),
			s: date.getSeconds()
		};
format = format.replace(/(M+|d+|h+|m+|s+)/g, function(v) {
			return ((v.length > 1 ? "0" : "") + eval('z.' + v.slice(-1))).slice(-2)
		});
return format.replace(/(y+)/g, function(v) {
			return date.getFullYear().toString().slice(-v.length)
		});
	}
	function _reduceArray(iterable, reference, isTimeAgo) {
		return iterable.reduce(function(value, key, index){
			var iterativeValue;
			if (reference[key]){
iterativeValue = isTimeAgo ? reference[key] : reference[key].replace(/ /g,'');
				value += iterativeValue;
				value += (index + 1 !== iterable.length) ? "@" : "";
			}
			return value;
		}, "");
	}
});
;
/*! RESOURCE: /scripts/sn/filter_widget/data/factory.snFilterGlobals.js */
angular.module('sn.filter_widget.data').factory('snFilterGlobals', function (DateTimeAPI, $q) {
    var dates = {};
	var operatorKeys = {
		"ON":["label", "before", "after"],
		"NOTON":["label", "before", "after"],
		"<":["before"],
		"<=":["between"],
		">":["between"],
		">=":["before"],
		"BETWEEN": ["before", "between"],
		"BETWEEN_A": ["before"],
		"BETWEEN_B":["between"],
		"IS":["is"],
		"ISNOT":["isnot"],
		"=":["is"],
		"!=":["isnot"]
	};
	var calendarDates = {};
	var snFilterGlobalsInitialization = DateTimeAPI.getDateTime().then(function(response) {
		dates = response.data.result;
	});
	var snFilterCalendarsInitialization = function(tableName){
		if (calendarDates[tableName]) {
			return $q.when();
		}
		else {
			return DateTimeAPI.getDateTime(tableName).then(function (response) {
				calendarDates[tableName] = response.data.result;
			});
		}
	};
	return {
		getOperatorKeys: function(key) {return operatorKeys[key];},
		getValues: function(prop) {return dates[prop];},
		snFilterGlobalsInitialization: snFilterGlobalsInitialization,
		snFilterInitialize: snFilterCalendarsInitialization,
		getCalendarValues: function(prop, tableName) { return calendarDates[tableName][prop]}
	}
});
;
/*! RESOURCE: /scripts/sn/filter_widget/data/factory.snFilterInstanceErrors.js */
angular.module('sn.filter_widget.data').factory('snFilterInstanceErrors', function () {
	'use strict';
	return {
		DuplicateFilterInstance: DuplicateFilterInstance,
		FilterInstanceUndefined: FilterInstanceUndefined,
		SortFilterMetadataError : SortFilterMetadataError,
		FilterComparisonInitializationError: FilterComparisonInitializationError,
		FilterComparisonToStringError: FilterComparisonToStringError,
		RelatedListModelError: RelatedListModelError
	};
	function DuplicateFilterInstance(){
		this.message = "Duplicate Filter Instances initialized";
	}
	function FilterInstanceUndefined(tableName){
		this.message = "Filter Instance undefined for " + tableName;
	}
	function SortFilterMetadataError(tableName){
		this.message = "Error retrieving sort metadata for " + tableName;
	}
	function FilterComparisonToStringError(){
		this.message = "Cant call to string on borked glide queries like this!"
	}
	function FilterComparisonInitializationError(ex){
		this.message = "Error initializing FilterComparisons from Query Parse Service response : " + ex;
	}
	function RelatedListModelError(ex){
		this.message = "Error setting related list table : " + ex;
	}
});
;
/*! RESOURCE: /scripts/sn/filter_widget/data/factory.snFilterInstanceModel.js */
angular.module('sn.filter_widget.data').factory('snFilterInstanceModel', function ($http, $q, i18n, snFilterComparisonFactory, GlideQuery, snFilterInstanceErrors, snFilterUtilities, filterAPI, snCustomEvent, KEYWORD_FIELD) {
	'use strict';
	return {
		create: create
	};
	function create(tableName, relatedEnabled, extendedOperatorOptions, fieldList, includeVariables, tinyURL) {
		var _glideQuery;
		var table = tableName;
		var tableLabel;
		var addRelated = relatedEnabled;
		var filterFieldList = fieldList;
		var tinyUrlQuery = tinyURL;
		var includeVariables = includeVariables;
		snFilterComparisonFactory.setEventHandler(snCustomEvent.fire);
		return {
			initialize: initialize,
			updateTable : updateTable,
			buildQueryString: buildQueryString,
			buildQueryObject: buildQueryObject,
			getSort: getSort,
			setSort: setSort,
			testResult: testResult,
			getTableLabel: getTableLabel
		};
		function initialize(query, table, extendedOperatorOptions) {
			var currentEncodedQuery,
				newEncodedQuery;
			if (_glideQuery)
				currentEncodedQuery = buildQueryString();
			return _getQueryMap(query, table, tinyUrlQuery).then(function(newGlideQuery){
				newEncodedQuery = newGlideQuery.toQueryString();
				if (currentEncodedQuery === newEncodedQuery && !_glideQuery.isEmpty())
					return $q.when(_glideQuery);
				_checkEmptyGlideQuery(newGlideQuery);
				_initializeFilterComparisons(newGlideQuery, extendedOperatorOptions);
				_addRelatedPredicate(newGlideQuery);
				_glideQuery = newGlideQuery;
				return $q.when(_glideQuery);
			});
		}
		function getSort(){
			return _glideQuery.order_by;
		}
		function setSort(sort){
			_glideQuery.order_by = sort;
		}
		function updateTable(tableName){
			table = tableName;
		}
		function isValidTableName(tableName) {
return !/[.%]/.test(tableName);
		}
		function getTableLabel() {
			if (tableLabel)
				return $q.resolve(tableLabel);
			if (!table || !isValidTableName(table))
				return $q.resolve("");
var url = "/api/now/ui/meta/" + table + "/table_label";
			return $http.get(url, {cache: true}).then(function(response) {
				tableLabel = response.data.result;
				return tableLabel;
			});
		}
		function _checkEmptyGlideQuery(glideQuery){
			var subcompound;
			for(var iGQ = 0; iGQ < glideQuery.predicates.length; iGQ++){
				try {
					subcompound = glideQuery.predicates[iGQ].subpredicates[0].subpredicates[0];
					if (!subcompound.subpredicates.length)
						subcompound.addComparison(_getEmptyComparison());
				} catch (ex){
					console.warn(ex);
				}
			}
		}
		function _addRelatedPredicate(glideQuery){
			if (glideQuery.predicates.length === 1 && addRelated){
				var rlCompound = glideQuery.addPredicateCompound(true);
				rlCompound.addRelatedComparison(_getEmptyComparison(true));
				var rlSubcompound = rlCompound.addAnd();
				var rlSubSubcompound = rlSubcompound.addAnd();
				var rlComparison = rlSubSubcompound.addComparison(_getEmptyComparison());
			}
		}
		function _getQueryMap(query, table, tinyUrlQuery){
			var glideQuery;
			if (query instanceof GlideQuery){
				glideQuery = $q.when(new GlideQuery(angular.merge({}, query)));
			} else if (!(query instanceof GlideQuery) && query.predicate) {
				glideQuery = $q.when(new GlideQuery(query));
			} else {
				glideQuery = filterAPI.parseQuery(query, table, tinyUrlQuery).then(function(parts){
					return new GlideQuery(parts);
				});
			}
			return glideQuery;
		}
		function buildQueryString(){
			return new GlideQuery(_glideQuery.toQueryObject()).toQueryString();
		}
		function buildQueryObject(){
			var intermediaryQuery = new GlideQuery(_glideQuery.toQueryObject());
			return snFilterUtilities.filterEmptyComparisonsFromGlideQuery(intermediaryQuery);
		}
		function _initializeFilterComparisons(gq, extendedOperatorOptions) {
			try {
				var predicate;
				var normalizedTable;
				for (var iP = 0; iP < gq.predicates.length; iP++){
					predicate = gq.predicates[iP];
					if (predicate.is_related && predicate.comparison && predicate.comparison.table)
						normalizedTable = predicate.comparison.table.split(".")[0];
					else
						normalizedTable = tableName;
					(predicate.subpredicates || []).forEach(function(compound) {
						(compound.subpredicates || []).forEach(function(subCompound) {
							subCompound.subpredicates = (subCompound.subpredicates || []).map(function(comparison) {
								return snFilterComparisonFactory.create(comparison, normalizedTable, true, extendedOperatorOptions, filterFieldList, includeVariables);
							});
						})
					});
					if (addRelated === false)
						break;
				}
			} catch (ex){
				throw new snFilterInstanceErrors.FilterComparisonInitializationError(ex);
			}
		}
		function testResult(){
			var encodedQuery = buildQueryString();
			return filterAPI.testFilter(encodedQuery, table);
		}
		function _getEmptyComparison(isRelated){
			var comparison;
			var emptyComparison = {
				value : undefined,
				field : "",
				term : "",
				operator : "",
				field_label : i18n.getMessage("-- Choose Field --"),
				term_label : "",
				operator_label : "",
				column_type : "element"
			};
			var relatedComparison = {
				table : undefined,
				options : undefined,
				quantity: {}
			};
			return isRelated ? relatedComparison : emptyComparison;
		}
	}
});
;
/*! RESOURCE: /scripts/sn/filter_widget/data/factory.snFilterInstanceStore.js */
angular.module('sn.filter_widget.data').factory('snFilterInstanceStore', function ($window, snFilterInstanceModel, snFilterUtilities) {
	"use strict";
	var filters = {};
	return {
		create: create,
		get: get,
		remove :remove
	};
	function create(tableName, relatedListQueryConditions, extendedOperatorOptions, fieldList, includeVariables, tinyURL) {
		var uuid = snFilterUtilities.generateKey();
		filters[uuid] = snFilterInstanceModel.create(tableName, relatedListQueryConditions, extendedOperatorOptions, fieldList, includeVariables, tinyURL);
		return uuid;
	}
	function get(tableName){
		if (!filters[tableName])
			return false;
		return filters[tableName];
	}
	function remove(tableName){
		delete filters[tableName];
	}
});
;
/*! RESOURCE: /scripts/sn/filter_widget/data/factory.snFilterSubjectCriteriaStore.js */
angular.module('sn.filter_widget.data').factory('snFilterSubjectCriteriaStore', function () {
    "use strict";
    var filters = {};
    return {
        create: create,
        isSubjectCriteria: isSubjectCriteria,
        getAttributeURL: getAttributeURL
    };
    function create(isSCriteria, tableName) {
filters[tableName] = {isSC: isSCriteria, scEndpoint: "/api/now/scriteria/attributes"};
    }
    function isSubjectCriteria(tableName){
        return filters[tableName] && filters[tableName].isSC;
    }
    function getAttributeURL(tableName){
        return (typeof filters[tableName] !== "undefined") ? filters[tableName].scEndpoint : "";
    }
});
;
/*! RESOURCE: /scripts/sn/filter_widget/data/factory.snFilterSecurityAttributesStore.js */
angular.module('sn.filter_widget.data').factory('snFilterSecurityAttributesStore', function () {
    "use strict";
    var filters = {};
    return {
        create: create,
        isSecurityAttributes: isSecurityAttributes,
        getAttributeURL: getAttributeURL
    };
function create(isSecAttributes, tableName) {
filters[tableName] = {isSA: isSecAttributes, saEndpoint: "/api/now/secattributes/attributes"};
    }
    function isSecurityAttributes(tableName){
        return filters[tableName] && filters[tableName].isSA;
    }
    function getAttributeURL(tableName){
        return (typeof filters[tableName] !== "undefined") ? filters[tableName].saEndpoint : "";
    }
});
;
/*! RESOURCE: /scripts/sn/filter_widget/data/factory.snFilterUtilities.js */
angular.module('sn.filter_widget.data').factory('snFilterUtilities', function (KEYWORD_FIELD) {
	return {
		getComparisons: getComparisons,
		getComparisonKey : getComparisonKey,
		generateKey: generateKey,
		getComparisonIndex: getComparisonIndex,
		filterEmptyComparisonsFromGlideQuery: filterEmptyComparisonsFromGlideQuery,
		getComparisonIndexesObject: getComparisonIndexesObject,
		getRulesets: getRulesets,
		getRulesetIndex: getRulesetIndex,
		getRulesetsBySet : getRulesetsBySet,
		compareTwoObjects: compareTwoObjects,
		convertArrayToObject: convertArrayToObject,
		convertObjectToArray : convertObjectToArray,
		normalizeTable : normalizeTable,
		convertBreadcrumbsToString : convertBreadcrumbsToString,
		canShowKeywordsField : canShowKeywordsField,
		hasExistingKeywordsField : hasExistingKeywordsField
	};
	function getComparisons (gq) {
		var allComparisons = [];
		(gq.predicate.subpredicates || []).map(function(iterativeSet){
			(iterativeSet.subpredicates || []).map(function(ruleSet){
				(ruleSet.subpredicates || []).map(function(comparison){
					allComparisons.push(comparison)
				});
			})
		});
		return allComparisons;
	}
	function filterEmptyComparisonsFromGlideQuery(gq){
		(gq.predicates || []).forEach(function(predicate){
			(predicate.subpredicates || []).forEach(function(compound){
				(compound.subpredicates || []).forEach(function(subCompound){
					subCompound.subpredicates = (subCompound.subpredicates || []).filter(function(comparison){
						return !!comparison.toQueryString();
					});
				})
			});
		});
		return gq;
	}
	function getComparisonIndex(gq, comparison){
		var iterativeSet;
		var iterativeRuleSet;
		var comparisonIndex;
		for (var i = 0; i < gq.predicate.subpredicates.length; i++){
			iterativeSet = gq.predicate.subpredicates[i];
			for (var j = 0; j < iterativeSet.subpredicates.length; j++){
				iterativeRuleSet = iterativeSet.subpredicates[j];
				comparisonIndex = iterativeRuleSet.subpredicates.indexOf(comparison);
				if (comparisonIndex > -1)
					return comparisonIndex;
			}
		}
	}
	function getComparisonIndexesObject(gq, comparison){
		var iterativeSet;
		var iterativeRuleSet;
		var comparisonIndex;
		for (var i = 0; i < gq.predicate.subpredicates.length; i++){
			iterativeSet = gq.predicate.subpredicates[i];
			for (var j = 0; j < iterativeSet.subpredicates.length; j++){
				iterativeRuleSet = iterativeSet.subpredicates[j];
				comparisonIndex = iterativeRuleSet.subpredicates.indexOf(comparison);
				if (comparisonIndex > -1)
					return {compoundIndex : i, subCompoundIndex : j, comparisonIndex : comparisonIndex};
			}
		}
	}
	function getRulesets (gq) {
		var allRuleSets = [];
		(gq.predicate.subpredicates || []).map(function(iterativeSet){
			(iterativeSet.subpredicates || []).map(function(ruleSet){
				allRuleSets.push(ruleSet)
			})
		});
		return allRuleSets;
	}
	function getRulesetsBySet (gq){
		return (gq.predicate.subpredicates || []).map(function(iterativeSet){
			return (iterativeSet.subpredicates || []).map(function(ruleSet){
				return ruleSet;
			})
		});
	}
	function getRulesetIndex(gq, ruleSet){
		var iterativeSet;
		for (var i = 0; i < gq.predicate.subpredicates.length; i++) {
			iterativeSet = gq.predicate.subpredicates[i];
			return iterativeSet.subpredicates.indexOf(ruleSet);
		}
	}
	function generateKey(){
		return Math.random().toString(36).slice(2);
	}
	function getComparisonKey(gq, setIndex, ruleSetIndex, comparisonIndex){
		try {
			return gq.predicate.subpredicates[setIndex].subpredicates[ruleSetIndex].subpredicates[comparisonIndex].comparisonKey;
		} catch (ex){
			console.warn(ex);
		}
	}
	function compareTwoObjects(x, y, properties) {
		if (!properties instanceof Array)
			properties = [properties];
		return properties.every(function(property){
			return x[property] !== y[property]
		});
	}
	function convertArrayToObject(array, key){
		if (!(array instanceof Array) || !key)
			throw "Incorrect Arguments passed to convertArrayToObject";
		var targetObject = {};
		array.forEach(function(item){
			var targetObjectKey = item[key];
			targetObject[targetObjectKey] = item;
		});
		return targetObject;
	}
	function convertObjectToArray(obj, objKey){
		return Object.keys(obj).map(function(key){
			return typeof objKey !== "undefined" ? obj[key][objKey] : obj[key];
		});
	}
	function normalizeTable(table){
		var normalizedTable = table;
		if (table && table.indexOf(".") > -1)
			normalizedTable = table.split(".")[0];
		return normalizedTable;
	}
	function convertBreadcrumbsToString(breadcrumbs){
		if (!breadcrumbs || !(breadcrumbs instanceof Array)	)
			return "";
		breadcrumbs.shift();
		return breadcrumbs
			.map(function(item){
				return item.label
			})
			.join(" > ");
	}
	function hasExistingKeywordsField(predicate) {
		if (!predicate) {
			return false;
		}
		return predicate.subpredicates.some(function(compound) {
			return compound.subpredicates.some(function(subCompound) {
				return subCompound.subpredicates.some(function(comparison) {
					return comparison.field === KEYWORD_FIELD;
				});
			});
		});
	}
	function canShowKeywordsField(predicate, currentComparison) {
		if (!predicate)
			return true;
		if (currentComparison && currentComparison.field === KEYWORD_FIELD)
			return true;
		if (predicate.is_related !== 'undefined' && predicate.is_related)
			return false;
		var existingKeywords = hasExistingKeywordsField(predicate);
		var isOrCondition = predicate.subpredicates.some(function(compound) {
			return compound.subpredicates.some(function(subCompound) {
				return subCompound.subpredicates.indexOf(currentComparison) !== -1 && subCompound.compound_type === 'or';
			});
		});
		var isNewQueryCompound = predicate.compound_type === 'or' && predicate.subpredicates.length > 1;
		return !existingKeywords && !isOrCondition && !isNewQueryCompound;
	}
});
;
;
/*! RESOURCE: /scripts/sn/filter_widget/data/js_includes_data.js */
/*! RESOURCE: /scripts/sn/filter_widget/dot_walk/_module.js */
angular.module('sn.filter_widget.dot_walk', [
	'sn.filter_widget.data'
]);
;
/*! RESOURCE: /scripts/sn/filter_widget/dot_walk/directive.snFilterDotWalkKeydownListener.js */
angular.module('sn.filter_widget.dot_walk').directive('snFilterDotWalkKeydownListener', function() {
	return {
		restrict : "A",
		link : function(scope, element){
			scope.$on("$destroy", function(){
				element.off("keydown");
			});
			element.on("keydown", function(e){
				var _keyCode = e.which || e.keyCode;
				var _$focusedElement = angular.element(e.target);
				if (_$focusedElement.length){
					switch (_keyCode){
						case 13:
							_enterKeydownHandler(_$focusedElement);
							break;
						case 37:
							_leftKeydownHandler(_$focusedElement);
							break;
						case 38:
							e.preventDefault();
							_upKeydownHandler(_$focusedElement);
							break;
						case 39:
							e.preventDefault();
							_rightKeydownHandler(_$focusedElement);
							break;
						case 40:
							e.preventDefault();
							_downKeydownHandler(_$focusedElement);
							break;
						case 27:
							e.preventDefault();
							_escapeKeydownHandler();
							break;
						case 9:
							e.preventDefault();
							_tabKeydownHandler();
							break;
						default :
					}
				} else {
					if (_keyCode === 40){
						e.preventDefault();
						element.find("ul").last().children("li:not(.sr-only)").first().children("a").focus();
					}
				}
			});
			function _enterKeydownHandler(_$focusedElement){
				_$focusedElement.trigger("click");
			}
			function _rightKeydownHandler(_$focusedElement){
				var _$ulIndex = _$focusedElement.closest("ul").index();
				var _loadedTable = angular.element('.filter-breadcrumbs a').eq(_$ulIndex).text().indexOf(_$focusedElement.text()) !== -1;
				var _$nextDotWalkList = _$focusedElement.closest("ul").next();
				if (_$focusedElement.siblings(".add-dot-walk-list").length &&  !_loadedTable)
					_$focusedElement.siblings(".add-dot-walk-list").trigger("click");
				else if (_$nextDotWalkList.length) {
					if (_$nextDotWalkList.children("li.selected").length)
						_$nextDotWalkList.children("li.selected").children("a").focus();
					else
						_$nextDotWalkList.children("li:not(.sr-only)").first().children("a").focus();
				}
			}
			function _leftKeydownHandler(_$focusedElement){
				var _$previousDotWalkList = _$focusedElement.closest("ul").prev();
				if (_$previousDotWalkList.length)
					if (_$previousDotWalkList.children("li.selected").length)
						_$previousDotWalkList.children("li.selected").children("a").focus();
					else
						_$previousDotWalkList.children("li:not(.sr-only)").first().children("a").focus();
			}
			function _upKeydownHandler(_$focused){
				var _$previous = _$focused.parent().prev().children("a");
				if (_$previous.length)
					_$previous.focus();
				else
					angular.element("#filter-fields-search").focus();
			}
			function _downKeydownHandler(_$focused){
				if (_$focused.is('input')) {
					var $listContainer = angular.element('#' + _$focused.attr('aria-owns'));
					$listContainer.find('a').first().focus();
					return;
				}
				var _$next = _$focused.parent().next().children("a");
				if (_$next.length)
					_$next.focus();
			}
			function _tabKeydownHandler() {
scope.$emit(scope.closeEvent,  true);
			}
			function _escapeKeydownHandler() {
				scope.$broadcast(scope.closeEvent);
			}
		}
	}
});
;
/*! RESOURCE: /scripts/sn/filter_widget/dot_walk/directive.snFilterDotWalkPositioner.js */
angular.module('sn.filter_widget.dot_walk').directive('snFilterDotWalkPositioner', function(snCustomEvent) {
	return {
		restrict : 'A',
		link : function(scope){
			snCustomEvent.observe('show.complexpopover.' + scope.ref, showPopover);
			function showPopover($toggleButton) {
				var btn = $toggleButton;
				if (!$toggleButton.hasClass('sn-popover-complex'))
					btn = $toggleButton.closest('.sn-popover-complex');
				if (!btn)
					return;
				var offset = btn.offset();
				offset.top = offset.top + btn.outerHeight() + 5;
				if ($toggleButton.data('bs.popover')) {
					$toggleButton.data('bs.popover').$tip.offset(offset);
				}
			}
			scope.$on('$destroy', function() {
				snCustomEvent.un('show.complexpopover.' + scope.ref, showPopover);
			});
		}
	}
});
;
/*! RESOURCE: /scripts/sn/filter_widget/dot_walk/directive.snFilterFieldList.js */
angular.module('sn.filter_widget.dot_walk').directive('snFilterFieldList', function($q, $timeout, $parse, getTemplateUrl, snDotWalkUtilities, snCustomEvent, snFilterUtilities, KEYWORD_FIELD) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl("sn_filter_field_list.xml"),
		controller: function($scope, $element, $attrs) {
			var glowTimeout;
			var fieldsModel;
			var _fieldsArray;
			var fieldsListIndex = $parse($attrs.index)($scope);
			$scope.isLoading = true;
			$scope.keyAction = keyAction;
			$scope.selectField = selectField;
			$scope.addReferenceList = addReferenceList;
			$scope.$watch("searchTerm", filterFieldList);
			$scope.$on("snfilter:scrolled_by_index", glowedUpList);
			$scope.$on('$destroy', destroyFilterFieldList);
			$element[0].addEventListener('focus', focusIn ,true);
			$element[0].onfocusin = focusIn;
			activate();
			function activate() {
				$scope.comparison.getFieldsListByIndex(fieldsListIndex)
					.then(_processData);
			}
			function _processData(data) {
				$scope.isLoading = false;
				var filteredFields;
				if ("fields" in data){
					fieldsModel = data.fields;
					var includeKeywords = snFilterUtilities.canShowKeywordsField($scope.predicate, $scope.comparison);
					if (fieldsListIndex !== 0 || $scope.setIndex != 0 || !includeKeywords)
						filteredFields = [KEYWORD_FIELD];
					fieldsModel = _addLabelToDuplicateFields(fieldsModel);
					_fieldsArray = snDotWalkUtilities.makeFieldsArray(fieldsModel, filteredFields);
					$scope.fieldsArray = _fieldsArray;
				}
				$timeout(function() {
					var event = 'set.' + ($scope.setIndex || 0) + '.snFilterFieldList.' + fieldsListIndex + '.' + $scope.ref + '.loaded';
					snCustomEvent.fire(event);
					_addSelectedClass($scope.fieldsArray, data);
					focusFirstItem();
				}, 0);
			}
			function keyAction(keyEvent, field) {
				if (keyEvent.which == 13)
					$scope.selectField(field);
			}
			function selectField(field) {
				var fieldObj = fieldsModel[field.field];
			 	if (fieldObj.base_type === "item_option_new"){
					$scope.$parent.selectVariable(fieldObj, fieldsListIndex);
				} else if (fieldObj && fieldObj.non_selectable) {
					$scope.$parent.selectReferenceList(field, fieldObj, fieldsListIndex);
					_addSelectedClass($scope.fieldsArray, field);
				} else {
					$scope.$parent.selectField(fieldObj, fieldsModel, fieldsListIndex);
					_addSelectedClass($scope.fieldsArray, field);
				}
			}
			function addReferenceList(field) {
				var fieldObj = fieldsModel[field.field];
				$scope.$parent.selectReferenceList(field, fieldObj, fieldsListIndex);
				_addSelectedClass($scope.fieldsArray, field);
			}
			function glowedUpList(event, index){
				if (index == fieldsListIndex) {
					$scope.selected = true;
					if (glowTimeout)
						$timeout.cancel(glowTimeout);
					glowTimeout = $timeout(function(){
						$scope.selected = false;
					}, 500);
				}
			}
			function destroyFilterFieldList(){
				$element[0].removeEventListener('focus', focusIn, true);
				$element[0].onfocusin = null;
			}
			function focusIn(){
				angular.element($element).siblings().removeClass("outline-filter-field-list");
				angular.element($element).addClass("outline-filter-field-list");
			}
			function filterFieldList(n, o){
				$scope.comparison.getFieldsListByIndex(fieldsListIndex).then(function() {
					var title;
					if (n && n != o){
						$scope.fieldsArray = _fieldsArray
							.filter(function(field){
								var isLastColumn = $scope.comparison.fieldsListsPromises.length - 1 === fieldsListIndex;
								var searchMatch = field.field_label ? field.field_label.toLowerCase().indexOf($scope.searchTerm.toLowerCase()) > -1 : false;
								if (field.selected && !isLastColumn){
									title = field;
									return false;
								}
								return searchMatch;
							});
							if (title)
								$scope.fieldsArray.unshift(title);
					} else {
						$scope.fieldsArray = _fieldsArray;
					}
				})
			}
			function _addSelectedClass (array, fieldObj){
				angular.forEach(array, function(item){
					if (fieldObj.field === item.field){
						item.selected = true;
					} else {
						item.selected = false;
					}
				});
			}
			function focusFirstItem(){
				if (fieldsListIndex === $scope.comparison.fieldsListsPromises.length  -1 && fieldsListIndex !== 0) {
					angular.element($element).find('li:not(.sr-only)').first().children('a').focus();
				}
			}
			function _addLabelToDuplicateFields(fieldsModel){
				var labelsArray = Object.keys(fieldsModel).map(function(key){
					return {
						name : fieldsModel[key].name,
						label : fieldsModel[key].label
					}
				});
				var _uniqueNamesFromLabels = _getDuplicateNamesFromLabels(labelsArray);
				_uniqueNamesFromLabels.forEach(function(dupeLabel){
					if (dupeLabel in fieldsModel)
						fieldsModel[dupeLabel].label = fieldsModel[dupeLabel].label + " (" + fieldsModel[dupeLabel].name + ")";
				});
				return fieldsModel
			}
			function _getDuplicateNamesFromLabels(array){
				var hash = {},
					i,
					l = array.length,
					results = [];
				for (i = 0; i < l; i++){
					var item = array[i];
					hash[item.label] = {
						count : item.label in hash ? hash[item.label].count + 1 : 1,
						names : hash[item.label] ? hash[item.label].names.concat([item.name]) : [item.name]
					};
				}
				for (var item in hash) {
					if (hash[item].count > 1){
						results = results.concat(hash[item].names);
					}
				}
				return results;
			}
		}
	};
});
;
/*! RESOURCE: /scripts/sn/filter_widget/dot_walk/directive.snFilterFieldListsParent.js */
angular.module('sn.filter_widget.dot_walk').directive('snFilterFieldListsParent', function($q, i18n, $timeout, $http, snCustomEvent, getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		require: 'ngModel',
		templateUrl: getTemplateUrl("sn_filter_field_lists_parent.xml"),
		scope: {
			ref: "@",
			setIndex: "@",
			comparison: "=",
			dotWalking: "=",
			baseTable: "=",
			uid: "=",
			table: "=",
			closeEvent: "@",
			popoverConfig: "=",
			popoverContainer: "=",
			predicate: '=',
			compoundMessage: '='
		},
		controller: function ($scope) {
			var uid = (!!$scope.uid) ? $scope.uid : $scope.baseTable;
			var container = "#" + uid + "gcond_filters";
			if ($scope.popoverContainer ) {
				container = $scope.popoverContainer;
			}
			else if ($scope.popoverConfig && $scope.popoverConfig.container) {
				container = $scope.popoverConfig.container;
			}
			
			$scope.popoverConfig = {
				placement: 'bottom',
				container : container,
template: '<div class="filter-fields-list-popover popover" role="tooltip"><div class="popover-content"></div></div>',
				onArrowKey: function (evt, callback) {
					if (evt.keyCode == 38 || evt.keyCode == 40) {
						callback(evt);
						evt.preventDefault();
					}
				}
			};
		},
		link: function(scope, iElement, iAttrs, ngModelCtrl) {
			var NONE_LABEL = i18n.getMessage("-- Choose Field --");
			scope.searchTerm;
			scope.displayFields = [];
			scope.selectField = selectField;
			scope.selectReferenceList = selectReferenceList;
			scope.scrollToReferenceList = scrollToReferenceList;
			scope.selectVariable = selectVariable;
			scope.removeFieldList = removeFieldList;
			scope.$on(scope.closeEvent, focusButton);
			ngModelCtrl.$formatters.unshift(toView);
			ngModelCtrl.$render = render;
			snCustomEvent.on('shown.complexpopover.' + scope.ref, toggleFieldSelectedFalse);
			function toggleFieldSelectedFalse() {
				scope.comparison.fieldSelected = false;
			}
			snCustomEvent.on('hide.complexpopover.' + scope.ref, toggleFieldSelectedTrue);
			function toggleFieldSelectedTrue() {
				scope.comparison.fieldSelected = true;
			}
			activate();
			function activate() {
				updateFields();
			}
			function cleanup() {
				snCustomEvent.un('shown.complexpopover.' + scope.ref, toggleFieldSelectedFalse);
				snCustomEvent.un('hide.complexpopover.' + scope.ref, toggleFieldSelectedTrue);
			}
			function render () {
				if (!ngModelCtrl.$viewValue)
					ngModelCtrl.$viewValue = { currentField: NONE_LABEL};
				scope.currentField = ngModelCtrl.$viewValue.currentField;
				$timeout(function() {
					snCustomEvent.fire("snfilter:conditionLabelChange")
				})
			}
			function toView (val) {
				return {
					currentField: val || NONE_LABEL
				};
			}
			function selectReferenceList(field, fieldsModel, index) {
				if (field.reference)
					scope.comparison.addFieldsModel(fieldsModel, index);
				updateFields();
			}
			function selectField(fieldObj, fieldsModel, index) {
				scope.$broadcast(scope.closeEvent);
				scope.comparison.comparisonChange(fieldObj, fieldsModel, index);
				updateFields();
			}
			function selectVariable(field, index) {
				$q.all(scope.comparison.fieldsListsPromises).then(function(values) {
						if (!values[2])
							return;
						scope.$broadcast(scope.closeEvent);
						var fieldsModel = values[2].fields;
						scope.comparison.comparisonChange(field, fieldsModel, index);
				});
			}
			function updateFields () {
				$q.all(scope.comparison.fieldsListsPromises).then(function(values) {
					if (!(values instanceof Array))
						return;
					if (scope.comparison._isVariable())
						scope.display_fields = values[values.length - 1].field_label;
					else {
						scope.display_fields = (values || []).map(function(item, index, values) {
							if (values && values.length > 1 && !item.field_label) {
								return values[index-1].field_label + " Fields"
							} else {
								return item.field_label;
							}
						});
					}
					scrollToReferenceList(values.length);
				});
			}
			function scrollToReferenceList(index) {
				index = index || 0;
				angular.element('.filter-field-sets-container').animate({scrollLeft: index * 250}, 300);
				if (index !== scope.comparison.fieldsListsPromises.length)
					scope.$broadcast('snfilter:scrolled_by_index', index);
			}
			function removeFieldList (index) {
				scope.comparison.fieldsListsPromises.length = index;
				updateFields();
			}
			scope.$on('$destroy', cleanup);
			function focusButton(sourceScope, isTabKey) {
				if (isTabKey)
					scope.comparison.fieldSelected = true;
			}
		}
	};
});
;
/*! RESOURCE: /scripts/sn/filter_widget/dot_walk/factory.snDotWalkUtilities.js */
angular.module('sn.filter_widget.dot_walk').factory('snDotWalkUtilities', function () {
	var DATE_TYPES = ["date", "datetime"];
	var SYS_TAGS = "sys_tags";
	var VARIABLES = "variables";
	return {
		makeFieldsArray: makeFieldsArray,
		makeDateFieldsArray: makeDateFieldsArray,
		removeUnwantedColumnsFromDotwalkedMetadata: removeUnwantedColumnsFromDotwalkedMetadata
	};
	function makeFieldsArray(fields, fieldsToFilter){
		var fieldsArray = _mapFieldsArrayByKeys(fields);
		return fieldsArray.filter(function(fieldObj){
			return ((fieldsToFilter || []).indexOf(fieldObj.field) === -1)
		});
	}
	function makeDateFieldsArray(fields, parent){
		var topLevel;
		try {
			var field = parent.field.field.split('.')
			if (field.length > 1) {
				field.pop();
				topLevel = field.join('.');
			}
		}catch(ex) {
			console.warn('bad parent format', ex);
		}
		var dates = {};
		for(var field in fields){
			if (DATE_TYPES.indexOf(fields[field].base_type) > -1 && (!fields[field].internal_type || fields[field].internal_type.indexOf('date') > -1)){
				dates[field] = fields[field];
			}
		}
		return _mapFieldsArrayByKeys(dates, topLevel);
	}
	function _mapFieldsArrayByKeys(fields, topLevel){
		return Object.keys(fields)
			.filter(function(field){
				return !(fields[field].filterable === false) && fields[field].label;
			})
			.map(function(field){
				var iterativeField = fields[field];
				var obj = {
					base_type: iterativeField.base_type,
					field: topLevel ? topLevel + '.' + iterativeField.name : iterativeField.name,
					field_label: iterativeField.label,
					selected: iterativeField.selected || false
				};
				if ("reference" in iterativeField && iterativeField.type !== "glide_list" && iterativeField.base_type != 'item_option_new')
					obj.reference = iterativeField.reference;
				return obj;
			})
			.sort(function(a, b){
				if (a.field_label.toLowerCase() < b.field_label.toLowerCase())
					return -1;
				if (a.field_label.toLowerCase() > b.field_label.toLowerCase())
					return 1;
				return 0;
			});
	}
	function removeUnwantedColumnsFromDotwalkedMetadata(panelIndex, columns) {
		if (!columns || typeof columns !== 'object') {
			return {};
		}
		
		if (panelIndex > 0 && columns[SYS_TAGS]) {
			delete columns[SYS_TAGS];
		}
		if (panelIndex > 0 && columns[VARIABLES]) {
			delete columns[VARIABLES];
		}
		return columns;
	}
});
;
/*! RESOURCE: /scripts/sn/filter_widget/dot_walk/factory.snDotWalkTableData.js */
angular.module('sn.filter_widget.dot_walk').factory('snDotWalkTableData', function ($http, $q, i18n, snFilterUtilities, snDotWalkTableAPI, snDotWalkUtilities, KEYWORD_FIELD) {
	return {
		getDataByField : getDataByField,
		getTableData: getTableData,
		getFieldsLists: getFieldsLists,
		getVariablesLists: getVariablesLists
	};
	function getDataByField(field, table){
		switch(field.base_type){
			case  "variables" :
				return snDotWalkTableAPI.getCatalogItems(table);
			case "variable" :
				return snDotWalkTableAPI.getVariablesByCatalogID(field.id, table);
case "extended_table":
			default:
				return snDotWalkTableAPI.getMetaData(field.reference);
		}
	}
	function getTableData(table){
		return snDotWalkTableAPI.getTableData(table).then(function(response){
			var fieldsModel = {};
			angular.forEach(response.data.result, function(item){
				fieldsModel[item.name] = {
					filterable: true,
					name: item.name,
					label: item.sys_name,
					base_type: "variable",
					type: "variable",
					non_selectable: true,
					reference: "item_option_new",
					id: item.sys_id
				}
			});
			return fieldsModel;
		});
	}
	function getVariablesLists(comparison, fieldList, table){
		var allPromises = [];
		var lastPromise = $q.when();
		var query = "sys_id=" + comparison.field;
		var catItemId;
		lastPromise = lastPromise.then(function() {
			return snDotWalkTableAPI.getTableData("item_option_new", query).then(function(result) {
				catItemId = result[0].cat_item.value;
			});
		});
		allPromises.push(lastPromise = lastPromise.then(function(){
			return snDotWalkTableAPI.getMetaData(comparison.table).then(function(columns) {
				if(fieldList.length > 0)
					columns = filterTableColumns(columns, fieldList);
				return {
					fields: columns,
					field: 'variables',
					field_label: i18n.getMessage('Variables')
				};
			})
		}));
		allPromises.push(lastPromise = lastPromise.then(function(){
			return snDotWalkTableAPI.getCatalogItems(table).then(function(response){
				var field = Object.keys(response).filter(function(field){ return (response[field].id === catItemId)})[0];
				return {
					fields: response,
					field: field
				}
			});
		}));
		allPromises.push(lastPromise = lastPromise.then(function(){
			return snDotWalkTableAPI.getVariablesByCatalogID(catItemId, comparison.table).then(function(response){
				var field = Object.keys(response).filter(function(field){ return (response[field].name === comparison.field)})[0];
				return {
					fields: response,
					field: field
				}
			});
		}));
		return allPromises;
	}
	function getFieldsLists(comparison, wantKeywords, extendedOperatorOptions, fieldList, includeVariables){
		var tableNames = [comparison.table];
		var fieldLabels = [];
		var fieldsSetsFields = [];
		var lastPromise = $q.when();
		var allPromises = [];
		if (comparison && comparison.reference_fields){
			angular.forEach(comparison.reference_fields, function(item, index, array){
				if (item.reference_table && (array.length - 1 !== index))
					tableNames.push(item.reference_table);
				fieldsSetsFields.push(item.field);
				fieldLabels.push(item.field_label);
			});
		} else if (comparison){
			fieldLabels.push(comparison.field_label);
			fieldsSetsFields.push(comparison.field);
		}
		tableNames.map(function(name, index) {
			var correctTable = (comparison && comparison.reference_fields) ? comparison.reference_fields[index - 1] : null;
			var isExtendedTable = correctTable && correctTable.internal_type === "extended_table";
			if (isExtendedTable) {
				wantKeywords = false;
				includeVariables = false;
			}
			lastPromise = lastPromise.then(function() {
					return snDotWalkTableAPI.getMetaData(name, false, wantKeywords, extendedOperatorOptions,
						includeVariables).then(function(columns) {
							columns = snDotWalkUtilities.removeUnwantedColumnsFromDotwalkedMetadata(index, columns);
							if(fieldList.length > 0)
								columns = filterTableColumns(columns, fieldList);
							return {
								fields: columns,
								field: fieldsSetsFields[index],
								field_label: fieldLabels[index]
							};
					})
				});
				allPromises.push(lastPromise);
		});
		return allPromises;
	}
	function filterTableColumns(columns, filterColumns) {
		var processedColumns = {};
		angular.forEach(filterColumns, function(column) {
			if(columns[column])
				processedColumns[column] = columns[column];
		});
		if(columns[KEYWORD_FIELD])
			processedColumns[KEYWORD_FIELD] = columns[KEYWORD_FIELD];
		return processedColumns;
	}
});
;
/*! RESOURCE: /scripts/sn/filter_widget/dot_walk/factory.snDotWalkTableAPI.js */
angular.module('sn.filter_widget.dot_walk').factory('snDotWalkTableAPI', function ($http, $q, $rootScope, snFilterSubjectCriteriaStore, snFilterSecurityAttributesStore) {
	"use strict";
var META_ENDPOINT = "/api/now/ui/meta/";
var DATA_ENDPOINT = "/api/now/table/";
var FILTER_VARIABLES = "/api/now/ui/filter_variables/";
	return {
		getTableData: getTableData,
		getMetaData : getMetaData,
		getCatalogItems: getCatalogItems,
		getVariablesByCatalogID: getVariablesByCatalogID
	};
	function isValidTableName(tableName) {
return !/[.%]/.test(tableName);
	}
	function getTableData(table, query){
		query = (typeof query !== "undefined") ? "?sysparm_query=" + query : "";
		if(!isValidTableName) {
			return $q.reject("invalid table name");
		}
		return $http.get(DATA_ENDPOINT + table + query, {cache: true}).then(function(response){
			return response.data.result;
		})
	}
	function getMetaData(table, isExtendedTable, wantKeywords, extendedOperatorOptions, includeVariables) {
		if(!isValidTableName(table)) {
			return $q.reject("invalid table name");
		}
        var isSubjectCriteria = snFilterSubjectCriteriaStore.isSubjectCriteria(table);
		var isSecurityAttributes = snFilterSecurityAttributesStore.isSecurityAttributes(table);
		$rootScope.$emit("snfilter:get_meta_data", true);
        var url;
if (isSubjectCriteria === true || isSecurityAttributes === true) {
			if (isSubjectCriteria === true) {
				url = snFilterSubjectCriteriaStore.getAttributeURL(table);
			} else if (isSecurityAttributes === true) {
				url = snFilterSecurityAttributesStore.getAttributeURL(table);
			}
        } else {
            url = META_ENDPOINT + table + "?sysparm_operators=true&sysparm_get_extended_tables=true";
            url += wantKeywords ? "&sysparm_keywords=true" : "";
            url += isExtendedTable ? "&sysparm_is_extended_table=true" : "";
            if (typeof includeVariables === "boolean")
                url += includeVariables ? "" : "&sysparm_includes_variables=false";
            if (extendedOperatorOptions && extendedOperatorOptions.table && extendedOperatorOptions.field) {
                url += ("&sysparm_extended_operators_table=" + extendedOperatorOptions.table);
                url += ("&sysparm_extended_operators_field=" + extendedOperatorOptions.field);
            }
        }
		return $http.get(url, {cache: true}).then(function(response){
			return response.data.result.columns;
		})
	}
	function getCatalogItems(table) {
		var url = FILTER_VARIABLES + "catalog_items";
		if (table)
			url += "?sysparm_base_table=" + table;
		return $http.get(url).then(function(response) {
			return response.data.result;
		});
	}
	function getVariablesByCatalogID (catID, variableTable) {
		return $http.get(FILTER_VARIABLES + "variable_pool?sysparm_cat_item_id=" + (catID !== undefined ? catID : "") + "&sysparm_variable_table=" + variableTable).then(function(response){
			return response.data.result;
		})
	}
});
;
;
/*! RESOURCE: /scripts/sn/filter_widget/dot_walk/js_includes_dot_walk.js */
/*! RESOURCE: /scripts/directive.snFilterWidget.js */
angular.module('sn.filter_widget').directive('snFilterWidget', function(getTemplateUrl, snCustomEvent, snFilterInstanceStore, $rootScope, snFilterSubjectCriteriaStore, snFilterSecurityAttributesStore) {
	"use strict";
	return {
		restrict: "E",
		replace: true,
		templateUrl: getTemplateUrl("sn_filter.xml"),
		scope: {
			table: "@",
			tableLabel: "@",
			filterConfig: "=",
			uid: "=?",
			tinyUrl: "=?",
			sortConfig: "="
		},
		controller: function($scope, $element, $attrs) {
			var GLIDE_QUERY = "glide_query";
			var ENCODED_QUERY = "encoded_query";
			var filterId;
			var filterInstance;
			var internalChange = false;
			var uid = angular.isDefined($scope.uid) ? $scope.uid : $scope.table;
			var defaults = {
				sets: true,
				watchConfig: false,
				dotWalking: true,
				saveFilter: true,
				loadFilter: true,
				testFilter: false,
				sortFilter: true,
				runFilter: true,
				closeFilter: true,
				clearFilter: true,
				outputType: GLIDE_QUERY,
				relatedListQueryConditions: false,
manageFiltersLink: "/sys_filter_list.do",
				uid: uid,
				fieldList : []
			};
			$scope.popoverConfig = {
				container: $scope.filterConfig.popoverContainer || $element
			};
			$scope.encodedQueryPreviewUrl = "";
			$scope.$watch("filterConfig", function(newValue) {
				$scope.encodedQueryPreviewUrl = window.encodeURIComponent(newValue.encodedQuery);
			}, true);
			$scope.fieldListCloseEvent = "filter-field-list-close";
			$scope.$on('$destroy', cleanUp);
			activate();
			function activate() {
				_extendConfig();
				_bindFilterConfigWatcher();
				filterId = snFilterInstanceStore.create($scope.table, $scope.filterConfig.relatedListQueryConditions, undefined, $scope.filterConfig.fieldList, $scope.filterConfig.includeVariables, $scope.tinyUrl);
                snFilterSubjectCriteriaStore.create($scope.filterConfig.isSubjectCriteria, $scope.table);
				snFilterSecurityAttributesStore.create($scope.filterConfig.isSecurityAttributes, $scope.table);
				filterInstance = snFilterInstanceStore.get(filterId);
				_bindTooltips();
				$scope.uid = $scope.filterConfig.uid;
				var query = _getQueryType();
				if (!$scope.tableLabel)
					filterInstance.getTableLabel().then(function(label){
						$scope.tableLabel = label;
					});
				_initializeQuery(query, false).then(function() {
					snCustomEvent.fireAll("snfilter:activated");
				});
			}
			$scope.$on("snfilter:update_table", function(e, data) {
				if ((data.id && $scope.widgetId && (data.id == $scope.widgetId)) || !$scope.widgetId) {
				filterInstance.updateTable(data.table);
				$scope.$broadcast("snfilter:update_predicate_base_table", data);
				}
			});
			$scope.$on("snfilter:initialize_query", function(e, query) {
				_initializeQuery(query, _updateFilter);
			});
			snCustomEvent.on("snfilter:initialize_query", initializeQuery);
			function initializeQuery(e, query) {
				_initializeQuery(typeof e.predicates !== 'undefined' ? e : query, false);
			}
			function updateOrderBy(e, sortArray) {
				filterInstance.setSort(sortArray);
				_updateFilter();
				_emitQuery();
				$rootScope.$broadcast('filter.order_by_updated');
			}
			$scope.$on('snfilter:update_order_by', updateOrderBy);
			$scope.$on('filter.update_order_by', updateOrderBy);
			$scope.$on('snfilter:get_order_by', _getQuerySort);
			snCustomEvent.observe('snfilter:conditionChange', conditionChange);
			function conditionChange() {
				_updateFilter();
				if (_isAutomatic())
					_emitQuery();
			}
			$scope.runFilter = runFilter;
			$scope.testFilter = testFilter;
			$scope.clearFilter = clearFilter;
			$scope.close = close;
			$scope.addComparisonRow = addComparisonRow;
			$scope.removeComparisonRow = removeComparisonRow;
			$scope.addCompound = addCompound;
			function addComparisonRow(setIndex, ruleSetIndex, condIndex, type) {
				$scope.$evalAsync(function() {
					filterInstance.addComparisonRow(setIndex, ruleSetIndex, condIndex, type);
				})
			}
			function removeComparisonRow(setIndex, ruleSetIndex, conditionIndex) {
				$scope.$broadcast($scope.fieldListCloseEvent);
				$scope.$evalAsync(function() {
					filterInstance.removeComparisonRow(setIndex, ruleSetIndex, conditionIndex);
					if (_isAutomatic())
						runFilter();
				});
			}
			function addCompound() {
				filterInstance.addCompound();
			}
			function clearFilter() {
				$scope.filterConfig.relatedShowCompounds = false;
				$scope.$broadcast("snfilter:reset_related_list_select");
				_initializeQuery("", true);
				snCustomEvent.fire('filter:table.clear_column_headers', $scope.table);
				$scope.$emit('snfilter:clear_filter');
			}
			function close() {
				$scope.$emit('snbreadcrumbs:toggle_filter');
				angular.element('#'+$scope.uid+'-open-filters-button').focus();
			}
			function testFilter() {
				filterInstance.testResult().then(function(count) {
					$scope.count = count;
				});
			}
			function runFilter() {
				try {
					_updateFilter();
					_emitQuery();
				} catch (ex) {
					_errorHandler(ex);
				}
				$scope.$emit('snfilter:run_filter');
			}
			function cleanUp() {
				$element.tooltip('destroy');
				snFilterInstanceStore.remove(filterId);
				snCustomEvent.un('snfilter:conditionChange', conditionChange);
				snCustomEvent.un('snfilter:initialize_query', initializeQuery);
			}
			function _extendConfig() {
				$scope.filterConfig = angular.extend({}, defaults, $scope.filterConfig);
				if ($attrs.relatedListQueryConditions === "true")
					angular.extend($scope.filterConfig, {relatedListQueryConditions: true});
				$scope.filterConfig.hideHeader = _checkHideHeader($scope.filterConfig);
			}
			function _bindFilterConfigWatcher() {
				if ($scope.filterConfig.watchConfig) {
					$scope.$watch('filterConfig', function(n, o) {
						if (n !== o && !internalChange)
							_extendConfig();
						internalChange = false;
					}, true);
				}
			}
			function _bindTooltips() {
				$element.tooltip({
					selector: '.sn-filter-tooltip',
					container: 'body'
				}).on('hide.bs.tooltip', function(evt) {
					var button = jQuery(evt.target);
					if (typeof button.hideFix === 'function') {
						button.hideFix();
					}
				});
			}
			function _isAutomatic() {
				return ($scope.filterConfig.runFilter === false);
			}
			function _checkHideHeader(config) {
				return (config.saveFilter === false &&
				config.loadFilter === false &&
				config.testFilter === false &&
				config.sortFilter === false &&
				config.runFilter === false &&
				config.closeFilter === false );
			}
			function _updateFilter() {
				if ($scope.filterConfig.watchConfig)
					internalChange = true;
				$scope.filterConfig.queryObj = filterInstance.buildQueryObject();
				$scope.filterConfig.encodedQuery = $scope.filterConfig.queryObj.toQueryString();
				$scope.$emit('snfilter:filter_change');
			}
			function _emitQuery() {
				switch ($scope.filterConfig.outputType) {
					case ENCODED_QUERY :
						$scope.$emit('snfilter:update_query', $scope.filterConfig.encodedQuery, $scope.table);
						break;
					case GLIDE_QUERY :
						$scope.$emit('snfilter:update_query', $scope.filterConfig.queryObj, $scope.table);
						break;
					default :
						$scope.$emit('snfilter:update_query', $scope.filterConfig.queryObj, $scope.table);
				}
			}
			function _getQueryType() {
				var query = [];
				if ($scope.filterConfig.queryObj)
					query = $scope.filterConfig.queryObj;
				else if ($scope.filterConfig.encodedQuery)
					query = $scope.filterConfig.encodedQuery;
				return query;
			}
			function _getQuerySort() {
				$scope.sortItems = [];
				angular.forEach(filterInstance.getSort(), function(value, key) {
					$scope.sortItems.push(Object.assign({}, value));
				});
			}
			function _initializeQuery(query, update) {
				$scope.initializing = true;
				return filterInstance.initialize(query, $scope.table, $scope.filterConfig.extendedOperatorOptions, '', [],
					$scope.filterConfig.includeVariables).then(function(queryMap) {
					$scope.initializing = false;
					$scope.queryMap = queryMap;
					_getQuerySort();
					$rootScope.$broadcast('filter.sort_items', $scope.sortItems);
					if (update) {
						if (typeof update === 'function') update();
						else {
							_updateFilter();
							_emitQuery();
						}
					}
				});
			}
			function _errorHandler(ex) {
				console.warn(ex);
			}
		}
	}
});
;
/*! RESOURCE: /scripts/directive.snFilterPredicate.js */
angular.module("sn.filter_widget").directive("snFilterPredicate", function(getTemplateUrl, i18n, snFilterPredicateWrapper, filterAPI, snFilterUtilities, snFilterInstanceErrors, $timeout, snCustomEvent) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		scope: {
			baseTable: "@",
			tableLabel : "@",
			predicate: "=",
			filterConfig: "=",
			popoverConfig: '=',
			relatedComparison : "=",
			table:"=",
			uid : "="
		},
		templateUrl: getTemplateUrl("sn_filter_predicate.xml"),
		controller : function($scope){
			var relatedTableModel;
			var M2M = "m2m";
			var relatedListTitle = i18n.getMessage("Related List");
			var orConditionMessage = i18n.getMessage("or condition");
			var andConditionMessage = i18n.getMessage("and condition");
			var predicateWrapper = snFilterPredicateWrapper.create($scope.table);
			predicateWrapper.setFilterConfig($scope.filterConfig);
			var _predicateQueryString = predicateWrapper.toQueryString($scope.predicate);
			var isCollapsed = ($scope.predicate.is_related && _predicateQueryString === "");
			$scope.data = {
				isRelated : $scope.predicate.is_related,
				collapsed : isCollapsed
			};
			$scope.ariaId = $scope.$id;
			$scope.displayTitle = getDisplayTitle();
			$scope.updateTable = updateTable;
			$scope.toggleState = toggleState;
			$scope.removeTable = removeTable;
			$scope.updateRelatedListModel = updateRelatedListModel;
			$scope.removeComparisonRow = removeComparisonRow;
			$scope.addComparisonRow = addComparisonRow;
			$scope.cleanToolTip = cleanToolTip;
			$scope.focusOrButton = focusOrButton;
			$scope.addCompound = addCompound;
			$scope.allowNewSets = function() {
				return !snFilterUtilities.hasExistingKeywordsField($scope.predicate)
			};
			$scope.getCompoundMessage = function(predicate) {
				if (predicate && predicate.subpredicates.length > 1) {
					return predicate.compound_type === 'or' ?
						orConditionMessage : andConditionMessage
				}
				return null;
			}
			$scope.$on("snfilter:update_predicate_base_table", function(e, data){
				if ($scope.data.isRelated){
					reset();
					$timeout(function() {
						initializeRelatedListModel(data.table);
					});
				} else {
					$scope.baseTable = data.table;
					$scope.table = data.table;
					$scope.tableLabel = data.tableLabel;
					$scope.displayTitle = getDisplayTitle();
				}
				predicateWrapper.updateTable($scope.predicate, data.table);
				snCustomEvent.fire('snfilter:conditionChange');
			});
			activate();
			function activate(){
				if ($scope.data.isRelated){
					$timeout(function() {
						initializeRelatedListModel($scope.baseTable);
					});
					$scope.filterConfig.relatedShowCompounds = !!$scope.table;
				}
			}
			function initializeRelatedListModel(table) {
				filterAPI.getRelatedLists(table).then(function(relatedLists){
					$scope.relatedLists = relatedLists;
					relatedTableModel = snFilterUtilities.convertArrayToObject(relatedLists, "value");
				});
			}
			function updateRelatedListModel(table){
				var _model;
				try{
					snCustomEvent.fire("fieldListCloseEvent");
					_model = relatedTableModel[table];
					if (_checkM2M(_model))
						$scope.predicate.comparison.addOption(M2M);
					else
						$scope.predicate.comparison.removeOption(M2M);
					$scope.predicate.comparison.table = _model.value;
					$scope.predicate.comparison.table_label = _model.label;
					$scope.updateTable(table);
				} catch (ex) {
					throw new snFilterInstanceErrors.RelatedListModelError(ex)
				}
			}
			function _checkM2M(model){
				return (model.parameters && model.parameters.type === M2M);
			}
			function updateTable(table){
				var _table = snFilterUtilities.normalizeTable(table);
				$scope.filterConfig.relatedShowCompounds = true;
				predicateWrapper.updateTable($scope.predicate, _table);
				snCustomEvent.fire('snfilter:conditionChange');
			}
			function removeTable(){
				reset();
				predicateWrapper.reset($scope.predicate);
				snCustomEvent.fire('snfilter:conditionChange');
				$scope.$broadcast('snfilter:reset_related_list_select');
			}
			function addCompound (){
				predicateWrapper.addCompound($scope.predicate);
			}
			function cleanToolTip(event){
				var element = event.currentTarget
				var toolTip = element.getAttribute('aria-describedby')
				if (toolTip) {
					var tip = document.getElementById(toolTip);
					if (tip)
						tip.parentNode.removeChild(tip);
				}
			}
			function addComparisonRow (compoundIndex, subCompoundIndex, comparisonIndex, type){
				angular.element(".filter-fields-list-popover").remove();
				predicateWrapper.addComparisonRow($scope.predicate, compoundIndex, subCompoundIndex, comparisonIndex, type);
			}
			function focusOrButton(rootInd, parentInd, isFirst, isOr)  {
if (isOr)
					return;
$timeout(function() {
if (!isFirst)
						parentInd++;
					var outerContainer = angular.element('.outer-condition-container')[rootInd];
					var ruleContainer = angular.element(outerContainer).find('.rule-set-type-container')[parentInd];
var conditionContainer = angular.element(ruleContainer).find('.ng-filter-widget-row')[0];
					angular.element(conditionContainer).find('.btn-or-condition').focus();
				}, 0, false);
			}
			function removeComparisonRow (compoundIndex, subCompoundIndex, comparisonIndex, noEmptyCheck){
				angular.element(".filter-fields-list-popover").remove();
				var oldCompoundSize = $scope.predicate.subpredicates.length;
				var oldSubcompoundSize = $scope.predicate.subpredicates[compoundIndex].subpredicates.length;
				var oldComparisonSize = $scope.predicate.subpredicates[compoundIndex].subpredicates[subCompoundIndex].subpredicates.length;
				predicateWrapper.removeComparisonRow($scope.predicate, compoundIndex, subCompoundIndex, comparisonIndex, noEmptyCheck);
$timeout(function(){
					var newCompoundSize = $scope.predicate.subpredicates.length;
					var indexArray = [compoundIndex, 0, 0];
					var isFocused = focusComparisonRow(newCompoundSize, oldCompoundSize, indexArray, 0);
					if (isFocused)
						return;
					var newSubcompoundSize = $scope.predicate.subpredicates[compoundIndex].subpredicates.length;
					indexArray = [compoundIndex, subCompoundIndex, 0];
					isFocused = focusComparisonRow(newSubcompoundSize, oldSubcompoundSize, indexArray, 1);
					if (isFocused)
						return;
					var newComparisonSize = $scope.predicate.subpredicates[compoundIndex].subpredicates[subCompoundIndex].subpredicates.length;
					indexArray = [compoundIndex, subCompoundIndex, comparisonIndex];
					isFocused = focusComparisonRow(newComparisonSize, oldComparisonSize, indexArray, 2);
					if (!isFocused)
						_focusComparisonRow(0, 0, 0);
				}, 0, false);
			}
			function focusComparisonRow(newSize, oldSize, indexArray, targetIndex) {
				var targetValue = indexArray[targetIndex];
				var isFocused = false;
				var argArray = indexArray;
				if (newSize < oldSize) {
					if (targetValue === oldSize - 1) {
						argArray = indexArray.map(function(val, index) {
							if (index > targetIndex)
								return -1
							else if (index === targetIndex)
								return val - 1;
							else
								return val;
						});
					}
					isFocused = _focusComparisonRow.apply(null, argArray);
				}
				return isFocused;
			}
			function _focusComparisonRow(compoundIndex, subCompoundIndex, comparisonIndex) {
				var outerContainer = angular.element('.outer-condition-container')[compoundIndex];
				var ruleContainer = angular.element(outerContainer).find('.rule-set-type-container');
				ruleContainer = (subCompoundIndex === -1) ? ruleContainer[ruleContainer.length - 1] : ruleContainer[subCompoundIndex];
				var conditionContainer = angular.element(ruleContainer).find('.ng-filter-widget-row');
				conditionContainer = (comparisonIndex === -1) ? conditionContainer[conditionContainer.length - 1] : conditionContainer[comparisonIndex];
				var field = angular.element(conditionContainer).find('.field-list-button')[0];
				if (field) {
					field.focus();
				}
				return true;
			}
			function reset(){
				$scope.filterConfig.relatedShowCompounds = false;
				$scope.predicate.comparison.options = [];
				$scope.predicate.comparison.table = "";
				$scope.predicate.comparison.table_label = "";
			}
			function getDisplayTitle(title){
				var title = "{TABLENAME} Conditions";
				var displayTitle;
				if ($scope.data.isRelated)
					displayTitle = i18n.getMessage(title).withValues({ TABLENAME : relatedListTitle});
				else
					displayTitle = i18n.getMessage(title).withValues({ TABLENAME : $scope.tableLabel});
				return displayTitle;
			}
			function toggleState (){
				$scope.data.collapsed = !$scope.data.collapsed
			}
		},
		link : function(scope, element){
			scope.$watchCollection("predicate.subpredicates", function(newVal, oldVal) {
				if (newVal.length > oldVal.length) {
					$timeout(function() {
						element.find(".compounds > .set:last .field-list-button").focus()
					}, 0, false);
				}
			})
			if (scope.data.isRelated)
				angular.element(element).addClass("related-list-query-section");
		}
	}
});
;
/*! RESOURCE: /scripts/directive.snFilterCompound.js */
angular.module("sn.filter_widget").directive("snFilterCompound", function(getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl("sn_filter_compound.xml")
	}
});
;
/*! RESOURCE: /scripts/directive.snFilterComparison.js */
angular.module("sn.filter_widget").directive("snFilterComparison", function(getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl("sn_filter_comparison.xml"),
		controller: function($scope){
			$scope.operatorExpanded = false;
			$scope.operatorExpandedToggle = function(bool) {
				$scope.operatorExpanded = bool;
			}
			$scope.operatorChange = function() {
				$scope.operatorExpandedToggle(false)
				if ($scope.comparison)
					$scope.comparison.operatorSelectChange();
			}
			$scope.operatorKeypress = function(event) {
				if (!event) return;
				var charCode = event.charCode;
				if (charCode === 32)
					$scope.operatorExpandedToggle(true);
			}
			$scope.filterRowKeypress = function(event) {
				if (!event) return;
				var enterKey = 13;
				if ((event.charCode === enterKey || event.key === 'Enter') && event.target.type !== 'textarea') {
					event.preventDefault();
				}
			}
		}
	}
});
;
/*! RESOURCE: /scripts/directive.snLoadFilterWidget.js */
angular.module('sn.filter_widget').directive('snLoadFilterWidget', function(i18n, getTemplateUrl, filterAPI, snCustomEvent, snNotification) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl("sn_load_filter_widget.xml"),
		link: function(scope, elem, attrs){
			scope.filterSearchTerm = "";
			var allSavedFilters;
			scope.$on("dialog.loadFilter.show", activate);
			scope.editFilter = editFilter;
			scope.deleteFilter = deleteFilter;
			scope.loadAndRunFilter = loadAndRunFilter;
			scope.preserveSearchedFilters = preserveSearchedFilters;
			scope.searchFilters = searchFilters;
			attrs.$observe('manageFiltersLink', function(value) {
scope.manageFiltersLink = (value) ? value: "/sys_filter_list.do";
			});
			function activate(){
				getFilters();
			}
			function getFilters(){
				filterAPI.getFilters(scope.table)
					.then(_bindFiltersToScope)
					.catch(_getFiltersFailure);
			}
			function _getFiltersFailure(ex){
				console.warn(ex);
			}
			function _bindFiltersToScope (response){
				var users = response.data.result.USER || [];
				var global = response.data.result.GLOBAL || [];
				var group = response.data.result.GROUP || [];
				allSavedFilters = [].concat.apply([], [users, group, global]);
				scope.savedFilters = allSavedFilters;
			}
			function deleteFilter(filter){
				scope.savedFilters = scope.savedFilters.filter(function(item){
					return (item !== filter);
				});
				filterAPI.deleteFilter(scope.table, filter.id)
					.then(_deleteFilterSuccess.call(null, filter))
					.catch(_deleteFilterError);
			}
			function editFilter(filter){
				snCustomEvent.fire("snfilter:edit_filter", filter);
			}
			function loadAndRunFilter(query){
				scope.$emit("snfilter:update_query", query.filter, scope.table, true);
				scope.$emit("snfilter:initialize_query", query.filter);
			}
			function preserveSearchedFilters(e) {
				if (e.keyCode === 13)
					e.preventDefault();
			}
			function searchFilters(searchTerm){
				if (searchTerm){
					scope.savedFilters = allSavedFilters
						.filter(function(filter){
							if (filter.title.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1){
								return filter;
							}
						});
				} else {
					scope.savedFilters = allSavedFilters;
				}
			}
			function _deleteFilterSuccess (filter){
				snNotification.show("success", i18n.getMessage("{0} has been deleted").withValues([filter.title]), 3000);
			}
			function _deleteFilterError (reason){
				snNotification.show("error", i18n.getMessage("{0} could not be deleted due to an error: {1}").withValues([filter.title, reason.data.error.detail]), 3000);
				scope.savedFilters.splice(index, 0, filter);
			}
		}
	};
});
;
/*! RESOURCE: /scripts/directive.snSaveFilterWidget.js */
angular.module('sn.filter_widget').directive('snSaveFilterWidget', function(i18n, getTemplateUrl, filterAPI, snNotification, snFilterUtilities) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl("sn_save_filter_widget.xml"),
		controller: function ($scope) {
			$scope.popoverConfig = angular.extend({
				placement: 'bottom',
template: '<div class="popover" role="tooltip"><div class="arrow"></div><div class="popover-header"><h4>' + i18n.getMessage("Save Filter") + '</h4></div><div class="popover-content"></div></div>',
			}, $scope.popoverConfig);
			$scope.closeEvent = "close_save_filter"
		},
		link: function(scope, element, attrs) {
			var hasGlobalRole = (attrs.globalRole === "true");
			var hasGroupRole = (attrs.groupRole === "true");
			var hasAdminRole = (attrs.adminRole === "true");
			scope.saveFilter = saveFilter;
			scope.$on("dialog.saveFilter.show", activate);
			scope.groupField = {
				targetTable: 'sys_user_group',
				reference_display_field: 'name',
				fieldRequired : true,
				value: '',
				fieldName: "groupValue",
				displayValue : ''
			};
			scope.filterSaveTypes = [
				{
					name : "user",
					value : "USER",
					label : i18n.getMessage("Only Me"),
					show: true
				},
				{
					name : "global",
					value : "GLOBAL",
					label : i18n.getMessage("Everyone"),
					show : (hasGlobalRole || hasAdminRole)
				},
				{
					name : "group",
					value : "GROUP",
					label : i18n.getMessage("Group"),
					show : (hasGroupRole || hasAdminRole)
				}
			];
			function activate(){
				if (typeof scope.filterConfig === "undefined" || typeof scope.filterConfig === "null")
					throw "No Filter Config available in sn save filter widget";
				_setFormObject();
			}
			function _setFormObject (){
				var encodedQuerystring = "";
				if (scope.filterConfig.encodedQuery)
					encodedQuerystring = scope.filterConfig.encodedQuery;
				else if (scope.filterConfig.queryObj)
					encodedQuerystring = scope.filterConfig.queryObj.toQueryString();
				filterAPI.getBreadcrumbs(scope.table, encodedQuerystring).then(function(breadcrumbs){
					scope.saveBreadcrumbs = snFilterUtilities.convertBreadcrumbsToString(breadcrumbs);
				});
				scope.newFilter = {};
				scope.newFilter.saveType = "USER";
				scope.newFilter.tableName = scope.table;
				scope.newFilter.filter = encodedQuerystring;
				scope.groupField.value = scope.groupField.displayValue = '';
			}
			function saveFilter(form){
				if (!form.$valid){
					snNotification.show("error", i18n.getMessage("Please make sure your saved filter has a name and a type"), 3000);
					return;
				}
				if (scope.newFilter.saveType == 'GROUP')
					scope.newFilter.group = scope.groupField.value;
				if (scope.newFilter.filter){
					filterAPI.saveFilter(scope.table, scope.newFilter)
						.then(_saveFilterSuccess)
						.catch(_saveFilterFailure);
				} else {
					snNotification.show("error", i18n.getMessage("Your filter could not be saved due to an error: {0}").withValues(["No filter available"]), 3000);
				}
			}
			function sendTelemetryData(eventName) {
				window.GlideUXMetrics && GlideUXMetrics.track(eventName, { 'Save filter count' : 1});
			}
			function _saveFilterSuccess(){
				snNotification.show("success", _getSuccessMessage(), 3000);
				sendTelemetryData("Save filter");
				scope.$broadcast('dialog.saveFilter.close');
				_setFormObject();
			}
			function _saveFilterFailure(reason){
				snNotification.show("error", i18n.getMessage("Your filter could not be saved due to an error: {0}").withValues([reason.data.error.detail]), 3000);
			}
			function _getSuccessMessage(){
				return i18n.getMessage("'{0}' has been saved").withValues([scope.newFilter.title]);
			}
		}
	};
});
;
/*! RESOURCE: /scripts/directive.snSortFilterWidget.js */
angular.module('sn.filter_widget').directive('snSortFilterWidget', function(getTemplateUrl, snDotWalkTableAPI, i18n, snFilterUtilities, snDotWalkUtilities, snFilterInstanceErrors) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl("sn_sort_filter_widget.xml"),
		controller : function($scope, $filter) {
			var firstField;
			$scope.sortDirections = [
				{
					label: i18n.getMessage("A to Z"),
					value: true
				},
				{
					label: i18n.getMessage("Z to A"),
					value: false
				}
			];
			$scope.addSortItem = addSortItem;
			$scope.removeSortItem = removeSortItem;
			$scope.setSort = setSort;
			$scope.updateSortOrder = updateSortOrder;
			$scope.onColumnChange = onColumnChange;
			$scope.enableDotWalkFieldPicker = $scope.sortConfig && $scope.sortConfig.enableDotWalkFieldPicker;
			$scope.sortFieldFilter = $scope.sortConfig && $scope.sortConfig.sortFieldFilter;
			$scope.$on("dialog.sortFilter.show", activate);
			function activate(){
				$scope.$emit("snfilter:get_order_by");
				if ($scope.enableDotWalkFieldPicker) {
					_checkEmptySortItems();
					return;
				}
				_getFilterFieldsData()
					.catch(function(){
						throw new snFilterInstanceErrors.SortFilterMetadataError($scope.table);
					})
					.finally(_checkEmptySortItems);
			}
			function setSort (){
				_checkValidSortItems();
				$scope.$emit("snfilter:update_order_by", $scope.sortItems);
			}
			function _getFilterFieldsData(){
				return snDotWalkTableAPI.getMetaData($scope.table, false, false).then(function(columns){
					if($scope.fieldList.length > 0)
						columns = filterTableColumns(columns, $scope.fieldList);
					var _filterFields = snFilterUtilities.convertObjectToArray(columns)
														 .filter(_removeEdgeEncryptionFields);
					$scope.sortFields = snDotWalkUtilities.makeFieldsArray(_filterFields);
					if ($scope.sortFields.length > 0)
						firstField = $scope.sortFields[0].field;
				});
			}
			function _checkEmptySortItems(){
				if ($scope.sortItems.length === 0)
					addSortItem();
			}
			function _checkValidSortItems(){
				if ($scope.sortItems.length !== 0){
					angular.forEach($scope.sortItems, function(obj, key) {
						if (!obj.column_name || obj.ascending === null)
							$scope.sortItems.splice(key, 1);
					});
				}
			}
			function updateSortOrder(index) {
				$scope.sortItems[index].ascending = true;
			}
			function updateFieldColumn(sortItem, fields) {
				sortItem.field_label = $filter('filter')(fields, { field: sortItem.column_name })[0].field_label;
			}
			function onColumnChange(index, fields) {
				updateSortOrder(index);
				updateFieldColumn($scope.sortItems[index], fields);
			}
			function addSortItem () {
				$scope.sortItems.push({
					column_name: null,
					ascending : null,
					field_label: null
				});
			}
			function removeSortItem(e, index){
				$scope.sortItems.splice(index, 1);
				_checkEmptySortItems();
			}
			function _removeEdgeEncryptionFields(item){
				return (["fixed"].indexOf(item.edge_encryption_type) === -1);
			}
			function filterTableColumns(columns, filterColumns) {
				var processedColumns = {};
				angular.forEach(filterColumns, function(column) {
					if(columns[column])
						processedColumns[column] = columns[column];
				});
				if(columns["123TEXTQUERY321"])
					processedColumns["123TEXTQUERY321"] = columns["123TEXTQUERY321"];
				return processedColumns;
			}
		},
		link: function(scope, elem, attrs) {
			attrs.$observe('fieldList', function(value) {
				scope.fieldList = (value) ? value.split(','): [];
			});
		}
	};
});
;
/*! RESOURCE: /scripts/directive.snFilterRelatedListSelect.js */
angular.module("sn.filter_widget").directive("snFilterRelatedListSelect", function(i18n, filterAPI, snFilterInstanceErrors) {
	"use strict";
	return {
		restrict: "E",
		replace: true,
template: '<select ng-model="predicate.comparison.table" ng-change="updateRelatedListModel(predicate.comparison.table)" ng-options="rl.value as rl.label for rl in relatedLists" class="form-control"><option></option></select>',
		link: function(scope, element) {
			render();
			function render() {
				setTimeout(function() {
					element.select2({
						placeholder: i18n.getMessage("- Table -"),
						width : "25%",
						dropdownParent: element.context.parentElement,
					});
				});
			}
			scope.$on("snfilter:reset_related_list_select", clear);
			scope.$on("snfilter:update_predicate_base_table", clear);
			function clear(){
				element.select2("val", "")
			}
		}
	}
});
;
/*! RESOURCE: /scripts/directive.snFilterRelatedListComparison.js */
angular.module("sn.filter_widget").directive("snFilterRelatedListComparison", function(getTemplateUrl, i18n, snCustomEvent) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl("sn_related_list_comparison.xml"),
		controller: function($scope, $element) {
			var rlcm;
			var container = $scope.popoverConfig.container;
			$scope.popoverConfig = {
				closeBtnClass: "filter-related-list-close-button",
				placement: 'bottom',
				container: angular.isDefined(container) ? container : $element,
				viewport :{
					selector: '.related-list-query-section',
					padding: 10
				},
template: '<div class="popover" role="dialog"><div class="arrow"></div><div class="popover-header popover-header-buttons"><h4>' + i18n.getMessage("Quantity") + '</h4><div class="pull-right"> <button type="button" class="btn btn-icon btn-sm icon-cross filter-related-list-close-button"><span class="sr-only">Close</span></button> </div> </div><div class="popover-content filter-related-list-comparison"></div></div>'
			};
$scope.ref = 'related_comparison';
			$scope.closeEvent = "snfilter:close_related_comparison";
			var relatedComparisonsModel = {
				">=" : {
					operatorLabel : i18n.getMessage("Greater than or Equal to"),
					operatorValue : ">="
				},
				">" : {
					operatorLabel : i18n.getMessage("Greater than"),
					operatorValue : ">"
				},
				"<=" : {
					operatorLabel : i18n.getMessage("Less than or Equal to"),
					operatorValue : "<="
				},
				"<" : {
					operatorLabel : i18n.getMessage("Less than"),
					operatorValue : "<"
				},
				"=" : {
					operatorLabel : i18n.getMessage("Equal to"),
					operatorValue : "="
				},
				"=0" : {
					operatorLabel : i18n.getMessage("None"),
					operatorValue : "=0",
					none : true
				},
				"BETWEEN" : {
					operatorLabel : i18n.getMessage("Between"),
					operatorValue : "BETWEEN",
					between : true
				}
			};
			$scope.relatedComparisonOperators = Object.keys(relatedComparisonsModel).map(function(key, index, array){
				return relatedComparisonsModel[key];
			});
			function RelatedListComparisonModel(operator, value){
				if (operator)
					this.model = angular.extend({}, relatedComparisonsModel[operator]);
				else {
					this.model = this._getDefaultModel();
					value = "1";
				}
				this.initialize(value);
			}
			RelatedListComparisonModel.prototype = {
				initialize : function(value) {
					if (!this.model)
						throw "No Model set in RelatedListComparisonModel";
					this.updateValue(value);
					if (this.model.between)
						this._initBetween();
					else
						this.model.between = false;
				},
				updateValue : function(value){
					this.model.value = value;
					this.model.displayValue = this._getDisplayValue(value);
				},
				updateOperator : function(operator){
					var operatorModel = relatedComparisonsModel[operator];
					this.model.operatorValue = operatorModel.operatorValue;
					this.model.operatorLabel = operatorModel.operatorLabel;
					this.model.none = (typeof operatorModel.none !== "undefined");
					this.model.between = (typeof operatorModel.between !== "undefined");
					if (this.model.between)
						this._initBetween();
					else
						this._sanitizeValue();
					if(this.model.none){
						this.updateValue("0");
						this.model.displayValue = "";
						this.model.operatorLabel = "No";
					}
				},
				getModel : function() {
					return this.model;
				},
				_sanitizeValue : function(){
					if (!this.model || !this.model.value)
						return;
					if (this.model.value.indexOf("@") > -1)
						this.updateValue(this.model.value.split("@")[0]);
				},
				_initBetween : function() {
					if (!typeof this.model.value === "string")
						return
					var splitValue = this.model.value.split("@");
					if (splitValue.length == 1)
						splitValue.push(splitValue[0]);
					this.updateValue(splitValue.join("@"));
					this.model.firstBetweenValue = splitValue[0];
					this.model.secondBetweenValue = splitValue[1];
				},
				_getDefaultModel : function(){
					var model = angular.extend({}, relatedComparisonsModel[">="]);
					return model;
				},
				_getDisplayValue : function(value) {
					value = value + "";
					var andString;
					if (!value)
						return "";
					if (value.indexOf("@") > -1){
						andString = i18n.getMessage(" " + i18n.getMessage("and") + " ");
						return value.split("@").join(andString);
					} else
						return value;
				}
			};
			$scope.relatedListComparisonOperatorChange = relatedListComparisonOperatorChange;
			$scope.relatedListComparisonValueChange = relatedListComparisonValueChange;
			$scope.formatBetween = formatBetween;
			$scope.closePopover = closePopover;
			activate();
			function activate(){
				rlcm = new RelatedListComparisonModel($scope.predicate.comparison.quantity.operator, $scope.predicate.comparison.quantity.value);
				$scope.relatedListComparisonModel = rlcm.getModel();
				updatePredicateComparison();
			}
			function relatedListComparisonOperatorChange(operator){
				if (!operator)
					return;
				rlcm.updateOperator(operator);
				$scope.relatedListComparisonModel = rlcm.getModel();
				$scope.disabledInput = ($scope.relatedListComparisonModel.none === true);
				updatePredicateComparison();
				snCustomEvent.fire('snfilter:conditionChange');
			}
			function relatedListComparisonValueChange (value){
				if (!value)
					return;
				rlcm.updateValue(value);
				$scope.relatedListComparisonModel = rlcm.getModel();
				updatePredicateComparison();
				snCustomEvent.fire('snfilter:conditionChange');
			}
			$scope.$watch('predicate.comparison.quantity.value', function(n, o) {
				if (n !== o && n === undefined)
					updatePredicateComparison();
			});
			$scope.$watch('predicate.comparison.table', function(n, o) {
				if (n !== o && n === undefined)
					$scope.removeTable();
			});
			function updatePredicateComparison(){
				$scope.predicate.comparison.quantity.operator_label = $scope.relatedListComparisonModel.operatorLabel;
				$scope.predicate.comparison.quantity.operator = $scope.relatedListComparisonModel.operatorValue;
				$scope.predicate.comparison.quantity.value = $scope.relatedListComparisonModel.value;
				$scope.predicate.comparison.quantity.display_value = $scope.relatedListComparisonModel.displayValue;
			}
			function closePopover(){
				$scope.$broadcast($scope.closeEvent);
			}
			function formatBetween(){
				if (!$scope.relatedListComparisonModel.firstBetweenValue || !$scope.relatedListComparisonModel.secondBetweenValue)
					return;
				var value = $scope.relatedListComparisonModel.firstBetweenValue + "@" + $scope.relatedListComparisonModel.secondBetweenValue;
				relatedListComparisonValueChange(value);
			}
		},
		link : function(scope, element){
			angular.element(element).on('click', '.filter-related-list-close-button', function(e){
				scope.closePopover();
			})
		}
	}
});
;
/*! RESOURCE: /scripts/directive.snDisabledExplanation.js */
angular.module("sn.filter_widget").directive("snDisabledExplanation", function() {
	"use strict";
	var DISABLED_CLASS = "sn-disabled-explanation";
	function makeHelp(placement, message) {
		var span = document.createElement("span");
		span.style = "display: inline-block;";
		span.setAttribute("title", message);
		span.setAttribute("tabindex", 0);
		span.setAttribute("data-placement", placement);
		span.classList.add(DISABLED_CLASS);
		return span;
	}
	return {
		restrict: "A",
		scope: {
			snDisabledExplanation: "@",
			placement: "@"
		},
		link: function($scope, $element) {
			$scope.$watch(function() {
				var isDisabled = $element.prop("disabled");
				var isWrapped = $element.parent().is("." + DISABLED_CLASS);
				if (isDisabled && !isWrapped) {
					$element.wrap(makeHelp($scope.placement, $scope.snDisabledExplanation));
				}
				if (!isDisabled && isWrapped) {
					$element.unwrap();
				}
			});
		}
	};
});
;
/*! RESOURCE: /scripts/elements/directive.formFilterWidget.js */
angular.module('sn.filter_widget').directive('formFilterWidget', function(snCustomEvent, $http) {
	return {
		scope: {
			ref: '@',
			initialQuery: '@',
			dependentField: '@',
			dependentTable: '@',
			restrictedFields: '@',
			extendedOperators: '@',
			staticDependent: '@',
			allowOrder: '=',
			allowRelatedListQuery: '=',
            		subjectCriteria: '=',
			securityAttributes: '=',
			showConditionCount: '=',
			usageContext: '@'
		},
template: "<div class='form-control-static' ng-if='readOnly' ng-bind='readOnlyText'></div>" +
"<sn-filter-widget ng-if='table' ng-show='!readOnly' table='{{ table }}' filter-config='filterConfig' />",
		replace: false,
		controller: function($scope) {
			var readOnlyFilter = "";
			$scope.$watch('readOnly', function(newValue) {
				if (newValue)
					updateReadOnlyFilter($scope.filterConfig.encodedQuery);
			})
			$scope.$watch('filterConfig.encodedQuery', function(newValue) {
				updateReadOnlyFilter(newValue);
			});
			function updateReadOnlyFilter(filter) {
				if (!$scope.readOnly)
					return;
				if (filter == readOnlyFilter)
					return;
$http.get('/api/now/ui/breadcrumbs?table=' + $scope.table + '&query=' + encodeURIComponent(filter)).then(function(response) {
					if (!response || !response.data || !response.data.result || !response.data.result.breadcrumb)
						setReadOnlyFilterData(filter, "Error while parsing filter");
					var filterPieces = response.data.result.breadcrumb
						.filter(function(item) {
							return !!item.value;
						})
						.map(function(item) {
							return item.label;
						});
					setReadOnlyFilterData(filter, filterPieces.join(" > ") || "(empty)");
				})
			}
			function setReadOnlyFilterData(filter, filterString) {
				readOnlyFilter = filter;
				$scope.readOnlyText = filterString;
			}
		},
		link: function(scope, element) {
			var dotWalk = true;
			if (scope.subjectCriteria) {
				scope.table = "sys_df_data_filtration";
				dotWalk = false;
			} else if (scope.securityAttributes) {
				scope.table = "sys_security_attribute";
				dotWalk = false;
			} else {
				scope.table = scope.staticDependent || setupDependent();
			}
			var fieldList = scope.restrictedFields ? scope.restrictedFields.split(';') : [];
			scope.filterConfig = {
				encodedQuery: scope.initialQuery,
				outputType: "encoded_query",
				sets: true,
				dotWalking: dotWalk,
				saveFilter: false,
				loadFilter: false,
				clearFilter: false,
				closeFilter: false,
				runFilter: false,
				testFilter: scope.showConditionCount,
				relatedListQueryConditions: scope.allowRelatedListQuery,
				sortFilter: scope.allowOrder,
                isSubjectCriteria: scope.subjectCriteria,
				isSecurityAttributes: scope.securityAttributes,
				watchConfig: true,
				mode: 'automatic',
				fieldList: fieldList,
				popoverContainer: 'form[id="' + element.closest('form[id]').attr('id') + '"]'
			};
			scope.$on('snfilter:update_query', function(someScope, queryString) {
				document.getElementById(scope.ref).value = queryString;
				scope.filterConfig.encodedQuery = queryString;
				onChange(scope.ref);
			});
			g_event_handlers.push({
				fieldName: scope.ref,
				handler: function(control, oldValue, newValue) {
					if (newValue == scope.filterConfig.encodedQuery)
						return;
					scope.$broadcast("snfilter:initialize_query", newValue);
					if (!scope.$root.$$phase)
						scope.$apply();
				}
			})
			function setupDependent() {
				if (g_form.hasField(scope.dependentField)) {
					g_event_handlers.push({
						fieldName: scope.dependentField,
						handler: function(control, oldValue, newValue) {
							scope.table = scope.dependentTable = newValue;
							if (!scope.table) {
								g_form.setValue(scope.ref, "");
								return;
							}
							scope.$broadcast('snfilter:update_table', {table: scope.table});
							if (!scope.$root.$$phase)
								scope.$apply();
						}
					})
				}
				return g_form.getValue(scope.dependentField);
			}
			g_form.registerHandler(scope.ref, {
				setReadOnly: function(value) {
					scope.readOnly = value;
					if (!scope.$root.$$phase)
						scope.$apply();
				}
			});
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/table_data/angular/_module.js */
angular.module('sn.common.table_data', []);
;
/*! RESOURCE: /scripts/sn/common/table_data/angular/ChoiceAPI.js */
angular.module('sn.common.table_data').factory('ChoiceAPI', function($http) {
	"use strict";
	return {
		getChoiceList: function(table, params) {
return $http.get('/api/now/ui/choice_list/' + table, {params: params || {}});
		},
		getDependentChoiceList: function(table, params) {
return $http.get('/api/now/ui/choice_list/' + table + '/dependent', {params: params || {}});
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/table_data/angular/DateTimeAPI.js */
angular.module('sn.common.table_data').factory('DateTimeAPI', function($http) {
    "use strict";
    return {
        getDateTime: function(tableName) {
        	var config = {};
        	if(tableName)
        		config.params = {table_name: tableName};
return $http.get("/api/now/ui/date_time", config);
        }
    }
});
;
/*! RESOURCE: /scripts/sn/common/table_data/angular/EmbeddedListAPI.js */
angular.module('sn.common.table_data').factory('EmbeddedListAPI', function($http) {
	"use strict";
	return {
		getRelatedLists: function(table, params) {
return $http.get('/api/now/ui/related_list/embedded/' + table, {params: params || {}});
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/table_data/angular/LabelAPI.js */
angular.module('sn.common.table_data').factory('LabelAPI', function($http) {
	"use strict";
	return {
		getLabels: function(table, sysId) {
return $http.get('/api/now/ui/labels/retrieve/' + table + '/' + sysId);
		},
		getLabelsForMultipleRecords: function(table, sysIds) {
return $http.get('/api/now/ui/labels/retrieve_multiple/' + table + '/' + sysIds);
		},
		getRecentLabels: function() {
return $http.get('/api/now/ui/labels/retrieve_recent');
		},
		createLabel: function(table, sysId, data) {
return $http.put('/api/now/ui/labels/create/' + table + '/' + sysId, data);
		},
		createLabelForMultiple: function(table, sysIds, data) {
return $http.put('/api/now/ui/labels/create_multiple/' + table + '/' + sysIds, data);
		},
		assignLabel: function(table, sysId, labelId) {
return $http.post('/api/now/ui/labels/assign/' + table + '/' + sysId + '/' + labelId, {});
		},
		assignMultiple: function(table, sysIds, labelId) {
return $http.post('/api/now/ui/labels/assign_multiple/' + table + '/' + sysIds + '/' + labelId, {});
		},
		removeLabel: function(table, sysId, labelId) {
return $http.post('/api/now/ui/labels/remove/' + table + '/' + sysId + '/' + labelId, {});
		},
		removeLabelFromMultiple: function(table, sysIds, labelId) {
return $http.post('/api/now/ui/labels/remove_multiple/' + table + '/' + sysIds + '/' + labelId, {});
		},
		deleteLabel: function(labelId) {
return $http.delete('/api/now/ui/labels/delete/' + labelId, {});
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/table_data/angular/ListAPI.js */
angular.module('sn.common.table_data').factory('ListAPI', function($http, glideUrlBuilder) {
	"use strict";
	function traversalPatternCheck(encodedURL) {
		const decodedURL = decodeURIComponent(encodedURL);
const traversalPattern = /(\.\.\/|\\)/g;
		if (traversalPattern.test(decodedURL)) {
			throw new Error('Security error: Traversal pattern detected in URL: ' + decodedURL);
		}
	}
	return {
		getInitializedList: function(table, data, apiVersion, params) {
var url = glideUrlBuilder.newGlideUrl('/api/now/' + apiVersion + 'ui/init_list/' + table);
			traversalPatternCheck(url.getURL(params));
			return $http.post(url.getURL(params), data || {});
		},
		getListLayout: function(table, params, apiVersion) {
apiVersion = angular.isUndefined(apiVersion) ? '' : apiVersion + '/';
traversalPatternCheck('/api/now/' + apiVersion + 'ui/table_layout/' + table);
return $http.get('/api/now/' + apiVersion + 'ui/table_layout/' + table, {params: params || {}});
		},
		getListData: function(table, data, apiVersion, params) {
apiVersion = angular.isUndefined(apiVersion) ? '' : apiVersion + '/';
var url = glideUrlBuilder.newGlideUrl('/api/now/' + apiVersion + 'ui/table/' + table);
			traversalPatternCheck(url.getURL(params));
			return $http.post(url.getURL(params), data || {});
		},
		getRecordSetData: function(table, data, apiVersion, params) {
apiVersion = angular.isUndefined(apiVersion) ? '' : apiVersion + '/';
var url = glideUrlBuilder.newGlideUrl('/api/now/' + apiVersion + 'ui/table/' + table + '/records');
			traversalPatternCheck(url.getURL(params));
			return $http.post(url.getURL(params), data || {});
		},
		getListGroup: function(table, data, apiVersion, params) {
apiVersion = angular.isUndefined(apiVersion) ? '' : apiVersion + '/';
var url = glideUrlBuilder.newGlideUrl('/api/now/' + apiVersion + 'ui/group/' + table);
			traversalPatternCheck(url.getURL(params));
			return $http.post(url.getURL(params), data || {});
		},
		getListCalculations: function(table, data, apiVersion, params) {
var url = glideUrlBuilder.newGlideUrl('/api/now/ui/calculations/' + table)
			traversalPatternCheck(url.getURL(params));
			return $http.post(url.getURL(params), data || {});
		},
		updateListCalculations: function(table, data, apiVersion, params) {
var url = glideUrlBuilder.newGlideUrl('/api/now/ui/calculations/' + table + '/update');
			traversalPatternCheck(url.getURL(params));
			return $http.post(url.getURL(params), data || {});
		},
		saveDefaultSort: function(table, data, apiVersion, params) {
apiVersion = angular.isUndefined(apiVersion) ? '' : apiVersion + '/';
var url = glideUrlBuilder.newGlideUrl('/api/now/' + apiVersion + 'ui/table/' + table + '/default_sort');
			traversalPatternCheck(url.getURL(params));
			return $http.post(url.getURL(params), data || {});
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/table_data/angular/ListEditAPI.js */
angular.module('sn.common.table_data').factory('ListEditAPI', function($http) {
	"use strict";
	return {
		getListEditRows: function(table, params) {
return $http.get('/api/now/ui/table_edit/' + table, {params: params || {}});
		},
		updateListRows: function(table, data) {
return $http.put('/api/now/ui/table_edit/' + table, data);
		},
		createRecord: function(table, data) {
return $http.post('/api/now/ui/record/' + table, data);
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/table_data/angular/QueryAPI.js */
angular.module('sn.common.table_data').factory('QueryAPI', function($http) {
	"use strict";
	return {
		getQueryParsedAsArray: function(table, params) {
return $http.get('/api/now/ui/query_parse/' + table, {params: params || {}});
		},
		getQueryParsedAsMap: function(table, params) {
return $http.get('/api/now/ui/query_parse/' + table + '/map', {params: params || {}});
		},
		getBreadcrumbs: function(table, params) {
return $http.get('/api/now/ui/breadcrumbs?table=' + table, {params: params || {}})
		},
		getQueryCollection : function(table, params) {
return $http.get('/api/now/ui/breadcrumbs/collection?table=' + table, {params: params || {}})
		},
		getQueryTermFromContext : function(params) {
return $http.get('/api/now/list_query', {params: params || {}});
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/table_data/angular/RelatedListAPI.js */
angular.module('sn.common.table_data').factory('RelatedListAPI', function($http) {
	"use strict";
	return {
		getRelatedLists: function(table, params) {
return $http.get('/api/now/ui/related_list/related/' + table, {params: params || {}});
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/table_data/angular/StackAPI.js */
angular.module('sn.common.table_data').factory('StackAPI', function($http) {
	"use strict";
	return {
		pushState : function(params) {
return $http.put('/api/now/ui/stack', {params: params || {}});
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/table_data/angular/UIActionsAPI.js */
angular.module('sn.common.table_data').factory('UIActionsAPI', function($http) {
	"use strict";
var URL = '/api/now/ui/ui_action/';
	return {
		getListBannerUIActions: function(table, params) {
return $http.get(URL + table + '/for_list_banner', {params: params || {}});
		},
		getListLinkUIActions: function(table, params) {
return $http.get(URL + table + '/for_list_links', {params: params || {}});
		},
		getChoiceListUIActions: function(table, params) {
return $http.get(URL + table + '/for_list_choice_list', {params: params || {}});
		},
		getContextMenuUIActions: function(table, sysId) {
return $http.get(URL + table + '/for_list_context_menu?sysparm_sys_id=' + sysId);
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/table_data/FormSubmitter.js */
function FormSubmitter(id, method, action) {
	this.form = document.getElementById('form_' + id);
	if (this.form)
		this.form.parentNode.removeChild(this.form);
	this.form = document.createElement('form');
	this.form.id = 'form_' + id;
	this.form.class = 'pane-target';
	this.form.method = method;
	this.form.action = action;
	this.formElements = {};
	this.submitParameters = {};
	this.doNotSubmitParameters = {};
	var body = document.getElementsByTagName('body')[0];
	body.appendChild(this.form);
}
FormSubmitter.prototype = {
	setFormTarget: function (target) {
		this.form.target = target;
	},
	setParameter: function (name, value) {
		this.formElements[name] = value;
	},
	setSubmitParameter: function (name, value) {
		this.submitParameters[name] = value;
	},
	setDoNotSubmitParameter: function (name, value) {
		this.doNotSubmitParameters[name] = value;
	},
	setParametersMap: function (map) {
		this._addNameValuePairs(map, this.setParameter);
	},
	setSubmitParametersMap: function (map) {
		this._addNameValuePairs(map, this.setSubmitParameter);
	},
	setDoNotSubmitParametersMap: function (map) {
		this._addNameValuePairs(map, this.setDoNotSubmitParameter);
	},
	submitForm: function () {
		this._setFormElementValues();
		this._addInputElements();
		try {
			this.form.submit();
		} catch (ex) {
		}
		this._cleanUp();
	},
	_addNameValuePairs: function (map, method) {
		for (var name in map)
			if (map.hasOwnProperty(name))
				method.apply(this, [name, map[name]]);
	},
	_setFormElementValues: function () {
		for (var name in this.submitParameters) {
			if (this.submitParameters.hasOwnProperty(name)) {
				if (this.doNotSubmitParameters[name])
					continue;
				this.setParameter(name, this.submitParameters[name]);
			}
		}
	},
	_addInputElements: function () {
		for (var name in this.formElements) {
			if (this.formElements.hasOwnProperty(name)) {
				var value = !this.formElements[name] ? '' : this.formElements[name];
				this._createInputElement(name, value, this.form);
			}
		}
	},
	_cleanUp: function () {
		this.formElements = {};
	},
	_createInputElement: function (name, value, form) {
		if (!value)
			value = '';
		var inputElement = document.createElement('input');
		inputElement.id = name;
		inputElement.type = 'HIDDEN';
		inputElement.name = name;
		inputElement.value = value;
		form.appendChild(inputElement);
	}
};
;
/*! RESOURCE: /scripts/sn/common/table_data/GlideQueryOperator.js */
(function(exports, console, undefined) {
	'use strict';
	function GlideQueryOperator() {
	}
	GlideQueryOperator.DICTIONARY = {
		AFTER: {
			dateType: true
		},
		ANYTHING: {
			key: 'ANYTHING',
			emptyValue: true
		},
		ASCENDING: {},
		ATORAFTER: {
			dateType: true
		},
		ATORBEFORE: {
			dateType: true
		},
		BEFORE: {
			dateType: true
		},
		BETWEEN: {
			dateType: true
		},
		CHANGESFROM: {
			dateType: true
		},
		CHANGESTO: {
			dateType: true
		},
		DATELESS: {
			dateType: true
		},
		DATEMORE: {
			dateType: true
		},
		DESCENDING: {
			key: 'descending',
			emptyValue: true
		},
		DIFFERENTDATE: {
			dateType: true
		},
		DIFFERENT: {},
		DYNAMIC: {},
		EMPTY: {},
		EMPTYSTRING: {
			key: 'EMPTYSTRING',
			emptyValue: true
		},
		ENDSWITH: {
			key: 'ENDSWITH'
		},
		GREATERTHANFIELD: {},
		GREATERTHAN: {},
		GREATERTHANORISFIELD: {},
		GREATERTHANORIS: {},
		HAS: {},
		INSTANCEOF: {},
		ISNOT: {},
		IS: {
			key: '='
		},
		LESSTHANFIELD: {},
		LESSTHAN: {},
		LESSTHANORISFIELD: {},
		LESSTHANORIS: {},
		LIKE: {
			key: 'LIKE'
		},
		MAXIMUM: {},
		MINIMUM: {},
		NOTEMPTY: {},
		NOTIN: {},
		NOTLIKE: {},
		NOTON: {
			dateType: true
		},
		ON: {
			dateType: true
		},
		RELATIVE: {
			dateType: true
		},
		SAMEASDATE: {
			dateType: true
		},
		SAMEAS: {},
		SINCE: {
			key: 'SINCE',
			emptyValue: true,
			dateType: true
		},
		STARTSWITH: {
			key: 'STARTSWITH'
		},
		ISEMPTY: {
			key: 'ISEMPTY',
			emptyValue: true
		},
		ISNOTEMPTY: {
			key: 'ISNOTEMPTY',
			emptyValue: true
		},
		MAX: {
			key: 'max',
			emptyValue: true
		},
		MIN: {
			key: 'min',
			emptyValue: true
		},
		SUM: {
			key: 'sum',
			emptyValue: true
		},
		VALCHANGES: {
			key: 'VALCHANGES',
			emptyValue: true
		}
	};
	GlideQueryOperator.isEmptyType = function(operatorKey) {
		var op = GlideQueryOperator.DICTIONARY[operatorKey.toUpperCase()];
		if (!op) {
			return false;
		}
		return !!op.emptyValue;
	};
	GlideQueryOperator.isDateType = function(operatorKey) {
		var op = GlideQueryOperator.DICTIONARY[operatorKey.toUpperCase()];
		if (!op) {
			return false;
		}
		return !!op.dateType;
	};
	exports.GlideQueryOperator = GlideQueryOperator;
})(window, typeof console !== 'undefined' ? console : undefined);
;
/*! RESOURCE: /scripts/sn/common/table_data/angular/GlideQueryOperator.js */
angular.module('sn.common.table_data').factory('GlideQueryOperator', function($window) {
	'use strict';
	return $window.GlideQueryOperator;
});
;
/*! RESOURCE: /scripts/sn/common/table_data/GlideQuery.js */
(function(exports, GlideQueryOperator, console, undefined) {
	'use strict';
	if (typeof console === 'undefined') {
		console = {
			log: function() {},
			error: function() {}
		};
	}
	function Subpredicate(params) {}
	Subpredicate.TYPE_COMPOUND = 'compound';
	Subpredicate.TYPE_COMPARISON = 'comparison';
	Subpredicate.create = function(params) {
		switch (params.type) {
			case Subpredicate.TYPE_COMPOUND:
				return Compound(params);
				break;
			case Subpredicate.TYPE_COMPARISON:
				return Comparison(params);
				break;
			default:
				throw 'Invalid subpredicate type';
		}
	};
	function Compound(params) {
		if (!(this instanceof Compound)) {
			return new Compound(params);
		}
		this.type = Subpredicate.TYPE_COMPOUND;
		this.compound_type = params.type;
		this.is_related = typeof params.is_related !== 'undefined' ? params.is_related : false;
		if (params.comparison)
			this.addRelatedComparison(params.comparison);
		switch (params.compound_type) {
			case Compound.TYPE_OR:
			case Compound.TYPE_AND:
				this.compound_type = params.compound_type;
				break;
			default:
				throw 'Invalid compound type';
		}
		this.subpredicates = [];
		if (typeof params.subpredicates !== 'undefined') {
			for (var i = 0, iM = params.subpredicates.length; i < iM; i++) {
				var subpredicate = Subpredicate.create(params.subpredicates[i]);
				if (!subpredicate) {
					continue;
				}
				this.subpredicates.push(subpredicate)
			}
		}
	}
	Compound.TYPE_OR = 'or';
	Compound.TYPE_AND = 'and';
	Compound.prototype = {
		isEmpty: function() {
			return this.subpredicates.length == 0;
		},
		addOr: function(insertAtIndex) {
			var index = typeof insertAtIndex === 'undefined' ? this.subpredicates.length : insertAtIndex;
			var compound = Compound({compound_type: 'or'});
			this.subpredicates.splice(index, 0, compound);
			return compound;
		},
		addAnd: function(insertAtIndex) {
			var index = typeof insertAtIndex === 'undefined' ? this.subpredicates.length : insertAtIndex;
			var compound = Compound({compound_type: 'and'});
			this.subpredicates.splice(index, 0, compound);
			return compound;
		},
		addComparison: function(comparison, insertAtIndex) {
			var index = typeof insertAtIndex === 'undefined' ? this.subpredicates.length : insertAtIndex;
			var comparison = Comparison(comparison);
			this.subpredicates.splice(index, 0, comparison);
			return comparison;
		},
		addRelatedComparison: function(comparison) {
			var comparison = Comparison(comparison);
			this.comparison = comparison;
			return comparison;
		},
		removeSubpredicate: function(subpredicate) {
			return _removeSubpredicate(this.subpredicates, subpredicate);
		},
		isRelated: function() {
			return this.is_related;
		},
		isValidRelatedComparison: function() {
			return !!this.comparison && this.comparison.isTableDefined() && this.comparison.isQuantityDefined();
		},
		setCompoundType: function(type) {
			switch (type) {
				case Compound.TYPE_OR:
				case Compound.TYPE_AND:
					this.compound_type = type;
					return true;
					break;
				case 'toggle':
					this.compound_type = this.compound_type === Compound.TYPE_OR ? Compound.TYPE_AND : Compound.TYPE_OR;
					return true;
					break;
			}
			return false;
		},
		toQueryString: function(options) {
			var subpredicates = this.subpredicates;
			var concatOperator = this.compound_type === Compound.TYPE_OR ? '^OR' : '^';
			var isPredicate = false;
			if ((typeof options !== 'undefined') && options.isPredicate) {
				isPredicate = true;
				concatOperator = '^NQ';
			}
			var queryString = '';
			for (var i = 0, iM = subpredicates.length; i < iM; i++) {
				if (isPredicate) {
					options = {
						allowKeywords: i == 0,
					};
				}
				var termString = subpredicates[i].toQueryString(options);
				if (termString !== '') {
					queryString += (i == 0 ? '' : concatOperator) + termString;
				}
			}
			if (this.isRelated() && this.isValidRelatedComparison())
				queryString = '^RLQUERY' + this.comparison.toQueryString() + (queryString !== '' ? '^' : '') + queryString + '^ENDRLQUERY';
			return queryString;
		}
	};
	function Comparison(comparison) {
		if (!(this instanceof Comparison)) {
			return new Comparison(comparison);
		}
		this.type = Subpredicate.TYPE_COMPARISON;
		this.column_type = comparison.column_type;
		this.field = comparison.field;
		this.field_label = comparison.field_label;
		this.operator = comparison.operator;
		this.operator_label = comparison.operator_label;
		this.value = comparison.value;
		this.display_value = comparison.display_value;
		this.goto_query = comparison.goto_query;
		this.term_label = comparison.term_label;
		this.term_label_fields = {
			field: this.field,
			operator: this.operator,
			value: this.value
		};
		if (comparison.reference_fields) {
			this.reference_fields = comparison.reference_fields;
		}
		if (typeof comparison.quantity !== "undefined") {
			this.table = comparison.table;
			this.table_label = comparison.table_label;
			this.options = comparison.options || [];
			this.quantity = comparison.quantity;
		}
	}
	Comparison.KEYWORDS_FIELD = '123TEXTQUERY321';
	Comparison.VARIABLE_TASK = 'variable_task';
	Comparison.VARIABLE_REQUEST = "variable_request";
	Comparison.TAG = "tag";
	Comparison.prototype = {
		hasField: function() {
			return typeof this.field !== 'undefined' && (this.field != null);
		},
		hasOperator: function() {
			return typeof this.operator !== 'undefined' && (this.operator != null);
		},
		hasValue: function() {
			return typeof this.value !== 'undefined' && (this.value != null);
		},
		hasQuantity: function() {
			return typeof this.quantity !== 'undefined' && (this.quantity != null && this.quantity !== {});
		},
		isRelated: function() {
			return this.hasQuantity();
		},
		getTermLabel: function() {
			if (this.term_label_fields.field === this.field && this.term_label_fields.operator === this.operator && this.term_label_fields.value === this.value) {
				if (typeof this.term_label !== 'undefined' && this.term_label != null) {
					return this.term_label;
				}
			}
			var operatorLabel = this.operator_label;
			switch (this.operator) {
				case '=':
				case '!=':
					operatorLabel = this.operator;
					break;
			}
			var valueLabel = (angular.isDefined(this.value) ? this.value : '');
			if (angular.isDefined(this.display_value) && this.display_value !== '') {
				valueLabel = this.display_value;
			}
			this.term_label = [
				this.field_label,
				operatorLabel,
				valueLabel
			].join(' ');
			return this.term_label;
		},
		isFieldKeywords: function() {
			return this.field === Comparison.KEYWORDS_FIELD;
		},
		addOption: function(option) {
			if (!this.isRelated())
				throw 'This comparison type does not contain options';
			if (this.options.indexOf(option) === -1)
				this.options.push(option);
		},
		removeOption: function(option) {
			if (!this.isRelated())
				throw 'This comparison type does not contain options';
			if (typeof this.options === 'undefined')
				throw 'No options found!';
			var index = typeof option !== 'number' ? undefined : option;
			if (typeof index === 'undefined') {
				for (var i = 0, l = this.options.length; i < l; i++) {
					if (this.options[i] === option) {
						index = i;
						break;
					}
				}
			}
			if (typeof index === 'undefined' || typeof this.options[index] === 'undefined')
				return false;
			this.options.splice(index, 1);
			return true;
		},
		addQuantity: function(operator, value) {
			this.quantity.operator = operator;
			this.quantity.value = value;
		},
		isTableDefined: function() {
			return !!this.table;
		},
		isQuantityDefined: function() {
			return !!this.quantity && !!this.quantity.operator && !!this.quantity.value;
		},
		isColumnVariable: function() {
			return this.isVariableRequest() || this.isVariableTask() || this.isQuestion();
		},
		isQuestion : function() {
			return this.column_type === 'questions';
		},
		isVariableTask: function() {
			return this.column_type === Comparison.VARIABLE_TASK;
		},
		isVariableRequest: function(){
			return this.column_type === Comparison.VARIABLE_REQUEST;
		},
		isColumnTag : function(){
			return this.column_type === Comparison.TAG;
		},
		toQueryString: function(options) {
			var s = '';
			if (!this.hasField() || !this.hasOperator()) {
				if (this.isRelated()) {
					s += this.table;
					s += ',';
					s += this.quantity.operator;
					s += this.quantity.value;
					if (typeof this.options !== "undefined"){
						s += this.options.length ? ',' : '';
						s += this.options.join();
					}
					return s;
				} else {
					return s;
				}
			}
			if (typeof options !== 'undefined' && !options.allowKeywords && this.isFieldKeywords()) {
				return s;
			}
			if (this.isColumnVariable()) {
					s += 'variables.';
			}
			if (this.isColumnTag()) {
				s += this.field;
				s += ".";
				s += this.value;
				s += this.operator;
				s += this.value;
			} else if (GlideQueryOperator.isEmptyType(this.operator)) {
				s += this.field;
				s += this.operator;
			} else if (this.hasField() && this.hasOperator() && this.hasValue()) {
				s += this.field;
				s += this.operator;
				s += this.escapeQueryValue(this.value);
			}
			return s;
		},
		escapeQueryValue: function(val) {
			if (!val)
				return val;
return String(val).replace(/\^\^/gm, "^").replace(/\^/gm, "^^");
		}
	};
	function QuerySort() {
	}
	QuerySort.create = function(fieldName, ascending) {
		return {
			column_name: fieldName,
			ascending: typeof ascending === 'undefined' ? true : ascending
		};
	};
	function GlideQuery(query) {
		this.predicates = [];
		this.order_by = [];
		this.group_by = [];
		if (typeof query !== 'undefined' && query != null) {
			var predicates = query.predicates;
			if (predicates && predicates.length > 0)
				for (var iP = 0; iP < predicates.length; iP++)
					this.predicates.push(Compound(predicates[iP]));
			this.order_by = [];
			if (query.order_by) {
				query.order_by.forEach(function(order) {
					this.order_by.push(_copy({}, order));
				}, this);
			}
			this.group_by = [];
			if (query.group_by) {
				this.group_by = Array.prototype.slice.call(query.group_by, 0);
			}
		} else {
			this.addPredicateCompound();
		}
	}
	GlideQuery._Subpredicate = Subpredicate;
	GlideQuery._Compound = Compound;
	GlideQuery._Comparison = Comparison;
	exports.GlideQuery = GlideQuery;
	GlideQuery.prototype = {
		hasPredicates: function() {
			return this.getPredicateCount() != 0;
		},
		getPredicateCount: function() {
			return this.predicates.length;
		},
		getPredicateIndex: function(predicate) {
			for (var i = 0; i < this.predicates.length; i++)
				if (this.predicates[i] === predicate)
					return i;
			throw 'No predicate index found!';
		},
		getPredicateCompound: function(index) {
			return this.predicates[index];
		},
		addPredicateCompound: function(isRelated) {
			isRelated = typeof isRelated !== 'undefined' ? isRelated : false;
			var compound = Compound({compound_type: 'or', is_related: isRelated});
			this.predicates.push(compound);
			return compound;
		},
		removePredicateCompound: function(predicate) {
			return _removeSubpredicate(this.predicates, predicate);
		},
		isEmpty: function(index) {
			return this.getQueryCompoundCount(typeof index === 'undefined' ? 0 : index) == 0;
		},
		getQueryCompoundCount: function(index) {
			if (this.predicates.length === 0)
				return 0;
			index = isNaN(index) ? 0 : index;
			return !this.predicates[index].subpredicates ? 0 : this.predicates[index].subpredicates.length;
		},
		getQueryCompound: function(index, predicateIndex) {
			if (typeof predicateIndex === 'undefined' || isNaN(predicateIndex))
				predicateIndex = 0;
			return this.predicates[predicateIndex].subpredicates[index];
		},
		addQueryCompound: function(predicateIndex) {
			if (this.predicates.length === 0)
				this.addPredicateCompound(false);
			if (typeof predicateIndex === 'undefined' || isNaN(predicateIndex))
				predicateIndex = 0;
			var compound = Compound({compound_type: Compound.TYPE_AND});
			this.predicates[predicateIndex].subpredicates.push(compound);
			return compound;
		},
		removeQueryCompound: function(compound, predicateIndex) {
			if (typeof predicateIndex === 'undefined' || isNaN(predicateIndex))
				predicateIndex = 0;
			if (this.predicates.length === 0)
				return false;
			return _removeSubpredicate(this.predicates[predicateIndex].subpredicates, compound);
		},
		setSort: function(fieldName) {
			var fieldSort = this.getSort(fieldName);
			if (fieldSort) {
				fieldSort.ascending = fieldSort.ascending ? false : true;
			} else {
				this.order_by.push(
					QuerySort.create(fieldName)
				);
			}
		},
		getSort: function(fieldName) {
			for (var i = 0; i < this.order_by.length; i++) {
				if (this.order_by[i].column_name === fieldName) {
					return this.order_by[i];
				}
			}
		},
		getFirstSort: function() {
			if (this.order_by.length > 0) {
				return this.order_by[0];
			}
			return null;
		},
		clearSort: function() {
			this.order_by.length = 0;
		},
		setGroupBy: function(field) {
			this.group_by = [field];
		},
		getGroupBy: function() {
			if (this.group_by.length > 0) {
				return this.group_by[0];
			}
		},
		toQueryString: function() {
			var queryString = '', relatedQueryString = '';
			for (var i = 0, l = this.predicates.length; i < l; i++)
				if (!this.predicates[i].isRelated())
					queryString += this.predicates[i].toQueryString({isPredicate: true});
				else
					if (this.predicates[i].toQueryString() !== '')
						relatedQueryString += this.predicates[i].toQueryString({isPredicate: true});
			if (this.group_by.length > 0) {
				for (var i = 0; i < this.group_by.length; i++) {
					queryString += '^GROUPBY' + this.group_by[i];
				}
			}
			if (this.order_by.length > 0) {
				for (var i = 0; i < this.order_by.length; i++) {
					queryString += this.order_by[i].ascending ? '^ORDERBY' : '^ORDERBYDESC';
					queryString += this.order_by[i].column_name;
				}
			}
			return queryString + relatedQueryString;
		},
		toQueryObject: function() {
			return JSON.parse(JSON.stringify(this));
		}
	};
	function _removeSubpredicate(subpredicates, subpredicate) {
		var index = typeof subpredicate !== 'number' ? undefined : subpredicate;
		if (typeof index === 'undefined') {
			for (var i = 0, iM = subpredicates.length; i < iM; i++) {
				if (subpredicates[i] === subpredicate) {
					index = i;
					break;
				}
			}
		}
		if (typeof index === 'undefined' || typeof subpredicates[index] === 'undefined') {
			return false;
		}
		subpredicates.splice(index, 1);
		return true;
	}
	function _copy(dest, src) {
		for (var prop in src) {
			if (Object.prototype.hasOwnProperty.call(src, prop)) {
				dest[prop] = src[prop];
			}
		}
		return dest;
	}
})(window, window.GlideQueryOperator, typeof console !== 'undefined' ? console : undefined);
;
/*! RESOURCE: /scripts/sn/common/table_data/angular/GlideQuery.js */
angular.module('sn.common.table_data').factory('GlideQuery', function($window, GlideQueryOperator) {
	'use strict';
	return $window.GlideQuery;
});
;
;
/*! RESOURCE: /scripts/sn/common/table_data/js_includes_table_data.js */
;
/*! RESOURCE: /scripts/js_includes_filter_widget.js */

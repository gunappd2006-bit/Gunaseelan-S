/*! RESOURCE: /scripts/app.ngFormElements/app.ngFormElements.js */
angular.module('sn.ngform', [
	'sn.ngform.elements',
	'sn.common.messaging'
]);
;
/*! RESOURCE: /scripts/app.ngFormElements/thirdparty/moment.min.noConflict.js */
(function(global) {
	if (!global.moment) {
/*! RESOURCE: /scripts/app.ngFormElements/thirdparty/moment.min.js */
//! moment.js
//! version : 2.29.4
//! authors : Tim Wood, Iskren Chernev, Moment.js contributors
//! license : MIT
//! momentjs.com
!function(e,t){"object"==typeof exports&&"undefined"!=typeof module?module.exports=t():"function"==typeof define&&define.amd?define(t):e.moment=t()}(this,function(){"use strict";var H;function f(){return H.apply(null,arguments)}function a(e){return e instanceof Array||"[object Array]"===Object.prototype.toString.call(e)}function F(e){return null!=e&&"[object Object]"===Object.prototype.toString.call(e)}function c(e,t){return Object.prototype.hasOwnProperty.call(e,t)}function L(e){if(Object.getOwnPropertyNames)return 0===Object.getOwnPropertyNames(e).length;for(var t in e)if(c(e,t))return;return 1}function o(e){return void 0===e}function u(e){return"number"==typeof e||"[object Number]"===Object.prototype.toString.call(e)}function V(e){return e instanceof Date||"[object Date]"===Object.prototype.toString.call(e)}function G(e,t){for(var n=[],s=e.length,i=0;i<s;++i)n.push(t(e[i],i));return n}function E(e,t){for(var n in t)c(t,n)&&(e[n]=t[n]);return c(t,"toString")&&(e.toString=t.toString),c(t,"valueOf")&&(e.valueOf=t.valueOf),e}function l(e,t,n,s){return Pt(e,t,n,s,!0).utc()}function m(e){return null==e._pf&&(e._pf={empty:!1,unusedTokens:[],unusedInput:[],overflow:-2,charsLeftOver:0,nullInput:!1,invalidEra:null,invalidMonth:null,invalidFormat:!1,userInvalidated:!1,iso:!1,parsedDateParts:[],era:null,meridiem:null,rfc2822:!1,weekdayMismatch:!1}),e._pf}function A(e){if(null==e._isValid){var t=m(e),n=j.call(t.parsedDateParts,function(e){return null!=e}),n=!isNaN(e._d.getTime())&&t.overflow<0&&!t.empty&&!t.invalidEra&&!t.invalidMonth&&!t.invalidWeekday&&!t.weekdayMismatch&&!t.nullInput&&!t.invalidFormat&&!t.userInvalidated&&(!t.meridiem||t.meridiem&&n);if(e._strict&&(n=n&&0===t.charsLeftOver&&0===t.unusedTokens.length&&void 0===t.bigHour),null!=Object.isFrozen&&Object.isFrozen(e))return n;e._isValid=n}return e._isValid}function I(e){var t=l(NaN);return null!=e?E(m(t),e):m(t).userInvalidated=!0,t}var j=Array.prototype.some||function(e){for(var t=Object(this),n=t.length>>>0,s=0;s<n;s++)if(s in t&&e.call(this,t[s],s,t))return!0;return!1},Z=f.momentProperties=[],z=!1;function $(e,t){var n,s,i,r=Z.length;if(o(t._isAMomentObject)||(e._isAMomentObject=t._isAMomentObject),o(t._i)||(e._i=t._i),o(t._f)||(e._f=t._f),o(t._l)||(e._l=t._l),o(t._strict)||(e._strict=t._strict),o(t._tzm)||(e._tzm=t._tzm),o(t._isUTC)||(e._isUTC=t._isUTC),o(t._offset)||(e._offset=t._offset),o(t._pf)||(e._pf=m(t)),o(t._locale)||(e._locale=t._locale),0<r)for(n=0;n<r;n++)o(i=t[s=Z[n]])||(e[s]=i);return e}function q(e){$(this,e),this._d=new Date(null!=e._d?e._d.getTime():NaN),this.isValid()||(this._d=new Date(NaN)),!1===z&&(z=!0,f.updateOffset(this),z=!1)}function h(e){return e instanceof q||null!=e&&null!=e._isAMomentObject}function B(e){!1===f.suppressDeprecationWarnings&&"undefined"!=typeof console&&console.warn&&console.warn("Deprecation warning: "+e)}function e(r,a){var o=!0;return E(function(){if(null!=f.deprecationHandler&&f.deprecationHandler(null,r),o){for(var e,t,n=[],s=arguments.length,i=0;i<s;i++){if(e="","object"==typeof arguments[i]){for(t in e+="\n["+i+"] ",arguments[0])c(arguments[0],t)&&(e+=t+": "+arguments[0][t]+", ");e=e.slice(0,-2)}else e=arguments[i];n.push(e)}B(r+"\nArguments: "+Array.prototype.slice.call(n).join("")+"\n"+(new Error).stack),o=!1}return a.apply(this,arguments)},a)}var J={};function Q(e,t){null!=f.deprecationHandler&&f.deprecationHandler(e,t),J[e]||(B(t),J[e]=!0)}function d(e){return"undefined"!=typeof Function&&e instanceof Function||"[object Function]"===Object.prototype.toString.call(e)}function X(e,t){var n,s=E({},e);for(n in t)c(t,n)&&(F(e[n])&&F(t[n])?(s[n]={},E(s[n],e[n]),E(s[n],t[n])):null!=t[n]?s[n]=t[n]:delete s[n]);for(n in e)c(e,n)&&!c(t,n)&&F(e[n])&&(s[n]=E({},s[n]));return s}function K(e){null!=e&&this.set(e)}f.suppressDeprecationWarnings=!1,f.deprecationHandler=null;var ee=Object.keys||function(e){var t,n=[];for(t in e)c(e,t)&&n.push(t);return n};function r(e,t,n){var s=""+Math.abs(e);return(0<=e?n?"+":"":"-")+Math.pow(10,Math.max(0,t-s.length)).toString().substr(1)+s}var te=/(\[[^\[]*\])|(\\)?([Hh]mm(ss)?|Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|Qo?|N{1,5}|YYYYYY|YYYYY|YYYY|YY|y{2,4}|yo?|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|kk?|mm?|ss?|S{1,9}|x|X|zz?|ZZ?|.)/g,ne=/(\[[^\[]*\])|(\\)?(LTS|LT|LL?L?L?|l{1,4})/g,se={},ie={};function s(e,t,n,s){var i="string"==typeof s?function(){return this[s]()}:s;e&&(ie[e]=i),t&&(ie[t[0]]=function(){return r(i.apply(this,arguments),t[1],t[2])}),n&&(ie[n]=function(){return this.localeData().ordinal(i.apply(this,arguments),e)})}function re(e,t){return e.isValid()?(t=ae(t,e.localeData()),se[t]=se[t]||function(s){for(var e,i=s.match(te),t=0,r=i.length;t<r;t++)ie[i[t]]?i[t]=ie[i[t]]:i[t]=(e=i[t]).match(/\[[\s\S]/)?e.replace(/^\[|\]$/g,""):e.replace(/\\/g,"");return function(e){for(var t="",n=0;n<r;n++)t+=d(i[n])?i[n].call(e,s):i[n];return t}}(t),se[t](e)):e.localeData().invalidDate()}function ae(e,t){var n=5;function s(e){return t.longDateFormat(e)||e}for(ne.lastIndex=0;0<=n&&ne.test(e);)e=e.replace(ne,s),ne.lastIndex=0,--n;return e}var oe={};function t(e,t){var n=e.toLowerCase();oe[n]=oe[n+"s"]=oe[t]=e}function _(e){return"string"==typeof e?oe[e]||oe[e.toLowerCase()]:void 0}function ue(e){var t,n,s={};for(n in e)c(e,n)&&(t=_(n))&&(s[t]=e[n]);return s}var le={};function n(e,t){le[e]=t}function he(e){return e%4==0&&e%100!=0||e%400==0}function y(e){return e<0?Math.ceil(e)||0:Math.floor(e)}function g(e){var e=+e,t=0;return t=0!=e&&isFinite(e)?y(e):t}function de(t,n){return function(e){return null!=e?(fe(this,t,e),f.updateOffset(this,n),this):ce(this,t)}}function ce(e,t){return e.isValid()?e._d["get"+(e._isUTC?"UTC":"")+t]():NaN}function fe(e,t,n){e.isValid()&&!isNaN(n)&&("FullYear"===t&&he(e.year())&&1===e.month()&&29===e.date()?(n=g(n),e._d["set"+(e._isUTC?"UTC":"")+t](n,e.month(),We(n,e.month()))):e._d["set"+(e._isUTC?"UTC":"")+t](n))}var i=/\d/,w=/\d\d/,me=/\d{3}/,_e=/\d{4}/,ye=/[+-]?\d{6}/,p=/\d\d?/,ge=/\d\d\d\d?/,we=/\d\d\d\d\d\d?/,pe=/\d{1,3}/,ke=/\d{1,4}/,ve=/[+-]?\d{1,6}/,Me=/\d+/,De=/[+-]?\d+/,Se=/Z|[+-]\d\d:?\d\d/gi,Ye=/Z|[+-]\d\d(?::?\d\d)?/gi,k=/[0-9]{0,256}['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFF07\uFF10-\uFFEF]{1,256}|[\u0600-\u06FF\/]{1,256}(\s*?[\u0600-\u06FF]{1,256}){1,2}/i;function v(e,n,s){be[e]=d(n)?n:function(e,t){return e&&s?s:n}}function Oe(e,t){return c(be,e)?be[e](t._strict,t._locale):new RegExp(M(e.replace("\\","").replace(/\\(\[)|\\(\])|\[([^\]\[]*)\]|\\(.)/g,function(e,t,n,s,i){return t||n||s||i})))}function M(e){return e.replace(/[-\/\\^$*+?.()|[\]{}]/g,"\\$&")}var be={},xe={};function D(e,n){var t,s,i=n;for("string"==typeof e&&(e=[e]),u(n)&&(i=function(e,t){t[n]=g(e)}),s=e.length,t=0;t<s;t++)xe[e[t]]=i}function Te(e,i){D(e,function(e,t,n,s){n._w=n._w||{},i(e,n._w,n,s)})}var S,Y=0,O=1,b=2,x=3,T=4,N=5,Ne=6,Pe=7,Re=8;function We(e,t){if(isNaN(e)||isNaN(t))return NaN;var n=(t%(n=12)+n)%n;return e+=(t-n)/12,1==n?he(e)?29:28:31-n%7%2}S=Array.prototype.indexOf||function(e){for(var t=0;t<this.length;++t)if(this[t]===e)return t;return-1},s("M",["MM",2],"Mo",function(){return this.month()+1}),s("MMM",0,0,function(e){return this.localeData().monthsShort(this,e)}),s("MMMM",0,0,function(e){return this.localeData().months(this,e)}),t("month","M"),n("month",8),v("M",p),v("MM",p,w),v("MMM",function(e,t){return t.monthsShortRegex(e)}),v("MMMM",function(e,t){return t.monthsRegex(e)}),D(["M","MM"],function(e,t){t[O]=g(e)-1}),D(["MMM","MMMM"],function(e,t,n,s){s=n._locale.monthsParse(e,s,n._strict);null!=s?t[O]=s:m(n).invalidMonth=e});var Ce="January_February_March_April_May_June_July_August_September_October_November_December".split("_"),Ue="Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"),He=/D[oD]?(\[[^\[\]]*\]|\s)+MMMM?/,Fe=k,Le=k;function Ve(e,t){var n;if(e.isValid()){if("string"==typeof t)if(/^\d+$/.test(t))t=g(t);else if(!u(t=e.localeData().monthsParse(t)))return;n=Math.min(e.date(),We(e.year(),t)),e._d["set"+(e._isUTC?"UTC":"")+"Month"](t,n)}}function Ge(e){return null!=e?(Ve(this,e),f.updateOffset(this,!0),this):ce(this,"Month")}function Ee(){function e(e,t){return t.length-e.length}for(var t,n=[],s=[],i=[],r=0;r<12;r++)t=l([2e3,r]),n.push(this.monthsShort(t,"")),s.push(this.months(t,"")),i.push(this.months(t,"")),i.push(this.monthsShort(t,""));for(n.sort(e),s.sort(e),i.sort(e),r=0;r<12;r++)n[r]=M(n[r]),s[r]=M(s[r]);for(r=0;r<24;r++)i[r]=M(i[r]);this._monthsRegex=new RegExp("^("+i.join("|")+")","i"),this._monthsShortRegex=this._monthsRegex,this._monthsStrictRegex=new RegExp("^("+s.join("|")+")","i"),this._monthsShortStrictRegex=new RegExp("^("+n.join("|")+")","i")}function Ae(e){return he(e)?366:365}s("Y",0,0,function(){var e=this.year();return e<=9999?r(e,4):"+"+e}),s(0,["YY",2],0,function(){return this.year()%100}),s(0,["YYYY",4],0,"year"),s(0,["YYYYY",5],0,"year"),s(0,["YYYYYY",6,!0],0,"year"),t("year","y"),n("year",1),v("Y",De),v("YY",p,w),v("YYYY",ke,_e),v("YYYYY",ve,ye),v("YYYYYY",ve,ye),D(["YYYYY","YYYYYY"],Y),D("YYYY",function(e,t){t[Y]=2===e.length?f.parseTwoDigitYear(e):g(e)}),D("YY",function(e,t){t[Y]=f.parseTwoDigitYear(e)}),D("Y",function(e,t){t[Y]=parseInt(e,10)}),f.parseTwoDigitYear=function(e){return g(e)+(68<g(e)?1900:2e3)};var Ie=de("FullYear",!0);function je(e,t,n,s,i,r,a){var o;return e<100&&0<=e?(o=new Date(e+400,t,n,s,i,r,a),isFinite(o.getFullYear())&&o.setFullYear(e)):o=new Date(e,t,n,s,i,r,a),o}function Ze(e){var t;return e<100&&0<=e?((t=Array.prototype.slice.call(arguments))[0]=e+400,t=new Date(Date.UTC.apply(null,t)),isFinite(t.getUTCFullYear())&&t.setUTCFullYear(e)):t=new Date(Date.UTC.apply(null,arguments)),t}function ze(e,t,n){n=7+t-n;return n-(7+Ze(e,0,n).getUTCDay()-t)%7-1}function $e(e,t,n,s,i){var r,t=1+7*(t-1)+(7+n-s)%7+ze(e,s,i),n=t<=0?Ae(r=e-1)+t:t>Ae(e)?(r=e+1,t-Ae(e)):(r=e,t);return{year:r,dayOfYear:n}}function qe(e,t,n){var s,i,r=ze(e.year(),t,n),r=Math.floor((e.dayOfYear()-r-1)/7)+1;return r<1?s=r+P(i=e.year()-1,t,n):r>P(e.year(),t,n)?(s=r-P(e.year(),t,n),i=e.year()+1):(i=e.year(),s=r),{week:s,year:i}}function P(e,t,n){var s=ze(e,t,n),t=ze(e+1,t,n);return(Ae(e)-s+t)/7}s("w",["ww",2],"wo","week"),s("W",["WW",2],"Wo","isoWeek"),t("week","w"),t("isoWeek","W"),n("week",5),n("isoWeek",5),v("w",p),v("ww",p,w),v("W",p),v("WW",p,w),Te(["w","ww","W","WW"],function(e,t,n,s){t[s.substr(0,1)]=g(e)});function Be(e,t){return e.slice(t,7).concat(e.slice(0,t))}s("d",0,"do","day"),s("dd",0,0,function(e){return this.localeData().weekdaysMin(this,e)}),s("ddd",0,0,function(e){return this.localeData().weekdaysShort(this,e)}),s("dddd",0,0,function(e){return this.localeData().weekdays(this,e)}),s("e",0,0,"weekday"),s("E",0,0,"isoWeekday"),t("day","d"),t("weekday","e"),t("isoWeekday","E"),n("day",11),n("weekday",11),n("isoWeekday",11),v("d",p),v("e",p),v("E",p),v("dd",function(e,t){return t.weekdaysMinRegex(e)}),v("ddd",function(e,t){return t.weekdaysShortRegex(e)}),v("dddd",function(e,t){return t.weekdaysRegex(e)}),Te(["dd","ddd","dddd"],function(e,t,n,s){s=n._locale.weekdaysParse(e,s,n._strict);null!=s?t.d=s:m(n).invalidWeekday=e}),Te(["d","e","E"],function(e,t,n,s){t[s]=g(e)});var Je="Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),Qe="Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"),Xe="Su_Mo_Tu_We_Th_Fr_Sa".split("_"),Ke=k,et=k,tt=k;function nt(){function e(e,t){return t.length-e.length}for(var t,n,s,i=[],r=[],a=[],o=[],u=0;u<7;u++)s=l([2e3,1]).day(u),t=M(this.weekdaysMin(s,"")),n=M(this.weekdaysShort(s,"")),s=M(this.weekdays(s,"")),i.push(t),r.push(n),a.push(s),o.push(t),o.push(n),o.push(s);i.sort(e),r.sort(e),a.sort(e),o.sort(e),this._weekdaysRegex=new RegExp("^("+o.join("|")+")","i"),this._weekdaysShortRegex=this._weekdaysRegex,this._weekdaysMinRegex=this._weekdaysRegex,this._weekdaysStrictRegex=new RegExp("^("+a.join("|")+")","i"),this._weekdaysShortStrictRegex=new RegExp("^("+r.join("|")+")","i"),this._weekdaysMinStrictRegex=new RegExp("^("+i.join("|")+")","i")}function st(){return this.hours()%12||12}function it(e,t){s(e,0,0,function(){return this.localeData().meridiem(this.hours(),this.minutes(),t)})}function rt(e,t){return t._meridiemParse}s("H",["HH",2],0,"hour"),s("h",["hh",2],0,st),s("k",["kk",2],0,function(){return this.hours()||24}),s("hmm",0,0,function(){return""+st.apply(this)+r(this.minutes(),2)}),s("hmmss",0,0,function(){return""+st.apply(this)+r(this.minutes(),2)+r(this.seconds(),2)}),s("Hmm",0,0,function(){return""+this.hours()+r(this.minutes(),2)}),s("Hmmss",0,0,function(){return""+this.hours()+r(this.minutes(),2)+r(this.seconds(),2)}),it("a",!0),it("A",!1),t("hour","h"),n("hour",13),v("a",rt),v("A",rt),v("H",p),v("h",p),v("k",p),v("HH",p,w),v("hh",p,w),v("kk",p,w),v("hmm",ge),v("hmmss",we),v("Hmm",ge),v("Hmmss",we),D(["H","HH"],x),D(["k","kk"],function(e,t,n){e=g(e);t[x]=24===e?0:e}),D(["a","A"],function(e,t,n){n._isPm=n._locale.isPM(e),n._meridiem=e}),D(["h","hh"],function(e,t,n){t[x]=g(e),m(n).bigHour=!0}),D("hmm",function(e,t,n){var s=e.length-2;t[x]=g(e.substr(0,s)),t[T]=g(e.substr(s)),m(n).bigHour=!0}),D("hmmss",function(e,t,n){var s=e.length-4,i=e.length-2;t[x]=g(e.substr(0,s)),t[T]=g(e.substr(s,2)),t[N]=g(e.substr(i)),m(n).bigHour=!0}),D("Hmm",function(e,t,n){var s=e.length-2;t[x]=g(e.substr(0,s)),t[T]=g(e.substr(s))}),D("Hmmss",function(e,t,n){var s=e.length-4,i=e.length-2;t[x]=g(e.substr(0,s)),t[T]=g(e.substr(s,2)),t[N]=g(e.substr(i))});k=de("Hours",!0);var at,ot={calendar:{sameDay:"[Today at] LT",nextDay:"[Tomorrow at] LT",nextWeek:"dddd [at] LT",lastDay:"[Yesterday at] LT",lastWeek:"[Last] dddd [at] LT",sameElse:"L"},longDateFormat:{LTS:"h:mm:ss A",LT:"h:mm A",L:"MM/DD/YYYY",LL:"MMMM D, YYYY",LLL:"MMMM D, YYYY h:mm A",LLLL:"dddd, MMMM D, YYYY h:mm A"},invalidDate:"Invalid date",ordinal:"%d",dayOfMonthOrdinalParse:/\d{1,2}/,relativeTime:{future:"in %s",past:"%s ago",s:"a few seconds",ss:"%d seconds",m:"a minute",mm:"%d minutes",h:"an hour",hh:"%d hours",d:"a day",dd:"%d days",w:"a week",ww:"%d weeks",M:"a month",MM:"%d months",y:"a year",yy:"%d years"},months:Ce,monthsShort:Ue,week:{dow:0,doy:6},weekdays:Je,weekdaysMin:Xe,weekdaysShort:Qe,meridiemParse:/[ap]\.?m?\.?/i},R={},ut={};function lt(e){return e&&e.toLowerCase().replace("_","-")}function ht(e){for(var t,n,s,i,r=0;r<e.length;){for(t=(i=lt(e[r]).split("-")).length,n=(n=lt(e[r+1]))?n.split("-"):null;0<t;){if(s=dt(i.slice(0,t).join("-")))return s;if(n&&n.length>=t&&function(e,t){for(var n=Math.min(e.length,t.length),s=0;s<n;s+=1)if(e[s]!==t[s])return s;return n}(i,n)>=t-1)break;t--}r++}return at}function dt(t){var e;if(void 0===R[t]&&"undefined"!=typeof module&&module&&module.exports&&null!=t.match("^[^/\\\\]*$"))try{e=at._abbr,require("./locale/"+t),ct(e)}catch(e){R[t]=null}return R[t]}function ct(e,t){return e&&((t=o(t)?mt(e):ft(e,t))?at=t:"undefined"!=typeof console&&console.warn&&console.warn("Locale "+e+" not found. Did you forget to load it?")),at._abbr}function ft(e,t){if(null===t)return delete R[e],null;var n,s=ot;if(t.abbr=e,null!=R[e])Q("defineLocaleOverride","use moment.updateLocale(localeName, config) to change an existing locale. moment.defineLocale(localeName, config) should only be used for creating a new locale See http://momentjs.com/guides/#/warnings/define-locale/ for more info."),s=R[e]._config;else if(null!=t.parentLocale)if(null!=R[t.parentLocale])s=R[t.parentLocale]._config;else{if(null==(n=dt(t.parentLocale)))return ut[t.parentLocale]||(ut[t.parentLocale]=[]),ut[t.parentLocale].push({name:e,config:t}),null;s=n._config}return R[e]=new K(X(s,t)),ut[e]&&ut[e].forEach(function(e){ft(e.name,e.config)}),ct(e),R[e]}function mt(e){var t;if(!(e=e&&e._locale&&e._locale._abbr?e._locale._abbr:e))return at;if(!a(e)){if(t=dt(e))return t;e=[e]}return ht(e)}function _t(e){var t=e._a;return t&&-2===m(e).overflow&&(t=t[O]<0||11<t[O]?O:t[b]<1||t[b]>We(t[Y],t[O])?b:t[x]<0||24<t[x]||24===t[x]&&(0!==t[T]||0!==t[N]||0!==t[Ne])?x:t[T]<0||59<t[T]?T:t[N]<0||59<t[N]?N:t[Ne]<0||999<t[Ne]?Ne:-1,m(e)._overflowDayOfYear&&(t<Y||b<t)&&(t=b),m(e)._overflowWeeks&&-1===t&&(t=Pe),m(e)._overflowWeekday&&-1===t&&(t=Re),m(e).overflow=t),e}var yt=/^\s*((?:[+-]\d{6}|\d{4})-(?:\d\d-\d\d|W\d\d-\d|W\d\d|\d\d\d|\d\d))(?:(T| )(\d\d(?::\d\d(?::\d\d(?:[.,]\d+)?)?)?)([+-]\d\d(?::?\d\d)?|\s*Z)?)?$/,gt=/^\s*((?:[+-]\d{6}|\d{4})(?:\d\d\d\d|W\d\d\d|W\d\d|\d\d\d|\d\d|))(?:(T| )(\d\d(?:\d\d(?:\d\d(?:[.,]\d+)?)?)?)([+-]\d\d(?::?\d\d)?|\s*Z)?)?$/,wt=/Z|[+-]\d\d(?::?\d\d)?/,pt=[["YYYYYY-MM-DD",/[+-]\d{6}-\d\d-\d\d/],["YYYY-MM-DD",/\d{4}-\d\d-\d\d/],["GGGG-[W]WW-E",/\d{4}-W\d\d-\d/],["GGGG-[W]WW",/\d{4}-W\d\d/,!1],["YYYY-DDD",/\d{4}-\d{3}/],["YYYY-MM",/\d{4}-\d\d/,!1],["YYYYYYMMDD",/[+-]\d{10}/],["YYYYMMDD",/\d{8}/],["GGGG[W]WWE",/\d{4}W\d{3}/],["GGGG[W]WW",/\d{4}W\d{2}/,!1],["YYYYDDD",/\d{7}/],["YYYYMM",/\d{6}/,!1],["YYYY",/\d{4}/,!1]],kt=[["HH:mm:ss.SSSS",/\d\d:\d\d:\d\d\.\d+/],["HH:mm:ss,SSSS",/\d\d:\d\d:\d\d,\d+/],["HH:mm:ss",/\d\d:\d\d:\d\d/],["HH:mm",/\d\d:\d\d/],["HHmmss.SSSS",/\d\d\d\d\d\d\.\d+/],["HHmmss,SSSS",/\d\d\d\d\d\d,\d+/],["HHmmss",/\d\d\d\d\d\d/],["HHmm",/\d\d\d\d/],["HH",/\d\d/]],vt=/^\/?Date\((-?\d+)/i,Mt=/^(?:(Mon|Tue|Wed|Thu|Fri|Sat|Sun),?\s)?(\d{1,2})\s(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s(\d{2,4})\s(\d\d):(\d\d)(?::(\d\d))?\s(?:(UT|GMT|[ECMP][SD]T)|([Zz])|([+-]\d{4}))$/,Dt={UT:0,GMT:0,EDT:-240,EST:-300,CDT:-300,CST:-360,MDT:-360,MST:-420,PDT:-420,PST:-480};function St(e){var t,n,s,i,r,a,o=e._i,u=yt.exec(o)||gt.exec(o),o=pt.length,l=kt.length;if(u){for(m(e).iso=!0,t=0,n=o;t<n;t++)if(pt[t][1].exec(u[1])){i=pt[t][0],s=!1!==pt[t][2];break}if(null==i)e._isValid=!1;else{if(u[3]){for(t=0,n=l;t<n;t++)if(kt[t][1].exec(u[3])){r=(u[2]||" ")+kt[t][0];break}if(null==r)return void(e._isValid=!1)}if(s||null==r){if(u[4]){if(!wt.exec(u[4]))return void(e._isValid=!1);a="Z"}e._f=i+(r||"")+(a||""),Tt(e)}else e._isValid=!1}}else e._isValid=!1}function Yt(e,t,n,s,i,r){e=[function(e){e=parseInt(e,10);{if(e<=49)return 2e3+e;if(e<=999)return 1900+e}return e}(e),Ue.indexOf(t),parseInt(n,10),parseInt(s,10),parseInt(i,10)];return r&&e.push(parseInt(r,10)),e}function Ot(e){var t,n,s,i,r=Mt.exec(e._i.replace(/\([^()]*\)|[\n\t]/g," ").replace(/(\s\s+)/g," ").replace(/^\s\s*/,"").replace(/\s\s*$/,""));r?(t=Yt(r[4],r[3],r[2],r[5],r[6],r[7]),n=r[1],s=t,i=e,n&&Qe.indexOf(n)!==new Date(s[0],s[1],s[2]).getDay()?(m(i).weekdayMismatch=!0,i._isValid=!1):(e._a=t,e._tzm=(n=r[8],s=r[9],i=r[10],n?Dt[n]:s?0:60*(((n=parseInt(i,10))-(s=n%100))/100)+s),e._d=Ze.apply(null,e._a),e._d.setUTCMinutes(e._d.getUTCMinutes()-e._tzm),m(e).rfc2822=!0)):e._isValid=!1}function bt(e,t,n){return null!=e?e:null!=t?t:n}function xt(e){var t,n,s,i,r,a,o,u,l,h,d,c=[];if(!e._d){for(s=e,i=new Date(f.now()),n=s._useUTC?[i.getUTCFullYear(),i.getUTCMonth(),i.getUTCDate()]:[i.getFullYear(),i.getMonth(),i.getDate()],e._w&&null==e._a[b]&&null==e._a[O]&&(null!=(i=(s=e)._w).GG||null!=i.W||null!=i.E?(u=1,l=4,r=bt(i.GG,s._a[Y],qe(W(),1,4).year),a=bt(i.W,1),((o=bt(i.E,1))<1||7<o)&&(h=!0)):(u=s._locale._week.dow,l=s._locale._week.doy,d=qe(W(),u,l),r=bt(i.gg,s._a[Y],d.year),a=bt(i.w,d.week),null!=i.d?((o=i.d)<0||6<o)&&(h=!0):null!=i.e?(o=i.e+u,(i.e<0||6<i.e)&&(h=!0)):o=u),a<1||a>P(r,u,l)?m(s)._overflowWeeks=!0:null!=h?m(s)._overflowWeekday=!0:(d=$e(r,a,o,u,l),s._a[Y]=d.year,s._dayOfYear=d.dayOfYear)),null!=e._dayOfYear&&(i=bt(e._a[Y],n[Y]),(e._dayOfYear>Ae(i)||0===e._dayOfYear)&&(m(e)._overflowDayOfYear=!0),h=Ze(i,0,e._dayOfYear),e._a[O]=h.getUTCMonth(),e._a[b]=h.getUTCDate()),t=0;t<3&&null==e._a[t];++t)e._a[t]=c[t]=n[t];for(;t<7;t++)e._a[t]=c[t]=null==e._a[t]?2===t?1:0:e._a[t];24===e._a[x]&&0===e._a[T]&&0===e._a[N]&&0===e._a[Ne]&&(e._nextDay=!0,e._a[x]=0),e._d=(e._useUTC?Ze:je).apply(null,c),r=e._useUTC?e._d.getUTCDay():e._d.getDay(),null!=e._tzm&&e._d.setUTCMinutes(e._d.getUTCMinutes()-e._tzm),e._nextDay&&(e._a[x]=24),e._w&&void 0!==e._w.d&&e._w.d!==r&&(m(e).weekdayMismatch=!0)}}function Tt(e){if(e._f===f.ISO_8601)St(e);else if(e._f===f.RFC_2822)Ot(e);else{e._a=[],m(e).empty=!0;for(var t,n,s,i,r,a=""+e._i,o=a.length,u=0,l=ae(e._f,e._locale).match(te)||[],h=l.length,d=0;d<h;d++)n=l[d],(t=(a.match(Oe(n,e))||[])[0])&&(0<(s=a.substr(0,a.indexOf(t))).length&&m(e).unusedInput.push(s),a=a.slice(a.indexOf(t)+t.length),u+=t.length),ie[n]?(t?m(e).empty=!1:m(e).unusedTokens.push(n),s=n,r=e,null!=(i=t)&&c(xe,s)&&xe[s](i,r._a,r,s)):e._strict&&!t&&m(e).unusedTokens.push(n);m(e).charsLeftOver=o-u,0<a.length&&m(e).unusedInput.push(a),e._a[x]<=12&&!0===m(e).bigHour&&0<e._a[x]&&(m(e).bigHour=void 0),m(e).parsedDateParts=e._a.slice(0),m(e).meridiem=e._meridiem,e._a[x]=function(e,t,n){if(null==n)return t;return null!=e.meridiemHour?e.meridiemHour(t,n):null!=e.isPM?((e=e.isPM(n))&&t<12&&(t+=12),t=e||12!==t?t:0):t}(e._locale,e._a[x],e._meridiem),null!==(o=m(e).era)&&(e._a[Y]=e._locale.erasConvertYear(o,e._a[Y])),xt(e),_t(e)}}function Nt(e){var t,n,s,i=e._i,r=e._f;if(e._locale=e._locale||mt(e._l),null===i||void 0===r&&""===i)return I({nullInput:!0});if("string"==typeof i&&(e._i=i=e._locale.preparse(i)),h(i))return new q(_t(i));if(V(i))e._d=i;else if(a(r))!function(e){var t,n,s,i,r,a,o=!1,u=e._f.length;if(0===u)return m(e).invalidFormat=!0,e._d=new Date(NaN);for(i=0;i<u;i++)r=0,a=!1,t=$({},e),null!=e._useUTC&&(t._useUTC=e._useUTC),t._f=e._f[i],Tt(t),A(t)&&(a=!0),r=(r+=m(t).charsLeftOver)+10*m(t).unusedTokens.length,m(t).score=r,o?r<s&&(s=r,n=t):(null==s||r<s||a)&&(s=r,n=t,a&&(o=!0));E(e,n||t)}(e);else if(r)Tt(e);else if(o(r=(i=e)._i))i._d=new Date(f.now());else V(r)?i._d=new Date(r.valueOf()):"string"==typeof r?(n=i,null!==(t=vt.exec(n._i))?n._d=new Date(+t[1]):(St(n),!1===n._isValid&&(delete n._isValid,Ot(n),!1===n._isValid&&(delete n._isValid,n._strict?n._isValid=!1:f.createFromInputFallback(n))))):a(r)?(i._a=G(r.slice(0),function(e){return parseInt(e,10)}),xt(i)):F(r)?(t=i)._d||(s=void 0===(n=ue(t._i)).day?n.date:n.day,t._a=G([n.year,n.month,s,n.hour,n.minute,n.second,n.millisecond],function(e){return e&&parseInt(e,10)}),xt(t)):u(r)?i._d=new Date(r):f.createFromInputFallback(i);return A(e)||(e._d=null),e}function Pt(e,t,n,s,i){var r={};return!0!==t&&!1!==t||(s=t,t=void 0),!0!==n&&!1!==n||(s=n,n=void 0),(F(e)&&L(e)||a(e)&&0===e.length)&&(e=void 0),r._isAMomentObject=!0,r._useUTC=r._isUTC=i,r._l=n,r._i=e,r._f=t,r._strict=s,(i=new q(_t(Nt(i=r))))._nextDay&&(i.add(1,"d"),i._nextDay=void 0),i}function W(e,t,n,s){return Pt(e,t,n,s,!1)}f.createFromInputFallback=e("value provided is not in a recognized RFC2822 or ISO format. moment construction falls back to js Date(), which is not reliable across all browsers and versions. Non RFC2822/ISO date formats are discouraged. Please refer to http://momentjs.com/guides/#/warnings/js-date/ for more info.",function(e){e._d=new Date(e._i+(e._useUTC?" UTC":""))}),f.ISO_8601=function(){},f.RFC_2822=function(){};ge=e("moment().min is deprecated, use moment.max instead. http://momentjs.com/guides/#/warnings/min-max/",function(){var e=W.apply(null,arguments);return this.isValid()&&e.isValid()?e<this?this:e:I()}),we=e("moment().max is deprecated, use moment.min instead. http://momentjs.com/guides/#/warnings/min-max/",function(){var e=W.apply(null,arguments);return this.isValid()&&e.isValid()?this<e?this:e:I()});function Rt(e,t){var n,s;if(!(t=1===t.length&&a(t[0])?t[0]:t).length)return W();for(n=t[0],s=1;s<t.length;++s)t[s].isValid()&&!t[s][e](n)||(n=t[s]);return n}var Wt=["year","quarter","month","week","day","hour","minute","second","millisecond"];function Ct(e){var e=ue(e),t=e.year||0,n=e.quarter||0,s=e.month||0,i=e.week||e.isoWeek||0,r=e.day||0,a=e.hour||0,o=e.minute||0,u=e.second||0,l=e.millisecond||0;this._isValid=function(e){var t,n,s=!1,i=Wt.length;for(t in e)if(c(e,t)&&(-1===S.call(Wt,t)||null!=e[t]&&isNaN(e[t])))return!1;for(n=0;n<i;++n)if(e[Wt[n]]){if(s)return!1;parseFloat(e[Wt[n]])!==g(e[Wt[n]])&&(s=!0)}return!0}(e),this._milliseconds=+l+1e3*u+6e4*o+1e3*a*60*60,this._days=+r+7*i,this._months=+s+3*n+12*t,this._data={},this._locale=mt(),this._bubble()}function Ut(e){return e instanceof Ct}function Ht(e){return e<0?-1*Math.round(-1*e):Math.round(e)}function Ft(e,n){s(e,0,0,function(){var e=this.utcOffset(),t="+";return e<0&&(e=-e,t="-"),t+r(~~(e/60),2)+n+r(~~e%60,2)})}Ft("Z",":"),Ft("ZZ",""),v("Z",Ye),v("ZZ",Ye),D(["Z","ZZ"],function(e,t,n){n._useUTC=!0,n._tzm=Vt(Ye,e)});var Lt=/([\+\-]|\d\d)/gi;function Vt(e,t){var t=(t||"").match(e);return null===t?null:0===(t=60*(e=((t[t.length-1]||[])+"").match(Lt)||["-",0,0])[1]+g(e[2]))?0:"+"===e[0]?t:-t}function Gt(e,t){var n;return t._isUTC?(t=t.clone(),n=(h(e)||V(e)?e:W(e)).valueOf()-t.valueOf(),t._d.setTime(t._d.valueOf()+n),f.updateOffset(t,!1),t):W(e).local()}function Et(e){return-Math.round(e._d.getTimezoneOffset())}function At(){return!!this.isValid()&&(this._isUTC&&0===this._offset)}f.updateOffset=function(){};var It=/^(-|\+)?(?:(\d*)[. ])?(\d+):(\d+)(?::(\d+)(\.\d*)?)?$/,jt=/^(-|\+)?P(?:([-+]?[0-9,.]*)Y)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)W)?(?:([-+]?[0-9,.]*)D)?(?:T(?:([-+]?[0-9,.]*)H)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)S)?)?$/;function C(e,t){var n,s=e,i=null;return Ut(e)?s={ms:e._milliseconds,d:e._days,M:e._months}:u(e)||!isNaN(+e)?(s={},t?s[t]=+e:s.milliseconds=+e):(i=It.exec(e))?(n="-"===i[1]?-1:1,s={y:0,d:g(i[b])*n,h:g(i[x])*n,m:g(i[T])*n,s:g(i[N])*n,ms:g(Ht(1e3*i[Ne]))*n}):(i=jt.exec(e))?(n="-"===i[1]?-1:1,s={y:Zt(i[2],n),M:Zt(i[3],n),w:Zt(i[4],n),d:Zt(i[5],n),h:Zt(i[6],n),m:Zt(i[7],n),s:Zt(i[8],n)}):null==s?s={}:"object"==typeof s&&("from"in s||"to"in s)&&(t=function(e,t){var n;if(!e.isValid()||!t.isValid())return{milliseconds:0,months:0};t=Gt(t,e),e.isBefore(t)?n=zt(e,t):((n=zt(t,e)).milliseconds=-n.milliseconds,n.months=-n.months);return n}(W(s.from),W(s.to)),(s={}).ms=t.milliseconds,s.M=t.months),i=new Ct(s),Ut(e)&&c(e,"_locale")&&(i._locale=e._locale),Ut(e)&&c(e,"_isValid")&&(i._isValid=e._isValid),i}function Zt(e,t){e=e&&parseFloat(e.replace(",","."));return(isNaN(e)?0:e)*t}function zt(e,t){var n={};return n.months=t.month()-e.month()+12*(t.year()-e.year()),e.clone().add(n.months,"M").isAfter(t)&&--n.months,n.milliseconds=+t-+e.clone().add(n.months,"M"),n}function $t(s,i){return function(e,t){var n;return null===t||isNaN(+t)||(Q(i,"moment()."+i+"(period, number) is deprecated. Please use moment()."+i+"(number, period). See http://momentjs.com/guides/#/warnings/add-inverted-param/ for more info."),n=e,e=t,t=n),qt(this,C(e,t),s),this}}function qt(e,t,n,s){var i=t._milliseconds,r=Ht(t._days),t=Ht(t._months);e.isValid()&&(s=null==s||s,t&&Ve(e,ce(e,"Month")+t*n),r&&fe(e,"Date",ce(e,"Date")+r*n),i&&e._d.setTime(e._d.valueOf()+i*n),s&&f.updateOffset(e,r||t))}C.fn=Ct.prototype,C.invalid=function(){return C(NaN)};Ce=$t(1,"add"),Je=$t(-1,"subtract");function Bt(e){return"string"==typeof e||e instanceof String}function Jt(e){return h(e)||V(e)||Bt(e)||u(e)||function(t){var e=a(t),n=!1;e&&(n=0===t.filter(function(e){return!u(e)&&Bt(t)}).length);return e&&n}(e)||function(e){var t,n,s=F(e)&&!L(e),i=!1,r=["years","year","y","months","month","M","days","day","d","dates","date","D","hours","hour","h","minutes","minute","m","seconds","second","s","milliseconds","millisecond","ms"],a=r.length;for(t=0;t<a;t+=1)n=r[t],i=i||c(e,n);return s&&i}(e)||null==e}function Qt(e,t){if(e.date()<t.date())return-Qt(t,e);var n=12*(t.year()-e.year())+(t.month()-e.month()),s=e.clone().add(n,"months"),t=t-s<0?(t-s)/(s-e.clone().add(n-1,"months")):(t-s)/(e.clone().add(1+n,"months")-s);return-(n+t)||0}function Xt(e){return void 0===e?this._locale._abbr:(null!=(e=mt(e))&&(this._locale=e),this)}f.defaultFormat="YYYY-MM-DDTHH:mm:ssZ",f.defaultFormatUtc="YYYY-MM-DDTHH:mm:ss[Z]";Xe=e("moment().lang() is deprecated. Instead, use moment().localeData() to get the language configuration. Use moment().locale() to change languages.",function(e){return void 0===e?this.localeData():this.locale(e)});function Kt(){return this._locale}var en=126227808e5;function tn(e,t){return(e%t+t)%t}function nn(e,t,n){return e<100&&0<=e?new Date(e+400,t,n)-en:new Date(e,t,n).valueOf()}function sn(e,t,n){return e<100&&0<=e?Date.UTC(e+400,t,n)-en:Date.UTC(e,t,n)}function rn(e,t){return t.erasAbbrRegex(e)}function an(){for(var e=[],t=[],n=[],s=[],i=this.eras(),r=0,a=i.length;r<a;++r)t.push(M(i[r].name)),e.push(M(i[r].abbr)),n.push(M(i[r].narrow)),s.push(M(i[r].name)),s.push(M(i[r].abbr)),s.push(M(i[r].narrow));this._erasRegex=new RegExp("^("+s.join("|")+")","i"),this._erasNameRegex=new RegExp("^("+t.join("|")+")","i"),this._erasAbbrRegex=new RegExp("^("+e.join("|")+")","i"),this._erasNarrowRegex=new RegExp("^("+n.join("|")+")","i")}function on(e,t){s(0,[e,e.length],0,t)}function un(e,t,n,s,i){var r;return null==e?qe(this,s,i).year:(r=P(e,s,i),function(e,t,n,s,i){e=$e(e,t,n,s,i),t=Ze(e.year,0,e.dayOfYear);return this.year(t.getUTCFullYear()),this.month(t.getUTCMonth()),this.date(t.getUTCDate()),this}.call(this,e,t=r<t?r:t,n,s,i))}s("N",0,0,"eraAbbr"),s("NN",0,0,"eraAbbr"),s("NNN",0,0,"eraAbbr"),s("NNNN",0,0,"eraName"),s("NNNNN",0,0,"eraNarrow"),s("y",["y",1],"yo","eraYear"),s("y",["yy",2],0,"eraYear"),s("y",["yyy",3],0,"eraYear"),s("y",["yyyy",4],0,"eraYear"),v("N",rn),v("NN",rn),v("NNN",rn),v("NNNN",function(e,t){return t.erasNameRegex(e)}),v("NNNNN",function(e,t){return t.erasNarrowRegex(e)}),D(["N","NN","NNN","NNNN","NNNNN"],function(e,t,n,s){s=n._locale.erasParse(e,s,n._strict);s?m(n).era=s:m(n).invalidEra=e}),v("y",Me),v("yy",Me),v("yyy",Me),v("yyyy",Me),v("yo",function(e,t){return t._eraYearOrdinalRegex||Me}),D(["y","yy","yyy","yyyy"],Y),D(["yo"],function(e,t,n,s){var i;n._locale._eraYearOrdinalRegex&&(i=e.match(n._locale._eraYearOrdinalRegex)),n._locale.eraYearOrdinalParse?t[Y]=n._locale.eraYearOrdinalParse(e,i):t[Y]=parseInt(e,10)}),s(0,["gg",2],0,function(){return this.weekYear()%100}),s(0,["GG",2],0,function(){return this.isoWeekYear()%100}),on("gggg","weekYear"),on("ggggg","weekYear"),on("GGGG","isoWeekYear"),on("GGGGG","isoWeekYear"),t("weekYear","gg"),t("isoWeekYear","GG"),n("weekYear",1),n("isoWeekYear",1),v("G",De),v("g",De),v("GG",p,w),v("gg",p,w),v("GGGG",ke,_e),v("gggg",ke,_e),v("GGGGG",ve,ye),v("ggggg",ve,ye),Te(["gggg","ggggg","GGGG","GGGGG"],function(e,t,n,s){t[s.substr(0,2)]=g(e)}),Te(["gg","GG"],function(e,t,n,s){t[s]=f.parseTwoDigitYear(e)}),s("Q",0,"Qo","quarter"),t("quarter","Q"),n("quarter",7),v("Q",i),D("Q",function(e,t){t[O]=3*(g(e)-1)}),s("D",["DD",2],"Do","date"),t("date","D"),n("date",9),v("D",p),v("DD",p,w),v("Do",function(e,t){return e?t._dayOfMonthOrdinalParse||t._ordinalParse:t._dayOfMonthOrdinalParseLenient}),D(["D","DD"],b),D("Do",function(e,t){t[b]=g(e.match(p)[0])});ke=de("Date",!0);s("DDD",["DDDD",3],"DDDo","dayOfYear"),t("dayOfYear","DDD"),n("dayOfYear",4),v("DDD",pe),v("DDDD",me),D(["DDD","DDDD"],function(e,t,n){n._dayOfYear=g(e)}),s("m",["mm",2],0,"minute"),t("minute","m"),n("minute",14),v("m",p),v("mm",p,w),D(["m","mm"],T);var ln,_e=de("Minutes",!1),ve=(s("s",["ss",2],0,"second"),t("second","s"),n("second",15),v("s",p),v("ss",p,w),D(["s","ss"],N),de("Seconds",!1));for(s("S",0,0,function(){return~~(this.millisecond()/100)}),s(0,["SS",2],0,function(){return~~(this.millisecond()/10)}),s(0,["SSS",3],0,"millisecond"),s(0,["SSSS",4],0,function(){return 10*this.millisecond()}),s(0,["SSSSS",5],0,function(){return 100*this.millisecond()}),s(0,["SSSSSS",6],0,function(){return 1e3*this.millisecond()}),s(0,["SSSSSSS",7],0,function(){return 1e4*this.millisecond()}),s(0,["SSSSSSSS",8],0,function(){return 1e5*this.millisecond()}),s(0,["SSSSSSSSS",9],0,function(){return 1e6*this.millisecond()}),t("millisecond","ms"),n("millisecond",16),v("S",pe,i),v("SS",pe,w),v("SSS",pe,me),ln="SSSS";ln.length<=9;ln+="S")v(ln,Me);function hn(e,t){t[Ne]=g(1e3*("0."+e))}for(ln="S";ln.length<=9;ln+="S")D(ln,hn);ye=de("Milliseconds",!1),s("z",0,0,"zoneAbbr"),s("zz",0,0,"zoneName");i=q.prototype;function dn(e){return e}i.add=Ce,i.calendar=function(e,t){1===arguments.length&&(arguments[0]?Jt(arguments[0])?(e=arguments[0],t=void 0):function(e){for(var t=F(e)&&!L(e),n=!1,s=["sameDay","nextDay","lastDay","nextWeek","lastWeek","sameElse"],i=0;i<s.length;i+=1)n=n||c(e,s[i]);return t&&n}(arguments[0])&&(t=arguments[0],e=void 0):t=e=void 0);var e=e||W(),n=Gt(e,this).startOf("day"),n=f.calendarFormat(this,n)||"sameElse",t=t&&(d(t[n])?t[n].call(this,e):t[n]);return this.format(t||this.localeData().calendar(n,this,W(e)))},i.clone=function(){return new q(this)},i.diff=function(e,t,n){var s,i,r;if(!this.isValid())return NaN;if(!(s=Gt(e,this)).isValid())return NaN;switch(i=6e4*(s.utcOffset()-this.utcOffset()),t=_(t)){case"year":r=Qt(this,s)/12;break;case"month":r=Qt(this,s);break;case"quarter":r=Qt(this,s)/3;break;case"second":r=(this-s)/1e3;break;case"minute":r=(this-s)/6e4;break;case"hour":r=(this-s)/36e5;break;case"day":r=(this-s-i)/864e5;break;case"week":r=(this-s-i)/6048e5;break;default:r=this-s}return n?r:y(r)},i.endOf=function(e){var t,n;if(void 0===(e=_(e))||"millisecond"===e||!this.isValid())return this;switch(n=this._isUTC?sn:nn,e){case"year":t=n(this.year()+1,0,1)-1;break;case"quarter":t=n(this.year(),this.month()-this.month()%3+3,1)-1;break;case"month":t=n(this.year(),this.month()+1,1)-1;break;case"week":t=n(this.year(),this.month(),this.date()-this.weekday()+7)-1;break;case"isoWeek":t=n(this.year(),this.month(),this.date()-(this.isoWeekday()-1)+7)-1;break;case"day":case"date":t=n(this.year(),this.month(),this.date()+1)-1;break;case"hour":t=this._d.valueOf(),t+=36e5-tn(t+(this._isUTC?0:6e4*this.utcOffset()),36e5)-1;break;case"minute":t=this._d.valueOf(),t+=6e4-tn(t,6e4)-1;break;case"second":t=this._d.valueOf(),t+=1e3-tn(t,1e3)-1;break}return this._d.setTime(t),f.updateOffset(this,!0),this},i.format=function(e){return e=e||(this.isUtc()?f.defaultFormatUtc:f.defaultFormat),e=re(this,e),this.localeData().postformat(e)},i.from=function(e,t){return this.isValid()&&(h(e)&&e.isValid()||W(e).isValid())?C({to:this,from:e}).locale(this.locale()).humanize(!t):this.localeData().invalidDate()},i.fromNow=function(e){return this.from(W(),e)},i.to=function(e,t){return this.isValid()&&(h(e)&&e.isValid()||W(e).isValid())?C({from:this,to:e}).locale(this.locale()).humanize(!t):this.localeData().invalidDate()},i.toNow=function(e){return this.to(W(),e)},i.get=function(e){return d(this[e=_(e)])?this[e]():this},i.invalidAt=function(){return m(this).overflow},i.isAfter=function(e,t){return e=h(e)?e:W(e),!(!this.isValid()||!e.isValid())&&("millisecond"===(t=_(t)||"millisecond")?this.valueOf()>e.valueOf():e.valueOf()<this.clone().startOf(t).valueOf())},i.isBefore=function(e,t){return e=h(e)?e:W(e),!(!this.isValid()||!e.isValid())&&("millisecond"===(t=_(t)||"millisecond")?this.valueOf()<e.valueOf():this.clone().endOf(t).valueOf()<e.valueOf())},i.isBetween=function(e,t,n,s){return e=h(e)?e:W(e),t=h(t)?t:W(t),!!(this.isValid()&&e.isValid()&&t.isValid())&&(("("===(s=s||"()")[0]?this.isAfter(e,n):!this.isBefore(e,n))&&(")"===s[1]?this.isBefore(t,n):!this.isAfter(t,n)))},i.isSame=function(e,t){var e=h(e)?e:W(e);return!(!this.isValid()||!e.isValid())&&("millisecond"===(t=_(t)||"millisecond")?this.valueOf()===e.valueOf():(e=e.valueOf(),this.clone().startOf(t).valueOf()<=e&&e<=this.clone().endOf(t).valueOf()))},i.isSameOrAfter=function(e,t){return this.isSame(e,t)||this.isAfter(e,t)},i.isSameOrBefore=function(e,t){return this.isSame(e,t)||this.isBefore(e,t)},i.isValid=function(){return A(this)},i.lang=Xe,i.locale=Xt,i.localeData=Kt,i.max=we,i.min=ge,i.parsingFlags=function(){return E({},m(this))},i.set=function(e,t){if("object"==typeof e)for(var n=function(e){var t,n=[];for(t in e)c(e,t)&&n.push({unit:t,priority:le[t]});return n.sort(function(e,t){return e.priority-t.priority}),n}(e=ue(e)),s=n.length,i=0;i<s;i++)this[n[i].unit](e[n[i].unit]);else if(d(this[e=_(e)]))return this[e](t);return this},i.startOf=function(e){var t,n;if(void 0===(e=_(e))||"millisecond"===e||!this.isValid())return this;switch(n=this._isUTC?sn:nn,e){case"year":t=n(this.year(),0,1);break;case"quarter":t=n(this.year(),this.month()-this.month()%3,1);break;case"month":t=n(this.year(),this.month(),1);break;case"week":t=n(this.year(),this.month(),this.date()-this.weekday());break;case"isoWeek":t=n(this.year(),this.month(),this.date()-(this.isoWeekday()-1));break;case"day":case"date":t=n(this.year(),this.month(),this.date());break;case"hour":t=this._d.valueOf(),t-=tn(t+(this._isUTC?0:6e4*this.utcOffset()),36e5);break;case"minute":t=this._d.valueOf(),t-=tn(t,6e4);break;case"second":t=this._d.valueOf(),t-=tn(t,1e3);break}return this._d.setTime(t),f.updateOffset(this,!0),this},i.subtract=Je,i.toArray=function(){var e=this;return[e.year(),e.month(),e.date(),e.hour(),e.minute(),e.second(),e.millisecond()]},i.toObject=function(){var e=this;return{years:e.year(),months:e.month(),date:e.date(),hours:e.hours(),minutes:e.minutes(),seconds:e.seconds(),milliseconds:e.milliseconds()}},i.toDate=function(){return new Date(this.valueOf())},i.toISOString=function(e){if(!this.isValid())return null;var t=(e=!0!==e)?this.clone().utc():this;return t.year()<0||9999<t.year()?re(t,e?"YYYYYY-MM-DD[T]HH:mm:ss.SSS[Z]":"YYYYYY-MM-DD[T]HH:mm:ss.SSSZ"):d(Date.prototype.toISOString)?e?this.toDate().toISOString():new Date(this.valueOf()+60*this.utcOffset()*1e3).toISOString().replace("Z",re(t,"Z")):re(t,e?"YYYY-MM-DD[T]HH:mm:ss.SSS[Z]":"YYYY-MM-DD[T]HH:mm:ss.SSSZ")},i.inspect=function(){if(!this.isValid())return"moment.invalid(/* "+this._i+" */)";var e,t="moment",n="";return this.isLocal()||(t=0===this.utcOffset()?"moment.utc":"moment.parseZone",n="Z"),t="["+t+'("]',e=0<=this.year()&&this.year()<=9999?"YYYY":"YYYYYY",this.format(t+e+"-MM-DD[T]HH:mm:ss.SSS"+(n+'[")]'))},"undefined"!=typeof Symbol&&null!=Symbol.for&&(i[Symbol.for("nodejs.util.inspect.custom")]=function(){return"Moment<"+this.format()+">"}),i.toJSON=function(){return this.isValid()?this.toISOString():null},i.toString=function(){return this.clone().locale("en").format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ")},i.unix=function(){return Math.floor(this.valueOf()/1e3)},i.valueOf=function(){return this._d.valueOf()-6e4*(this._offset||0)},i.creationData=function(){return{input:this._i,format:this._f,locale:this._locale,isUTC:this._isUTC,strict:this._strict}},i.eraName=function(){for(var e,t=this.localeData().eras(),n=0,s=t.length;n<s;++n){if(e=this.clone().startOf("day").valueOf(),t[n].since<=e&&e<=t[n].until)return t[n].name;if(t[n].until<=e&&e<=t[n].since)return t[n].name}return""},i.eraNarrow=function(){for(var e,t=this.localeData().eras(),n=0,s=t.length;n<s;++n){if(e=this.clone().startOf("day").valueOf(),t[n].since<=e&&e<=t[n].until)return t[n].narrow;if(t[n].until<=e&&e<=t[n].since)return t[n].narrow}return""},i.eraAbbr=function(){for(var e,t=this.localeData().eras(),n=0,s=t.length;n<s;++n){if(e=this.clone().startOf("day").valueOf(),t[n].since<=e&&e<=t[n].until)return t[n].abbr;if(t[n].until<=e&&e<=t[n].since)return t[n].abbr}return""},i.eraYear=function(){for(var e,t,n=this.localeData().eras(),s=0,i=n.length;s<i;++s)if(e=n[s].since<=n[s].until?1:-1,t=this.clone().startOf("day").valueOf(),n[s].since<=t&&t<=n[s].until||n[s].until<=t&&t<=n[s].since)return(this.year()-f(n[s].since).year())*e+n[s].offset;return this.year()},i.year=Ie,i.isLeapYear=function(){return he(this.year())},i.weekYear=function(e){return un.call(this,e,this.week(),this.weekday(),this.localeData()._week.dow,this.localeData()._week.doy)},i.isoWeekYear=function(e){return un.call(this,e,this.isoWeek(),this.isoWeekday(),1,4)},i.quarter=i.quarters=function(e){return null==e?Math.ceil((this.month()+1)/3):this.month(3*(e-1)+this.month()%3)},i.month=Ge,i.daysInMonth=function(){return We(this.year(),this.month())},i.week=i.weeks=function(e){var t=this.localeData().week(this);return null==e?t:this.add(7*(e-t),"d")},i.isoWeek=i.isoWeeks=function(e){var t=qe(this,1,4).week;return null==e?t:this.add(7*(e-t),"d")},i.weeksInYear=function(){var e=this.localeData()._week;return P(this.year(),e.dow,e.doy)},i.weeksInWeekYear=function(){var e=this.localeData()._week;return P(this.weekYear(),e.dow,e.doy)},i.isoWeeksInYear=function(){return P(this.year(),1,4)},i.isoWeeksInISOWeekYear=function(){return P(this.isoWeekYear(),1,4)},i.date=ke,i.day=i.days=function(e){if(!this.isValid())return null!=e?this:NaN;var t,n,s=this._isUTC?this._d.getUTCDay():this._d.getDay();return null!=e?(t=e,n=this.localeData(),e="string"!=typeof t?t:isNaN(t)?"number"==typeof(t=n.weekdaysParse(t))?t:null:parseInt(t,10),this.add(e-s,"d")):s},i.weekday=function(e){if(!this.isValid())return null!=e?this:NaN;var t=(this.day()+7-this.localeData()._week.dow)%7;return null==e?t:this.add(e-t,"d")},i.isoWeekday=function(e){return this.isValid()?null!=e?(t=e,n=this.localeData(),n="string"==typeof t?n.weekdaysParse(t)%7||7:isNaN(t)?null:t,this.day(this.day()%7?n:n-7)):this.day()||7:null!=e?this:NaN;var t,n},i.dayOfYear=function(e){var t=Math.round((this.clone().startOf("day")-this.clone().startOf("year"))/864e5)+1;return null==e?t:this.add(e-t,"d")},i.hour=i.hours=k,i.minute=i.minutes=_e,i.second=i.seconds=ve,i.millisecond=i.milliseconds=ye,i.utcOffset=function(e,t,n){var s,i=this._offset||0;if(!this.isValid())return null!=e?this:NaN;if(null==e)return this._isUTC?i:Et(this);if("string"==typeof e){if(null===(e=Vt(Ye,e)))return this}else Math.abs(e)<16&&!n&&(e*=60);return!this._isUTC&&t&&(s=Et(this)),this._offset=e,this._isUTC=!0,null!=s&&this.add(s,"m"),i!==e&&(!t||this._changeInProgress?qt(this,C(e-i,"m"),1,!1):this._changeInProgress||(this._changeInProgress=!0,f.updateOffset(this,!0),this._changeInProgress=null)),this},i.utc=function(e){return this.utcOffset(0,e)},i.local=function(e){return this._isUTC&&(this.utcOffset(0,e),this._isUTC=!1,e&&this.subtract(Et(this),"m")),this},i.parseZone=function(){var e;return null!=this._tzm?this.utcOffset(this._tzm,!1,!0):"string"==typeof this._i&&(null!=(e=Vt(Se,this._i))?this.utcOffset(e):this.utcOffset(0,!0)),this},i.hasAlignedHourOffset=function(e){return!!this.isValid()&&(e=e?W(e).utcOffset():0,(this.utcOffset()-e)%60==0)},i.isDST=function(){return this.utcOffset()>this.clone().month(0).utcOffset()||this.utcOffset()>this.clone().month(5).utcOffset()},i.isLocal=function(){return!!this.isValid()&&!this._isUTC},i.isUtcOffset=function(){return!!this.isValid()&&this._isUTC},i.isUtc=At,i.isUTC=At,i.zoneAbbr=function(){return this._isUTC?"UTC":""},i.zoneName=function(){return this._isUTC?"Coordinated Universal Time":""},i.dates=e("dates accessor is deprecated. Use date instead.",ke),i.months=e("months accessor is deprecated. Use month instead",Ge),i.years=e("years accessor is deprecated. Use year instead",Ie),i.zone=e("moment().zone is deprecated, use moment().utcOffset instead. http://momentjs.com/guides/#/warnings/zone/",function(e,t){return null!=e?(this.utcOffset(e="string"!=typeof e?-e:e,t),this):-this.utcOffset()}),i.isDSTShifted=e("isDSTShifted is deprecated. See http://momentjs.com/guides/#/warnings/dst-shifted/ for more information",function(){if(!o(this._isDSTShifted))return this._isDSTShifted;var e,t={};return $(t,this),(t=Nt(t))._a?(e=(t._isUTC?l:W)(t._a),this._isDSTShifted=this.isValid()&&0<function(e,t,n){for(var s=Math.min(e.length,t.length),i=Math.abs(e.length-t.length),r=0,a=0;a<s;a++)(n&&e[a]!==t[a]||!n&&g(e[a])!==g(t[a]))&&r++;return r+i}(t._a,e.toArray())):this._isDSTShifted=!1,this._isDSTShifted});w=K.prototype;function cn(e,t,n,s){var i=mt(),s=l().set(s,t);return i[n](s,e)}function fn(e,t,n){if(u(e)&&(t=e,e=void 0),e=e||"",null!=t)return cn(e,t,n,"month");for(var s=[],i=0;i<12;i++)s[i]=cn(e,i,n,"month");return s}function mn(e,t,n,s){t=("boolean"==typeof e?u(t)&&(n=t,t=void 0):(t=e,e=!1,u(n=t)&&(n=t,t=void 0)),t||"");var i,r=mt(),a=e?r._week.dow:0,o=[];if(null!=n)return cn(t,(n+a)%7,s,"day");for(i=0;i<7;i++)o[i]=cn(t,(i+a)%7,s,"day");return o}w.calendar=function(e,t,n){return d(e=this._calendar[e]||this._calendar.sameElse)?e.call(t,n):e},w.longDateFormat=function(e){var t=this._longDateFormat[e],n=this._longDateFormat[e.toUpperCase()];return t||!n?t:(this._longDateFormat[e]=n.match(te).map(function(e){return"MMMM"===e||"MM"===e||"DD"===e||"dddd"===e?e.slice(1):e}).join(""),this._longDateFormat[e])},w.invalidDate=function(){return this._invalidDate},w.ordinal=function(e){return this._ordinal.replace("%d",e)},w.preparse=dn,w.postformat=dn,w.relativeTime=function(e,t,n,s){var i=this._relativeTime[n];return d(i)?i(e,t,n,s):i.replace(/%d/i,e)},w.pastFuture=function(e,t){return d(e=this._relativeTime[0<e?"future":"past"])?e(t):e.replace(/%s/i,t)},w.set=function(e){var t,n;for(n in e)c(e,n)&&(d(t=e[n])?this[n]=t:this["_"+n]=t);this._config=e,this._dayOfMonthOrdinalParseLenient=new RegExp((this._dayOfMonthOrdinalParse.source||this._ordinalParse.source)+"|"+/\d{1,2}/.source)},w.eras=function(e,t){for(var n,s=this._eras||mt("en")._eras,i=0,r=s.length;i<r;++i){switch(typeof s[i].since){case"string":n=f(s[i].since).startOf("day"),s[i].since=n.valueOf();break}switch(typeof s[i].until){case"undefined":s[i].until=1/0;break;case"string":n=f(s[i].until).startOf("day").valueOf(),s[i].until=n.valueOf();break}}return s},w.erasParse=function(e,t,n){var s,i,r,a,o,u=this.eras();for(e=e.toUpperCase(),s=0,i=u.length;s<i;++s)if(r=u[s].name.toUpperCase(),a=u[s].abbr.toUpperCase(),o=u[s].narrow.toUpperCase(),n)switch(t){case"N":case"NN":case"NNN":if(a===e)return u[s];break;case"NNNN":if(r===e)return u[s];break;case"NNNNN":if(o===e)return u[s];break}else if(0<=[r,a,o].indexOf(e))return u[s]},w.erasConvertYear=function(e,t){var n=e.since<=e.until?1:-1;return void 0===t?f(e.since).year():f(e.since).year()+(t-e.offset)*n},w.erasAbbrRegex=function(e){return c(this,"_erasAbbrRegex")||an.call(this),e?this._erasAbbrRegex:this._erasRegex},w.erasNameRegex=function(e){return c(this,"_erasNameRegex")||an.call(this),e?this._erasNameRegex:this._erasRegex},w.erasNarrowRegex=function(e){return c(this,"_erasNarrowRegex")||an.call(this),e?this._erasNarrowRegex:this._erasRegex},w.months=function(e,t){return e?(a(this._months)?this._months:this._months[(this._months.isFormat||He).test(t)?"format":"standalone"])[e.month()]:a(this._months)?this._months:this._months.standalone},w.monthsShort=function(e,t){return e?(a(this._monthsShort)?this._monthsShort:this._monthsShort[He.test(t)?"format":"standalone"])[e.month()]:a(this._monthsShort)?this._monthsShort:this._monthsShort.standalone},w.monthsParse=function(e,t,n){var s,i;if(this._monthsParseExact)return function(e,t,n){var s,i,r,e=e.toLocaleLowerCase();if(!this._monthsParse)for(this._monthsParse=[],this._longMonthsParse=[],this._shortMonthsParse=[],s=0;s<12;++s)r=l([2e3,s]),this._shortMonthsParse[s]=this.monthsShort(r,"").toLocaleLowerCase(),this._longMonthsParse[s]=this.months(r,"").toLocaleLowerCase();return n?"MMM"===t?-1!==(i=S.call(this._shortMonthsParse,e))?i:null:-1!==(i=S.call(this._longMonthsParse,e))?i:null:"MMM"===t?-1!==(i=S.call(this._shortMonthsParse,e))||-1!==(i=S.call(this._longMonthsParse,e))?i:null:-1!==(i=S.call(this._longMonthsParse,e))||-1!==(i=S.call(this._shortMonthsParse,e))?i:null}.call(this,e,t,n);for(this._monthsParse||(this._monthsParse=[],this._longMonthsParse=[],this._shortMonthsParse=[]),s=0;s<12;s++){if(i=l([2e3,s]),n&&!this._longMonthsParse[s]&&(this._longMonthsParse[s]=new RegExp("^"+this.months(i,"").replace(".","")+"$","i"),this._shortMonthsParse[s]=new RegExp("^"+this.monthsShort(i,"").replace(".","")+"$","i")),n||this._monthsParse[s]||(i="^"+this.months(i,"")+"|^"+this.monthsShort(i,""),this._monthsParse[s]=new RegExp(i.replace(".",""),"i")),n&&"MMMM"===t&&this._longMonthsParse[s].test(e))return s;if(n&&"MMM"===t&&this._shortMonthsParse[s].test(e))return s;if(!n&&this._monthsParse[s].test(e))return s}},w.monthsRegex=function(e){return this._monthsParseExact?(c(this,"_monthsRegex")||Ee.call(this),e?this._monthsStrictRegex:this._monthsRegex):(c(this,"_monthsRegex")||(this._monthsRegex=Le),this._monthsStrictRegex&&e?this._monthsStrictRegex:this._monthsRegex)},w.monthsShortRegex=function(e){return this._monthsParseExact?(c(this,"_monthsRegex")||Ee.call(this),e?this._monthsShortStrictRegex:this._monthsShortRegex):(c(this,"_monthsShortRegex")||(this._monthsShortRegex=Fe),this._monthsShortStrictRegex&&e?this._monthsShortStrictRegex:this._monthsShortRegex)},w.week=function(e){return qe(e,this._week.dow,this._week.doy).week},w.firstDayOfYear=function(){return this._week.doy},w.firstDayOfWeek=function(){return this._week.dow},w.weekdays=function(e,t){return t=a(this._weekdays)?this._weekdays:this._weekdays[e&&!0!==e&&this._weekdays.isFormat.test(t)?"format":"standalone"],!0===e?Be(t,this._week.dow):e?t[e.day()]:t},w.weekdaysMin=function(e){return!0===e?Be(this._weekdaysMin,this._week.dow):e?this._weekdaysMin[e.day()]:this._weekdaysMin},w.weekdaysShort=function(e){return!0===e?Be(this._weekdaysShort,this._week.dow):e?this._weekdaysShort[e.day()]:this._weekdaysShort},w.weekdaysParse=function(e,t,n){var s,i;if(this._weekdaysParseExact)return function(e,t,n){var s,i,r,e=e.toLocaleLowerCase();if(!this._weekdaysParse)for(this._weekdaysParse=[],this._shortWeekdaysParse=[],this._minWeekdaysParse=[],s=0;s<7;++s)r=l([2e3,1]).day(s),this._minWeekdaysParse[s]=this.weekdaysMin(r,"").toLocaleLowerCase(),this._shortWeekdaysParse[s]=this.weekdaysShort(r,"").toLocaleLowerCase(),this._weekdaysParse[s]=this.weekdays(r,"").toLocaleLowerCase();return n?"dddd"===t?-1!==(i=S.call(this._weekdaysParse,e))?i:null:"ddd"===t?-1!==(i=S.call(this._shortWeekdaysParse,e))?i:null:-1!==(i=S.call(this._minWeekdaysParse,e))?i:null:"dddd"===t?-1!==(i=S.call(this._weekdaysParse,e))||-1!==(i=S.call(this._shortWeekdaysParse,e))||-1!==(i=S.call(this._minWeekdaysParse,e))?i:null:"ddd"===t?-1!==(i=S.call(this._shortWeekdaysParse,e))||-1!==(i=S.call(this._weekdaysParse,e))||-1!==(i=S.call(this._minWeekdaysParse,e))?i:null:-1!==(i=S.call(this._minWeekdaysParse,e))||-1!==(i=S.call(this._weekdaysParse,e))||-1!==(i=S.call(this._shortWeekdaysParse,e))?i:null}.call(this,e,t,n);for(this._weekdaysParse||(this._weekdaysParse=[],this._minWeekdaysParse=[],this._shortWeekdaysParse=[],this._fullWeekdaysParse=[]),s=0;s<7;s++){if(i=l([2e3,1]).day(s),n&&!this._fullWeekdaysParse[s]&&(this._fullWeekdaysParse[s]=new RegExp("^"+this.weekdays(i,"").replace(".","\\.?")+"$","i"),this._shortWeekdaysParse[s]=new RegExp("^"+this.weekdaysShort(i,"").replace(".","\\.?")+"$","i"),this._minWeekdaysParse[s]=new RegExp("^"+this.weekdaysMin(i,"").replace(".","\\.?")+"$","i")),this._weekdaysParse[s]||(i="^"+this.weekdays(i,"")+"|^"+this.weekdaysShort(i,"")+"|^"+this.weekdaysMin(i,""),this._weekdaysParse[s]=new RegExp(i.replace(".",""),"i")),n&&"dddd"===t&&this._fullWeekdaysParse[s].test(e))return s;if(n&&"ddd"===t&&this._shortWeekdaysParse[s].test(e))return s;if(n&&"dd"===t&&this._minWeekdaysParse[s].test(e))return s;if(!n&&this._weekdaysParse[s].test(e))return s}},w.weekdaysRegex=function(e){return this._weekdaysParseExact?(c(this,"_weekdaysRegex")||nt.call(this),e?this._weekdaysStrictRegex:this._weekdaysRegex):(c(this,"_weekdaysRegex")||(this._weekdaysRegex=Ke),this._weekdaysStrictRegex&&e?this._weekdaysStrictRegex:this._weekdaysRegex)},w.weekdaysShortRegex=function(e){return this._weekdaysParseExact?(c(this,"_weekdaysRegex")||nt.call(this),e?this._weekdaysShortStrictRegex:this._weekdaysShortRegex):(c(this,"_weekdaysShortRegex")||(this._weekdaysShortRegex=et),this._weekdaysShortStrictRegex&&e?this._weekdaysShortStrictRegex:this._weekdaysShortRegex)},w.weekdaysMinRegex=function(e){return this._weekdaysParseExact?(c(this,"_weekdaysRegex")||nt.call(this),e?this._weekdaysMinStrictRegex:this._weekdaysMinRegex):(c(this,"_weekdaysMinRegex")||(this._weekdaysMinRegex=tt),this._weekdaysMinStrictRegex&&e?this._weekdaysMinStrictRegex:this._weekdaysMinRegex)},w.isPM=function(e){return"p"===(e+"").toLowerCase().charAt(0)},w.meridiem=function(e,t,n){return 11<e?n?"pm":"PM":n?"am":"AM"},ct("en",{eras:[{since:"0001-01-01",until:1/0,offset:1,name:"Anno Domini",narrow:"AD",abbr:"AD"},{since:"0000-12-31",until:-1/0,offset:1,name:"Before Christ",narrow:"BC",abbr:"BC"}],dayOfMonthOrdinalParse:/\d{1,2}(th|st|nd|rd)/,ordinal:function(e){var t=e%10;return e+(1===g(e%100/10)?"th":1==t?"st":2==t?"nd":3==t?"rd":"th")}}),f.lang=e("moment.lang is deprecated. Use moment.locale instead.",ct),f.langData=e("moment.langData is deprecated. Use moment.localeData instead.",mt);var _n=Math.abs;function yn(e,t,n,s){t=C(t,n);return e._milliseconds+=s*t._milliseconds,e._days+=s*t._days,e._months+=s*t._months,e._bubble()}function gn(e){return e<0?Math.floor(e):Math.ceil(e)}function wn(e){return 4800*e/146097}function pn(e){return 146097*e/4800}function kn(e){return function(){return this.as(e)}}pe=kn("ms"),me=kn("s"),Ce=kn("m"),we=kn("h"),ge=kn("d"),Je=kn("w"),k=kn("M"),_e=kn("Q"),ve=kn("y");function vn(e){return function(){return this.isValid()?this._data[e]:NaN}}var ye=vn("milliseconds"),ke=vn("seconds"),Ie=vn("minutes"),w=vn("hours"),Mn=vn("days"),Dn=vn("months"),Sn=vn("years");var Yn=Math.round,On={ss:44,s:45,m:45,h:22,d:26,w:null,M:11};function bn(e,t,n,s){var i=C(e).abs(),r=Yn(i.as("s")),a=Yn(i.as("m")),o=Yn(i.as("h")),u=Yn(i.as("d")),l=Yn(i.as("M")),h=Yn(i.as("w")),i=Yn(i.as("y")),r=(r<=n.ss?["s",r]:r<n.s&&["ss",r])||a<=1&&["m"]||a<n.m&&["mm",a]||o<=1&&["h"]||o<n.h&&["hh",o]||u<=1&&["d"]||u<n.d&&["dd",u];return(r=(r=null!=n.w?r||h<=1&&["w"]||h<n.w&&["ww",h]:r)||l<=1&&["M"]||l<n.M&&["MM",l]||i<=1&&["y"]||["yy",i])[2]=t,r[3]=0<+e,r[4]=s,function(e,t,n,s,i){return i.relativeTime(t||1,!!n,e,s)}.apply(null,r)}var xn=Math.abs;function Tn(e){return(0<e)-(e<0)||+e}function Nn(){if(!this.isValid())return this.localeData().invalidDate();var e,t,n,s,i,r,a,o=xn(this._milliseconds)/1e3,u=xn(this._days),l=xn(this._months),h=this.asSeconds();return h?(e=y(o/60),t=y(e/60),o%=60,e%=60,n=y(l/12),l%=12,s=o?o.toFixed(3).replace(/\.?0+$/,""):"",i=Tn(this._months)!==Tn(h)?"-":"",r=Tn(this._days)!==Tn(h)?"-":"",a=Tn(this._milliseconds)!==Tn(h)?"-":"",(h<0?"-":"")+"P"+(n?i+n+"Y":"")+(l?i+l+"M":"")+(u?r+u+"D":"")+(t||e||o?"T":"")+(t?a+t+"H":"")+(e?a+e+"M":"")+(o?a+s+"S":"")):"P0D"}var U=Ct.prototype;return U.isValid=function(){return this._isValid},U.abs=function(){var e=this._data;return this._milliseconds=_n(this._milliseconds),this._days=_n(this._days),this._months=_n(this._months),e.milliseconds=_n(e.milliseconds),e.seconds=_n(e.seconds),e.minutes=_n(e.minutes),e.hours=_n(e.hours),e.months=_n(e.months),e.years=_n(e.years),this},U.add=function(e,t){return yn(this,e,t,1)},U.subtract=function(e,t){return yn(this,e,t,-1)},U.as=function(e){if(!this.isValid())return NaN;var t,n,s=this._milliseconds;if("month"===(e=_(e))||"quarter"===e||"year"===e)switch(t=this._days+s/864e5,n=this._months+wn(t),e){case"month":return n;case"quarter":return n/3;case"year":return n/12}else switch(t=this._days+Math.round(pn(this._months)),e){case"week":return t/7+s/6048e5;case"day":return t+s/864e5;case"hour":return 24*t+s/36e5;case"minute":return 1440*t+s/6e4;case"second":return 86400*t+s/1e3;case"millisecond":return Math.floor(864e5*t)+s;default:throw new Error("Unknown unit "+e)}},U.asMilliseconds=pe,U.asSeconds=me,U.asMinutes=Ce,U.asHours=we,U.asDays=ge,U.asWeeks=Je,U.asMonths=k,U.asQuarters=_e,U.asYears=ve,U.valueOf=function(){return this.isValid()?this._milliseconds+864e5*this._days+this._months%12*2592e6+31536e6*g(this._months/12):NaN},U._bubble=function(){var e=this._milliseconds,t=this._days,n=this._months,s=this._data;return 0<=e&&0<=t&&0<=n||e<=0&&t<=0&&n<=0||(e+=864e5*gn(pn(n)+t),n=t=0),s.milliseconds=e%1e3,e=y(e/1e3),s.seconds=e%60,e=y(e/60),s.minutes=e%60,e=y(e/60),s.hours=e%24,t+=y(e/24),n+=e=y(wn(t)),t-=gn(pn(e)),e=y(n/12),n%=12,s.days=t,s.months=n,s.years=e,this},U.clone=function(){return C(this)},U.get=function(e){return e=_(e),this.isValid()?this[e+"s"]():NaN},U.milliseconds=ye,U.seconds=ke,U.minutes=Ie,U.hours=w,U.days=Mn,U.weeks=function(){return y(this.days()/7)},U.months=Dn,U.years=Sn,U.humanize=function(e,t){if(!this.isValid())return this.localeData().invalidDate();var n=!1,s=On;return"object"==typeof e&&(t=e,e=!1),"boolean"==typeof e&&(n=e),"object"==typeof t&&(s=Object.assign({},On,t),null!=t.s&&null==t.ss&&(s.ss=t.s-1)),e=this.localeData(),t=bn(this,!n,s,e),n&&(t=e.pastFuture(+this,t)),e.postformat(t)},U.toISOString=Nn,U.toString=Nn,U.toJSON=Nn,U.locale=Xt,U.localeData=Kt,U.toIsoString=e("toIsoString() is deprecated. Please use toISOString() instead (notice the capitals)",Nn),U.lang=Xe,s("X",0,0,"unix"),s("x",0,0,"valueOf"),v("x",De),v("X",/[+-]?\d+(\.\d{1,3})?/),D("X",function(e,t,n){n._d=new Date(1e3*parseFloat(e))}),D("x",function(e,t,n){n._d=new Date(g(e))}),f.version="2.29.4",H=W,f.fn=i,f.min=function(){return Rt("isBefore",[].slice.call(arguments,0))},f.max=function(){return Rt("isAfter",[].slice.call(arguments,0))},f.now=function(){return Date.now?Date.now():+new Date},f.utc=l,f.unix=function(e){return W(1e3*e)},f.months=function(e,t){return fn(e,t,"months")},f.isDate=V,f.locale=ct,f.invalid=I,f.duration=C,f.isMoment=h,f.weekdays=function(e,t,n){return mn(e,t,n,"weekdays")},f.parseZone=function(){return W.apply(null,arguments).parseZone()},f.localeData=mt,f.isDuration=Ut,f.monthsShort=function(e,t){return fn(e,t,"monthsShort")},f.weekdaysMin=function(e,t,n){return mn(e,t,n,"weekdaysMin")},f.defineLocale=ft,f.updateLocale=function(e,t){var n,s;return null!=t?(s=ot,null!=R[e]&&null!=R[e].parentLocale?R[e].set(X(R[e]._config,t)):(t=X(s=null!=(n=dt(e))?n._config:s,t),null==n&&(t.abbr=e),(s=new K(t)).parentLocale=R[e],R[e]=s),ct(e)):null!=R[e]&&(null!=R[e].parentLocale?(R[e]=R[e].parentLocale,e===ct()&&ct(e)):null!=R[e]&&delete R[e]),R[e]},f.locales=function(){return ee(R)},f.weekdaysShort=function(e,t,n){return mn(e,t,n,"weekdaysShort")},f.normalizeUnits=_,f.relativeTimeRounding=function(e){return void 0===e?Yn:"function"==typeof e&&(Yn=e,!0)},f.relativeTimeThreshold=function(e,t){return void 0!==On[e]&&(void 0===t?On[e]:(On[e]=t,"s"===e&&(On.ss=t-1),!0))},f.calendarFormat=function(e,t){return(e=e.diff(t,"days",!0))<-6?"sameElse":e<-1?"lastWeek":e<0?"lastDay":e<1?"sameDay":e<2?"nextDay":e<7?"nextWeek":"sameElse"},f.prototype=i,f.HTML5_FMT={DATETIME_LOCAL:"YYYY-MM-DDTHH:mm",DATETIME_LOCAL_SECONDS:"YYYY-MM-DDTHH:mm:ss",DATETIME_LOCAL_MS:"YYYY-MM-DDTHH:mm:ss.SSS",DATE:"YYYY-MM-DD",TIME:"HH:mm",TIME_SECONDS:"HH:mm:ss",TIME_MS:"HH:mm:ss.SSS",WEEK:"GGGG-[W]WW",MONTH:"YYYY-MM"},f});
	}
})(window);
;
/*! RESOURCE: /scripts/app.ngFormElements/thirdparty/datetimepicker.js */
(function (factory) {
	'use strict';
if (typeof define === 'function' &&  define.amd) {
define(['angular', 'moment'], factory);
	} else if (typeof exports === 'object') {
module.exports = factory(require('angular'), require('moment'));
	} else {
factory(window.angular, window.moment);
	}
}(function (angular, moment) {
	'use strict';
	angular.module('ui.bootstrap.datetimepicker', ['ngAria'])
		.constant('dateTimePickerConfig', {
			dropdownSelector: null,
			minuteStep: 5,
			minView: 'minute',
			startView: 'day'
		})
		.directive('datetimepicker', ['$log', 'dateTimePickerConfig', 'i18n', function datetimepickerDirective($log, defaultConfig, i18n) {
			function DateObject() {
				var tempDate = new Date();
				var localOffset = tempDate.getTimezoneOffset() * 60000;
				this.utcDateValue = tempDate.getTime();
				this.selectable = true;
				this.localDateValue = function () {
					return this.utcDateValue + localOffset;
				};
				var validProperties = ['utcDateValue', 'localDateValue', 'display', 'fullDisplay', 'active', 'selectable', 'past', 'future'];
				for (var prop in arguments[0]) {
					if (validProperties.indexOf(prop) >= 0) {
						this[prop] = arguments[0][prop];
					}
				}
			}
			var dateTimePickerMsgs = {"Next decade": "Next decade",
							"Previous decade": "Previous decade",
							"Next year": "Next year",
							"Previous year": "Previous year",
							"Select year": "Select year", 
							"Previous month": "Previous month", 
							"Next month": "Next month", 
							"Select month": "Select month"};
			i18n.getMessages(["Next decade", "Previous decade", "Next year", "Previous year", "Select year", "Previous month", "Next month", "Select month"], function(response){
				dateTimePickerMsgs = response;
			});
			var validateConfiguration = function validateConfiguration(configuration) {
				var validOptions = ['startView', 'minView', 'minuteStep', 'dropdownSelector', 'renderOn'];
				for (var prop in configuration) {
					if (validOptions.indexOf(prop) < 0) {
						throw ('invalid option: ' + prop);
					}
				}
				var validViews = ['minute', 'hour', 'day', 'month', 'year'];
				if (validViews.indexOf(configuration.startView) < 0) {
					throw ('invalid startView value: ' + configuration.startView);
				}
				if (validViews.indexOf(configuration.minView) < 0) {
					throw ('invalid minView value: ' + configuration.minView);
				}
				if (validViews.indexOf(configuration.minView) > validViews.indexOf(configuration.startView)) {
					throw ('startView must be greater than minView');
				}
				if (!angular.isNumber(configuration.minuteStep)) {
					throw ('minuteStep must be numeric');
				}
				if (configuration.minuteStep <= 0 || configuration.minuteStep >= 60) {
					throw ('minuteStep must be greater than zero and less than 60');
				}
				if (configuration.dropdownSelector !== null && !angular.isString(configuration.dropdownSelector)) {
					throw ('dropdownSelector must be a string');
				}
				if (configuration.dropdownSelector !== null && ((typeof jQuery === 'undefined') || (typeof jQuery().dropdown !== 'function'))) {
					$log.error('Please DO NOT specify the dropdownSelector option unless you are using jQuery AND Bootstrap.js. ' +
					'Please include jQuery AND Bootstrap.js, or write code to close the dropdown in the on-set-time callback. \n\n' +
					'The dropdownSelector configuration option is being removed because it will not function properly.');
					delete configuration.dropdownSelector;
				}
			};
			return {
				restrict: 'E',
				require: 'ngModel',
				template: '<div class="datetimepicker table-responsive">' +
				'<table class="table table-striped  {{ data.currentView }}-view" role="grid">' +
				'   <thead>' +
				'       <tr>' +
'           <th class="left" tabindex="0" role="button" aria-label="{{data.previousTitle}}" data-dynamic-title="{{data.previousTitle}}" data-ng-click="changeView(data.currentView, data.leftDate, $event)" data-ng-show="data.leftDate.selectable"><i class="glyphicon glyphicon-arrow-left"/></th>' +
'           <th class="switch" tabindex="0" role="button" aria-label="{{data.ariaLabel}}" data-dynamic-title="{{data.upTitle}}" colspan="5" data-ng-show="data.previousViewDate.selectable" data-ng-click="changeView(data.previousView, data.previousViewDate, $event)">{{ data.previousViewDate.display }}</th>' +
'           <th class="right" tabindex="0" role="button" aria-label="{{data.nextTitle}}" data-dynamic-title="{{data.nextTitle}}" data-ng-click="changeView(data.currentView, data.rightDate, $event)" data-ng-show="data.rightDate.selectable"><i class="glyphicon glyphicon-arrow-right"/></th>' +
'       </tr>' +
				'       <tr>' +
'           <th class="dow" data-ng-repeat="day in data.dayNames track by $index" >{{ day }}</th>' +
'       </tr>' +
'   </thead>' +
				'   <tbody>' +
				'       <tr data-ng-if="data.currentView !== \'day\'" >' +
				'           <td colspan="7" >' +
				'              <span    class="{{ data.currentView }}" ' +
				'                       data-ng-repeat="dateObject in data.dates"  ' +
				'                       data-ng-class="{active: dateObject.active, past: dateObject.past, future: dateObject.future, disabled: !dateObject.selectable}" ' +
				'                       tabindex="0" role="button" aria-selected="{{dateObject.active}}" aria-label="{{dateObject.fullDisplay}}"' +
				'                       data-ng-click="changeView(data.nextView, dateObject, $event)"' +
'                       data-ng-keydown="keyPress(data.nextView, dateObject, $event)">{{ dateObject.display }}</span> ' +
'           </td>' +
'       </tr>' +
				'       <tr data-ng-if="data.currentView === \'day\'" data-ng-repeat="week in data.weeks">' +
				'           <td data-ng-repeat="dateObject in week.dates" ' +
				'               data-ng-click="changeView(data.nextView, dateObject, $event)"' +
				'               data-ng-keydown="keyPress(data.nextView, dateObject, $event)"' +
				'               tabindex="0" role="gridcell" aria-selected="{{dateObject.active}}" aria-label="{{dateObject.fullDisplay}}"' +
				'               class="day" ' +
'               data-ng-class="{active: dateObject.active, past: dateObject.past, future: dateObject.future, disabled: !dateObject.selectable}" >{{ dateObject.display }}</td>' +
'       </tr>' +
'   </tbody>' +
'</table></div>',
				scope: {
					onSetTime: '&',
					beforeRender: '&'
				},
				replace: true,
				link: function link(scope, element, attrs, ngModelController) {
					var directiveConfig = {};
					if (attrs.datetimepickerConfig) {
						directiveConfig = scope.$parent.$eval(attrs.datetimepickerConfig);
					}
					var configuration = {};
					angular.extend(configuration, defaultConfig, directiveConfig);
					validateConfiguration(configuration);
					if (configuration.renderOn)
						scope.$on(configuration.renderOn, function() {
							ngModelController.$render();
						});
					var startOfDecade = function startOfDecade(unixDate) {
var startYear = (parseInt(moment.utc(unixDate).year() / 10, 10) * 10);
						return moment.utc(unixDate).year(startYear).startOf('year');
					};
					var dataFactory = {
						year: function year(unixDate) {
							var selectedDate = moment.utc(unixDate).startOf('year');
var startDecade = (parseInt(selectedDate.year() / 10, 10) * 10);
							var startDate = moment.utc(startOfDecade(unixDate)).subtract(1, 'year').startOf('year');
							var activeYear = ngModelController.$modelValue ? moment(ngModelController.$modelValue).year() : 0;
							var result = {
								'currentView': 'year',
								'nextTitle': dateTimePickerMsgs['Next decade'],
								'previousTitle': dateTimePickerMsgs['Previous decade'],
								'nextView': configuration.minView === 'year' ? 'setTime' : 'month',
								'previousViewDate': new DateObject({
									utcDateValue: null,
									display: startDecade + '-' + (startDecade + 9)
								}),
								'leftDate': new DateObject({utcDateValue: moment.utc(startDate).subtract(9, 'year').valueOf()}),
								'rightDate': new DateObject({utcDateValue: moment.utc(startDate).add(11, 'year').valueOf()}),
								'dates': []
							};
							for (var i = 0; i < 12; i += 1) {
								var yearMoment = moment.utc(startDate).add(i, 'years');
								var dateValue = {
									'utcDateValue': yearMoment.valueOf(),
									'display': yearMoment.format('YYYY'),
									'past': yearMoment.year() < startDecade,
									'future': yearMoment.year() > startDecade + 9,
									'active': yearMoment.year() === activeYear
								};
								result.dates.push(new DateObject(dateValue));
							}
							return result;
						},
						month: function month(unixDate) {
							var startDate = moment.utc(unixDate).startOf('year');
							var previousViewDate = startOfDecade(unixDate);
							var activeDate = ngModelController.$modelValue ? moment(ngModelController.$modelValue).format('MMMM-YYYY') : 0;
							var result = {
								'previousView': 'year',
								'currentView': 'month',
								'nextTitle': dateTimePickerMsgs['Next year'],
								'previousTitle': dateTimePickerMsgs['Previous year'],
								'upTitle': dateTimePickerMsgs['Select year'],
								'ariaLabel': startDate.format('YYYY') + ', ' + dateTimePickerMsgs['Select year'],
								'nextView': configuration.minView === 'month' ? 'setTime' : 'day',
								'previousViewDate': new DateObject({
									utcDateValue: previousViewDate.valueOf(),
									display: startDate.format('YYYY')
								}),
								'leftDate': new DateObject({utcDateValue: moment.utc(startDate).subtract(1, 'year').valueOf()}),
								'rightDate': new DateObject({utcDateValue: moment.utc(startDate).add(1, 'year').valueOf()}),
								'dates': []
							};
							for (var i = 0; i < 12; i += 1) {
								var monthMoment = moment.utc(startDate).add(i, 'months');
								var dateValue = {
									'utcDateValue': monthMoment.valueOf(),
									'display': monthMoment.format('MMM'),
									'active': monthMoment.format('MMMM-YYYY') === activeDate
								};
								result.dates.push(new DateObject(dateValue));
							}
							return result;
						},
						day: function day(unixDate) {
							var selectedDate = moment.utc(unixDate);
							var startOfMonth = moment.utc(selectedDate).startOf('month');
							var previousViewDate = moment.utc(selectedDate).startOf('year');
							var endOfMonth = moment.utc(selectedDate).endOf('month');
							var startDate = moment.utc(startOfMonth).subtract(Math.abs(startOfMonth.weekday()), 'days');
							var activeDate = ngModelController.$modelValue ? moment(ngModelController.$modelValue).format('MMMM-DD-YYYY') : '';
							var result = {
								'previousView': 'month',
								'nextTitle': dateTimePickerMsgs['Next month'],
								'previousTitle': dateTimePickerMsgs['Previous month'],
								'upTitle': dateTimePickerMsgs['Select month'],
								'ariaLabel': startOfMonth.format('MMMM-YYYY') + ', ' + dateTimePickerMsgs['Select month'],
								'currentView': 'day',
								'nextView': configuration.minView === 'day' ? 'setTime' : 'hour',
								'previousViewDate': new DateObject({
									utcDateValue: previousViewDate.valueOf(),
									display: startOfMonth.format('MMMM-YYYY')
								}),
								'leftDate': new DateObject({utcDateValue: moment.utc(startOfMonth).subtract(1, 'months').valueOf()}),
								'rightDate': new DateObject({utcDateValue: moment.utc(startOfMonth).add(1, 'months').valueOf()}),
								'dayNames': [],
								'weeks': []
							};
							for (var dayNumber = 0; dayNumber < 7; dayNumber += 1) {
								result.dayNames.push(moment.utc().weekday(dayNumber).format('dd'));
							}
							for (var i = 0; i < 6; i += 1) {
								var week = {dates: []};
								for (var j = 0; j < 7; j += 1) {
									var monthMoment = moment.utc(startDate).add((i * 7) + j, 'days');
									var dateValue = {
										'utcDateValue': monthMoment.valueOf(),
										'display': monthMoment.format('D'),
										'fullDisplay': monthMoment.format('MMMM D YYYY dddd'),
										'active': monthMoment.format('MMMM-DD-YYYY') === activeDate,
										'past': monthMoment.isBefore(startOfMonth),
										'future': monthMoment.isAfter(endOfMonth)
									};
									week.dates.push(new DateObject(dateValue));
								}
								result.weeks.push(week);
							}
							return result;
						},
						hour: function hour(unixDate) {
							var selectedDate = moment.utc(unixDate).startOf('day');
							var previousViewDate = moment.utc(selectedDate).startOf('month');
							var activeFormat = ngModelController.$modelValue ? moment(ngModelController.$modelValue).format('YYYY-MM-DD H') : '';
							var result = {
								'previousView': 'day',
								'currentView': 'hour',
								'nextView': configuration.minView === 'hour' ? 'setTime' : 'minute',
								'previousViewDate': new DateObject({
									utcDateValue: previousViewDate.valueOf(),
									display: selectedDate.format('ll')
								}),
								'leftDate': new DateObject({utcDateValue: moment.utc(selectedDate).subtract(1, 'days').valueOf()}),
								'rightDate': new DateObject({utcDateValue: moment.utc(selectedDate).add(1, 'days').valueOf()}),
								'dates': []
							};
							for (var i = 0; i < 24; i += 1) {
								var hourMoment = moment.utc(selectedDate).add(i, 'hours');
								var dateValue = {
									'utcDateValue': hourMoment.valueOf(),
									'display': hourMoment.format('LT'),
									'active': hourMoment.format('YYYY-MM-DD H') === activeFormat
								};
								result.dates.push(new DateObject(dateValue));
							}
							return result;
						},
						minute: function minute(unixDate) {
							var selectedDate = moment.utc(unixDate).startOf('hour');
							var previousViewDate = moment.utc(selectedDate).startOf('day');
							var activeFormat = ngModelController.$modelValue ? moment(ngModelController.$modelValue).format('YYYY-MM-DD H:mm') : '';
							var result = {
								'previousView': 'hour',
								'currentView': 'minute',
								'nextView': 'setTime',
								'previousViewDate': new DateObject({
									utcDateValue: previousViewDate.valueOf(),
									display: selectedDate.format('lll')
								}),
								'leftDate': new DateObject({utcDateValue: moment.utc(selectedDate).subtract(1, 'hours').valueOf()}),
								'rightDate': new DateObject({utcDateValue: moment.utc(selectedDate).add(1, 'hours').valueOf()}),
								'dates': []
							};
var limit = 60 / configuration.minuteStep;
							for (var i = 0; i < limit; i += 1) {
								var hourMoment = moment.utc(selectedDate).add(i * configuration.minuteStep, 'minute');
								var dateValue = {
									'utcDateValue': hourMoment.valueOf(),
									'display': hourMoment.format('LT'),
									'active': hourMoment.format('YYYY-MM-DD H:mm') === activeFormat
								};
								result.dates.push(new DateObject(dateValue));
							}
							return result;
						},
						setTime: function setTime(unixDate) {
							var tempDate = new Date(unixDate);
							var newDate = new Date(tempDate.getUTCFullYear(), tempDate.getUTCMonth(), tempDate.getUTCDate(), tempDate.getUTCHours(), tempDate.getUTCMinutes(), tempDate.getUTCSeconds(), tempDate.getUTCMilliseconds());
							var oldDate = ngModelController.$modelValue;
							if (angular.element('input[id^="glide_date_time_"]')[0])
								ngModelController.$setViewValue(moment(newDate).format(angular.element('input[id^="glide_date_time_"]')[0].getAttribute("format")));
							if (configuration.dropdownSelector) {
								jQuery(configuration.dropdownSelector).dropdown('toggle');
							}
							scope.onSetTime({newDate: newDate, oldDate: oldDate});
							return dataFactory[configuration.startView](unixDate);
						}
					};
					var getUTCTime = function getUTCTime(modelValue) {
						var tempDate = (modelValue ? moment(modelValue).toDate() : new Date());
						return tempDate.getTime() - (tempDate.getTimezoneOffset() * 60000);
					};
					scope.changeView = function changeView(viewName, dateObject, event) {
						if (event) {
							event.stopPropagation();
							event.preventDefault();
						}
						var oldView = scope.data ? scope.data.currentView : '';
						if (viewName && (dateObject.utcDateValue > -Infinity) && dateObject.selectable && dataFactory[viewName]) {
							var result = dataFactory[viewName](dateObject.utcDateValue);
							var weekDates = [];
							if (result.weeks) {
								for (var i = 0; i < result.weeks.length; i += 1) {
									var week = result.weeks[i];
									for (var j = 0; j < week.dates.length; j += 1) {
										var weekDate = week.dates[j];
										weekDates.push(weekDate);
									}
								}
							}
							scope.beforeRender({
								$view: result.currentView,
								$dates: result.dates || weekDates,
								$leftDate: result.leftDate,
								$upDate: result.previousViewDate,
								$rightDate: result.rightDate
							});
							scope.data = result;
						}
						
						if (scope.data && oldView != scope.data.currentView)
							scope.focusDate();
					};
					scope.keyPress = function keyPress(viewName, dateObject, event) {
						var currentCell = event.target;
						var nodesPerRow = scope.data.currentView == 'day' ? 7 : 4;
if (event.keyCode == 13)
							scope.changeView(viewName, dateObject, event);
else if (event.keyCode == 37)
							selectDate(currentCell, -1);
else if (event.keyCode == 39)
							selectDate(currentCell, 1);
else if (event.keyCode == 38)
							selectDate(currentCell, 0 - nodesPerRow);
else if (event.keyCode == 40)
							selectDate(currentCell, nodesPerRow);
						else
							return;
						event.stopPropagation();
						event.preventDefault();
						function selectDate(fromCell, dateDifference) {
							var allTheCells = element.find('.' + scope.data.currentView);
							var thisCellIndex = allTheCells.index(fromCell);
							var targetCellIndex = Math.max(0, Math.min(allTheCells.length - 1, thisCellIndex + dateDifference));
							allTheCells[targetCellIndex].focus();
						}
					};
					scope.focusDate = function focusDate() {
						setTimeout(function() {
							var toFocus = element.find('.active');
							if (toFocus.length == 0)
								toFocus = element.find('.' + scope.data.currentView + ':not(.disabled)');
							toFocus[0].focus();
						}, 0);
					};
					ngModelController.$render = function $render() {
						scope.changeView(configuration.startView, new DateObject({utcDateValue: getUTCTime(ngModelController.$viewValue)}));
					};
				}
			};
		}]);
}));
;
/*! RESOURCE: /scripts/app.ngFormElements/thirdparty/typeahead.bundle.js */
!function(a,b){"function"==typeof define&&define.amd?define("bloodhound",["jquery"],function(c){return a.Bloodhound=b(c)}):"object"==typeof exports?module.exports=b(require("jquery")):a.Bloodhound=b(jQuery)}(this,function(a){var b=function(){"use strict";return{isMsie:function(){return/(msie|trident)/i.test(navigator.userAgent)?navigator.userAgent.match(/(msie |rv:)(\d+(.\d+)?)/i)[2]:!1},isBlankString:function(a){return!a||/^\s*$/.test(a)},escapeRegExChars:function(a){return a.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g,"\\$&")},isString:function(a){return"string"==typeof a},isNumber:function(a){return"number"==typeof a},isArray:a.isArray,isFunction:a.isFunction,isObject:a.isPlainObject,isUndefined:function(a){return"undefined"==typeof a},isElement:function(a){return!(!a||1!==a.nodeType)},isJQuery:function(b){return b instanceof a},toStr:function(a){return b.isUndefined(a)||null===a?"":a+""},bind:a.proxy,each:function(b,c){function d(a,b){return c(b,a)}a.each(b,d)},map:a.map,filter:a.grep,every:function(b,c){var d=!0;return b?(a.each(b,function(a,e){return(d=c.call(null,e,a,b))?void 0:!1}),!!d):d},some:function(b,c){var d=!1;return b?(a.each(b,function(a,e){return(d=c.call(null,e,a,b))?!1:void 0}),!!d):d},mixin:a.extend,identity:function(a){return a},clone:function(b){return a.extend(!0,{},b)},getIdGenerator:function(){var a=0;return function(){return a++}},templatify:function(b){function c(){return String(b)}return a.isFunction(b)?b:c},defer:function(a){setTimeout(a,0)},debounce:function(a,b,c){var d,e;return function(){var f,g,h=this,i=arguments;return f=function(){d=null,c||(e=a.apply(h,i))},g=c&&!d,clearTimeout(d),d=setTimeout(f,b),g&&(e=a.apply(h,i)),e}},throttle:function(a,b){var c,d,e,f,g,h;return g=0,h=function(){g=new Date,e=null,f=a.apply(c,d)},function(){var i=new Date,j=b-(i-g);return c=this,d=arguments,0>=j?(clearTimeout(e),e=null,g=i,f=a.apply(c,d)):e||(e=setTimeout(h,j)),f}},stringify:function(a){return b.isString(a)?a:JSON.stringify(a)},noop:function(){}}}(),c="0.11.1",d=function(){"use strict";function a(a){return a=b.toStr(a),a?a.split(/\s+/):[]}function c(a){return a=b.toStr(a),a?a.split(/\W+/):[]}function d(a){return function(c){return c=b.isArray(c)?c:[].slice.call(arguments,0),function(d){var e=[];return b.each(c,function(c){e=e.concat(a(b.toStr(d[c])))}),e}}}return{nonword:c,whitespace:a,obj:{nonword:d(c),whitespace:d(a)}}}(),e=function(){"use strict";function c(c){this.maxSize=b.isNumber(c)?c:100,this.reset(),this.maxSize<=0&&(this.set=this.get=a.noop)}function d(){this.head=this.tail=null}function e(a,b){this.key=a,this.val=b,this.prev=this.next=null}return b.mixin(c.prototype,{set:function(a,b){var c,d=this.list.tail;this.size>=this.maxSize&&(this.list.remove(d),delete this.hash[d.key],this.size--),(c=this.hash[a])?(c.val=b,this.list.moveToFront(c)):(c=new e(a,b),this.list.add(c),this.hash[a]=c,this.size++)},get:function(a){var b=this.hash[a];return b?(this.list.moveToFront(b),b.val):void 0},reset:function(){this.size=0,this.hash={},this.list=new d}}),b.mixin(d.prototype,{add:function(a){this.head&&(a.next=this.head,this.head.prev=a),this.head=a,this.tail=this.tail||a},remove:function(a){a.prev?a.prev.next=a.next:this.head=a.next,a.next?a.next.prev=a.prev:this.tail=a.prev},moveToFront:function(a){this.remove(a),this.add(a)}}),c}(),f=function(){"use strict";function c(a,c){this.prefix=["__",a,"__"].join(""),this.ttlKey="__ttl__",this.keyMatcher=new RegExp("^"+b.escapeRegExChars(this.prefix)),this.ls=c||h,!this.ls&&this._noop()}function d(){return(new Date).getTime()}function e(a){return JSON.stringify(b.isUndefined(a)?null:a)}function f(b){return a.parseJSON(b)}function g(a){var b,c,d=[],e=h.length;for(b=0;e>b;b++)(c=h.key(b)).match(a)&&d.push(c.replace(a,""));return d}var h;try{h=window.localStorage,h.setItem("~~~","!"),h.removeItem("~~~")}catch(i){h=null}return b.mixin(c.prototype,{_prefix:function(a){return this.prefix+a},_ttlKey:function(a){return this._prefix(a)+this.ttlKey},_noop:function(){this.get=this.set=this.remove=this.clear=this.isExpired=b.noop},_safeSet:function(a,b){try{this.ls.setItem(a,b)}catch(c){"QuotaExceededError"===c.name&&(this.clear(),this._noop())}},get:function(a){return this.isExpired(a)&&this.remove(a),f(this.ls.getItem(this._prefix(a)))},set:function(a,c,f){return b.isNumber(f)?this._safeSet(this._ttlKey(a),e(d()+f)):this.ls.removeItem(this._ttlKey(a)),this._safeSet(this._prefix(a),e(c))},remove:function(a){return this.ls.removeItem(this._ttlKey(a)),this.ls.removeItem(this._prefix(a)),this},clear:function(){var a,b=g(this.keyMatcher);for(a=b.length;a--;)this.remove(b[a]);return this},isExpired:function(a){var c=f(this.ls.getItem(this._ttlKey(a)));return b.isNumber(c)&&d()>c?!0:!1}}),c}(),g=function(){"use strict";function c(a){a=a||{},this.cancelled=!1,this.lastReq=null,this._send=a.transport,this._get=a.limiter?a.limiter(this._get):this._get,this._cache=a.cache===!1?new e(0):h}var d=0,f={},g=6,h=new e(10);return c.setMaxPendingRequests=function(a){g=a},c.resetCache=function(){h.reset()},b.mixin(c.prototype,{_fingerprint:function(b){return b=b||{},b.url+b.type+a.param(b.data||{})},_get:function(a,b){function c(a){b(null,a),k._cache.set(i,a)}function e(){b(!0)}function h(){d--,delete f[i],k.onDeckRequestArgs&&(k._get.apply(k,k.onDeckRequestArgs),k.onDeckRequestArgs=null)}var i,j,k=this;i=this._fingerprint(a),this.cancelled||i!==this.lastReq||((j=f[i])?j.done(c).fail(e):g>d?(d++,f[i]=this._send(a).done(c).fail(e).always(h)):this.onDeckRequestArgs=[].slice.call(arguments,0))},get:function(c,d){var e,f;d=d||a.noop,c=b.isString(c)?{url:c}:c||{},f=this._fingerprint(c),this.cancelled=!1,this.lastReq=f,(e=this._cache.get(f))?d(null,e):this._get(c,d)},cancel:function(){this.cancelled=!0}}),c}(),h=window.SearchIndex=function(){"use strict";function c(c){c=c||{},c.datumTokenizer&&c.queryTokenizer||a.error("datumTokenizer and queryTokenizer are both required"),this.identify=c.identify||b.stringify,this.datumTokenizer=c.datumTokenizer,this.queryTokenizer=c.queryTokenizer,this.reset()}function d(a){return a=b.filter(a,function(a){return!!a}),a=b.map(a,function(a){return a.toLowerCase()})}function e(){var a={};return a[i]=[],a[h]={},a}function f(a){for(var b={},c=[],d=0,e=a.length;e>d;d++)b[a[d]]||(b[a[d]]=!0,c.push(a[d]));return c}function g(a,b){var c=0,d=0,e=[];a=a.sort(),b=b.sort();for(var f=a.length,g=b.length;f>c&&g>d;)a[c]<b[d]?c++:a[c]>b[d]?d++:(e.push(a[c]),c++,d++);return e}var h="c",i="i";return b.mixin(c.prototype,{bootstrap:function(a){this.datums=a.datums,this.trie=a.trie},add:function(a){var c=this;a=b.isArray(a)?a:[a],b.each(a,function(a){var f,g;c.datums[f=c.identify(a)]=a,g=d(c.datumTokenizer(a)),b.each(g,function(a){var b,d,g;for(b=c.trie,d=a.split("");g=d.shift();)b=b[h][g]||(b[h][g]=e()),b[i].push(f)})})},get:function(a){var c=this;return b.map(a,function(a){return c.datums[a]})},search:function(a){var c,e,j=this;return c=d(this.queryTokenizer(a)),b.each(c,function(a){var b,c,d,f;if(e&&0===e.length)return!1;for(b=j.trie,c=a.split("");b&&(d=c.shift());)b=b[h][d];return b&&0===c.length?(f=b[i].slice(0),void(e=e?g(e,f):f)):(e=[],!1)}),e?b.map(f(e),function(a){return j.datums[a]}):[]},all:function(){var a=[];for(var b in this.datums)a.push(this.datums[b]);return a},reset:function(){this.datums={},this.trie=e()},serialize:function(){return{datums:this.datums,trie:this.trie}}}),c}(),i=function(){"use strict";function a(a){this.url=a.url,this.ttl=a.ttl,this.cache=a.cache,this.prepare=a.prepare,this.transform=a.transform,this.transport=a.transport,this.thumbprint=a.thumbprint,this.storage=new f(a.cacheKey)}var c;return c={data:"data",protocol:"protocol",thumbprint:"thumbprint"},b.mixin(a.prototype,{_settings:function(){return{url:this.url,type:"GET",dataType:"json"}},store:function(a){this.cache&&(this.storage.set(c.data,a,this.ttl),this.storage.set(c.protocol,location.protocol,this.ttl),this.storage.set(c.thumbprint,this.thumbprint,this.ttl))},fromCache:function(){var a,b={};return this.cache?(b.data=this.storage.get(c.data),b.protocol=this.storage.get(c.protocol),b.thumbprint=this.storage.get(c.thumbprint),a=b.thumbprint!==this.thumbprint||b.protocol!==location.protocol,b.data&&!a?b.data:null):null},fromNetwork:function(a){function b(){a(!0)}function c(b){a(null,e.transform(b))}var d,e=this;a&&(d=this.prepare(this._settings()),this.transport(d).fail(b).done(c))},clear:function(){return this.storage.clear(),this}}),a}(),j=function(){"use strict";function a(a){this.url=a.url,this.prepare=a.prepare,this.transform=a.transform,this.transport=new g({cache:a.cache,limiter:a.limiter,transport:a.transport})}return b.mixin(a.prototype,{_settings:function(){return{url:this.url,type:"GET",dataType:"json"}},get:function(a,b){function c(a,c){b(a?[]:e.transform(c))}var d,e=this;if(b)return a=a||"",d=this.prepare(a,this._settings()),this.transport.get(d,c)},cancelLastRequest:function(){this.transport.cancel()}}),a}(),k=function(){"use strict";function d(d){var e;return d?(e={url:null,ttl:864e5,cache:!0,cacheKey:null,thumbprint:"",prepare:b.identity,transform:b.identity,transport:null},d=b.isString(d)?{url:d}:d,d=b.mixin(e,d),!d.url&&a.error("prefetch requires url to be set"),d.transform=d.filter||d.transform,d.cacheKey=d.cacheKey||d.url,d.thumbprint=c+d.thumbprint,d.transport=d.transport?h(d.transport):a.ajax,d):null}function e(c){var d;if(c)return d={url:null,cache:!0,prepare:null,replace:null,wildcard:null,limiter:null,rateLimitBy:"debounce",rateLimitWait:300,transform:b.identity,transport:null},c=b.isString(c)?{url:c}:c,c=b.mixin(d,c),!c.url&&a.error("remote requires url to be set"),c.transform=c.filter||c.transform,c.prepare=f(c),c.limiter=g(c),c.transport=c.transport?h(c.transport):a.ajax,delete c.replace,delete c.wildcard,delete c.rateLimitBy,delete c.rateLimitWait,c}function f(a){function b(a,b){return b.url=f(b.url,a),b}function c(a,b){return b.url=b.url.replace(g,encodeURIComponent(a)),b}function d(a,b){return b}var e,f,g;return e=a.prepare,f=a.replace,g=a.wildcard,e?e:e=f?b:a.wildcard?c:d}function g(a){function c(a){return function(c){return b.debounce(c,a)}}function d(a){return function(c){return b.throttle(c,a)}}var e,f,g;return e=a.limiter,f=a.rateLimitBy,g=a.rateLimitWait,e||(e=/^throttle$/i.test(f)?d(g):c(g)),e}function h(c){return function(d){function e(a){b.defer(function(){g.resolve(a)})}function f(a){b.defer(function(){g.reject(a)})}var g=a.Deferred();return c(d,e,f),g}}return function(c){var f,g;return f={initialize:!0,identify:b.stringify,datumTokenizer:null,queryTokenizer:null,sufficient:5,sorter:null,local:[],prefetch:null,remote:null},c=b.mixin(f,c||{}),!c.datumTokenizer&&a.error("datumTokenizer is required"),!c.queryTokenizer&&a.error("queryTokenizer is required"),g=c.sorter,c.sorter=g?function(a){return a.sort(g)}:b.identity,c.local=b.isFunction(c.local)?c.local():c.local,c.prefetch=d(c.prefetch),c.remote=e(c.remote),c}}(),l=function(){"use strict";function c(a){a=k(a),this.sorter=a.sorter,this.identify=a.identify,this.sufficient=a.sufficient,this.local=a.local,this.remote=a.remote?new j(a.remote):null,this.prefetch=a.prefetch?new i(a.prefetch):null,this.index=new h({identify:this.identify,datumTokenizer:a.datumTokenizer,queryTokenizer:a.queryTokenizer}),a.initialize!==!1&&this.initialize()}var e;return e=window&&window.Bloodhound,c.noConflict=function(){return window&&(window.Bloodhound=e),c},c.tokenizers=d,b.mixin(c.prototype,{__ttAdapter:function(){function a(a,b,d){return c.search(a,b,d)}function b(a,b){return c.search(a,b)}var c=this;return this.remote?a:b},_loadPrefetch:function(){function b(a,b){return a?c.reject():(e.add(b),e.prefetch.store(e.index.serialize()),void c.resolve())}var c,d,e=this;return c=a.Deferred(),this.prefetch?(d=this.prefetch.fromCache())?(this.index.bootstrap(d),c.resolve()):this.prefetch.fromNetwork(b):c.resolve(),c.promise()},_initialize:function(){function a(){b.add(b.local)}var b=this;return this.clear(),(this.initPromise=this._loadPrefetch()).done(a),this.initPromise},initialize:function(a){return!this.initPromise||a?this._initialize():this.initPromise},add:function(a){return this.index.add(a),this},get:function(a){return a=b.isArray(a)?a:[].slice.call(arguments),this.index.get(a)},search:function(a,c,d){function e(a){var c=[];b.each(a,function(a){!b.some(f,function(b){return g.identify(a)===g.identify(b)})&&c.push(a)}),d&&d(c)}var f,g=this;return f=this.sorter(this.index.search(a)),c(this.remote?f.slice():f),this.remote&&f.length<this.sufficient?this.remote.get(a,e):this.remote&&this.remote.cancelLastRequest(),this},all:function(){return this.index.all()},clear:function(){return this.index.reset(),this},clearPrefetchCache:function(){return this.prefetch&&this.prefetch.clear(),this},clearRemoteCache:function(){return g.resetCache(),this},ttAdapter:function(){return this.__ttAdapter()}}),c}();return l}),function(a,b){"function"==typeof define&&define.amd?define("typeahead.js",["jquery"],function(a){return b(a)}):"object"==typeof exports?module.exports=b(require("jquery")):b(jQuery)}(this,function(a){var b=function(){"use strict";return{isMsie:function(){return/(msie|trident)/i.test(navigator.userAgent)?navigator.userAgent.match(/(msie |rv:)(\d+(.\d+)?)/i)[2]:!1},isBlankString:function(a){return!a||/^\s*$/.test(a)},escapeRegExChars:function(a){return a.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g,"\\$&")},isString:function(a){return"string"==typeof a},isNumber:function(a){return"number"==typeof a},isArray:a.isArray,isFunction:a.isFunction,isObject:a.isPlainObject,isUndefined:function(a){return"undefined"==typeof a},isElement:function(a){return!(!a||1!==a.nodeType)},isJQuery:function(b){return b instanceof a},toStr:function(a){return b.isUndefined(a)||null===a?"":a+""},bind:a.proxy,each:function(b,c){function d(a,b){return c(b,a)}a.each(b,d)},map:a.map,filter:a.grep,every:function(b,c){var d=!0;return b?(a.each(b,function(a,e){return(d=c.call(null,e,a,b))?void 0:!1}),!!d):d},some:function(b,c){var d=!1;return b?(a.each(b,function(a,e){return(d=c.call(null,e,a,b))?!1:void 0}),!!d):d},mixin:a.extend,identity:function(a){return a},clone:function(b){return a.extend(!0,{},b)},getIdGenerator:function(){var a=0;return function(){return a++}},templatify:function(b){function c(){return String(b)}return a.isFunction(b)?b:c},defer:function(a){setTimeout(a,0)},debounce:function(a,b,c){var d,e;return function(){var f,g,h=this,i=arguments;return f=function(){d=null,c||(e=a.apply(h,i))},g=c&&!d,clearTimeout(d),d=setTimeout(f,b),g&&(e=a.apply(h,i)),e}},throttle:function(a,b){var c,d,e,f,g,h;return g=0,h=function(){g=new Date,e=null,f=a.apply(c,d)},function(){var i=new Date,j=b-(i-g);return c=this,d=arguments,0>=j?(clearTimeout(e),e=null,g=i,f=a.apply(c,d)):e||(e=setTimeout(h,j)),f}},stringify:function(a){return b.isString(a)?a:JSON.stringify(a)},noop:function(){}}}(),c=function(){"use strict";function a(a){var g,h;return h=b.mixin({},f,a),g={css:e(),classes:h,html:c(h),selectors:d(h)},{css:g.css,html:g.html,classes:g.classes,selectors:g.selectors,mixin:function(a){b.mixin(a,g)}}}function c(a){return{wrapper:'<span class="'+a.wrapper+'"></span>',menu:'<div class="'+a.menu+'"></div>'}}function d(a){var c={};return b.each(a,function(a,b){c[b]="."+a}),c}function e(){var a={wrapper:{position:"relative",display:"inline-block"},hint:{position:"absolute",top:"0",left:"0",borderColor:"transparent",boxShadow:"none",opacity:"1"},input:{position:"relative",verticalAlign:"top",backgroundColor:"transparent"},inputWithNoHint:{position:"relative",verticalAlign:"top"},menu:{position:"absolute",top:"100%",left:"0",zIndex:"100",display:"none"},ltr:{left:"0",right:"auto"},rtl:{left:"auto",right:" 0"}};return b.isMsie()&&b.mixin(a.input,{backgroundImage:"url(data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7)"}),a}var f={wrapper:"twitter-typeahead",input:"tt-input",hint:"tt-hint",menu:"tt-menu",dataset:"tt-dataset",suggestion:"tt-suggestion",selectable:"tt-selectable",empty:"tt-empty",open:"tt-open",cursor:"tt-cursor",highlight:"tt-highlight"};return a}(),d=function(){"use strict";function c(b){b&&b.el||a.error("EventBus initialized without el"),this.$el=a(b.el)}var d,e;return d="typeahead:",e={render:"rendered",cursorchange:"cursorchanged",select:"selected",autocomplete:"autocompleted"},b.mixin(c.prototype,{_trigger:function(b,c){var e;return e=a.Event(d+b),(c=c||[]).unshift(e),this.$el.trigger.apply(this.$el,c),e},before:function(a){var b,c;return b=[].slice.call(arguments,1),c=this._trigger("before"+a,b),c.isDefaultPrevented()},trigger:function(a){var b;this._trigger(a,[].slice.call(arguments,1)),(b=e[a])&&this._trigger(b,[].slice.call(arguments,1))}}),c}(),e=function(){"use strict";function a(a,b,c,d){var e;if(!c)return this;for(b=b.split(i),c=d?h(c,d):c,this._callbacks=this._callbacks||{};e=b.shift();)this._callbacks[e]=this._callbacks[e]||{sync:[],async:[]},this._callbacks[e][a].push(c);return this}function b(b,c,d){return a.call(this,"async",b,c,d)}function c(b,c,d){return a.call(this,"sync",b,c,d)}function d(a){var b;if(!this._callbacks)return this;for(a=a.split(i);b=a.shift();)delete this._callbacks[b];return this}function e(a){var b,c,d,e,g;if(!this._callbacks)return this;for(a=a.split(i),d=[].slice.call(arguments,1);(b=a.shift())&&(c=this._callbacks[b]);)e=f(c.sync,this,[b].concat(d)),g=f(c.async,this,[b].concat(d)),e()&&j(g);return this}function f(a,b,c){function d(){for(var d,e=0,f=a.length;!d&&f>e;e+=1)d=a[e].apply(b,c)===!1;return!d}return d}function g(){var a;return a=window.setImmediate?function(a){setImmediate(function(){a()})}:function(a){setTimeout(function(){a()},0)}}function h(a,b){return a.bind?a.bind(b):function(){a.apply(b,[].slice.call(arguments,0))}}var i=/\s+/,j=g();return{onSync:c,onAsync:b,off:d,trigger:e}}(),f=function(a){"use strict";function c(a,c,d){for(var e,f=[],g=0,h=a.length;h>g;g++)f.push(b.escapeRegExChars(a[g]));return e=d?"\\b("+f.join("|")+")\\b":"("+f.join("|")+")",c?new RegExp(e):new RegExp(e,"i")}var d={node:null,pattern:null,tagName:"strong",className:null,wordsOnly:!1,caseSensitive:!1};return function(e){function f(b){var c,d,f;return(c=h.exec(b.data))&&(f=a.createElement(e.tagName),e.className&&(f.className=e.className),d=b.splitText(c.index),d.splitText(c[0].length),f.appendChild(d.cloneNode(!0)),b.parentNode.replaceChild(f,d)),!!c}function g(a,b){for(var c,d=3,e=0;e<a.childNodes.length;e++)c=a.childNodes[e],c.nodeType===d?e+=b(c)?1:0:g(c,b)}var h;e=b.mixin({},d,e),e.node&&e.pattern&&(e.pattern=b.isArray(e.pattern)?e.pattern:[e.pattern],h=c(e.pattern,e.caseSensitive,e.wordsOnly),g(e.node,f))}}(window.document),g=function(){"use strict";function c(c,e){c=c||{},c.input||a.error("input is missing"),e.mixin(this),this.$hint=a(c.hint),this.$input=a(c.input),this.query=this.$input.val(),this.queryWhenFocused=this.hasFocus()?this.query:null,this.$overflowHelper=d(this.$input),this._checkLanguageDirection(),0===this.$hint.length&&(this.setHint=this.getHint=this.clearHint=this.clearHintIfInvalid=b.noop)}function d(b){return a('<pre aria-hidden="true"></pre>').css({position:"absolute",visibility:"hidden",whiteSpace:"pre",fontFamily:b.css("font-family"),fontSize:b.css("font-size"),fontStyle:b.css("font-style"),fontVariant:b.css("font-variant"),fontWeight:b.css("font-weight"),wordSpacing:b.css("word-spacing"),letterSpacing:b.css("letter-spacing"),textIndent:b.css("text-indent"),textRendering:b.css("text-rendering"),textTransform:b.css("text-transform")}).insertAfter(b)}function f(a,b){return c.normalizeQuery(a)===c.normalizeQuery(b)}function g(a){return a.altKey||a.ctrlKey||a.metaKey||a.shiftKey}var h;return h={9:"tab",27:"esc",37:"left",39:"right",13:"enter",38:"up",40:"down"},c.normalizeQuery=function(a){return b.toStr(a).replace(/^\s*/g,"").replace(/\s{2,}/g," ")},b.mixin(c.prototype,e,{_onBlur:function(){this.resetInputValue(),this.trigger("blurred")},_onFocus:function(){this.queryWhenFocused=this.query,this.trigger("focused")},_onKeydown:function(a){var b=h[a.which||a.keyCode];this._managePreventDefault(b,a),b&&this._shouldTrigger(b,a)&&this.trigger(b+"Keyed",a)},_onInput:function(){this._setQuery(this.getInputValue()),this.clearHintIfInvalid(),this._checkLanguageDirection()},_managePreventDefault:function(a,b){var c;switch(a){case"up":case"down":c=!g(b);break;default:c=!1}c&&b.preventDefault()},_shouldTrigger:function(a,b){var c;switch(a){case"tab":c=!g(b);break;default:c=!0}return c},_checkLanguageDirection:function(){var a=(this.$input.css("direction")||"ltr").toLowerCase();this.dir!==a&&(this.dir=a,this.$hint.attr("dir",a),this.trigger("langDirChanged",a))},_setQuery:function(a,b){var c,d;c=f(a,this.query),d=c?this.query.length!==a.length:!1,this.query=a,b||c?!b&&d&&this.trigger("whitespaceChanged",this.query):this.trigger("queryChanged",this.query)},bind:function(){var a,c,d,e,f=this;return a=b.bind(this._onBlur,this),c=b.bind(this._onFocus,this),d=b.bind(this._onKeydown,this),e=b.bind(this._onInput,this),this.$input.on("blur.tt",a).on("focus.tt",c).on("keydown.tt",d),!b.isMsie()||b.isMsie()>9?this.$input.on("input.tt",e):this.$input.on("keydown.tt keypress.tt cut.tt paste.tt",function(a){h[a.which||a.keyCode]||b.defer(b.bind(f._onInput,f,a))}),this},focus:function(){this.$input.focus()},blur:function(){this.$input.blur()},getLangDir:function(){return this.dir},getQuery:function(){return this.query||""},setQuery:function(a,b){this.setInputValue(a),this._setQuery(a,b)},hasQueryChangedSinceLastFocus:function(){return this.query!==this.queryWhenFocused},getInputValue:function(){return this.$input.val()},setInputValue:function(a){this.$input.val(a),this.clearHintIfInvalid(),this._checkLanguageDirection()},resetInputValue:function(){this.setInputValue(this.query)},getHint:function(){return this.$hint.val()},setHint:function(a){this.$hint.val(a)},clearHint:function(){this.setHint("")},clearHintIfInvalid:function(){var a,b,c,d;a=this.getInputValue(),b=this.getHint(),c=a!==b&&0===b.indexOf(a),d=""!==a&&c&&!this.hasOverflow(),!d&&this.clearHint()},hasFocus:function(){return this.$input.is(":focus")},hasOverflow:function(){var a=this.$input.width()-2;return this.$overflowHelper.text(this.getInputValue()),this.$overflowHelper.width()>=a},isCursorAtEnd:function(){var a,c,d;return a=this.$input.val().length,c=this.$input[0].selectionStart,b.isNumber(c)?c===a:document.selection?(d=document.selection.createRange(),d.moveStart("character",-a),a===d.text.length):!0},destroy:function(){this.$hint.off(".tt"),this.$input.off(".tt"),this.$overflowHelper.remove(),this.$hint=this.$input=this.$overflowHelper=a("<div>")}}),c}(),h=function(){"use strict";function c(c,e){c=c||{},c.templates=c.templates||{},c.templates.notFound=c.templates.notFound||c.templates.empty,c.source||a.error("missing source"),c.node||a.error("missing node"),c.name&&!h(c.name)&&a.error("invalid dataset name: "+c.name),e.mixin(this),this.highlight=!!c.highlight,this.name=c.name||j(),this.limit=c.limit||5,this.displayFn=d(c.display||c.displayKey),this.templates=g(c.templates,this.displayFn),this.source=c.source.__ttAdapter?c.source.__ttAdapter():c.source,this.async=b.isUndefined(c.async)?this.source.length>2:!!c.async,this._resetLastSuggestion(),this.$el=a(c.node).addClass(this.classes.dataset).addClass(this.classes.dataset+"-"+this.name)}function d(a){function c(b){return b[a]}return a=a||b.stringify,b.isFunction(a)?a:c}function g(c,d){function e(b){return a("<div>").text(d(b))}return{notFound:c.notFound&&b.templatify(c.notFound),pending:c.pending&&b.templatify(c.pending),header:c.header&&b.templatify(c.header),footer:c.footer&&b.templatify(c.footer),suggestion:c.suggestion||e}}function h(a){return/^[_a-zA-Z0-9-]+$/.test(a)}var i,j;return i={val:"tt-selectable-display",obj:"tt-selectable-object"},j=b.getIdGenerator(),c.extractData=function(b){var c=a(b);return c.data(i.obj)?{val:c.data(i.val)||"",obj:c.data(i.obj)||null}:null},b.mixin(c.prototype,e,{_overwrite:function(a,b){b=b||[],b.length?this._renderSuggestions(a,b):this.async&&this.templates.pending?this._renderPending(a):!this.async&&this.templates.notFound?this._renderNotFound(a):this._empty(),this.trigger("rendered",this.name,b,!1)},_append:function(a,b){b=b||[],b.length&&this.$lastSuggestion.length?this._appendSuggestions(a,b):b.length?this._renderSuggestions(a,b):!this.$lastSuggestion.length&&this.templates.notFound&&this._renderNotFound(a),this.trigger("rendered",this.name,b,!0)},_renderSuggestions:function(a,b){var c;c=this._getSuggestionsFragment(a,b),this.$lastSuggestion=c.children().last(),this.$el.html(c).prepend(this._getHeader(a,b)).append(this._getFooter(a,b))},_appendSuggestions:function(a,b){var c,d;c=this._getSuggestionsFragment(a,b),d=c.children().last(),this.$lastSuggestion.after(c),this.$lastSuggestion=d},_renderPending:function(a){var b=this.templates.pending;this._resetLastSuggestion(),b&&this.$el.html(b({query:a,dataset:this.name}))},_renderNotFound:function(a){var b=this.templates.notFound;this._resetLastSuggestion(),b&&this.$el.html(b({query:a,dataset:this.name}))},_empty:function(){this.$el.empty(),this._resetLastSuggestion()},_getSuggestionsFragment:function(c,d){var e,g=this;return e=document.createDocumentFragment(),b.each(d,function(b){var d,f;f=g._injectQuery(c,b),d=a(g.templates.suggestion(f)).data(i.obj,b).data(i.val,g.displayFn(b)).addClass(g.classes.suggestion+" "+g.classes.selectable),e.appendChild(d[0])}),this.highlight&&f({className:this.classes.highlight,node:e,pattern:c}),a(e)},_getFooter:function(a,b){return this.templates.footer?this.templates.footer({query:a,suggestions:b,dataset:this.name}):null},_getHeader:function(a,b){return this.templates.header?this.templates.header({query:a,suggestions:b,dataset:this.name}):null},_resetLastSuggestion:function(){this.$lastSuggestion=a()},_injectQuery:function(a,c){return b.isObject(c)?b.mixin({_query:a},c):c},update:function(b){function c(a){g||(g=!0,a=(a||[]).slice(0,e.limit),h=a.length,e._overwrite(b,a),h<e.limit&&e.async&&e.trigger("asyncRequested",b))}function d(c){c=c||[],!f&&h<e.limit&&(e.cancel=a.noop,h+=c.length,e._append(b,c.slice(0,e.limit-h)),e.async&&e.trigger("asyncReceived",b))}var e=this,f=!1,g=!1,h=0;this.cancel(),this.cancel=function(){f=!0,e.cancel=a.noop,e.async&&e.trigger("asyncCanceled",b)},this.source(b,c,d),!g&&c([])},cancel:a.noop,clear:function(){this._empty(),this.cancel(),this.trigger("cleared")},isEmpty:function(){return this.$el.is(":empty")},destroy:function(){this.$el=a("<div>")}}),c}(),i=function(){"use strict";function c(c,d){function e(b){var c=f.$node.find(b.node).first();return b.node=c.length?c:a("<div>").appendTo(f.$node),new h(b,d)}var f=this;c=c||{},c.node||a.error("node is required"),d.mixin(this),this.$node=a(c.node),this.query=null,this.datasets=b.map(c.datasets,e)}return b.mixin(c.prototype,e,{_onSelectableClick:function(b){this.trigger("selectableClicked",a(b.currentTarget))},_onRendered:function(a,b,c,d){this.$node.toggleClass(this.classes.empty,this._allDatasetsEmpty()),this.trigger("datasetRendered",b,c,d)},_onCleared:function(){this.$node.toggleClass(this.classes.empty,this._allDatasetsEmpty()),this.trigger("datasetCleared")},_propagate:function(){this.trigger.apply(this,arguments)},_allDatasetsEmpty:function(){function a(a){return a.isEmpty()}return b.every(this.datasets,a)},_getSelectables:function(){return this.$node.find(this.selectors.selectable)},_removeCursor:function(){var a=this.getActiveSelectable();a&&a.removeClass(this.classes.cursor)},_ensureVisible:function(a){var b,c,d,e;b=a.position().top,c=b+a.outerHeight(!0),d=this.$node.scrollTop(),e=this.$node.height()+parseInt(this.$node.css("paddingTop"),10)+parseInt(this.$node.css("paddingBottom"),10),0>b?this.$node.scrollTop(d+b):c>e&&this.$node.scrollTop(d+(c-e))},bind:function(){var a,c=this;return a=b.bind(this._onSelectableClick,this),this.$node.on("click.tt",this.selectors.selectable,a),b.each(this.datasets,function(a){a.onSync("asyncRequested",c._propagate,c).onSync("asyncCanceled",c._propagate,c).onSync("asyncReceived",c._propagate,c).onSync("rendered",c._onRendered,c).onSync("cleared",c._onCleared,c)}),this},isOpen:function(){return this.$node.hasClass(this.classes.open)},open:function(){this.$node.addClass(this.classes.open)},close:function(){this.$node.removeClass(this.classes.open),this._removeCursor()},setLanguageDirection:function(a){this.$node.attr("dir",a)},selectableRelativeToCursor:function(a){var b,c,d,e;return c=this.getActiveSelectable(),b=this._getSelectables(),d=c?b.index(c):-1,e=d+a,e=(e+1)%(b.length+1)-1,e=-1>e?b.length-1:e,-1===e?null:b.eq(e)},setCursor:function(a){this._removeCursor(),(a=a&&a.first())&&(a.addClass(this.classes.cursor),this._ensureVisible(a))},getSelectableData:function(a){return a&&a.length?h.extractData(a):null},getActiveSelectable:function(){var a=this._getSelectables().filter(this.selectors.cursor).first();return a.length?a:null},getTopSelectable:function(){var a=this._getSelectables().first();return a.length?a:null},update:function(a){function c(b){b.update(a)}var d=a!==this.query;return d&&(this.query=a,b.each(this.datasets,c)),d},empty:function(){function a(a){a.clear()}b.each(this.datasets,a),this.query=null,this.$node.addClass(this.classes.empty)},destroy:function(){function c(a){a.destroy()}this.$node.off(".tt"),this.$node=a("<div>"),b.each(this.datasets,c)}}),c}(),j=function(){"use strict";function a(){i.apply(this,[].slice.call(arguments,0))}var c=i.prototype;return b.mixin(a.prototype,i.prototype,{open:function(){return!this._allDatasetsEmpty()&&this._show(),c.open.apply(this,[].slice.call(arguments,0))},close:function(){return this._hide(),c.close.apply(this,[].slice.call(arguments,0))},_onRendered:function(){return this._allDatasetsEmpty()?this._hide():this.isOpen()&&this._show(),c._onRendered.apply(this,[].slice.call(arguments,0))},_onCleared:function(){return this._allDatasetsEmpty()?this._hide():this.isOpen()&&this._show(),c._onCleared.apply(this,[].slice.call(arguments,0))},setLanguageDirection:function(a){return this.$node.css("ltr"===a?this.css.ltr:this.css.rtl),c.setLanguageDirection.apply(this,[].slice.call(arguments,0))},_hide:function(){this.$node.hide()},_show:function(){this.$node.css("display","block")}}),a}(),k=function(){"use strict";function c(c,e){var f,g,h,i,j,k,l,m,n,o,p;c=c||{},c.input||a.error("missing input"),c.menu||a.error("missing menu"),c.eventBus||a.error("missing event bus"),e.mixin(this),this.eventBus=c.eventBus,this.minLength=b.isNumber(c.minLength)?c.minLength:1,this.input=c.input,this.menu=c.menu,this.enabled=!0,this.active=!1,this.input.hasFocus()&&this.activate(),this.dir=this.input.getLangDir(),this._hacks(),this.menu.bind().onSync("selectableClicked",this._onSelectableClicked,this).onSync("asyncRequested",this._onAsyncRequested,this).onSync("asyncCanceled",this._onAsyncCanceled,this).onSync("asyncReceived",this._onAsyncReceived,this).onSync("datasetRendered",this._onDatasetRendered,this).onSync("datasetCleared",this._onDatasetCleared,this),f=d(this,"activate","open","_onFocused"),g=d(this,"deactivate","_onBlurred"),h=d(this,"isActive","isOpen","_onEnterKeyed"),i=d(this,"isActive","isOpen","_onTabKeyed"),j=d(this,"isActive","_onEscKeyed"),k=d(this,"isActive","open","_onUpKeyed"),l=d(this,"isActive","open","_onDownKeyed"),m=d(this,"isActive","isOpen","_onLeftKeyed"),n=d(this,"isActive","isOpen","_onRightKeyed"),o=d(this,"_openIfActive","_onQueryChanged"),p=d(this,"_openIfActive","_onWhitespaceChanged"),this.input.bind().onSync("focused",f,this).onSync("blurred",g,this).onSync("enterKeyed",h,this).onSync("tabKeyed",i,this).onSync("escKeyed",j,this).onSync("upKeyed",k,this).onSync("downKeyed",l,this).onSync("leftKeyed",m,this).onSync("rightKeyed",n,this).onSync("queryChanged",o,this).onSync("whitespaceChanged",p,this).onSync("langDirChanged",this._onLangDirChanged,this)}function d(a){var c=[].slice.call(arguments,1);return function(){var d=[].slice.call(arguments);b.each(c,function(b){return a[b].apply(a,d)})}}return b.mixin(c.prototype,{_hacks:function(){var c,d;c=this.input.$input||a("<div>"),d=this.menu.$node||a("<div>"),c.on("blur.tt",function(a){var e,f,g;
	e=document.activeElement,f=d.is(e),g=d.has(e).length>0,b.isMsie()&&(f||g)&&(a.preventDefault(),a.stopImmediatePropagation(),b.defer(function(){c.focus()}))}),d.on("mousedown.tt",function(a){a.preventDefault()})},_onSelectableClicked:function(a,b){this.select(b)},_onDatasetCleared:function(){this._updateHint()},_onDatasetRendered:function(a,b,c,d){this._updateHint(),this.eventBus.trigger("render",c,d,b)},_onAsyncRequested:function(a,b,c){this.eventBus.trigger("asyncrequest",c,b)},_onAsyncCanceled:function(a,b,c){this.eventBus.trigger("asynccancel",c,b)},_onAsyncReceived:function(a,b,c){this.eventBus.trigger("asyncreceive",c,b)},_onFocused:function(){this._minLengthMet()&&this.menu.update(this.input.getQuery())},_onBlurred:function(){this.input.hasQueryChangedSinceLastFocus()&&this.eventBus.trigger("change",this.input.getQuery())},_onEnterKeyed:function(a,b){var c;(c=this.menu.getActiveSelectable())&&this.select(c)&&b.preventDefault()},_onTabKeyed:function(a,b){var c;(c=this.menu.getActiveSelectable())?this.select(c)&&b.preventDefault():(c=this.menu.getTopSelectable())&&this.autocomplete(c)&&b.preventDefault()},_onEscKeyed:function(){this.close()},_onUpKeyed:function(){this.moveCursor(-1)},_onDownKeyed:function(){this.moveCursor(1)},_onLeftKeyed:function(){"rtl"===this.dir&&this.input.isCursorAtEnd()&&this.autocomplete(this.menu.getTopSelectable())},_onRightKeyed:function(){"ltr"===this.dir&&this.input.isCursorAtEnd()&&this.autocomplete(this.menu.getTopSelectable())},_onQueryChanged:function(a,b){this._minLengthMet(b)?this.menu.update(b):this.menu.empty()},_onWhitespaceChanged:function(){this._updateHint()},_onLangDirChanged:function(a,b){this.dir!==b&&(this.dir=b,this.menu.setLanguageDirection(b))},_openIfActive:function(){this.isActive()&&this.open()},_minLengthMet:function(a){return a=b.isString(a)?a:this.input.getQuery()||"",a.length>=this.minLength},_updateHint:function(){var a,c,d,e,f,h,i;a=this.menu.getTopSelectable(),c=this.menu.getSelectableData(a),d=this.input.getInputValue(),!c||b.isBlankString(d)||this.input.hasOverflow()?this.input.clearHint():(e=g.normalizeQuery(d),f=b.escapeRegExChars(e),h=new RegExp("^(?:"+f+")(.+$)","i"),i=h.exec(c.val),i&&this.input.setHint(d+i[1]))},isEnabled:function(){return this.enabled},enable:function(){this.enabled=!0},disable:function(){this.enabled=!1},isActive:function(){return this.active},activate:function(){return this.isActive()?!0:!this.isEnabled()||this.eventBus.before("active")?!1:(this.active=!0,this.eventBus.trigger("active"),!0)},deactivate:function(){return this.isActive()?this.eventBus.before("idle")?!1:(this.active=!1,this.close(),this.eventBus.trigger("idle"),!0):!0},isOpen:function(){return this.menu.isOpen()},open:function(){return this.isOpen()||this.eventBus.before("open")||(this.menu.open(),this._updateHint(),this.eventBus.trigger("open")),this.isOpen()},close:function(){return this.isOpen()&&!this.eventBus.before("close")&&(this.menu.close(),this.input.clearHint(),this.input.resetInputValue(),this.eventBus.trigger("close")),!this.isOpen()},setVal:function(a){this.input.setQuery(b.toStr(a))},getVal:function(){return this.input.getQuery()},select:function(a){var b=this.menu.getSelectableData(a);return b&&!this.eventBus.before("select",b.obj)?(this.input.setQuery(b.val,!0),this.eventBus.trigger("select",b.obj),this.close(),!0):!1},autocomplete:function(a){var b,c,d;return b=this.input.getQuery(),c=this.menu.getSelectableData(a),d=c&&b!==c.val,d&&!this.eventBus.before("autocomplete",c.obj)?(this.input.setQuery(c.val),this.eventBus.trigger("autocomplete",c.obj),!0):!1},moveCursor:function(a){var b,c,d,e,f;return b=this.input.getQuery(),c=this.menu.selectableRelativeToCursor(a),d=this.menu.getSelectableData(c),e=d?d.obj:null,f=this._minLengthMet()&&this.menu.update(b),f||this.eventBus.before("cursorchange",e)?!1:(this.menu.setCursor(c),d?this.input.setInputValue(d.val):(this.input.resetInputValue(),this._updateHint()),this.eventBus.trigger("cursorchange",e),!0)},destroy:function(){this.input.destroy(),this.menu.destroy()}}),c}();!function(){"use strict";function e(b,c){b.each(function(){var b,d=a(this);(b=d.data(p.typeahead))&&c(b,d)})}function f(a,b){return a.clone().addClass(b.classes.hint).removeData().css(b.css.hint).css(l(a)).prop("readonly",!0).removeAttr("id name placeholder required").attr({autocomplete:"off",spellcheck:"false",tabindexF:-1})}function h(a,b){a.data(p.attrs,{dir:a.attr("dir"),autocomplete:a.attr("autocomplete"),spellcheck:a.attr("spellcheck"),style:a.attr("style")}),a.addClass(b.classes.input).attr({autocomplete:"off",spellcheck:!1});try{!a.attr("dir")&&a.attr("dir","auto")}catch(c){}return a}function l(a){return{backgroundAttachment:a.css("background-attachment"),backgroundClip:a.css("background-clip"),backgroundColor:a.css("background-color"),backgroundImage:a.css("background-image"),backgroundOrigin:a.css("background-origin"),backgroundPosition:a.css("background-position"),backgroundRepeat:a.css("background-repeat"),backgroundSize:a.css("background-size")}}function m(a){var c,d;c=a.data(p.www),d=a.parent().filter(c.selectors.wrapper),b.each(a.data(p.attrs),function(c,d){b.isUndefined(c)?a.removeAttr(d):a.attr(d,c)}),a.removeData(p.typeahead).removeData(p.www).removeData(p.attr).removeClass(c.classes.input),d.length&&(a.detach().insertAfter(d),d.remove())}function n(c){var d,e;return d=b.isJQuery(c)||b.isElement(c),e=d?a(c).first():[],e.length?e:null}var o,p,q;o=a.fn.typeahead,p={www:"tt-www",attrs:"tt-attrs",typeahead:"tt-typeahead"},q={initialize:function(e,l){function m(){var c,m,q,r,s,t,u,v,w,x,y;b.each(l,function(a){a.highlight=!!e.highlight}),c=a(this),m=a(o.html.wrapper),q=n(e.hint),r=n(e.menu),s=e.hint!==!1&&!q,t=e.menu!==!1&&!r,s&&(q=f(c,o)),t&&(r=a(o.html.menu).css(o.css.menu)),q&&q.val(""),c=h(c,o),(s||t)&&(m.css(o.css.wrapper),c.css(s?o.css.input:o.css.inputWithNoHint),c.wrap(m).parent().prepend(s?q:null).append(t?r:null)),y=t?j:i,u=new d({el:c}),v=new g({hint:q,input:c},o),w=new y({node:r,datasets:l},o),x=new k({input:v,menu:w,eventBus:u,minLength:e.minLength},o),c.data(p.www,o),c.data(p.typeahead,x)}var o;return l=b.isArray(l)?l:[].slice.call(arguments,1),e=e||{},o=c(e.classNames),this.each(m)},isEnabled:function(){var a;return e(this.first(),function(b){a=b.isEnabled()}),a},enable:function(){return e(this,function(a){a.enable()}),this},disable:function(){return e(this,function(a){a.disable()}),this},isActive:function(){var a;return e(this.first(),function(b){a=b.isActive()}),a},activate:function(){return e(this,function(a){a.activate()}),this},deactivate:function(){return e(this,function(a){a.deactivate()}),this},isOpen:function(){var a;return e(this.first(),function(b){a=b.isOpen()}),a},open:function(){return e(this,function(a){a.open()}),this},close:function(){return e(this,function(a){a.close()}),this},select:function(b){var c=!1,d=a(b);return e(this.first(),function(a){c=a.select(d)}),c},autocomplete:function(b){var c=!1,d=a(b);return e(this.first(),function(a){c=a.autocomplete(d)}),c},moveCursor:function(a){var b=!1;return e(this.first(),function(c){b=c.moveCursor(a)}),b},val:function(a){var b;return arguments.length?(e(this,function(b){b.setVal(a)}),this):(e(this.first(),function(a){b=a.getVal()}),b)},destroy:function(){return e(this,function(a,b){m(b),a.destroy()}),this}},a.fn.typeahead=function(a){return q[a]?q[a].apply(this,[].slice.call(arguments,1)):q.initialize.apply(this,arguments)},a.fn.typeahead.noConflict=function(){return a.fn.typeahead=o,this}}()});
;
/*! RESOURCE: /scripts/app.ngFormElements/thirdparty/angular-typeahead.js */
angular.module('typeahead.directives', []);
angular.module('typeahead.directives').directive('ngTypeahead', function () {
		return {
restrict: 'AC',
require: '?ngModel',
			scope: {
options: '=',
datasets: '=',
				suggestionKey : '@'
			},
			link: function (scope, element, attrs, ngModel) {
				var options = scope.options || {},
datasets = (angular.isArray(scope.datasets) ? scope.datasets : [scope.datasets]) || [],
					init = true;
				initialize();
				scope.$watch('options', initialize);
				if (angular.isArray(scope.datasets)) {
					scope.$watchCollection('datasets', initialize);
				}
				else {
					scope.$watch('datasets', initialize);
				}
				ngModel.$parsers.push(function (fromView) {
					var isDatum = angular.isObject(fromView);
					if (options.editable === false) {
						ngModel.$setValidity('typeahead', isDatum);
						return isDatum ? fromView : undefined;
					}
					return fromView;
				});
				ngModel.$formatters.push(function (fromModel) {
					if (angular.isObject(fromModel)) {
						var found = false;
						$.each(datasets, function (index, dataset) {
							var query = dataset.source,
								displayKey = dataset.displayKey || 'value',
								value = (angular.isFunction(displayKey) ? displayKey(fromModel) : fromModel[displayKey]) || '';
if (found) return false;
							if (!value) {
								search([]);
								return;
							}
							query(value, search);
							return;
							function search(suggestions) {
								var exists = inArray(suggestions, fromModel);
								if (exists) {
									ngModel.$setViewValue(fromModel);
									found = true;
								} else {
									ngModel.$setViewValue(options.editable === false ? undefined : fromModel);
								}
								if (found || index === datasets.length - 1) {
									setTimeout(function () {
										scope.$apply(function () {
											element.typeahead('val', value);
										});
									}, 0);
								}
							}
						});
return '';
					} else if (fromModel == null) {
						element.typeahead('val', null);
					}
					return fromModel;
				});
				function initialize() {
					if (init) {
						element.typeahead(scope.options, scope.datasets)
						init = false;
					} else {
						var value = element.val();
						element.typeahead('destroy');
						element.typeahead(scope.options, scope.datasets)
						ngModel.$setViewValue(value);
						element.triggerHandler('typeahead:opened');
					}
				}
				function inArray(array, element) {
					var found = -1;
					angular.forEach(array, function (value, key) {
						if (angular.equals(element, value)) {
							found = key;
						}
					});
					return found >= 0;
				}
				function updateScope (object, suggestion, dataset) {
					scope.$apply(function () {
						var newViewValue = (angular.isDefined(scope.suggestionKey)) ?
							suggestion[scope.suggestionKey] : suggestion;
						ngModel.$setViewValue(newViewValue);
					});
				}
				element.bind('typeahead:selected', function(object, suggestion, dataset) {
					updateScope(object, suggestion, dataset);
					scope.$emit('typeahead:selected', suggestion, dataset);
				});
				element.bind('typeahead:autocompleted', function(object, suggestion, dataset) {
					updateScope(object, suggestion, dataset);
					scope.$emit('typeahead:autocompleted', suggestion, dataset);
				});
				element.bind('typeahead:opened', function() {
					scope.$emit('typeahead:opened');
				});
				element.bind('typeahead:closed', function() {
					scope.$emit('typeahead:closed');
				});
				element.bind('typeahead:cursorchanged', function(event, suggestion, dataset) {
					scope.$emit('typeahead:cursorchanged', event, suggestion, dataset);
				});
			}
		};
	});
;
/*! RESOURCE: /scripts/sn/common/keyboard/_module.js */
angular.module('sn.common.keyboard', []);
;
/*! RESOURCE: /scripts/sn/common/keyboard/directive.snKeyCode.js */
angular.module('sn.common.keyboard').directive('snKeyCode', function() {
	"use strict";
	return {
		restrict: 'A',
		link: function(scope, element, attrs) {
			element.bind("keypress", function(event) {
				var keyCode = event.which || event.keyCode;
				var codes;
				if (!attrs.code)
					return;
				codes = attrs.code
					.split(',')
					.map(function(item) {
						return parseInt(item, 10);
					});
				if (!event.shiftKey && codes.indexOf(keyCode) > -1) {
					scope.$apply(function() {
						scope.$eval(attrs.snKeyCode, {$event: event});
					});
				}
			});
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/keyboard/directive.snKeyTrap.js */
angular.module('sn.common.keyboard').directive('keyTrap', function() {
	return function( scope, elem ) {
		elem.bind('keydown', function( event ) {
			scope.$broadcast('keydown', { code: event.keyCode } );
		});
	};
});
;
;
/*! RESOURCE: /scripts/sn/common/keyboard/js_includes_keyboard.js */
/*! RESOURCE: /scripts/app.ngFormElements/elements/_elements.js */
angular.module('sn.ngform.elements', [
	'ui.bootstrap.datetimepicker',
	'sn.common.keyboard',
	'typeahead.directives'
]);
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snStringElement.js */
angular.module('sn.ngform.elements').directive('snStringElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl('sn_string_element.xml')
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snTextareaElement.js */
angular.module('sn.ngform.elements').directive('snTextareaElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl('sn_textarea_element.xml')
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snFilterTextareaElement.js */
angular.module('sn.ngform.elements').directive('snFilterTextareaElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl('sn_filter_textarea_element.xml')
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snAutonumberElement.js */
angular.module('sn.ngform.elements').directive('snAutonumberElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl('sn_autonumber_element.xml'),
		controller: function($scope) {
			$scope.generateNumber = function(e) {
				$scope.numInput = e.currentTarget.previousSibling;
				$scope.numButton = e.currentTarget;
				var aj = new GlideAjax("GetNextNumberAjax");
				aj.addParam("sysparm_name", e.currentTarget.getAttribute("data-ref"));
				aj.getXML($scope.gotNumber.bind(e), "", new Array(e.currentTarget.getAttribute("data-ref")));
			};
			$scope.gotNumber = function(request){
				var rxml = request.responseXML;
				var numberField = $scope.numInput;
				var items = rxml.getElementsByTagName("item");
				if (items.length > 0) {
					var v = items[0].getAttribute("value");
					numberField.value = v;
					$scope.field.value = v;
					var displayField = $scope.numButton;
					if (displayField)
						displayField.style.display = "none";
				}
			};
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snBooleanElement.js */
angular.module("sn.ngform.elements").directive("snBooleanElement", function (i18n, getTemplateUrl) {
	"use strict";
	return {
		restrict: "E",
		replace: true,
		templateUrl: getTemplateUrl("sn_boolean_element.xml"),
		controller: function($scope){
			var messages;
			i18n.getMessages(["True", "False"], function(response){
				messages = response;
			})
			$scope.booleanChoices = [
				{
					label: messages["True"],
					value: "true"
				},
				{
					label: messages["False"],
					value: "false"
				}
			];
		}
	};
}).directive("snBooleanElementFormatter", function() {
	"use strict";
	return {
		require: "ngModel",
		restrict: "A",
		link: function(scope, element, attrs, ngModel) {
			ngModel.$formatters.push(function(value) {
				if (value === "1") {
					return "true";
				} else if (value === "0") {
					return "false";
				}
				return value;
			});
		}
	}
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/factory.snCurrency.js */
angular.module('sn.ngform.elements').factory('snCurrencyFactory', function () {
	'use strict';
	function fromRestApi(rawData) {
		var data = rawData;
		return {
			get sysID() {
				return data.sys_id;
			},
			get symbol() {
				return data.symbol;
			},
			get code() {
				return data.code;
			},
			get name() {
				return data.name;
			},
			get isDefault() {
				return data.default;
			},
			get display() {
				return this.symbol + ' (' + this.code + ')';
			},
			update: function(rawData) {
				data = rawData;
			},
			calcScriptValue: function(table, field, value) {
				if (!table || !field || !value)
					return '';
				return "javascript:global.getCurrencyFilter('"
					+ table + "','"
					+ field + "','"
					+ this.code + ";"
					+ value + "')";
			}
		}
	}
	return {
		fromRestApi: fromRestApi
	}
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/service.snCurrency.js */
angular.module('sn.ngform.elements').service('snCurrencyService', function($http, $rootScope, snRecordWatcher, snCurrencyFactory) {
	'use strict';
var REST_API_ACTIVE = '/api/now/ui/currency/active';
	var currencies = [];
	var requestPromise = request();
	snRecordWatcher.initChannel('fx_currency', 'active=true');
	$rootScope.$on('record.updated', function(event, response) {
		var record = response.record;
		var found = findSysID(response.sys_id);
		if (record.active && (record.active.value === 'false') && (found.index !== -1)) {
			$rootScope.$apply(function() {
				removeCurrency(found.index);
			});
			return;
		}
		requestPromise = request();
	});
	function request() {
		return $http.get(REST_API_ACTIVE).then(updateCurrencies);
	}
	function updateCurrencies(response) {
		var rawList = response.data.result;
		if (!rawList)
			return;
		currencies.forEach(function(item) {
			item.remove = true;
		});
		rawList.forEach(function(rawData, index) {
			delete insert(rawData, index).remove;
		});
		for (var i = currencies.length - 1; i >= 0; --i)
			if (currencies[i].remove)
				removeCurrency(i);
	}
	function insert(rawData, index) {
		var found = findSysID(rawData.sys_id);
		if (found.item) {
			currencies[found.index].update(rawData);
		} else {
			found.item = snCurrencyFactory.fromRestApi(rawData);
			insertCurrency(index, found.item);
		}
		return found.item;
	}
	function insertCurrency(index, currency) {
		currencies.splice(index, 0, currency);
	}
	function removeCurrency(index) {
		currencies.splice(index, 1);
	}
	function find(field, value) {
		for (var i = 0; i < currencies.length; ++i) {
			if (currencies[i][field] === value) {
				return {
					item: currencies[i],
					index: i
				};
			}
		}
		return {
			index: -1
		};
	}
	function findSysID(sysID) {
		return find('sysID', sysID);
	}
	function findCode(code) {
		return find('code', code).item || currencies[0];
	}
	function parseBetweenValue(betweenCurrencies) {
		var DEFAULT = {
			values: [],
			type: currencies[0]
		};
		if (!betweenCurrencies)
			return DEFAULT;
		var splitCurrencyValues = betweenCurrencies.split("@");
		if (splitCurrencyValues.length !== 2)
			return DEFAULT;
		var map = splitCurrencyValues.map(function(splitValue) {
var values = splitValue.split(/[;,]+/);
			if (values.length < 2)
				return {
					type: currencies[0]
				};
			return {
				type: findCode(values[0]),
				value: values[1]
			}
		});
		return {
			values: [map[0].value, map[1].value],
			type: map[1].type
		};
	}
	function reduceBetweenValue(betweenCurrencies) {
		if (!betweenCurrencies)
			return null;
		if (betweenCurrencies.values.length != 2)
			return null;
		if (betweenCurrencies.values.some(function(currency) {
				return !currency || currency === "null";
			}))
			return null;
		if (!betweenCurrencies.type)
			return null;
		var code = betweenCurrencies.type.code;
		return betweenCurrencies.values.map(function(amount) {
			return code + "," + amount;
		}).join("@");
	}
	return {
		parseBetweenValue: parseBetweenValue,
		reduceBetweenValue: reduceBetweenValue,
		findCode: findCode,
		request: function() {
			return requestPromise;
		},
		get currencies() {
			return currencies;
		},
		get defaultCurrency() {
			return currencies[0];
		},
		extract: function(scriptValue) {
			if (scriptValue) {
var values = /'([^']+);(\d+)'/.exec(scriptValue);
				if (values && values.length >= 3) {
					return {
						type: findCode(values[1]),
						value: values[2]
					};
				}
			}
			return {
				type: this.defaultCurrency,
				value: ''
			};
		}
	}
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snCurrencyElement.js */
angular.module('sn.ngform.elements').directive('snCurrencyElement', function (getTemplateUrl) {
	'use strict';
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl('sn_currency_element.xml'),
		controller: function($scope, snCurrencyService) {
			$scope.currencies = snCurrencyService.currencies;
			$scope.currency = {};
			var scriptValue = $scope.field.value;
			$scope.field.value = '';
			snCurrencyService.request().then(function() {
				$scope.currency = snCurrencyService.extract(scriptValue);
				$scope.field.value = scriptValue;
			});
			$scope.$watch('field.operator', function(newValue, oldValue) {
				if (newValue === oldValue)
					return;
				$scope.currency.value = '';
			});
			$scope.valueHandler = function valueHandler() {
				var type = $scope.currency.type;
				$scope.field.value = type
						? type.calcScriptValue($scope.field.table, $scope.field.field, $scope.currency.value)
						: '';
				if (typeof $scope.field.onChange === 'function')
					$scope.field.onChange();
			}
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snChoiceElement.js */
angular.module('sn.ngform.elements').directive('snChoiceElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl('sn_choice_element.xml')
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snChoiceMultipleElement.js */
angular.module('sn.ngform.elements').directive('snChoiceMultipleElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl('sn_choice_multiple_element.xml'),
		controller: function($scope){
			activate();
			function activate() {
				if (!angular.isArray($scope.field.value)) {
					$scope.field.value = ($scope.field.value || "").split(",").map(function(v){
						return v.trim();
					});
				}
			}
			$scope.$on('$destroy', function(){
				$scope.field.value = ($scope.field.value || []).join(", ");
			})
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snDateElement.js */
angular.module('sn.ngform.elements').directive('snDateElement', function($window, getTemplateUrl, snFormDateHelper) {
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl("sn_date_time_element.xml"),
		controller: function($scope){
			var config = {
				startView: "day",
				minView : "day",
				dropdownSelector : "glide_date_time_" + $scope.field.ref + "_dropdown"
			};
			$scope.config = angular.extend(config, $scope.field.timepickerConfig);
			$scope.setDateTime = setDateTime;
			$scope.dateTimeOnChangeHandler = dateTimeOnChangeHandler;
			activate();
			function activate(){
				if (typeof $scope.field === "undefined" || typeof $scope.field === "null")
					throw "Invalid field model";
				if (typeof moment === "undefined" || typeof moment === "null")
					throw "Moment.js is unavailable";
				_setMomentLocale();
				_initFieldData();
			}
			function setDateTime(newDateTime, oldDateTime) {
				if (newDateTime === oldDateTime)
					return;
				_toggleDropdownMenu();
				$scope.field.value = snFormDateHelper.addTimezoneOffset(newDateTime);
				$scope.field.displayValue = moment($scope.field.value).format($scope.field.dateFormat);
				_triggerFieldOnChange();
			}
			function dateTimeOnChangeHandler(){
				$scope.dateAsPicker = moment($scope.field.value).format($scope.field.dateFormat);
				_triggerFieldOnChange();
			}
			function _toggleDropdownMenu(){
				angular.element("#" + $scope.config.dropdownSelector).dropdown("toggle");
			}
			function _initFieldData() {
				if ($scope.field.value){
					$scope.field.displayValue = moment($scope.field.value).format($scope.field.dateFormat);
					$scope.dateAsPicker = moment().format(snFormDateHelper.removeTimezoneOffset($scope.field.value), $scope.field.dateFormat);
				} else {
					$scope.field.displayValue = moment().format($scope.field.dateFormat);
					$scope.field.value = snFormDateHelper.addTimezoneOffset($scope.field.displayValue);
					$scope.dateAsPicker = moment().format($scope.field.dateFormat);
				}
			}
			function _setMomentLocale(){
				moment.locale('en', {
					week: {
dow: $window.g_date_picker_first_day_of_week
					}
				});
			}
			function _triggerFieldOnChange(){
				if ($scope.field.onChange && typeof $scope.field.onChange === "function")
					$scope.field.onChange();
			}
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snDateChoiceElement.js */
angular.module('sn.ngform.elements').directive('snDateChoiceElement', function (getTemplateUrl, i18n, filterDateService, snFilterGlobals) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl('sn_date_choice_element.xml'),
		controller: function($scope){
			var dateValue;
			var NONE_LABEL = i18n.getMessage('-- None --');
			var ERROR_MESSAGE = "failed to look up date value in directive.snDateChoiceElement.js";
			var choiceModel;
			$scope.data = {};
			$scope.timeEdit = false;
			$scope.closeEvent = "close_date_choice";
			$scope.popoverConfig = angular.extend({}, $scope.popoverConfig, {
				placement: 'bottom',
template: '<div class="popover date-choice-popover" role="tooltip"><div class="popover-content"></div></div>'
			});
			$scope.timepickerConfig = {
				startView:'day',
				minView:'day'
			};
			snFilterGlobals.snFilterInitialize($scope.$parent.field.table).then(initialize);
			function initialize() {
				choiceModel = snFilterGlobals.getCalendarValues('dateChoiceModel', $scope.$parent.field.table);
				var model = $scope.field.between ? 'dateChoiceBetweenDisplayValues': 'dateChoiceDisplayValues';
				$scope.data.displayChoices = snFilterGlobals.getCalendarValues(model, $scope.$parent.field.table);
				$scope.$watch('field.field', _fieldOrOperatorChangeHandler);
				$scope.$watch('field.operator', _fieldOrOperatorChangeHandler);
				$scope.dateValueLookup = dateValueLookup;
				$scope.onCalendarDateSet = onCalendarDateSet;
				$scope.buildDateValue = buildDateValue;
				$scope.onInputTimeSet = onInputTimeSet;
				$scope.toggleSection = toggleSection;
				$scope.onKeyPress = onKeyPress;
				_setTimeModels();
				$scope.includeTime = _includeTime();
				if ($scope.field.value){
					_initData()
				} else {
					$scope.data.dateModel = "";
					$scope.data.displayValue = NONE_LABEL;
				}
			}
			function _initData(){
				if ($scope.field.value.indexOf('dateGenerate') > -1){
					_initDateValue();
				} else if (dateLabelLookup($scope.field.value)){
					_initChoiceValue();
				} else {
					var momentDate = moment($scope.field.value);
					$scope.data.displayValue = $scope.field.value;
					$scope.data.dateAsPicker = momentDate.format();
					var timeParts = momentDate.format("HH:mm:ss").split(":");
					_setTimeModels(timeParts);
				}
				$scope.timeEdit = true;
			}
			function toggleSection(choice){
				angular.forEach($scope.data.displayChoices, function(item){
					if (item.type !== choice.type)
						item.show = false;
				});
				choice.show = !choice.show;
			}
			function onKeyPress(event,choice) {
				if (!event) return;
				var currentElement = event.target;
				var keyCode = event.keyCode;
				var key = event.key;
				var currIndex = -1;
				var elements = document.querySelectorAll('.filter-accordion-title, .filter-accordion-section-content[aria-hidden="false"] > ul > li > a');
				for (var i=0; i < elements.length; i++) {
					if (elements[i] === currentElement) {
						currIndex = i;
						break;
					}
				}
				currentElement.tabIndex = -1;
				if (currIndex < 0)
					return;
				if ((key === 'ArrowDown' || keyCode === 40) && elements[++currIndex]) {
						elements[currIndex].focus();
				}
				else if ((key === 'ArrowUp' || keyCode === 38) && elements[--currIndex]) {
						elements[currIndex].focus();
				}
				else if (key === 'Tab' || keyCode === 9) {
					currentElement.tabIndex = 0;
				}
				else if (isSectionHeader(elements[currIndex])) {
					if (isToggleOpen(choice.show)) {
						if (key === 'ArrowLeft' || keyCode === 37)
							toggleSection(choice);
					}
					else {
						if (key === 'ArrowRight' || keyCode === 39)
							toggleSection(choice);
					}
				}
			}
			function isSectionHeader(element) {
				return (element.className.indexOf('filter-accordion-title') !== -1) ? true: false;
			}
			function isToggleOpen(toggled) {
				return Boolean(toggled);
			}
			function _initDateValue(){
var dateParts = $scope.field.value.split(/'|@/).filter(function(item){
					return (item !== 'javascript:gs.dateGenerate(' && item !== ',' && item !== ')');
				});
				var timeParts;
				$scope.data.dateAsPicker = moment(dateParts[0]).format();
				if (_includeTime()){
					$scope.data.displayValue = _getDisplayValue(dateParts[0], dateParts[1]);
timeParts = dateParts[1].split(/:|\./);
					_setTimeModels(timeParts);
				} else {
					$scope.data.displayValue = _getDisplayValue(dateParts[0], dateParts[1]);
				}
			}
			function _initChoiceValue(){
				dateValue = dateLabelLookup($scope.field.value);
				var dateChoice = choiceModel
					.filter(function(item){
						return (item.value == dateValue);
					})[0];
				$scope.data.displayValue = dateChoice.label;
			}
			function buildDateValue(dateChoice){
				_reset();
				$scope.$broadcast($scope.closeEvent);
				dateValue = dateChoice.value;
				$scope.data.displayValue = dateChoice.label;
				buildFieldValue()
			}
			function onInputTimeSet(data){
				if (data.hours === null)
					data.hours = 0;
				if (data.minutes === null)
					data.minutes = 0;
				if (data.seconds === null)
					data.seconds = 0;
				data.hours = Math.round(data.hours);
				data.minutes = Math.round(data.minutes);
				data.seconds = Math.round(data.seconds);
				_sanitizeTimeValues(data);
				var date = moment($scope.data.displayValue, _getSystemDateFormat()).format("YYYY-MM-DD");
				var time = _pad(data.hours, 2) + ":" + _pad(data.minutes, 2) + ":" + _pad(data.seconds, 2);
				var momentDate = moment(date + " " + time);
				$scope.data.displayValue = _getDisplayValue(date, time);
				buildFieldDateValue(momentDate.format("YYYY-MM-DD"), momentDate.format("HH:mm:ss"));
			}
			function onCalendarDateSet(newDate) {
				var momentDate = moment().set({
					'year': newDate.getFullYear(),
					'month': newDate.getMonth(),
					'date': newDate.getDate(),
					'hour': $scope.data.hours,
					'minute': $scope.data.minutes,
					'second': $scope.data.seconds,
				});
				var date = momentDate.format("YYYY-MM-DD");
				var time = momentDate.format("HH:mm:ss");
				$scope.data.dateAsPicker = new Date(momentDate).toUTCString();
				$scope.data.displayValue = _getDisplayValue(date, time);
				$scope.timeEdit = true;
				buildFieldDateValue(date, time);
				if (!$scope.includeTime)
					$scope.$broadcast($scope.closeEvent);
			}
			function buildFieldValue(){
				try{
					$scope.field.value = dateValueLookup(dateValue);
					if ($scope.field.onChange && typeof $scope.field.onChange === "function")
						$scope.field.onChange();
				} catch(ex){
					console.warn(ERROR_MESSAGE, ex);
				}
			}
			function buildFieldDateValue(date, time){
				try {
				$scope.field.displayValue = _getDisplayValue(date, time);
				if (!isEncrypted()){
					if (_includeTime()){
						$scope.field.value = "javascript:gs.dateGenerate('" + date +"','" + time +"')";
					} else {
						var values = [
							date,
							"javascript:gs.dateGenerate('" + date +"','start')",
							"javascript:gs.dateGenerate('" + date +"','end')"
						];
						$scope.field.value = values.join("@");
					}
				} else {
					$scope.field.value = $scope.field.displayValue;
				}
				if ($scope.field.onChange && typeof $scope.field.onChange === "function")
					$scope.field.onChange();
				} catch(ex) {
					console.warn(ERROR_MESSAGE, ex);
				}
			}
			function dateValueLookup (value){
				return filterDateService.dateValueLookup($scope.field.operator, value, $scope.$parent.field.table);
			}
			function dateLabelLookup (value){
				return filterDateService.dateLabelLookup($scope.field, value, $scope.$parent.field.table);
			}
			function _fieldOrOperatorChangeHandler(n, o){
				if (n === o)
					return;
				$scope.includeTime = _includeTime();
				_reset();
			}
			function _includeTime(operator){
				operator = typeof operator === "undefined" ?  $scope.field.operator : operator;
				return !(operator == "ON" || operator == "NOTON");
			}
			function _pad(num, size) {
				var s = num + "";
				while (s.length < size) s = "0" + s;
				return s;
			}
			function _reset(){
				$scope.data.dateModel = "";
				$scope.data.dateAsPicker = "";
				$scope.data.displayValue = NONE_LABEL;
				$scope.timeEdit = false;
				_setTimeModels();
			}
			function _getDisplayValue(dateParam, timeParam){
				if (_includeTime()){
					var date = moment(dateParam + " " + timeParam).format(_getSystemDateFormat());
					var time = moment(dateParam + " " + timeParam).format(_getSystemTimeFormat());
					var selectedField = $scope.field.field;
					if ($scope.field.baseFields[selectedField] && $scope.field.baseFields[selectedField].internal_type === "glide_date" && isEncrypted())
						return date;
					return date + " " + time;
				} else {
					var date = moment(dateParam).format(_getSystemDateFormat());
					return date;
				}
			}
			function _getSystemDateFormat(){
				var dateFormat = "yyyy-MM-dd";
				if (window.NOW && window.NOW.dateFormat && window.NOW.dateFormat.dateStringFormat) {
                    dateFormat = window.NOW.dateFormat.dateStringFormat;
                } else if (typeof g_user_date_format !== 'undefined' && g_user_date_format) {
                    dateFormat = g_user_date_format;
				}
				return dateFormat.toUpperCase();
			}
			function _getSystemTimeFormat(){
				var timeFormat = "HH:mm:ss";
				if (window.NOW && window.NOW.dateFormat && window.NOW.dateFormat.timeStringFormat)
					timeFormat = window.NOW.dateFormat.timeStringFormat;
				return timeFormat;
			}
			function _setTimeModels(array){
				if (typeof array === "undefined" || array.length !== 3)
					array = [0,0,0];
				$scope.data.hours = parseInt(array[0], 10);
				$scope.data.minutes = parseInt(array[1], 10);
				$scope.data.seconds = parseInt(array[2], 10);
			}
			function _sanitizeTimeValues(data){
				if (typeof data.hours === "undefined" || data.hours > 23)
					data.hours = 23;
				if (typeof data.minutes === "undefined" || data.minutes > 59)
					data.minutes = 59;
				if (typeof data.seconds === "undefined" || data.seconds > 59)
					data.seconds = 59;
			}
			function isEncrypted() {
				var isEdgeEncrypted = $scope.field.baseFields[$scope.field.field] && $scope.field.baseFields[$scope.field.field].edge_encrypted;
				var isEncrypted = $scope.field.baseFields[$scope.field.field] && $scope.field.baseFields[$scope.field.field].glide_encrypted;
				return ((isEdgeEncrypted !== "undefined" && isEdgeEncrypted == true)
					|| (isEncrypted !== "undefined" && isEncrypted == true))
			}
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snDateTrendElement.js */
angular.module('sn.ngform.elements').directive('snDateTrendElement', function (getTemplateUrl, i18n, snFilterGlobals) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl('sn_date_trend_element.xml'),
		controller: function($scope){
			var operatorValue;
			var dateValue;
			var ERROR_MESSAGE = "blew up because of string manipulations in directive.snDateTrendElement.js ";
			var NONE_LABEL = i18n.getMessage('-- None --');
			$scope.closeEvent = "close_relative_duration";
			$scope.popoverConfig = angular.extend({
				placement: 'bottom',
template: '<div class="popover" role="tooltip"><div class="popover-content"></div></div>'
			}, $scope.popoverConfig);
			snFilterGlobals.snFilterGlobalsInitialization.then(initialization);
			function initialization() {
				$scope.trendOperators = snFilterGlobals.getValues('relativeOperators');
				$scope.trendValues = snFilterGlobals.getValues('dateParts');
				if ($scope.field.value) {
					try{
var valueParts = $scope.field.value.split(/'|@/).filter(function(item){
							return (item !== 'javascript:gs.datePart(' && item !== ',' && item !== ')');
						})
							.map(function(item){
								return item.trim();
							});
						$scope.trendOperatorModel = operatorValue = valueParts.pop();
						$scope.trendValueModel = dateValue = valueParts.join(",");
						$scope.displayValue = valueParts[0];
					} catch(ex){
						console.warn(ERROR_MESSAGE, ex)
					}
				} else {
					$scope.trendOperatorModel = operatorValue = $scope.trendOperators[0][1];
					$scope.displayValue = NONE_LABEL;
				}
			}
			$scope.toggleSection = function(trendValue){
				angular.forEach($scope.trendValues, function(item){
					if (item.type !== trendValue.type)
						item.show = false;
				});
				trendValue.show = !trendValue.show;
			};
			$scope.buildOperatorValue = function buildOperatorValue (trendOperator){
				operatorValue = trendOperator;
				buildFieldValue();
			};
			$scope.buildDateValue = function buildDateValue(trendDate){
				dateValue = trendDate.value;
				$scope.displayValue = trendDate.label;
				$scope.$broadcast($scope.closeEvent);
				buildFieldValue()
			};
			function buildFieldValue (){
				try{
					if (operatorValue && dateValue){
						var dateParts = dateValue.split(",");
						var fieldValue = dateParts[0] + "@javascript:gs.datePart('" + dateParts[1] + "','" + dateParts[2] + "','" + operatorValue + "')";
						$scope.field.value = fieldValue;
					} else {
						$scope.field.value = "";
						$scope.field.value = NONE_LABEL;
					}
					if ($scope.field.onChange && typeof $scope.field.onChange === "function")
						$scope.field.onChange();
				} catch(ex){
					console.warn(ERROR_MESSAGE, ex);
				}
			}
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snDateRelativeElement.js */
angular.module('sn.ngform.elements').directive('snDateRelativeElement', function(getTemplateUrl, i18n, snFilterGlobals) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		require: 'ngModel',
		templateUrl: getTemplateUrl("sn_date_relative_element.xml"),
		controller: function ($scope) {
			var stayOpen;
			var ERROR_MESSAGE = "blew up because of string manipulations in directive.snDateRelativeElement.js ";
			var NONE_LABEL = i18n.getMessage('-- None --');
			$scope.closeEvent = "close_relative_duration";
			$scope.popoverConfig = angular.extend({
				placement: 'bottom',
template: '<div class="popover" role="tooltip"><div class="popover-content"></div></div>'
			}, $scope.popoverConfig);
			snFilterGlobals.snFilterGlobalsInitialization.then(initialization);
			function initialization() {
				var relativeOperators = snFilterGlobals.getValues('relativeOperators');
				var unsupportedOperators = ['EE', 'GE', 'LE'];
				$scope.relativeOperators = relativeOperators.filter(function (op) {
					return unsupportedOperators.indexOf(op[1]) === -1;
				});
				$scope.durations = snFilterGlobals.getValues('relativeDurations');
				$scope.types = snFilterGlobals.getValues('relativeTypes');
				if ($scope.field.value) {
					try {
						stayOpen = true;
						var dateParts = ($scope.field.value || []).split("@").filter(function(item) {
							return item;
						});
						$scope.relativeOperatorModel = dateParts[0];
						$scope.durationModel = dateParts[1];
						$scope.typeModel = dateParts[2];
						$scope.valueModel = dateParts[3];
						$scope.displayValue = getDisplayValue();
						if (unsupportedOperators.indexOf($scope.relativeOperatorModel) !== -1) {
							var unsupportedOp = relativeOperators.filter(function(op) {
								return op[1] === $scope.relativeOperatorModel;
							});
							if (unsupportedOp[0]) {
								$scope.relativeOperators.push(unsupportedOp[0]);
							}
						}
					} catch(ex) {
						console.warn(ERROR_MESSAGE, ex);
					}
				} else {
					$scope.displayValue = NONE_LABEL;
					$scope.relativeOperatorModel = $scope.relativeOperators[0][1];
				}
			}
			$scope.operatorHandler = function operatorHandler(value){
				$scope.relativeOperatorModel = value;
				buildFieldValue();
			};
			$scope.durationHandler = function durationHandler(value){
				$scope.durationModel = value;
				buildFieldValue();
			};
			$scope.typeHandler = function typeHandler(value){
				$scope.typeModel = value;
				buildFieldValue();
			};
			$scope.valueHandler = function valueHandler(value){
				$scope.valueModel = Math.round(value);
				buildFieldValue();
			};
			function buildFieldValue(){
				try{
					if ($scope.relativeOperatorModel && $scope.durationModel && $scope.typeModel && ($scope.valueModel || $scope.valueModel === 0)){
						$scope.field.value = $scope.relativeOperatorModel + "@" + $scope.durationModel + "@" + $scope.typeModel + "@" + $scope.valueModel;
						$scope.displayValue = getDisplayValue();
						if (!stayOpen)
							$scope.$broadcast($scope.closeEvent);
						stayOpen = true;
					} else {
						$scope.field.value = "";
						$scope.displayValue = NONE_LABEL;
					}
					if ($scope.field.onChange && typeof $scope.field.onChange === "function")
						$scope.field.onChange();
				} catch(ex){
					console.warn(ERROR_MESSAGE, ex);
				}
			}
			function getDisplayValue(){
				try{
					var displayDuration = $scope.durations.filter(function(item){
						return (item[1] == $scope.durationModel);
					});
					return $scope.valueModel + " " + displayDuration[0][0] + " " + $scope.typeModel;
				} catch(ex){
					console.warn(ERROR_MESSAGE, ex);
				}
			}
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snDateComparativeElement.js */
angular.module('sn.ngform.elements').directive('snDateComparativeElement', function(getTemplateUrl, i18n, snDotWalkUtilities, snFilterGlobals) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl("sn_date_comparative_element.xml"),
		controller: function($scope) {
			var stayOpen;
			var ERROR_MESSAGE = "blew up because of string manipulations in directive.snDateComparativeElement.js ";
			var NONE_LABEL = i18n.getMessage('-- None --');
			$scope.closeEvent = "close_comparative_duration";
			$scope.popoverConfig = angular.extend({
				placement: 'bottom',
template: '<div class="popover" role="tooltip"><div class="popover-content"></div></div>'
			}, $scope.popoverConfig);
			snFilterGlobals.snFilterGlobalsInitialization.then(function() {
				initialize();
				$scope.$watch('field.value', function (n, o) {
					if (n !== o && n === undefined)
						initialize()
				});
			});
			function initialize() {
				$scope.durations = _getDurations($scope.field.operator);
				$scope.types = snFilterGlobals.getValues('comparativeTypes');
				$scope.fields = snDotWalkUtilities.makeDateFieldsArray($scope.field.topFields, $scope.$parent);
				if ($scope.field.value) {
					try {
						stayOpen = true;
						var dateParts = ($scope.field.value || []).split("@").filter(function(item) {
							return item;
						});
						$scope.fieldModel = dateParts[0];
						$scope.durationModel = dateParts[1];
						$scope.typeModel = dateParts[2];
						$scope.valueModel = dateParts[3];
						$scope.displayValue = getDisplayValue();
					} catch(ex) {
						console.warn(ERROR_MESSAGE, ex);
					}
				} else {
					if ($scope.fields.length === 0 && $scope.field.baseFields)
						$scope.fields = snDotWalkUtilities.makeDateFieldsArray($scope.field.baseFields, $scope.$parent);
					if ($scope.fields.length !== 0)
						$scope.fieldModel = $scope.fields[0].field;
					$scope.displayValue = NONE_LABEL;
				}
			}
			$scope.fieldHandler = function fieldHandler(value){
				$scope.fieldModel = value;
				buildFieldValue();
			};
			$scope.durationHandler = function durationHandler(value){
				$scope.durationModel = value;
				buildFieldValue();
			};
			$scope.typeHandler = function typeHandler(value){
				$scope.typeModel = value;
				buildFieldValue();
			};
			$scope.valueHandler = function valueHandler(value){
				$scope.valueModel = Math.round(value);
				buildFieldValue();
			};
			function buildFieldValue(){
				try{
					if ($scope.fieldModel && $scope.durationModel && $scope.typeModel && ($scope.valueModel || $scope.valueModel === 0)){
						$scope.displayValue = getDisplayValue();
						$scope.field.value = $scope.fieldModel + "@" + $scope.durationModel + "@" + $scope.typeModel + "@" + $scope.valueModel;
						if (!stayOpen)
							$scope.$broadcast($scope.closeEvent);
						stayOpen = true;
					} else {
						$scope.field.value = "";
						$scope.displayValue = NONE_LABEL;
					}
					if ($scope.field.onChange && typeof $scope.field.onChange === "function")
						$scope.field.onChange();
				} catch(ex){
					console.warn(ERROR_MESSAGE, ex);
				}
			}
			function getDisplayValue(){
				try{
					var displayDuration = $scope.durations.filter(function(item){
						return (item[1] == $scope.durationModel);
					});
					return $scope.valueModel + " " + displayDuration[0][0] + " " + $scope.typeModel;
				} catch(ex){
					console.warn(ERROR_MESSAGE, ex);
				}
			}
			function _getDurations(operator) {
				if (operator == 'LESSTHAN' || operator == 'MORETHAN' || operator == 'SAMEAS')
					return snFilterGlobals.getValues('trendValuesWithFieldsPlural');
				return snFilterGlobals.getValues('comparativeDurations');
			}
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snDateEquivalentElement.js */
angular.module('sn.ngform.elements').directive('snDateEquivalentElement', function(getTemplateUrl, snDotWalkUtilities, snFilterGlobals) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl("sn_date_equivalent_element.xml"),
		controller: function ($scope) {
			var ERROR_MESSAGE = "blew up because of string manipulations in directive.snDateEquivalentElement.js ";
			snFilterGlobals.snFilterGlobalsInitialization.then(initialize);
			$scope.$watch('field.operator', function (newOperator, oldOperator) {
				if (newOperator !== oldOperator || newOperator === undefined)
					initialize();
			});
			function initialize(){
				$scope.durations = snFilterGlobals.getValues('equivalentDurations');
				$scope.fields = snDotWalkUtilities.makeDateFieldsArray($scope.field.topFields, $scope.$parent);
				if ($scope.field.value) {
					try {
						var dateParts = ($scope.field.value || []).split("@").filter(function(item){
							return item;
						});
						$scope.fieldModel = dateParts[0];
						$scope.durationModel = dateParts[1];
					} catch(ex) {
						console.warn(ERROR_MESSAGE, ex);
					}
				} else {
					if ($scope.fields.length === 0 && $scope.field.baseFields)
						$scope.fields = snDotWalkUtilities.makeDateFieldsArray($scope.field.baseFields, $scope.$parent);
					if ($scope.fields.length !== 0)
						$scope.fieldModel = $scope.fields[0].field;
					$scope.durationModel = $scope.durations[0][1];
					buildFieldValue();
				}
			}
			$scope.fieldHandler = function fieldHandler(value){
				$scope.fieldModel = value;
				buildFieldValue();
			};
			$scope.durationHandler = function durationHandler(value){
				$scope.durationModel = value;
				buildFieldValue();
			};
			function buildFieldValue(){
				try{
					if ($scope.fieldModel && $scope.durationModel){
						$scope.field.value = $scope.fieldModel + "@" + $scope.durationModel;
					} else {
						$scope.field.value = "";
					}
					if ($scope.field.onChange && typeof $scope.field.onChange === "function")
						$scope.field.onChange();
				} catch(ex){
					console.warn(ERROR_MESSAGE, ex);
				}
			}
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snDayOfWeekElement.js */
angular.module('sn.ngform.elements').directive('snDayOfWeekElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl('sn_day_of_week_element.xml')
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snDateTimeElement.js */
angular.module('sn.ngform.elements').directive('snDateTimeElement', function($window, getTemplateUrl, snFormDateHelper) {
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl("sn_date_time_element.xml"),
		controller: function($scope){
			var config = {
				startView: "day",
				minView : "minute",
				dropdownSelector : "glide_date_time_" + $scope.field.ref + "_dropdown",
				renderOn: 'datepicker.render'
			};
			$scope.config = angular.extend(config, $scope.field.timepickerConfig);
			$scope.setDateTime = setDateTime;
			$scope.dateTimeOnChangeHandler = dateTimeOnChangeHandler;
			activate();
			function activate(){
				if (typeof $scope.field === "undefined" || typeof $scope.field === "null")
					throw "Invalid field model";
				if (typeof moment === "undefined" || typeof moment === "null")
					throw "Moment.js is unavailable";
				_initFieldData();
				_setMomentLocale();
			}
			function setDateTime(newDate, oldDate) {
				if (newDate === oldDate)
					return;
				_toggleDropdownMenu();
				$scope.field.value = moment(newDate).format("YYYY-MM-DD HH:mm:ss");
				$scope.field.displayValue = moment(newDate).format($scope.field.dateFormat);
				_triggerFieldOnChange();
			}
			function dateTimeOnChangeHandler() {
				if (!moment($scope.field.displayValue, $scope.field.dateFormat).isValid())
					return;
				$scope.field.value = $scope.field.displayValue;
				$scope.dateAsPicker = moment($scope.field.value).format($scope.field.dateFormat);
				_triggerFieldOnChange();
			}
			function _toggleDropdownMenu() {
				angular.element("#" + $scope.config.dropdownSelector).dropdown("toggle");
			}
			function _initFieldData() {
				if ($scope.field.value){
					if (!$scope.field.displayValue)
						$scope.field.displayValue = moment($scope.field.value).format($scope.field.dateFormat);
					$scope.dateAsPicker = moment($scope.field.value).format("YYYY-MM-DD HH:mm:ss");
				} else {
					$scope.field.displayValue = moment().format($scope.field.dateFormat);
					$scope.field.value = snFormDateHelper.addTimezoneOffset("YYYY-MM-DD HH:mm:ss");
					$scope.dateAsPicker = moment().format($scope.field.dateFormat);
				}
			}
			function _setMomentLocale(){
				var firstDayOfWeek = parseInt($window.g_date_picker_first_day_of_week,10) || 1;
				moment.locale('en', {
					week: {
						dow: Math.min(Math.max(firstDayOfWeek - 1, 0), 6)
					}
				});
			}
			function _triggerFieldOnChange(){
				if ($scope.field.onChange && typeof $scope.field.onChange === "function")
					$scope.field.onChange();
			}
		},
		link: function(scope, element) {
			const keyHandler = (event) => {
if (event.key === "Enter" || event.keyCode === 13)
					return;
				const targetElement = event.target;
				const dropDown = angular.element(targetElement).closest('.dropdown-menu');
				const focusableElements = dropDown.find('th, td, span').filter(':visible').filter('[tabindex="0"]');
				if (focusableElements.length === 0) {
					return;
				}
				const currentIndex = focusableElements.index(document.activeElement);
				let nextIndex = -1;
				if (event.key === 'Tab' || event.keyCode === 9) {
if (event.shiftKey) {
						nextIndex = currentIndex - 1;
} else {
						nextIndex = currentIndex + 1;
					}
				}
				else if (event.key === 'ArrowUp' || event.key === 'ArrowDown' || event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
					const nodesPerRow= targetElement.closest('table').className.includes('day-view') ? 7 : 4;
					if (event.key === 'ArrowUp') {
						nextIndex = currentIndex - nodesPerRow;
					} else if (event.key === 'ArrowDown') {
						nextIndex = currentIndex + nodesPerRow;
					} else if (event.key === 'ArrowLeft') {
						nextIndex = currentIndex - 1;
					} else if (event.key === 'ArrowRight') {
						nextIndex = currentIndex + 1;
					}
				}
nextIndex = (nextIndex + focusableElements.length) % focusableElements.length;
				focusableElements[nextIndex].focus();
				event.stopPropagation();
				event.preventDefault();
			};
			element.on('show.bs.dropdown', function() {
				scope.$broadcast('datepicker.render');
				setTimeout(() => {
					focusOnActiveDate(element)
					document.addEventListener('keydown', keyHandler, true)
				}, 0);
			});
			element.on('hidden.bs.dropdown', function() {
				angular.element('input', angular.element('[id="' + scope.config.dropdownSelector + '"]')).focus();
				document.removeEventListener('keydown', keyHandler, true);
			});
			function focusOnActiveDate(element) {
const activeDateElement = element.find('.day.active');
				if (activeDateElement.length) {
					activeDateElement.focus(); 
					activeDateElement.on('focus', function(event) {
						event.stopPropagation();
						event.preventDefault();
					});
				}
			}
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snDomainIdElement.js */
angular.module('sn.ngform.elements').directive('snDomainIdElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl('sn_domain_id_element.xml'),
		controller: function($scope){
			$scope.field.targetTable = "domain";
			$scope.field.display_field = "name";
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snEmailElement.js */
angular.module('sn.ngform.elements').directive('snEmailElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace:true,
		templateUrl: getTemplateUrl('sn_email_element.xml')
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snMonthOfYearElement.js */
angular.module('sn.ngform.elements').directive('snMonthOfYearElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl('sn_month_of_year_element.xml')
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snTimeElement.js */
angular.module('sn.ngform.elements').directive('snTimeElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace:true,
		templateUrl: getTemplateUrl('sn_time_element.xml'),
		controller: function($scope, snFormDateHelper){
			$scope.field.displayHour = $scope.field.displayValue.split(":")[0];
			$scope.field.displayMin = $scope.field.displayValue.split(":")[1];
			$scope.field.displaySec = $scope.field.displayValue.split(":")[2];
			if (!$scope.field.displayHour){
				$scope.field.displayHour = "00";
				$scope.field.displayMin = "00";
				$scope.field.displaySec = "00";
			}
			$scope.field.displayValue = snFormDateHelper.removeTimezoneOffset($scope.field.value);
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snWeekOfMonthElement.js */
angular.module('sn.ngform.elements').directive('snWeekOfMonthElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl('sn_week_of_month_element.xml')
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snReferenceElement.js */
angular.module('sn.ngform.elements').directive('snReferenceElement', function (getTemplateUrl, $http) {
	"use strict";
	var requestCount = 0;
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl('sn_reference_element.xml'),
		controller: function($scope, $element, $attrs){
			$scope.field = $scope.field || $scope.$eval($attrs.field);
			$scope.$watch('field.suggestion', function(n,o){
				if (n !== o){
					addSuggestionToQuery();
				}
			});
			if (!Bloodhound){
				return;
			}
			var displayFieldKey = $scope.field.reference_display_field || $scope.field.display_field;
			var bHound = new Bloodhound({
				datumTokenizer: function(d) { return Bloodhound.tokenizers.whitespace(d.displayValue); },
				queryTokenizer: Bloodhound.tokenizers.whitespace,
				identify: function(obj){ return obj.sysId},
				local: []
			});
			var initialized = false;
			var wildcard = false;
			var idArray;
			var data;
			var query;
			var displayField = (displayFieldKey instanceof Array) ? displayFieldKey : [displayFieldKey];
			$scope.config = {
				minLength: 1,
				highlight: true
			};
			$scope.referenceData = {
				displayKey: 'displayValue',
				source: typeaheadWithWildcard,
				limit: 15
			};
			$scope.$watch('field.suggestion', function(n, o){
				if (n !== o && n === "**"){
					wildcard = true;
					getData();
				} else if ( n !== o &&  n != null){
					wildcard = false;
					getData();
				}
			});
			$scope.$watch('field.targetTable', function(n, o){
				if ( n !== o ){
					bHound.clear();
				}
			});
			function typeaheadWithWildcard(q, sync){
				if (q === "**"){
					sync(bHound.get(idArray));
				} else {
					bHound.search(q, sync);
				}
			}
			$scope.activate = function activate(){
				bHound.initialize();
				getData();
			};
			function getData(){
				if (!$scope.field.suggestion) {
					data = [];
					addData();
					return;
				}
				var field = $scope.field.display_field || 'name';
				query = (wildcard) ? "" : field + "STARTSWITH" + $scope.field.suggestion;
				var params = {
					sysparm_query: query || '',
					sysparm_fields: displayField,
					sysparm_reference_field: $scope.field.name,
					sysparm_referring_table : $scope.field.table,
					sysparm_referring_record_id: $scope.field.sysId,
					sysparm_display_value: 'all',
					sysparm_exclude_reference_link: 'true',
					sysparm_field_styles: 'true',
					sysparm_timer: ++requestCount,
					sysparm_completer_id: $scope.field.table + '.' + $scope.field.name
				};
$http.get("/api/now/ui/table/" + $scope.field.targetTable, {
					params: params
				}).then(function(response){
					data = response.data.result.records[0].records.map(function (obj) {
						try {
							return {
								displayValue: obj.data[displayField].display_value,
								sysId: obj.sys_id
							};
						} catch(e) {
							return {
								displayValue: obj.metadata.display_value,
								sysId: obj.sys_id
							};
						}
					});
					addData();
				})
			}
			function addData() {
				if (wildcard){
					_createArrayOfIds();
				}
				bHound.add(data);
				if (!initialized){
					initialized = true;
					return;
				}
				$scope.$broadcast('openTypeahead');
			}
			function _createArrayOfIds(){
				idArray = [];
				var length = (data.length < $scope.referenceData.limit) ? data.length : $scope.referenceData.limit;
				for(var i = 0; i < length; i++){
					idArray.push(data[i].sysId);
				}
			}
			function addSuggestionToQuery(){
				$scope.query = $scope.field.suggestion ? $scope.field.display_field + "STARTSWITH" + $scope.field.suggestion : '';
			}
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snDurationElement.js */
angular.module('sn.ngform.elements').directive('snDurationElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
 		replace: true,
		templateUrl: getTemplateUrl('sn_duration_element.xml'),
		controller: function($scope) {
			$scope.showDays = $scope.showHours = $scope.showMinutes = true;
			if ($scope.field.maxUnit == 'hours')
				$scope.showDays = false;
			else if ($scope.field.maxUnit == 'minutes')
				$scope.showDays = $scope.showHours = false;
			else if ($scope.field.maxUnit == 'seconds')
				$scope.showDays = $scope.showHours = $scope.showMinutes = false;
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snIntegerElement.js */
angular.module('sn.ngform.elements').directive('snIntegerElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace:true,
		templateUrl: getTemplateUrl('sn_integer_element.xml')
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snDecimalElement.js */
angular.module('sn.ngform.elements').directive('snDecimalElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace:true,
		templateUrl: getTemplateUrl('sn_decimal_element.xml')
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snPasswordElement.js */
angular.module('sn.ngform.elements').directive('snPasswordElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace:true,
		templateUrl: getTemplateUrl('sn_password_element.xml'),
		controller: function($scope){
			$scope.showPassword = false;
			$scope.toggleShowPassword = function(){
				$scope.showPassword = !$scope.showPassword;
			};
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/directive.snIpAddressElement.js */
angular.module('sn.ngform.elements').directive('snIpAddressElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl('sn_ip_address_element.xml')
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/util/directive.snListFormElement.js */
angular.module('sn.ngform.elements').directive('snListFormElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace:true,
		scope:{
			field: '=',
			isEmbedded: '='
		},
		templateUrl: getTemplateUrl('sn_list_form_element.xml'),
		link: function(scope, element){
			element.addClass('row');
			if (scope.isEmbedded === 'true')
				element.css({margin: 0});
			if (!scope.field.onChange)
				scope.field.onChange = angular.noop;
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/util/directive.snFormElement.js */
angular.module('sn.ngform.elements').directive('snFormElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		scope:{
			field: '='
		},
		templateUrl: getTemplateUrl('sn_form_element.xml'),
		link: function(scope, element){
			scope.field.fieldType = scope.field.type;
			element.addClass('row');
			if (!scope.field.onChange)
				scope.field.onChange = angular.noop;
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/util/directive.snFilterWidgetElement.js */
angular.module('sn.ngform.elements').directive('snFilterWidgetElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		scope:{
			field: '=',
			popoverConfig: '='
		},
		templateUrl: getTemplateUrl('sn_filter_widget_element.xml'),
		controller: function($scope){
			$scope.field.inline = true;
			$scope.field.ref = $scope.field.field + "." + $scope.field.$$hashKey;
			if (!$scope.field.onChange)
				$scope.field.onChange = angular.noop;
			if ($scope.field.display_value){
				$scope.field.displayValue = $scope.field.display_value;
			}
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/util/directive.snFilterWidgetBetweenElement.js */
angular.module('sn.ngform.elements').directive('snFilterWidgetBetweenElement', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		scope:{
			field: '=',
			popoverConfig: '='
		},
		templateUrl: getTemplateUrl('sn_filter_widget_between_element.xml'),
		controller: function($scope) {
			activate();
			function activate() {
				var field = $scope.field;
				var values = (field.value || "@").split("@").map(function(v) {
					return v.trim();
				});
				$scope.field1 = createFieldModel(field, values[0], field.betweenType, 'BETWEEN_A');
				$scope.field2 = createFieldModel(field, values[1], field.betweenType, 'BETWEEN_B');
				$scope.$watch('field1.value + field2.value', function(n, o) {
					if (n != o){
						if ($scope.field1.value && $scope.field2.value)
							field.value = $scope.field1.value + "@" + $scope.field2.value;
						if (field.onChange && typeof field.onChange === "function")
							field.onChange();
					}
				});
			}
			function createFieldModel (obj, value, type, operator) {
				return Object.create(obj, {
					value: {
						writable: true,
						value: value
					},
					advancedEditor: {
						value: type
					},
					operator: {
						value : obj.betweenType === 'glide_date_choice' ? operator : obj.operator
					},
					between : {
						value: true
					},
					onChange: {
						writable: true,
						value: null
					}
				});
			}
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/util/directive.snFormGroup.js */
angular.module('sn.ngform.elements').directive('snFormGroup', function (getTemplateUrl) {
	"use strict";
	return {
		restrict: 'A',
		transclude: "element",
		replace: true,
		templateUrl: getTemplateUrl('sn_form_group.xml'),
		link: function(scope, element, attrs){
			if (!scope.field.inline)
				scope.label = attrs.label || scope.field.label;
			var input = element.find(":input");
			var id = input.attr("id");
			input.addClass('form-control');
			scope.for = id;
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/util/service.snFormDateHelper.js */
(function(){
	angular.module('sn.ngform.elements').factory('snFormDateHelper', function () {
		var d,
			hours;
		
		if (typeof g_tz_offset !== "undefined"){
			d = moment.duration(g_tz_offset, 'milliseconds');
			hours = Math.floor(d.asHours());
		} else{
			d = 0;
			hours = 0;
		} 
		return {
			removeTimezoneOffset: removeTimezoneOffset,
			addTimezoneOffset: addTimezoneOffset
		};
		function removeTimezoneOffset(value){
			if (moment(value).isDST())
				return moment(value).subtract(Math.abs(hours) - 1, 'hours').format("YYYY-MM-DD HH:mm:ss");
			else
				return moment(value).subtract(Math.abs(hours), 'hours').format("YYYY-MM-DD HH:mm:ss");
		}
		function addTimezoneOffset(value){
			if (moment(value).isDST())
				return moment(value).add(Math.abs(hours) - 1, 'hours').format("YYYY-MM-DD HH:mm:ss");
			else
				return moment(value).add(Math.abs(hours), 'hours').format("YYYY-MM-DD HH:mm:ss");
		}
	});
})();
;
/*! RESOURCE: /scripts/app.ngFormElements/util/directive.snStringToNumber.js */
angular.module('sn.ngform.elements').directive('snStringToNumber', function() {
	return {
		require: 'ngModel',
		link: function(scope, element, attrs, ngModel) {
			ngModel.$parsers.push(function(value) {
				return '' + value;
			});
			ngModel.$formatters.push(function(value) {
				return parseFloat(value, 10);
			});
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/util/directive.snDurationFormatter.js */
angular.module('sn.ngform.elements').directive('snDurationFormatter', function () {
	"use strict";
	return {
		require: "ngModel",
		restrict: "A",
		link: function(scope, element, attrs, ngModelCtrl) {
			var theDawnOfTime;
			ngModelCtrl.$formatters.push(function() {
				if (!scope.field.value)
					return {days: 0, hours: 0, minutes: 0, seconds: 0}
				theDawnOfTime = moment.unix(0).utc();
				var fieldValueMoment = moment.utc(scope.field.value, 'YYYY-MM-DD HH:mm:ss');
				var duration = moment.duration(fieldValueMoment.diff(theDawnOfTime));
				var days = Math.floor(duration.asDays());
				var	hours = duration.get('hours');
				var	minutes = duration.get('minutes');
				var	seconds = duration.get('seconds');
				var maxUnit = scope.field.maxUnit;
				if (maxUnit == 'hours') {
					days = 0;
					hours = Math.floor(duration.asHours());
				}
				if (maxUnit == 'minutes') {
					days = hours = 0;
					minutes = Math.floor(duration.asMinutes());
				}
				if (maxUnit == 'seconds') {
					days = hours = minutes = 0;
					seconds = duration.asSeconds();
				}
				return {
					days: days,
					hours: hours,
					minutes: minutes,
					seconds: seconds
				};
			});
			ngModelCtrl.$render = function() {
				scope.days = ngModelCtrl.$viewValue.days;
				scope.hours = ngModelCtrl.$viewValue.hours;
				scope.minutes = ngModelCtrl.$viewValue.minutes;
				scope.seconds = ngModelCtrl.$viewValue.seconds;
			};
			ngModelCtrl.$parsers.push(function(model) {
				theDawnOfTime = moment.unix(0).utc();
				var modelValue = moment.duration(model);
				var newValue = theDawnOfTime.add(modelValue).format("YYYY-MM-DD HH:mm:ss");
				return newValue;
			});
			scope.$watch('days + hours + minutes + seconds', function() {
				ngModelCtrl.$setViewValue({
					days: scope.days,
					hours: scope.hours,
					minutes: scope.minutes,
					seconds: scope.seconds
				});
			});
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/util/directive.snFilterTextareaFormatter.js */
angular.module('sn.ngform.elements').directive('snFilterTextareaFormatter', function () {
	"use strict";
	return {
		require: "ngModel",
		restrict: "A",
		link: function(scope, element, attrs, ngModelCtrl) {
			ngModelCtrl.$parsers.push(_toModel);
			ngModelCtrl.$formatters.push(_toView);
			function _toModel(input){
				if (!input)
					return;
var normalized = input.split(/[,\n]+/g);
				var normalizedString = normalized.filter(_removeEmptyStrings).join(",");
				return normalizedString;
			}
			function _toView(input){
				if (input)
return input.replace(/[,]/g, ",\n");
				return input;
			}
			function _removeEmptyStrings(item){
				return item;
			}
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/util/directive.snReferenceFormatter.js */
angular.module('sn.ngform.elements').directive('snReferenceFormatter', function () {
	"use strict";
	return {
		require: "ngModel",
		restrict: "A",
		link: function(scope, element, attrs, ngModelCtrl) {
			var originalValue = scope.field.displayValue;
			ngModelCtrl.$parsers.push(function(model){
				if (model !== '') {
					if (angular.isObject(model)) {
						scope.field.value = model.sysId;
						scope.field.suggestion = null;
						return originalValue = scope.field.displayValue = model.displayValue;
					} else {
						scope.field.suggestion = model;
						return originalValue;
					}
				} else {
					return originalValue = scope.field.displayValue = scope.field.value = model;
				}
			});
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/util/directive.snTypeaheadTrigger.js */
angular.module('typeahead.directives').directive('snTypeaheadTrigger', function() {
	"use strict";
	return {
		limit: 'A',
		link: function(scope, element) {
			scope.$on("openTypeahead", function(ref){
				var origVal = element.val();
				if (origVal !== ''){
					element.val('').trigger('input').val(origVal).trigger('input');
				}
			});
		}
	}
});
;
/*! RESOURCE: /scripts/app.ngFormElements/util/filter.snStringEmpty.js */
angular.module('sn.ngform.elements').filter('empty', function(i18n) {
	return function(input) {
		return (!!input) ? input : i18n.getMessage('(empty)');
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/util/filter.snTrustedHtml.js */
angular.module('sn.ngform.elements').filter('snTrustedHtml', function($sce){
	return function(text) {
		return $sce.trustAsHtml(text);
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/elements/js_includes_elements.js */
/*! RESOURCE: scripts/directive.snCurrency2BetweenElement.js */
angular.module('sn.ngform.elements').directive('snCurrency2BetweenElement', function(getTemplateUrl) {
	'use strict';
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl('sn_currency2_between_element.xml'),
		controller: function($scope, snCurrencyService) {
			$scope.currencies = snCurrencyService.currencies;
			$scope.currency = {
				values: []
			};
			var fieldValue = $scope.field.value;
			$scope.field.value = '';
			snCurrencyService.request().then(function() {
				$scope.currency = snCurrencyService.parseBetweenValue(fieldValue);
			});
			$scope.valueHandler = function valueHandler() {
				var value = snCurrencyService.reduceBetweenValue($scope.currency);
				if (!value)
					return;
				$scope.field.value = value;
				if (typeof $scope.field.onChange === 'function')
					$scope.field.onChange();
			}
		}
	};
});
;
/*! RESOURCE: scripts/directive.snCurrency2Element.js */
angular.module('sn.ngform.elements').directive('snCurrency2Element', function(getTemplateUrl) {
  'use strict';
  return {
    restrict: 'E',
    replace: true,
    templateUrl: getTemplateUrl('sn_currency_element.xml'),
    controller: function($scope, snCurrencyService) {
      $scope.currencies = snCurrencyService.currencies;
      $scope.currency = {};
      var fieldValue = $scope.field.value;
      $scope.field.value = '';
      snCurrencyService.request().then(function() {
        if (!fieldValue) {
			$scope.currency.type = snCurrencyService.defaultCurrency;
			return;
        }
var values = fieldValue.split(/,(.+)/);
        $scope.currency.type = snCurrencyService.findCode(values[0]);
        $scope.currency.value = values[1];
        $scope.field.value = fieldValue;
      });
      $scope.$watch('field.operator', function(newValue, oldValue) {
        if (newValue === oldValue)
          return;
        $scope.currency.value = '';
      });
      $scope.valueHandler = function valueHandler() {
        var type = $scope.currency.type;
        var currencyValue = (type) ? type.code : "";
        var amountValue = $scope.currency.value;
        $scope.field.value = currencyValue + "," + amountValue;
        if (typeof $scope.field.onChange === 'function')
          $scope.field.onChange();
      }
    }
  };
});
;
;
/*! RESOURCE: /scripts/app.ngFormElements/components/_components.js */
angular.module('sn.ngform.components', [
	'sn.common.ui.popover',
	'sn.ngform.components.record_preview',
	'sn.ngform.components.reference_selector'
]);
;
/*! RESOURCE: /scripts/sn/common/ui/popover/_module.js */
angular.module('sn.common.ui.popover', []);
;
/*! RESOURCE: /scripts/sn/common/ui/popover/directive.snBindPopoverSelection.js */
angular.module('sn.common.ui.popover').directive('snBindPopoverSelection', function(snCustomEvent) {
	"use strict";
	return {
		restrict: "A",
		controller: function($scope, $element, $attrs , snCustomEvent) {
			snCustomEvent.observe('list.record_select', recordSelectDataHandler);
			function recordSelectDataHandler(data, event) {
				if (!data || !event)
					return;
				event.stopPropagation();
				var ref = ($scope.field) ? $scope.field.ref : $attrs.ref;
				if (data.ref === ref) {
					if (window.g_form) {
						if ($attrs.addOption) {
							addGlideListChoice('select_0' + $attrs.ref, data.value, data.displayValue);
						} else {
							var fieldValue = typeof $attrs.ref === 'undefined' ? data.ref : $attrs.ref;
							window.g_form._setValue(fieldValue, data.value, data.displayValue);
							clearDerivedFields(data.value);
						}
					}
					if ($scope.field) {
						$scope.field.value = data.value;
						$scope.field.displayValue = data.displayValue;
					}
				}
			}
			function clearDerivedFields(value) {
				if (window.DerivedFields) {
					var df = new DerivedFields($scope.field ? $scope.field.ref : $attrs.ref);
					df.clearRelated();
					df.updateRelated(value);
				}
			}
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/ui/popover/directive.snComplexPopover.js */
angular.module('sn.common.ui.popover').directive('snComplexPopover', function(getTemplateUrl, $q, $http, $templateCache, $compile, $timeout){
	"use strict";
	return {
		restrict: 'E',
		replace:true,
		templateUrl: function(elem, attrs){
			return getTemplateUrl(attrs.buttonTemplate);
		},
		controller: function($scope, $element, $attrs, $q, $document, snCustomEvent, snComplexPopoverService){
			$scope.type = $attrs.complexPopoverType || "complex_popover";
			if ($scope.closeEvent){
				snCustomEvent.observe($scope.closeEvent, destroyPopover);
				$scope.$on($scope.closeEvent, destroyPopover);
			}
			$scope.$parent.$on('$destroy', destroyPopover);
			$scope.$on('$destroy', function() {
				snCustomEvent.un($scope.closeEvent, destroyPopover);
			});
			var newScope;
			var open;
			var popover;
			var content;
			var popoverDefaults = {
				container: 'body',
				html: true,
				placement: 'auto',
				trigger: 'manual',
template: '<div class="complex_popover popover" role="dialog"><div class="arrow"></div><div class="popover-content"></div></div>'
			};
			var popoverConfig = angular.extend(popoverDefaults, $scope.popoverConfig);
			$scope.loading      = false;
			$scope.initialized  = false;
			$scope.popOverDisplaying = false;
			$scope.onDownKey = function(event) {
				if (!event) return;
				var downArrowKey = 40;
				if (event.keyCode === downArrowKey || event.key === 'ArrowDown')
					$scope.togglePopover(event);
			};
			$scope.togglePopover = function(event) {
				if (!open){
					showPopover(event);
				} else {
					destroyPopover();
				}
				$scope.popOverDisplaying = !$scope.popOverDisplaying;
			};
			function showPopover(e) {
				if ($scope.loading)
					return;
				$scope.$toggleButton = angular.element(e.target);
				$scope.loading = true;
				$scope.$emit('list.toggleLoadingState', true);
				_getTemplate()
					.then(_insertTemplate)
					.then(_createPopover)
					.then(_bindHtml)
					.then(function(){
						$scope.initialized = true;
						if (!$scope.loadEvent)
							_openPopover();
					});
			}
			function destroyPopover() {
				if (!newScope)
					return;
				$scope.$toggleButton.on('hidden.bs.popover', function(){
					open = false;
					$scope.$toggleButton.data('bs.popover').$element.removeData('bs.popover').off('.popover');
					$scope.$toggleButton = null;
					snCustomEvent.fire('hidden.complexpopover.' + $scope.ref);
				});
				$scope.$toggleButton.popover('hide');
				snCustomEvent.fire('hide.complexpopover.' + $scope.ref, $scope.$toggleButton);
newScope.$broadcast('$destroy');
				newScope.$destroy();
				newScope = null;
				$scope.initialized = false;
				angular.element(popoverConfig.container).off({
					'keydown': keyDownHandler
				});
				angular.element(window).off({
					'click': complexHtmlHandler
				});
			}
			function _getTemplate() {
				return snComplexPopoverService.getTemplate(getTemplateUrl($attrs.template));
			}
			function _createPopover() {
				$scope.$toggleButton.popover(popoverConfig);
				return $q.when(true);
			}
			function _insertTemplate(response) {
				newScope = $scope.$new();
				if ($scope.loadEvent)
					newScope.$on($scope.loadEvent, _openPopover);
				content = $compile(response.data)(newScope);
				popoverConfig.content = content;
				newScope.open = true;
				snCustomEvent.fire('inserted.complexpopover.' + $scope.ref, $scope.$toggleButton);
				return $q.when(true);
			}
			function _bindHtml() {
				angular.element(popoverConfig.container).on({
					'keydown': keyDownHandler
				});
				angular.element(window).on({
					'click': complexHtmlHandler
				});
				return $q.when(true);
			}
			function complexHtmlHandler(e) {
				var parentComplexPopoverScope = angular.element(e.target).parents('.popover-content').children().scope();
				if (parentComplexPopoverScope && (parentComplexPopoverScope.type = "complex_popover") && $scope.type === "complex_popover")
					return;
				if (!open || angular.element(e.target).parents('html').length === 0)
					return;
				if ($scope.initialized && !$scope.loading && !$scope.$toggleButton.is(e.target) && content.parents('.popover').has(angular.element(e.target)).length === 0) {
					_eventClosePopover(e);
					destroyPopover(e);
				}
				if (e.target.classList.contains(popoverConfig.closeBtnClass) && e.type === 'click') {
					_eventClosePopover(e);
					destroyPopover(e);
				}
			}
			function keyDownHandler(e) {
if (e.keyCode != 27)
					return;
				if (!open || angular.element(e.target).parents('html').length === 0)
					return;
				if ($scope.initialized && !$scope.loading && !$scope.$toggleButton.is(e.target) && content.parents('.popover').has(angular.element(e.target)).length > 0) {
					_eventClosePopover(e);
					destroyPopover();
				}
			}
			function _eventClosePopover(e) {
					e.preventDefault();
					e.stopPropagation();
			}
			function createAndActivateFocusTrap(popover) {
				var deferred = $q.defer();
				if (!window.focusTrap) {
					deferred.reject('Focus trap not found');
				} else {
					if (!$scope.focusTrap) {
						$scope.focusTrap = window.focusTrap(popover, { clickOutsideDeactivates: true });
					}
					try {
						$scope.focusTrap.activate({
							onActivate: function() {
								deferred.resolve();
							}
						});
					} catch(e) {
						console.warn("Unable to activate focus trap", e);
					}
				}
				return deferred.promise;
			}
			function deactivateAndDestroyFocusTrap() {
				var deferred = $q.defer();
				if (!$scope.focusTrap) {
					deferred.reject("Focus trap not found");
				} else {
					try {
						$scope.focusTrap.deactivate({
							returnFocus: false,
							onDeactivate: function () {
								deferred.resolve();
							}
						});
					} catch (e) {
						console.warn("Unable to deactivate focus trap", e);
					}
					$scope.focusTrap = null;
				}
				return deferred.promise;
			}
			function _openPopover() {
				if (open) {
					return;
				}
				open = true;
				$timeout(function() {
					$scope.$toggleButton.popover('show');
					$scope.loading = false;
					snCustomEvent.fire('show.complexpopover.' + $scope.ref, $scope.$toggleButton);
					$scope.$toggleButton.on('shown.bs.popover', function(evt) {
						var popoverObject = angular.element(evt.target).data('bs.popover'),
							$tooltip,
							popover;
						$tooltip = popoverObject && popoverObject.$tip;
						popover = $tooltip && $tooltip[0];
						if (popover) {
							createAndActivateFocusTrap(popover);
						}
						snCustomEvent.fire('shown.complexpopover.' + $scope.ref, $scope.$toggleButton);
						var element = document.querySelector('.filter-accordion-title');
						if (element)
							element.focus();
					});
					$scope.$toggleButton.on('hide.bs.popover', function () {
						deactivateAndDestroyFocusTrap().finally(function() {
							$scope.$toggleButton.focus();
						});
					});
				}, 0 );
			}
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/ui/popover/service.snComplexPopoverService.js */
angular.module('sn.common.ui.popover').service('snComplexPopoverService', function($http, $q, $templateCache){
	"use strict";
	return {
		getTemplate: getTemplate
	};
	function getTemplate(template){
		return $http.get(template, {cache: $templateCache});
	}
});
;
;
/*! RESOURCE: /scripts/sn/common/ui/popover/js_includes_ui_popover.js */
/*! RESOURCE: /scripts/app.ngFormElements/components/reference_selector/_reference_selector.js */
angular.module('sn.ngform.components.reference_selector', []);
;
/*! RESOURCE: /scripts/app.ngFormElements/components/reference_selector/directive.snReferenceSelector.js */
angular.module('sn.ngform.components.reference_selector').directive('snReferenceSelector', function(getTemplateUrl, snCustomEvent, snReferenceSelectorService) {
	"use strict";
	return {
		restrict: 'E',
		templateUrl: getTemplateUrl("sn_reference_selector.xml"),
		scope: {
			target:"@",
			referringRecordId:"@",
			referringTable:"@",
			referenceKey:"@",
			dependentField:"@",
			query:"@",
			popoverConfig: "=",
			closeEvent: "@",
			loadEvent: "@",
			ref: "@",
			targetTable: "@",
			buttonTabIndex: "@",
			referenceLabel: "@"
		},
		replace: true,
		controller: function($scope, $element) {
			$scope.clearStack = true;
			$scope.query = '';
			$scope.sysparmView = "sys_ref_list";
			$scope.listType = "reference";
			$scope.encodedQueryRecord = angular.element('#sysparm_encoded_record').val();
			$scope.loaded = false;
			$scope.referenceField = $scope.target.substring($scope.target.indexOf('.') + 1);
			var originalValue;
var modal = $element.find('.modal')[0],
modalParent = null;
			angular.element(modal).on('show.bs.modal', function(evt) {
					var displayField = angular.element("#sys_display." + $scope.ref);
					if (typeof originalValue === undefined) {
						originalValue = angular.element("#sys_display.original." + $scope.ref).value;
					}
					if (displayField.value != originalValue) {
						$scope.referenceFieldValue = displayField.value;
						originalValue = displayField.value;
					}
					var srcModal = evt.target;
					if (srcModal != modal)
						return;
					modalParent = modal.parentNode;
					angular.element(modal).appendTo('body');
					$scope.loaded = true;
					$scope.$evalAsync();
				})
				.on('hidden.bs.modal', function(evt) {
					var srcModal = evt.target;
					if (srcModal != modal)
						return;
					angular.element(modal).appendTo(modalParent);
					angular.element(modal).find('sn-list').scope().$destroy();
					$scope.loaded = false;
					$scope.$evalAsync();
				});
			if (window.g_form) {
				snCustomEvent.observe('show.complexpopover.' + $scope.ref, function() {
					var elem = angular.element('sys_display.' + $scope.ref);
					var originalValElem = angular.element('sys_display.original.' + $scope.ref);
					if (!originalValElem) {
						return;
					}
					if (elem.value === originalValElem.value) {
						$scope.query = '';
						return;
					}
					if (elem.value && elem.attr('ac_order_by')) {
						$scope.query = elem.attr('ac_order_by') + "STARTSWITH" + elem.value;
					}
				});
				snCustomEvent.observe('form.isModified', setChangedValues);
			}
			function setChangedValues() {
				var desiredFields = window.g_form.modifiedFields || {};
				$scope.referringRecordChangedValues = snReferenceSelectorService.getModifiedFieldValues(desiredFields, $scope.referringTable);
				var dependentFieldEl = gel("sys_original." + $scope.referringTable + "." + $scope.dependentField);
				if (window.g_form.hasField($scope.dependentField) && dependentFieldEl && g_form.getValue($scope.dependentField) !== dependentFieldEl.value) {
					desiredFields[$scope.dependentField] = true;
				}
			}
			snCustomEvent.observe('list.record_select', function(data) {
				if (data.ref == $scope.ref) {
					angular.element(data.event.target)
						.closest('.modal')
						.modal('hide');
					data.event.preventDefault();
				}
			});
			$scope.$on("$destroy", function() {
				angular.element(modal).modal('hide');
			});
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/components/reference_selector/service.snReferenceSelectorService.js */
angular.module('sn.ngform.components.reference_selector').service('snReferenceSelectorService', function() {
	"use strict";
	return {
		getModifiedFieldValues: getModifiedFieldValues
	};
	function getModifiedFieldValues(fields){
		var modifiedFields = {};
		if (!window.g_form){
			console.warn("g_form is undefined");
			return;
		}
		for (var key in fields) {
			if (fields.hasOwnProperty(key)) {
				if (key.indexOf(".") > -1){
					key = key.split('.').splice(1,2).join('.');
				}
				modifiedFields[key] = window.g_form.getValue(key);
			}
		}
		return modifiedFields;
	}
});
;
;
/*! RESOURCE: /scripts/app.ngFormElements/components/reference_selector/js_includes_reference_selector.js */
/*! RESOURCE: /scripts/app.ngFormElements/components/record_preview/_record_preview.js */
angular.module('sn.ngform.components.record_preview', []);
;
/*! RESOURCE: /scripts/app.ngFormElements/components/record_preview/directive.snRecordPreview.js */
angular.module('sn.ngform.components.record_preview').directive('snRecordPreview', function(getTemplateUrl, i18n) {
	return {
		restrict: 'E',
		templateUrl: getTemplateUrl("sn_record_preview.xml"),
		scope: {
			recordTitle: "@",
			popoverConfig: "=",
			closeEvent: "@",
			loadEvent: "@",
			targetTable: "@",
			sysId: "@",
			column: "@",
			ref: "@",
			isRelated : "=",
			currentRow: "@",
			refDataTestId: "@",
			isForm: "@",
			buttonStyles : "@"
		},
		controller : function($scope, $element){
			CustomEvent.observe("refFieldPreviewButtonChange", function(ref, sys_id, displayValue){
				if ($scope.ref == ref) {
					$scope.title = displayValue;
					$scope.sysId = sys_id;
				}
			});
			var sel = '#' + $scope.ref + ' .list_table_tbody';
			$scope.buttonStyles = "sn-popover-complex btn btn-icon table-btn-lg icon-info list-select-record";
			$scope.screenReaderPreview = i18n.getMessage('Preview {0}').withValues([$scope.recordTitle]);
			if ($scope.isForm == "true") {
				sel = '.form_body';
				$scope.buttonStyles = "btn btn-default btn-ref icon icon-info";
			}
			$scope.popoverConfig = angular.extend({}, {
				viewport : {
					selector: sel,
					padding: 5
				}
			}, $scope.popoverConfig);
			if ($scope.isRelated){
				angular.extend($scope.popoverConfig, {
					container : '.section_header_content_no_scroll',
					viewport : {
						selector: 'body'
					}
				})
			}
		}
	};
});
;
/*! RESOURCE: /scripts/app.ngFormElements/components/record_preview/service.snRecordPreviewService.js */
angular.module('sn.ngform.components.record_preview').service('snRecordPreviewService', function($http, $q, urlTools){
	"use strict";
var TABLE_DATA = "/api/now/ui/table/";
	var layoutCache = {};
	return {
		getFields: getFields,
		getTableData: getTableData
	};
	function getFields(table, sysId, view, field) {
		var layoutCacheKey = [table, sysId, view, field].join('^');
		if (layoutCacheKey in layoutCache){
			return $q.when(layoutCache[layoutCacheKey]);
		}
		var view = view || null;
		var src = urlTools.getURL('popupform', {
			table: table,
			sys_id: sysId,
			view: view,
			field: field
		});
		return $http.post(src)
			.then(function(response){
				layoutCache[layoutCacheKey] = _processFields(response.data[1]);
				return layoutCache[layoutCacheKey];
			})
			.catch(function(){
				console.warn(error);
			});
	}
	function getTableData(table, fields, sysId) {
		var src = TABLE_DATA + table;
		var query = "sys_id=" + sysId;
		return $http({
				cache: false,
				method: "get",
				url: src,
				params: {
					sysparm_query: query,
					sysparm_display_value: true,
					sysparm_fields: fields
				}})
					.then(function(response){
				return response.data.result.records[0].records[0].data;
			}).catch(function(error){
				console.warn(error);
			});
	}
	function _processFields(fields){
		var sections = [];
		var fieldsString = [];
		angular.forEach(fields, function(field){
			var columns = [];
			angular.forEach(field.columns, function(column){
				var fields = [];
				angular.forEach(column.fields, function(field){
					if (_checkComponent(field)){
						fields.push(field);
						fieldsString.push(field.name);
					}
				});
				columns.push(fields);
			});
			sections.push(columns);
		});
		return {
			sections: sections,
			fields: fieldsString.join(",")
		};
	}
	function _checkComponent(field){
		var unsupportedComponent = ["formatter", "annotation", "journal_list", "journal_input", "chart", "embedded"];
		return (unsupportedComponent.indexOf(field.type) === -1);
	}
});
;
/*! RESOURCE: /scripts/app.ngFormElements/components/record_preview/directive.snRecordPreviewForm.js */
angular.module('sn.ngform.components.record_preview').directive('snRecordPreviewForm', function (getTemplateUrl, snRecordPreviewService){
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl('sn_record_preview_form.xml'),
		controller: function($scope, snRecordPreviewService){
			var sections;
			var fieldsList;
			activate();
			function activate() {
				var fields = snRecordPreviewService.getFields($scope.targetTable, $scope.sysId, $scope.view, $scope.column);
				fields
					.then(function(fieldsData) {
						sections = fieldsData.sections;
						fieldsList = fieldsData.fields;
						snRecordPreviewService.getTableData($scope.targetTable, fieldsList, $scope.sysId)
							.then(bindColumnsResponse)
							.catch(errorHandler);
				});
			}
			function bindColumnsResponse(response){
				$scope.sections = sections;
				$scope.data = response;
				$scope.$emit($scope.loadEvent);
			}
			function errorHandler(ex){
				console.warn(ex)
			}
			$scope.columnSplitter = function(columns){
				if (columns.length === 1){
					return "col-sm-12";
				} else {
					var classes = [];
classes.push("col-sm-" + parseInt(12/columns.length, 10));
					classes.push("vsplit");
					return classes.join(' ');
				}
			};
			$scope.openNewRecord = function(evt) {
				if ($scope.isForm == "true")
window.location.href = "/" + $scope.targetTable + ".do?sys_id=" + $scope.sysId;
				else {
					$scope.$emit('openRecord', {
						table: $scope.targetTable,
						sysId: $scope.sysId,
						rowIndex: $scope.currentRow,
						event: evt
					});
				}
				$scope.togglePopover();
			};
		}
	};
});
;
;
/*! RESOURCE: /scripts/js_includes_ng_form_elements.js */

/*! RESOURCE: /scripts/doctype/SetTransactionSource.js */
(function(){
	if (!window.transaction_source) {
		var attrs = [ "Interface=Web", "Interface-Type=Classic Environment" ];
		if ((window.NOW && NOW.isUsingPolaris) || (top.NOW && top.NOW.isPolarisWrapper === "true"))
			attrs.push("Interface-Name=Unified Navigation App");
		else
			attrs.push("Interface-Name=Core UI");
		window.transaction_source = attrs.join();
	}
	if (window.jQuery) {
		window.jQuery.ajaxPrefilter(function(options) {
			if (!options.crossDomain) {
				if (!options.headers)
					options.headers = {};
				options.headers["X-Transaction-Source"] = window.transaction_source;
			}
		});
	}
})()
;
/*! RESOURCE: /scripts/sn/common/_module.js */
angular.module('sn.common', [
	'ngSanitize',
	'ngAnimate',
	'sn.common.avatar',
	'sn.common.controls',
	'sn.common.datetime',
	'sn.common.glide',
	'sn.common.i18n',
	'sn.common.link',
	'sn.common.mention',
	'sn.common.messaging',
	'sn.common.notification',
	'sn.common.presence',
	'sn.common.stream',
	'sn.common.ui',
	'sn.common.user_profile',
	'sn.common.util',
	'sn.common.dynamicTranslation'
]);
angular.module('ng.common', [
	'sn.common'
]);
;
/*! RESOURCE: /scripts/sn/common/dist/templates.js */
angular.module('sn.common.dist.templates', []);
;
/*! RESOURCE: /scripts/sn/common/datetime/_module.js */
angular.module('sn.common.datetime', [
	'sn.common.i18n'
]);
angular.module('sn.timeAgo', [
	'sn.common.datetime'
]);
;
/*! RESOURCE: /scripts/sn/common/datetime/directive.snTimeAgo.js */
angular.module('sn.common.datetime').constant('DATE_GRANULARITY', {
	DATETIME: 1,
    DATE: 2
});
angular.module('sn.common.datetime').factory('timeAgoTimer', function($interval, $rootScope, DATE_GRANULARITY) {
	"use strict";
	var digestInterval;
	return function(displayGranularityType) {
		displayGranularityType = typeof displayGranularityType !== 'undefined' ? displayGranularityType : DATE_GRANULARITY.DATETIME;
		if (!digestInterval && displayGranularityType == DATE_GRANULARITY.DATETIME)
			digestInterval = $interval(function() {
				$rootScope.$broadcast('sn.TimeAgo.tick');
			}, 30 * 1000);
		return Date.now();
	};
});
angular.module('sn.common.datetime').factory('timeAgo', function(timeAgoSettings, DATE_GRANULARITY) {
	var service = {
		settings: timeAgoSettings.get(),
		allowFuture: function allowFuture(bool) {
			this.settings.allowFuture = bool;
			return this;
		},
		toWords: function toWords(distanceMillis, messageGranularity, verbose) {
			messageGranularity = messageGranularity || DATE_GRANULARITY.DATETIME;
			var $l = verbose ? service.settings.strings_verbose : service.settings.strings;
var seconds = Math.abs(distanceMillis) / 1000;
var minutes = seconds / 60;
var hours = minutes / 60;
var days = hours / 24;
var years = days / 365;
			var ago = $l.ago;
			if ((seconds < 45 && messageGranularity == DATE_GRANULARITY.DATETIME)
				|| (hours < 24 && messageGranularity == DATE_GRANULARITY.DATE)
				|| (!service.settings.allowFuture && distanceMillis < 0))
				ago = '%d';
			if (service.settings.allowFuture) {
				if (distanceMillis < 0) {
					ago = $l.fromNow;
				}
			}
			function substitute(stringOrFunction, number) {
				var string = angular.isFunction(stringOrFunction) ?
					stringOrFunction(number, distanceMillis) : stringOrFunction;
				if (!string)
					return "";
				var value = ($l.numbers && $l.numbers[number]) || number;
return string.replace(/%d/i, value);
			}
			var wantDate = messageGranularity == DATE_GRANULARITY.DATE;
			var wantDateTime = messageGranularity == DATE_GRANULARITY.DATETIME;
			var words = distanceMillis <= 0 && wantDateTime && substitute($l.justNow, 0) ||
			distanceMillis <= 0 && wantDate && substitute($l.today, 0) ||
			seconds < 45 && (distanceMillis >= 0 || !service.settings.allowFuture) && wantDateTime && substitute($l.justNow, Math.round(seconds)) ||
			seconds < 45 && wantDateTime && substitute($l.seconds, Math.round(seconds)) ||
			seconds < 90 && wantDateTime && substitute($l.minute, 1) ||
			minutes < 45 && wantDateTime && substitute($l.minutes, Math.round(minutes)) ||
			minutes < 90 && wantDateTime && substitute($l.hour, 1) ||
			hours < 24 && wantDateTime && substitute($l.hours, Math.round(hours)) ||
			hours < 24 && wantDate && substitute($l.today, 0) ||
				hours < 42 && substitute($l.day, 1) ||
				days < 30 && substitute($l.days, Math.ceil(days)) ||
				days < 45 && substitute($l.month, 1) ||
days < 365 && substitute($l.months, Math.round(days / 30)) ||
				years < 1.5 && substitute($l.year, 1) ||
				substitute($l.years, Math.round(years));
			return substitute(ago, words);
		},
		parse: function(iso8601) {
			if (angular.isNumber(iso8601))
				return new Date(parseInt(iso8601, 10));
			var s = iso8601.trim();
s = s.replace(/\.\d+/,"");
s = s.replace(/-/,"/").replace(/-/,"/");
s = s.replace(/T/," ").replace(/Z/," UTC");
s = s.replace(/([\+\-]\d\d)\:?(\d\d)/," $1$2");
			return new Date(s);
		}
	};
	return service;
});
angular.module('sn.common.datetime').directive("snTimeAgo", function(timeAgoSettings, $rootScope, timeAgo, timeAgoTimer, DATE_GRANULARITY, dateUtils) {
	"use strict";
	return {
		restrict: "E",
template: '<time data-toggle="tooltip" data-placement="bottom" title="{{ ::titleTime }}" tabindex="0"><span aria-hidden="true">{{timeAgo}}</span><span class="sr-only">{{timeAgoVerbose}}</span></time>',
		scope: {
			timestamp: "=",
local: "=",
label: "=",
			voiceOverLabel: "="
		},
		link: function(scope) {
			timeAgoSettings.ready.then(function() {
				timeAgoTimer(DATE_GRANULARITY.DATETIME)
				scope.$on('sn.TimeAgo.tick', setTimeAgo);
				setTimeAgo();
			});
			function setTimeAgo() {
				scope.timeAgo = [scope.label, timeAgoConverter(scope.timestamp, true, false)].filter(Boolean).join(' ');
				scope.timeAgoVerbose = [scope.voiceOverLabel, scope.label, timeAgoConverter(scope.timestamp, true, true)].filter(Boolean).join(' ');
			}
			function timeAgoConverter(input, noFuture, verbose) {
if (!input)
					return;
				var allowFuture = !noFuture;
				var date = timeAgo.parse(input);
if (scope.local) {
					scope.titleTime = input;
					return timeAgo.allowFuture(allowFuture).toWords(new Date() - date, 1, verbose);
				}
				if (Object.prototype.toString.call(date) !== "[object Date]" && Object.prototype.toString.call(date) !== "[object Number]")
					return input;
				else if (Object.prototype.toString.call(date) == "[object Date]" && isNaN(date.getTime()))
					return input;
				setTitleTime(date);
				var currentDate = new Date();
				currentDate = new Date(currentDate.getUTCFullYear(), currentDate.getUTCMonth(), currentDate.getUTCDate(), currentDate.getUTCHours(), currentDate.getUTCMinutes(), currentDate.getUTCSeconds() );
				var diff = currentDate - date;
				return timeAgo.allowFuture(allowFuture).toWords(diff, 1, verbose);
			}
			function setTitleTime(date) {
				var t = date.getTime();
var o = date.getTimezoneOffset();
t -= o * 60 * 1000;
				if (typeof g_user_date_time_format !== 'undefined' && g_user_date_time_format.indexOf('z') == -1)
					scope.titleTime = dateUtils.formatDate(new Date(t), g_user_date_time_format);
				else
					scope.titleTime = new Date(t).toLocaleString();
			}
		}
	}
});
angular.module('sn.common.datetime').directive("snTimeAgoStatic", function(timeAgoSettings, $rootScope, timeAgo, timeAgoTimer, DATE_GRANULARITY) {
	"use strict";
	return {
		restrict: "E",
template: '<time title="{{ ::titleTime }}">{{timeAgo}}</time>',
		scope: {
			timestamp: "@",
local: "@"
		},
		link: function(scope) {
			timeAgoSettings.ready.then(function() {
				timeAgoTimer(DATE_GRANULARITY.DATETIME)
				scope.$on('sn.TimeAgo.tick', setTimeAgo);
				setTimeAgo();
			});
			function setTimeAgo() {
				scope.timeAgo = timeAgoConverter(scope.timestamp, true);
			}
			function timeAgoConverter(input, noFuture) {
if (!input)
					return;
				var allowFuture = !noFuture;
				var date = timeAgo.parse(input);
if (scope.local) {
					scope.titleTime = input;
					return timeAgo.allowFuture(allowFuture).toWords(new Date() - date);
				}
				if (Object.prototype.toString.call(date) !== "[object Date]" && Object.prototype.toString.call(date) !== "[object Number]")
					return input;
				else if (Object.prototype.toString.call(date) == "[object Date]" && isNaN(date.getTime()))
					return input;
				setTitleTime(date);
				var currentDate = new Date();
				currentDate = new Date(currentDate.getUTCFullYear(), currentDate.getUTCMonth(), currentDate.getUTCDate(), currentDate.getUTCHours(), currentDate.getUTCMinutes(), currentDate.getUTCSeconds() );
				var diff = currentDate - date;
				return timeAgo.allowFuture(allowFuture).toWords(diff);
			}
			function setTitleTime(date) {
				var t = date.getTime();
var o = date.getTimezoneOffset();
t -= o * 60 * 1000;
				scope.titleTime = new Date(t).toLocaleString();
			}
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/datetime/directive.snDayAgo.js */
angular.module('sn.common.datetime').directive("snDayAgo", function(timeAgoSettings, $rootScope, timeAgo, timeAgoTimer, DATE_GRANULARITY) {
	"use strict";
	return {
		restrict: "E",
template: '<time>{{dayAgo}}</time>',
		scope: {
			date: "=",
			label: "="
		},
		link: function(scope) {
			timeAgoSettings.ready.then(function() {
				setDayAgo();
			});
			function setDayAgo() {
				scope.dayAgo = [scope.label, dayAgoConverter(scope.date, "noFuture")].filter(Boolean).join(' ');
			}
			
			function dayAgoConverter(input, option) {
				if (!input) return;
				var allowFuture = !((option === 'noFuture') || (option === 'no_future'));
				var date = timeAgo.parse(input);
				if ( Object.prototype.toString.call(date) !== "[object Date]" )
					return input;
				else if ( isNaN(date.getTime()) )
					return input;
				
				var diff = timeAgoTimer(DATE_GRANULARITY.DATE) - date;
				return timeAgo.allowFuture(allowFuture).toWords(diff, DATE_GRANULARITY.DATE);
			}
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/datetime/snTimeAgoSettings.js */
angular.module('sn.common.datetime').provider('snTimeAgoSettings', function() {
	"use strict";
	var INIT_NEVER = 'never';
	var INIT_AUTO = 'auto';
	var INIT_MANUAL = 'manual';
	var _initMethod = INIT_AUTO;
	this.setInitializationMethod = function(init) {
		switch (init) {
			default:
				init = INIT_AUTO;
			case INIT_NEVER:
			case INIT_AUTO:
			case INIT_MANUAL:
				_initMethod = init;
				break;
		}
	};
	this.$get = function(i18n, $q) {
		var settings = {
			allowFuture: true,
			dateOnly: false,
			strings: {}
		};
		var _initialized = false;
		var ready = $q.defer();
		function initialize() {
			if (_initMethod === INIT_NEVER) {
				return $q.reject();
			}
			if (!_initialized) {
				_initialized = true;
				i18n.getMessages(['%d ago', '%d from now', 'just now',
					'%d minutes_verbose', 'about %d hours_verbose', '%d days_verbose', '%d months_verbose', '%d years_verbose',
					'less than a minute', 'about a minute', '%d minutes', 'about an hour', 'about %d hours', 'today', 'a day', '%d days',
					'about a month', '%d months', 'about a year', 'about a year', '%d years'], function (msgs) {
					settings.strings = {
						ago: msgs['%d ago'],
						fromNow: msgs['%d from now'],
						justNow: msgs["just now"],
						seconds: msgs["less than a minute"],
						minute: msgs["about a minute"],
						minutes: msgs["%d minutes"],
						hour: msgs["about an hour"],
						hours: msgs["about %d hours"],
						day: msgs["a day"],
						days: msgs["%d days"],
						month: msgs["about a month"],
						months: msgs["%d months"],
						year: msgs["about a year"],
						years: msgs["%d years"],
						today: msgs["today"],
						wordSeparator: msgs["timeago_number_separator"],
						numbers: []
					};
					settings.strings_verbose = Object.assign({}, settings.strings, {
						minutes: msgs["%d minutes_verbose"],
						hours: msgs["about %d hours_verbose"],
						days: msgs["%d days_verbose"],
						months: msgs["%d months_verbose"],
						years: msgs["%d years_verbose"]
					});
					ready.resolve();
				});
			}
			return ready.promise;
		}
		if (_initMethod === INIT_AUTO) {
			initialize();
		}
		return {
			initialize: initialize,
			ready: ready.promise,
			get: function get() {
				return settings;
			},
			set: function set(translated) {
				settings = angular.extend(settings, translated);
			}
		};
	};
}).factory('timeAgoSettings', function(snTimeAgoSettings) {
	return snTimeAgoSettings;
});
;
;
/*! RESOURCE: /scripts/sn/common/datetime/js_includes_datetime.js */
/*! RESOURCE: /scripts/sn/common/glide/_module.js */
angular.module('sn.common.glide', [
	'sn.common.util'
]);
;
/*! RESOURCE: /scripts/sn/common/glide/factory.glideUrlBuilder.js */
angular.module('sn.common.glide').factory('glideUrlBuilder', ['$window', function($window) {
	"use strict";
	function GlideUrl(contextPath){
		var objDef = {
			contextPath: '',
			params: {},
			encodedString: '',
			encode: true,
			setFromCurrent: function() {
				this.setFromString($window.location.href);
			},
			setFromString:function(href) {
				var pos = href.indexOf('?');
				if (pos < 0) {
					this.contextPath = href;
					return;
				}
				this.contextPath = href.slice(0, pos);
				var hashes = href.slice(pos + 1).split('&');
				var i = hashes.length;
				while (i--) {
					var pos = hashes[i].indexOf('=');
					this.params[hashes[i].substring(0, pos)] = hashes[i].substring(++pos);
				}
			},
			setContextPath: function(c) {
				this.contextPath = c;
			},
			getParam: function(p) {
				return this.params[p];
			},
			getParams: function() {
				return this.params;
			},
			addParam: function(name, value) {
				this.params[name] = value;
				return this;
			},
			addToken: function() {
				if (typeof g_ck != 'undefined' && g_ck != "")
					this.addParam('sysparm_ck', g_ck);
				return this;
			},
			deleteParam: function(name) {
				delete this.params[name];
			},
			addEncodedString: function(s) {
				if (!s)
					return;
				if (s.substr(0, 1) != "&")
					this.encodedString += "&";
				this.encodedString += s;
				return this;
			},
			getQueryString: function(additionalParams) {
				var qs = this._getParamsForURL(this.params);
				qs += this._getParamsForURL(additionalParams);
				qs += this.encodedString;
				if (qs.length == 0)
					return "";
				return qs.substring(1);
			},
			_getParamsForURL: function(params) {
				if (!params)
					return '';
				var url = '';
				for (var n in params) {
					var p = params[n] || '';
					url += '&' + n + '=' + (this.encode ? encodeURIComponent(p + '') : p);
				}
				return url;
			},
			getURL: function(additionalParams) {
				var url = this.contextPath;
				var qs = this.getQueryString(additionalParams);
				if (qs)
					url += "?" + qs;
				return url;
			},
			setEncode: function(b) {
				this.encode = b;
			},
			toString: function() { return 'GlideURL'; }
		}
		return objDef;
	}
	return {
		newGlideUrl: function(contextPath) {
			var glideUrl = new GlideUrl();
			glideUrl.setFromString(contextPath ? contextPath : '');
			return glideUrl;
		},
		refresh: function(){
			$window.location.replace( $window.location.href );
		},
		getCancelableLink: function(link) {
			if ($window.NOW && $window.NOW.g_cancelPreviousTransaction) {
				var nextChar = link.indexOf('?') > -1 ? '&' : '?';
				link += nextChar + "sysparm_cancelable=true";
			}
			return link;
		}
	};
}]);
;
/*! RESOURCE: /scripts/sn/common/glide/service.queryFilter.js */
angular.module('sn.common.glide').factory('queryFilter', function() {
	"use strict";
	return {
		create : function() {
			var that = {};
			that.conditions = [];
			function newCondition(field, operator, value, label, displayValue, type){
				var condition = {
					field: field,
					operator: operator,
					value: value,
					displayValue: displayValue,
					label: label,
					left: null,
					right: null,
					type: null,
					setValue: function(value, displayValue){
						this.value = value;
						this.displayValue = displayValue ? displayValue : value;
					}
				};
				if (type)
					condition.type = type;
				return condition;
			}
			function addCondition(condition) {
				that.conditions.push(condition);
				return condition;
			}
			function removeCondition(condition) {
				for (var i = that.conditions.length-1; i >= 0; i--) {
					if (that.conditions[i] === condition)
						that.conditions.splice(i, 1);
				}
			}
			function getConditionsByField(conditions, field){
				var conditionsToReturn = [];
				for(var condition in conditions){
					if (conditions.hasOwnProperty(condition)){
						if (conditions[condition].field == field)
							conditionsToReturn.push(conditions[condition]);
					}
				}
				return conditionsToReturn;
			}
			function encodeCondition(condition){
				var output = "";
				if (condition.hasOwnProperty("left") && condition.left){
					output += encodeCondition(condition.left);
				}
				if (condition.hasOwnProperty("right") && condition.right){
					var right = encodeCondition(condition.right);
					if (right.length > 0){
						output += "^" + condition.type + right;
					}
				}
				if (condition.field){
					output += condition.field;
					output += condition.operator;
					if (condition.value !== null && typeof condition.value !== "undefined")
						output += condition.value;
				}
				return output;
			}
			function createEncodedQuery() {
				var eq = "";
				var ca = that.conditions;
				for (var i = 0; i < ca.length; i++) {
					var condition = ca[i];
					if (eq.length)
						eq += '^';
					eq += encodeCondition(condition);
				}
				eq += "^EQ";
				return eq;
			}
			that.addCondition = addCondition;
			that.newCondition = newCondition;
			that.createEncodedQuery = createEncodedQuery;
			that.getConditionsByField = getConditionsByField;
			that.removeCondition = removeCondition;
			return that;
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/glide/service.filterExpressionParser.js */
angular.module('sn.common.glide').factory('filterExpressionParser', function() {
	'use strict';
	var operatorExpressions = [{
		wildcardExp: '(.*)',
		operator: 'STARTSWITH',
		toExpression: function(filter) {
			return filter;
		}
	},{
		wildcardExp: '^\\*(.*)',
		operator: 'LIKE',
		toExpression: function(filter) {
			return (filter === '*' ? filter : '*' + filter);
		}
	},{
		wildcardExp: '^\\.(.*)',
		operator: 'LIKE',
		toExpression: function(filter) {
			return '.' + filter;
		}
	},{
		wildcardExp: '^%(.*)',
		operator: 'ENDSWITH',
		toExpression: function(filter) {
			return (filter === '%' ? filter : '%' + filter);
		}
	},{
		wildcardExp: '(.*)%',
		operator: 'LIKE',
		toExpression: function(filter) {
			return filter + '%';
		}
	},{
		wildcardExp: '^=(.*)',
		operator: '=',
		toExpression: function(filter) {
			return (filter === '=' ? filter : '=' + filter);
		}
	},{
		wildcardExp: '^!\\*(.*)',
		operator: 'NOT LIKE',
		toExpression: function(filter) {
			return (filter === '!*' || filter === '!' ? filter : '!*' + filter);
		}
	},{
		wildcardExp: '^!=(.*)',
		operator: '!=',
		toExpression: function(filter) {
			return (filter === '!=' || filter === '!' ? filter : '!=' + filter);
		}
	}, {
		wildcardExp: '^\\*\\*$',
		operator: 'ANYTHING',
		toExpression: function() {
			return "ANYTHING";
		}
	}];
	return {
		getOperatorExpressionForOperator: function(operator) {
			for (var i = 0; i < operatorExpressions.length; i++) {
				var item = operatorExpressions[i];
				if (item.operator === operator)
					return item;
			}
			throw {
				name: 'OperatorNotSupported',
				message: 'The operator ' + operator + ' is not in the list of operatorExpressions.'
			};
		},
		parse: function(val, defaultOperator) {
			var parsedValue = {
				filterText: val,
				operator: defaultOperator || 'STARTSWITH'
			};
			for (var i = 1; i < operatorExpressions.length; i++) {
				var operatorItem = operatorExpressions[i];
				var match = val.match(operatorItem.wildcardExp);
				if (match && match[1] !== '') {
					parsedValue.operator = operatorItem.operator;
					parsedValue.filterText = match[1];
				}
			}
			return parsedValue;
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/glide/service.userPreferences.js */
angular.module('sn.common.glide').factory("userPreferences", function ($http, $q, unwrappedHTTPPromise, urlTools) {
	"use strict";
	var	preferencesCache = {};
	function getPreference(preferenceName) {
		if (preferenceName in preferencesCache)
			return preferencesCache[preferenceName];
		var targetURL = urlTools.getURL('user_preference', {
				"sysparm_pref_name": preferenceName,
				"sysparm_action": "get"
			}),
			deferred = $q.defer();
		$http.get(targetURL).success(function (response) {
			deferred.resolve(response.sysparm_pref_value);
		}).error(function (data, status) {
			deferred.reject("Error getting preference " + preferenceName + ": " + status);
		});
		preferencesCache[preferenceName] = deferred.promise;
		return deferred.promise;
	}
	function setPreference(preferenceName, preferenceValue) {
var preferenceValueString = "" + preferenceValue;
		var parmsObj = {
				"sysparm_pref_name": preferenceName,
				"sysparm_action": "set"
			};
		var useGet = preferenceValueString.length <= 1024;
		if (useGet)
			parmsObj["sysparm_pref_value"] = preferenceValueString;
		var targetURL = urlTools.getURL('user_preference', parmsObj);
		
		var httpPromise = useGet ? $http.get(targetURL) : $http.post(targetURL, {'sysparm_pref_value': preferenceValueString});
		addToCache(preferenceName, preferenceValue);
		return unwrappedHTTPPromise(httpPromise);
	}
	function addToCache(preferenceName, preferenceValue){
		preferencesCache[preferenceName] = $q.when(preferenceValue);
	}
	var userPreferences = {
		getPreference: getPreference,
		setPreference: setPreference,
		addToCache: addToCache
	};
	return userPreferences;
});
;
/*! RESOURCE: /scripts/sn/common/glide/service.nowStream.js */
angular.module('sn.common.glide').constant('nowStreamTimerInterval', 5000);
angular.module('sn.common.glide').factory('nowStream', function($q, amb, $timeout, urlTools, nowStreamTimerInterval, snResource, snCustomEvent, $log) {
	'use strict';
	var POLLING_OFF = window.NOW.activity && !(window.NOW.activity.polling && window.NOW.activity.isV0);
	var EDIT_ENABLED = window.NOW.activity && !(window.NOW.activity.editTimeLimit === '0');
var HISTORY_UPDATE_AMB_CHANNEL = '/history/update';
var V1_EMAIL_CHANNEL = '/activity/ui16';
var V0_EMAIL_CHANNEL = '/activity/email';
var EDIT_CHANNEL = '/activity/ui16/edit';
	amb.connect();
	var Stream = function() {
		this.initialize.apply(this, arguments);
	};
	Stream.prototype = {
		initialize: function(table, query, sys_id, processor, interval, source, includeAttachments) {
			this.table = table;
			this.query = query;
			this.sysparmQuery = null;
			this.sys_id = sys_id;
			this.processor = processor;
			this.lastTimestamp = 0;
			this.inflightRequest = null;
			this.requestImmediateUpdate = false;
			this.interval = interval;
			this.source = source;
			this.includeAttachments = includeAttachments;
			this.stopped = true;
			this.isLoggedIn = true;
			this.ambChannel = null;
			this.editChannel = null;
var meta_connect = '/meta/connect';
			var connectToEmailAmb = window.NOW.activity ? window.NOW.activity.useEmailAmb : false;
			var channelName;
			if (!POLLING_OFF)
channelName = HISTORY_UPDATE_AMB_CHANNEL + '/' + this.table + '/' + this.sys_id;
			else if (connectToEmailAmb)
channelName = (window.NOW.activity.isV0 ? V0_EMAIL_CHANNEL : V1_EMAIL_CHANNEL) + '/' + this.sys_id;
			else
channelName = null;
			if (channelName)
				this.ambChannel = amb.getChannel(channelName).subscribe(POLLING_OFF ? this.fetchStreamForAmb.bind(this) : this.tap.bind(this));
			this.metaConnect = amb.getChannel(meta_connect).subscribe(this.evaluateLoggedIn.bind(this));
			var editChannelName;
			if (EDIT_ENABLED) {
				var connectToEditAmbWithTable = window.NOW.activity ? window.NOW.activity.useEditAmbWithTable : false;
				if (this.sys_id && !connectToEditAmbWithTable)
editChannelName = EDIT_CHANNEL + '/' + this.sys_id;
				if (connectToEditAmbWithTable) {
					if (this.table)
editChannelName = EDIT_CHANNEL + '/' + this.table;
					else if (window.NOW.activity.editAmbTable)
editChannelName = EDIT_CHANNEL + '/' + window.NOW.activity.editAmbTable;
				}
				this.editChannel = amb.getChannel(editChannelName).subscribe(this.getEditMessageAndMakeEdit.bind(this));
			}
		},
		evaluateLoggedIn: function(message) {
			var msg = message.ext || {};
			this.ambConnected = message.successful;
			var SESSION_STATUS = "glide.session.status";
			var SESSION_TIMEOUT = "glide.session.time.remaining.in.seconds";
			var SESSION_LOGGED_IN = "session.logged.in";
			var SESSION_LOGGED_OUT = "session.logged.out";
			var SESSION_INVALIDATED = "session.invalidated";
			if (msg[SESSION_STATUS] === SESSION_LOGGED_IN) {
				if (msg[SESSION_TIMEOUT] && parseInt(msg[SESSION_TIMEOUT]) > 0)
					this.isLoggedIn = true;
			}
			else if (msg[SESSION_STATUS] === SESSION_INVALIDATED || msg[SESSION_STATUS] === SESSION_LOGGED_OUT)
				this.isLoggedIn = false;
		},
		parseEditMessage: function(jsonString) {
			if (!jsonString || typeof jsonString !== 'string')
				return null;
			try {
				var parsed = JSON.parse(jsonString);
				var result = {
					new: parsed.new || '',
					type: parsed.type || '',
					containsCode: parsed.containsCode === 'true',
					historyLineIds: []
				};
				if (parsed.historyLineIds && typeof parsed.historyLineIds === 'string') {
					try {
						result.historyLineIds = JSON.parse(parsed.historyLineIds);
					} catch (e) {
						console.error('History line ids is not a JSON string:', e);
						result.historyLineIds = [parsed.historyLineIds];
					}
				}
				return result;
			} catch (error) {
				console.error('Error parsing edit message data', error);
				return null;
			}
		},
		getEditMessageAndMakeEdit: function(message) {
			var parsedJson = this.parseEditMessage(message.data.data);
			if (!parsedJson)
				return;
			var editType = parsedJson.type;
			var newValue = parsedJson.new;
			var containsCode = parsedJson.containsCode;
			var historyLineIds = parsedJson.historyLineIds;
			var selector = historyLineIds.map(function(id) {
				return '#activity_' + id;
			}).join(', ');
			var textDivElements = document.querySelectorAll(selector);
			if (textDivElements.length === 0)
				return;
			if (editType === 'edited') {
				for (var i = 0; i < textDivElements.length; i++) {
					if(this.handleEdit(textDivElements[i], containsCode, newValue)) {
						snCustomEvent.fire('sn.stream.entries_edited',
							this.getHistoryLineId(textDivElements[i].id), newValue, containsCode);
					}
				}
			}
			if (editType === 'deleted') {
				for (var i = 0; i < textDivElements.length; i++) {
					var liElement = textDivElements[i].closest('li.h-card');
					if (liElement) {
						var historyLineId = this.getHistoryLineId(textDivElements[i].id);
						var widgetDivElements = liElement.querySelectorAll('div.sn-widget');
						if (widgetDivElements.length === 1 || widgetDivElements.length === 0) {
							liElement.remove();
						}
						else {
							textDivElements[i].remove();
						}
						snCustomEvent.fire('sn.stream.entries_deleted', historyLineId);
					}
				}
			}
		},
		getHistoryLineId: function(id) {
			var prefix = 'activity_';
			if (id.startsWith(prefix)) {
				return id.substring(prefix.length);
			}
			return id;
		},
		handleEdit: function(textDivElement, containsCode, newValue, historyLineId) {
			var spanElement = textDivElement.querySelector('span.sn-widget-textblock-body');
			if (!spanElement)
				return false;
			if (containsCode) {
				var targetElement = spanElement.querySelector('sn-html-content-wrapper');
				if (!targetElement)
					targetElement = spanElement;
				var shadowRootElement = targetElement.shadowRoot;
				if (shadowRootElement) {
					var divElement = shadowRootElement.querySelector('div');
					if (divElement) {
						divElement.innerHTML = newValue;
						return true;
					}
				}
				this.encapsulate(targetElement, newValue, historyLineId);
				targetElement.innerHTML = '';
				return true;
			}
			spanElement.innerHTML = newValue;
			return true;
		},
		createDefaultCssLink: function() {
			var link = document.createElement("link");
link.href = "styles/activity_encapsulated.css";
			link.rel = "stylesheet";
link.type = "text/css";
			return link;
		},
		createBaseElement: function() {
			var base = document.createElement("base");
			base.setAttribute("target", "_blank");
			return base;
		},
		encapsulate: function(root, content, uniqueId) {
			var defaultCssLink = this.createDefaultCssLink();
			var style = document.createElement('style');
			style.innerHTML = ':host img {max-width: 100%; height: auto; overflow: hidden;}';
			if (document.head.createShadowRoot || document.head.attachShadow) {
				var shadow = root.shadowRoot || (document.head.attachShadow ?
					root.attachShadow({mode: 'open'}) :
					root.createShadowRoot());
				var contentDiv = document.createElement('div');
				contentDiv.innerHTML = content;
				if (window.NOW && window.NOW.isUsingPolaris) contentDiv.classList.add('-polaris');
				shadow.innerHTML = contentDiv.outerHTML;
				shadow.appendChild(defaultCssLink);
				shadow.appendChild(style);
			} else {
				var iframeId = "activity-iframe-" + uniqueId;
				var existingIframe = document.getElementById(iframeId);
				if (existingIframe) {
					existingIframe.contentDocument.write(content);
					existingIframe.contentWindow.document.head.appendChild(defaultCssLink);
					existingIframe.setAttribute("height", existingIframe.contentWindow.document.body.scrollHeight + 'px');
				}
				else {
					var rootEl = typeof $j !== 'undefined' ? $j(root) : null;
					var iframe = document.createElement("iframe");
					iframe.setAttribute("id", iframeId);
					iframe.setAttribute("style", "border:none;display:block;width:100%");
					iframe.setAttribute("class", "html-content");
					iframe.setAttribute("scrolling", "no");
					iframe.setAttribute("height", "0");
					iframe.setAttribute("sandbox", "allow-same-origin");
					root.appendChild(iframe);
					var doc = iframe.contentWindow.document;
					doc.open();
					doc.write(content);
					doc.close();
					iframe.contentWindow.document.head.appendChild(defaultCssLink);
					iframe.contentWindow.document.head.appendChild(this.createBaseElement());
					iframe.height = doc.body.scrollHeight + 'px';
					if (rootEl && rootEl.closest) {
						var parentTab = rootEl.closest(".tabs2_section");
						var parentSectionId = parentTab.attr ? parentTab.attr("data-section-id") : null;
						var setIFrameHeightFn = function(tab) {
							if (typeof $j !== 'undefined') {
								var openedTab = $j(".tabs2_section." + tab);
								if (openedTab.length > 0 && openedTab.attr("data-section-id") === parentSectionId) {
									iframe.contentWindow.document.head.appendChild(defaultCssLink);
									iframe.height = doc.body.scrollHeight + 'px';
									if (typeof CustomEvent !== 'undefined' && CustomEvent.un) {
										CustomEvent.un("tab.activated", setIFrameHeightFn);
									}
								}
							}
						};
						if (typeof CustomEvent !== 'undefined' && CustomEvent.observe) {
							CustomEvent.observe("tab.activated", setIFrameHeightFn);
						}
					}
				}
			}
		},
		fetchStreamForAmb: function(message) {
			this._executeRequest().then(this._successCallback.bind(this));
		},
		fetchStream: function(callback, preRequestCallback) {
			this.callback = callback;
			this.preRequestCallback = preRequestCallback;
			this._executeRequest().then(this._successCallback.bind(this));
		},
		setQuery: function(sysparmQuery) {
			this.sysparmQuery = sysparmQuery;
		},
		poll: function(callback, preRequestCallback) {
			if (POLLING_OFF)
				return;
			this.callback = callback;
			this.preRequestCallback = preRequestCallback;
			this._stopPolling();
			this._startPolling();
		},
		tap: function() {
			if (POLLING_OFF)
				return;
			if (!this.inflightRequest) {
				this._stopPolling();
				this._startPolling();
			}
			else
				this.requestImmediateUpdate = true;
		},
		insert: function(field, text) {
			this.insertForEntry(field, text, this.table, this.sys_id);
		},
		insertForEntry: function(field, text, table, sys_id) {
			return this.insertEntries([{
				field: field,
				text: text
			}], table, sys_id);
		},
		expandMentions: function (entryText, mentionIDMap) {
			var text = entryText;
			Object.getOwnPropertyNames(mentionIDMap).forEach(function(element) {
var atMention = element.replace(/[.*+\-?^()|[\]\\]/g, '\\$&');
				var search = new RegExp("@\\[" + atMention + "\\]", "gi");
				var sysId = mentionIDMap[element];
				text = text.replace(search, "@[" + sysId + ":" + element + "]");
			});
			return text;
		},
		addCarriageReturns: function(entryText) {
return entryText.replace(/\r*\n/g, '\r\n');
		},
		insertEntries: function(entries, table, sys_id, mentionIDMap) {
			mentionIDMap = mentionIDMap || {};
			var sanitizedEntries = [];
			for (var i = 0; i < entries.length; i++) {
				var entryText = entries[i].text;
				if (entryText && entryText.endsWith('\n'))
					entryText = entryText.substring(0, entryText.length - 1);
				if (!entryText)
					continue;
				entries[i].text = this.addCarriageReturns(this.expandMentions(entryText, mentionIDMap));
				sanitizedEntries.push(entries[i]);
			}
			if (sanitizedEntries.length === 0)
				return;
			this._isInserting = true;
			var url = this._getInsertURL(table, sys_id);
			var that = this;
			return snResource().post(url, {
				entries: sanitizedEntries
			}).then(this._successCallback.bind(this), function() {
				$log.warn('Error submitting entries', sanitizedEntries);
			}).then(function() {
				that._isInserting = false;
			});
		},
		cancel: function() {
			this._stopPolling();
			if (this.ambChannel)
				this.ambChannel.unsubscribe();
			if (this.editChannel)
				this.editChannel.unsubscribe();
		},
		_startPolling : function() {
			var interval = this._getInterval();
			var that = this;
			var successCallback = this._successCallback.bind(this);
			that.stopped = false;
			function runPoll() {
				if (that._isInserting) {
					establishNextRequest();
					return;
				}
				if (that.lastPollFailed) {
					that.stopNextRequest = !that.ambConnected || !that.isLoggedIn;
					establishNextRequest();
				}
				if (!that.inflightRequest && !that.stopNextRequest) {
					that.inflightRequest = that._executeRequest();
					that.inflightRequest.then(successCallback);
					that.inflightRequest.finally(function() {
						that.inflightRequest = null;
						if (that.requestImmediateUpdate) {
							that.requestImmediateUpdate = false;
							establishNextRequest(0);
						}
						else {
							establishNextRequest();
						}
					});
				}
			}
			function establishNextRequest(intervalOverride) {
				if (that.stopped)
return;
				intervalOverride = (parseFloat(intervalOverride) >= 0) ? intervalOverride : interval;
				$timeout.cancel(that.timer);
				that.timer = $timeout(runPoll, intervalOverride);
			}
			runPoll();
		},
		_stopPolling : function() {
			if (this.timer)
				$timeout.cancel(this.timer);
			this.stopped = true;
		},
		_executeRequest: function() {
			var url = this._getURL();
			if (this.preRequestCallback) {
				this.preRequestCallback();
			}
			return snResource().get(url);
		},
		_getURL: function() {
			var params = {
				table: this.table,
				action: this._getAction(),
				sysparm_silent_request: true,
				sysparm_auto_request: true,
				sysparm_timestamp: this.lastTimestamp,
				include_attachments: this.includeAttachments
			};
			if (this.sys_id) {
				params['sys_id'] = this.sys_id;
			} else if (this.sysparmQuery) {
				params['sysparm_query'] = this.sysparmQuery;
			}
			var url = urlTools.getURL(this.processor, params);
			if (!this.sys_id) {
url += "&p=" + this.query;
			}
			if (this.processor === "list_history")
				url = url.replace("angular", "list_history")
			return url;
		},
		_getInsertURL: function(table, sys_id) {
			return urlTools.getURL(this.processor, {
				action: 'insert',
				table: table,
				sys_id: sys_id,
				sysparm_timestamp: this.timestamp || 0,
				sysparm_source: this.source
			});
		},
		_successCallback: function(answer) {
			var response = answer.data;
			if (response.entries && response.entries.length) {
				response.entries = this._filterOld(response.entries);
				if (response.entries.length > 0) {
					this.lastEntry = angular.copy(response.entries[0]);
					this.lastTimestamp = response.sys_timestamp || response.entries[0].sys_timestamp;
				}
			}
			this.lastPollFailed = (response.entries && response.entries.length) == undefined;
			this.callback.call(null, response);
		},
		_filterOld: function(entries) {
			for (var i = 0; i < entries.length; i++) {
				if (entries[i].sys_timestamp === this.lastTimestamp) {
					if (this.lastEntry) {
						if (!angular.equals(this._makeComparable(entries[i]), this._makeComparable(this.lastEntry)))
							continue;
						if (entries[i].attachment)
							snCustomEvent.fire('sn.stream.attachment_state_updated', entries[i]);
					}
				}
				if (entries[i].sys_timestamp <= this.lastTimestamp)
					return entries.slice(0, i);
			}
			return entries;
		},
		_makeComparable: function(entry) {
			if (entry.attachment)
				return entry.attachment.sys_id;
			var copy = angular.copy(entry);
			delete copy.short_description;
			delete copy.display_value;
			if (copy.entries?.journal) {
				for (var i = 0; i < copy.entries.journal.length; i++) {
					var sysId = copy.entries.journal[i].sys_id;
					copy.entries.journal[i] = { sys_id: sysId };
				}
			}
			return copy;
		},
		_getAction: function() {
			return this.sys_id ? 'get_new_entries' : 'get_set_entries';
		},
		_getInterval: function() {
			if (this.interval)
				return this.interval;
			else if (window.NOW && NOW.stream_poll_interval)
				return NOW.stream_poll_interval * 1000;
			else
				return nowStreamTimerInterval;
		}
	};
	return {
		create: function(table, query, sys_id, processor, interval, source) {
			return new Stream(table, query, sys_id, processor, interval, source);
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/glide/service.nowServer.js */
angular.module('sn.common.glide').factory('nowServer', function($http, $q, userPreferences, angularProcessorUrl, urlTools) {
	return {
		getBaseURL: function () {
			return angularProcessorUrl;
		},
		getPartial: function(scope, partial, parms, callback) {
			var url = this.getPartialURL(partial, parms);
			if (url === scope.url) {
				callback.call();
				return;
			}
			var fn = scope.$on('$includeContentLoaded', function() {
fn.call();
				callback.call();
			});
			scope.url = url;
		},
		replaceView: function($location, newView) {
			var p = $location.path();
var a = p.split("/");
			a[1] = newView;
p = a.join("/");
			return p;
		},
		getPartialURL: urlTools.getPartialURL,
		getURL: urlTools.getURL,
		urlFor : urlTools.urlFor,
		getPropertyURL: urlTools.getPropertyURL,
		setPreference: userPreferences.setPreference,
		getPreference: userPreferences.getPreference
	}
});
;
;
/*! RESOURCE: /scripts/sn/common/glide/js_includes_glide.js */
/*! RESOURCE: /scripts/glide-amb-client-bundle.min.js */
!function(e){var t={};function n(i){if(t[i])return t[i].exports;var o=t[i]={i:i,l:!1,exports:{}};return e[i].call(o.exports,o,o.exports,n),o.l=!0,o.exports}n.m=e,n.c=t,n.d=function(e,t,i){n.o(e,t)||Object.defineProperty(e,t,{configurable:!1,enumerable:!0,get:i})},n.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(t,"a",t),t},n.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},n.p="",n(n.s=12)}([function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=function(e){return e&&e.__esModule?e:{default:e}}(n(1));var o=function(e){function t(t){window.console&&console.log(e+" "+t)}return{debug:function(e){"debug"===i.default.logLevel&&t("[DEBUG] "+e)},addInfoMessage:function(e){t("[INFO] "+e)},addErrorMessage:function(e){t("[ERROR] "+e)},addWarnMessage:function(e){t("[WARN] "+e)}}};t.default=o},function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=t.WEBSOCKET_TYPE_NAME=t.TOKEN_MANAGEMENT_EXTENSION=void 0;t.WEBSOCKET_TYPE_NAME="websocket";t.TOKEN_MANAGEMENT_EXTENSION="tokenManagementExtension";var i={servletPath:"amb",logLevel:"info",loginWindow:"true",wsConnectTimeout:1e4,overlayStyle:"",pruneFailedTransports:"true",subscribeCommandsFlow:{enable:!1,maxInflight:1,maxWait:1e4,retries:3,retryDelay:{min:2e3,max:3e5,increaseFactor:2}},redeliveryDisconnectTimeoutInMins:10,requestHeaderToClearStickySessionCookie:!0,batchLogging:{enabled:!1,channels:[],startTime:null}};t.default=i},function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.WS_CONNECTION_NODE_ID=t.TRANSACTION_ALREADY_SUBMITTED=t.REQUEST_SUCCESS=t.REQUEST_ACCEPTED=t.PUBLISH_FAILURE=t.NODEID_COOKIE_KEY=t.MSG_SHARD=t.MSG_NUM=t.MISSING_REQUEST_DATA=t.MISSING_INTERACTION_ID=t.META_HANDSHAKE=t.MESSAGE_REDELIVERY_OPTIONS=t.GLIDE_REMEMBER_ME=t.GLIDE_AMB_HUP_SIGNAL_RECONNECT_IN_SEC=t.GLIDE_AMB_HANDSHAKE_LIMIT_ENABLED=t.CHANNEL_READY_TO_DELIVER=t.CHANNEL_NOT_READY_TO_DELIVER=t.CANCEL_TRANSACTION_CHANNEL=t.CANCEL_TRANSACTION_ACTION=void 0;t.MSG_NUM="msg_num";t.MSG_SHARD="msg_shard";t.MESSAGE_REDELIVERY_OPTIONS="msg_redelivery_options";t.CHANNEL_READY_TO_DELIVER="Channel set to deliver messages now: ";t.CHANNEL_NOT_READY_TO_DELIVER="Channel set to not deliver messages until re-subscription & re-delivery of missed messages is over: ";t.META_HANDSHAKE="/meta/handshake";t.WS_CONNECTION_NODE_ID="glide.amb.wsConnectionNodeId";t.NODEID_COOKIE_KEY="glide_node_id_for_js";t.GLIDE_REMEMBER_ME="glide.remember.me";t.GLIDE_AMB_HUP_SIGNAL_RECONNECT_IN_SEC="glide.amb.hup.signal.reconnect.in.sec";t.GLIDE_AMB_HANDSHAKE_LIMIT_ENABLED="glide.amb.client.websocket_handshake_limit_enabled";t.CANCEL_TRANSACTION_CHANNEL="/service/transaction/cancel";t.CANCEL_TRANSACTION_ACTION="cancelTransaction";t.REQUEST_SUCCESS="200::Success";t.REQUEST_ACCEPTED="202::Request accepted";t.MISSING_REQUEST_DATA="400::Missing request data";t.MISSING_INTERACTION_ID="400::Missing nowUiInteractionId id";t.TRANSACTION_ALREADY_SUBMITTED="409::Transaction with nowUiInteraction has already been submitted for cancel";t.PUBLISH_FAILURE="503::Unable to publish message"},function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=function(e){return e&&e.__esModule?e:{default:e}}(n(0));var o=function(e,t,n){var o,r,s=new i.default("amb.ChannelListener"),a=e;return{getCallback:function(){return r},getSubscriptionCallback:function(){return n},getID:function(){return o},setNewChannel:function(e){a.unsubscribe(this),a=e,this.subscribe(r)},subscribe:function(e){return r=e,o=a.subscribe(this),this},resubscribe:function(){return this.subscribe(r)},unsubscribe:function(){return a.unsubscribe(this),s.debug("Unsubscribed from channel: "+a.getName()),this},publish:function(e,t){a.publish(e,t)},publishAsync:function(e,t){a.publishAsync(e,t)},getName:function(){return a.getName()}}};t.default=o},function(e,t,n){"use strict";function i(e){"@babel/helpers - typeof";return(i="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e})(e)}Object.defineProperty(t,"__esModule",{value:!0}),t.isUndefined=t.isObject=t.isNull=t.isNil=t.isEmptyObject=void 0;var o=function(e){return void 0===e};t.isUndefined=o;var r=function(e){return null===e};t.isNull=r;t.isNil=function(e){return r(e)||o(e)};var s=function(e){return null!=e&&"object"===i(e)};t.isObject=s;t.isEmptyObject=function(e){return s(e)&&0===Object.keys(e).length}},function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=function(e){var t=[],n=0;return{subscribe:function(e,i){var o=n++;return t.push({event:e,callback:i,id:o}),o},unsubscribe:function(e){for(var n=0;n<t.length;n++)e===t[n].id&&t.splice(n,1)},publish:function(e,t){for(var n=this._getSubscriptions(e),i=0;i<n.length;i++)n[i].callback.apply(null,t)},getEvents:function(){return e},_getSubscriptions:function(e){for(var n=[],i=0;i<t.length;i++)t[i].event===e&&n.push(t[i]);return n}}};t.default=i},function(e,t,n){"use strict";function i(e){"@babel/helpers - typeof";return(i="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e})(e)}Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var o=p(n(5)),r=p(n(0)),s=function(e,t){if(!t&&e&&e.__esModule)return e;if(null===e||"object"!==i(e)&&"function"!=typeof e)return{default:e};var n=b(t);if(n&&n.has(e))return n.get(e);var o={},r=Object.defineProperty&&Object.getOwnPropertyDescriptor;for(var s in e)if("default"!==s&&Object.prototype.hasOwnProperty.call(e,s)){var a=r?Object.getOwnPropertyDescriptor(e,s):null;a&&(a.get||a.set)?Object.defineProperty(o,s,a):o[s]=e[s]}o.default=e,n&&n.set(e,o);return o}(n(1)),a=p(n(7)),u=p(n(8)),c=p(n(24)),l=n(4),d=p(n(25)),f=p(n(26)),g=p(n(27)),h=n(2);function b(e){if("function"!=typeof WeakMap)return null;var t=new WeakMap,n=new WeakMap;return(b=function(e){return e?n:t})(e)}function p(e){return e&&e.__esModule?e:{default:e}}var m=function(e,t){var n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:new c.default,i=!1,b=!1,p=null,m=new o.default({CONNECTION_INITIALIZED:"connection.initialized",CONNECTION_OPENED:"connection.opened",CONNECTION_CLOSED:"connection.closed",CONNECTION_BROKEN:"connection.broken",SESSION_LOGGED_IN:"session.logged.in",SESSION_LOGGED_OUT:"session.logged.out",SESSION_INVALIDATED:"session.invalidated",SESSION_REESTABLISHED:"session.reestablished"}),v={SESSION_LOGGED_IN:"session.logged.in",SESSION_LOGGED_OUT:"session.logged.out",SESSION_INVALIDATED:"session.invalidated"},_="closed",y={},T={},C=new r.default("amb.ServerConnection");!function(){e.addListener("/meta/handshake",this,te),e.addListener("/meta/connect",this,ge),e.addListener("/meta/subscribe",this,ce),e.addListener("/meta/unsubscribe",this,re)}();var S=v.SESSION_INVALIDATED,E=null,w="true"===s.default.loginWindow,N=null,I={UNKNOWN_CLIENT:"402::Unknown client",UNKNOWN_SESSION:"402::session_unknown",NODE_MISMATCH:"websocket_http_node_mismatch",RECONNECT_REMEMBER_ME:"reconnect_remember_me_http_activity",HUP_SIGNAL:"reconnect_on_hup_signal"},O=!1,x={},M=!1,k=new a.default(e,x),A=!1,L="glide.amb.session.logout.overlay.style",R="glide.amb.redelivery.disconnect.timeout.in.mins",D="glide.amb.clear_node_affinity_cookie",B="glide.session.status",U="session.touch.http",P="amb.ServerConnection.reestablish.session",G="set.header.request.sent",F="request.reconnection",j=e.getExtension(s.TOKEN_MANAGEMENT_EXTENSION),q=null,H=new g.default(e),W=null,z=!0,V=null,Q=null,Y=null,K=null,X=null,J=t,$=[],Z=3e5,ee=3;function te(t){!function(t){if(he()){var n=new Date;$.push(n);for(var i=n-Z;$.length>0&&$[0]<i;)$.shift();var o=ne(t,h.GLIDE_AMB_HANDSHAKE_LIMIT_ENABLED);o&&$.length>=ee&&(C.addInfoMessage("Transport type will switch to long-polling in next connection error"),e.websocketEnabled=!1)}}(t),re(t),void 0!==ne(t,h.WS_CONNECTION_NODE_ID)&&(p=ne(t,h.WS_CONNECTION_NODE_ID),C.debug("Node Id from handshake callback initially set to "+p));var n=ne(t,L);n&&(s.default.overlayStyle=n);var i=ne(t,R);i&&(s.default.redeliveryDisconnectTimeoutInMins=i),void 0!==ne(t,D)&&(s.default.requestHeaderToClearStickySessionCookie=!0===ne(t,D)),S=ne(t,B),function(e){if(e.ext){var t=e.ext.subscribeCommandsFlow;if(t){var n=s.default.subscribeCommandsFlow;if(s.default.subscribeCommandsFlow.enable=function(e,t){var n=t;return(0,l.isNil)(e)||(n=!!e),n}(t.enable,n.enable),s.default.subscribeCommandsFlow.enable){s.default.subscribeCommandsFlow.retries=le(t.retries,n.retries),s.default.subscribeCommandsFlow.maxInflight=le(t.maxInflight,n.maxInflight),s.default.subscribeCommandsFlow.maxWait=le(t.maxWait,n.maxWait);var i=t.retryDelay;if(i){var o=s.default.subscribeCommandsFlow.retryDelay;s.default.subscribeCommandsFlow.retryDelay.min=le(i.min,o.min),s.default.subscribeCommandsFlow.retryDelay.max=le(i.max,o.max),s.default.subscribeCommandsFlow.retryDelay.increaseFactor=le(i.increaseFactor,o.increaseFactor)}}!function(){if(s.default.subscribeCommandsFlow.enable){C.addInfoMessage("_initializeSubscriptionCommandSender: SubscriptionCommandSender is enabled"),null!=j&&j.updateTokenCount(s.default.subscribeCommandsFlow.maxInflight),q&&q.stop();var e=window.location.protocol+"//"+window.location.host;q=new f.default(new d.default(1e4),j,J!==e)}}()}}}(t),setTimeout(function(){t.successful&&be()},0)}function ne(e,t){if((0,l.isObject)(e.ext))return e.ext[t]}function ie(t,n){if(t in y)return y[t];var i=new u.default(e,t,A,n);return y[t]=i,i}function oe(e){T[e]=y[e],delete y[e]}function re(t){if(t.ext){!1===t.ext["glide.amb.active"]&&x.disconnect();var n=ne(t,"glide.amb.client.log.level");n&&(s.default.logLevel=n,e.setLogLevel(s.default.logLevel)),s.default.pruneFailedTransports="false"!==ne(t,"glide.amb.pruneFailedTransports");var i=ne(t,"glide.amb.client.batch.logging.enabled");void 0!==i&&(s.default.batchLogging.enabled=!1!==i);var o=ne(t,"glide.amb.client.batch.logging.startTime");void 0!==o&&(s.default.batchLogging.startTime=o||null);var r=ne(t,"glide.amb.client.batch.logging.channels");void 0!==r&&(s.default.batchLogging.channels=r?r.split(",").map(function(e){return e.trim()}):[])}}function se(){null!==ae()&&(clearInterval(Q),Q=null,V=null,M=!0,N=I.RECONNECT_REMEMBER_ME,x.connect())}function ae(){if(void 0!==document.cookie)for(var e=document.cookie.split(";"),t=0;t<e.length;t++){var n=e[t].trim();if(n.startsWith("".concat(h.NODEID_COOKIE_KEY,"=")))return n.substring(h.NODEID_COOKIE_KEY.length+1)}return null}function ue(t){p=null,b=!0,e.disconnect(function(){C.addInfoMessage("Disconnected WS Connection. Connecting back"),N=t,i=!1,_e(),Y=null,M=!0,b=!1,x.connect()})}function ce(e){re(e)}function le(e,t){var n=Math.floor(parseInt(e));return(isNaN(n)||n<0)&&(n=t),n}function de(){for(var e in C.debug("Resubscribing to all!"),y){var t=y[e];t&&t.resubscribeToCometD()}}function fe(){for(var e in C.debug("Unsubscribing from all!"),y){var t=y[e];t&&t.unsubscribeFromCometD()}}function ge(e){if(re(e),ne(e,h.GLIDE_REMEMBER_ME)&&(V=ne(e,h.GLIDE_REMEMBER_ME)),ne(e,h.GLIDE_AMB_HUP_SIGNAL_RECONNECT_IN_SEC)&&function(e){Y||(Y=setTimeout(function(){C.addInfoMessage("Reconnecting after "+e+"sec as the server received an HUP signal from load balancer"),ue(I.HUP_SIGNAL)},1e3*e))}(ne(e,h.GLIDE_AMB_HUP_SIGNAL_RECONNECT_IN_SEC)),b)setTimeout(function(){i=!1,_e()},0);else{i&&!Te(ne(e,B))&&function(){if(null!==p){var e=ae();null!==e&&p!==e&&setTimeout(function(){null!==(e=ae())&&p!==e&&(C.addInfoMessage("WS Connection is with "+p+" whereas httpsession is with "+e+". Disconnecting WS connection"),ue(I.NODE_MISMATCH))},2e4)}}();var t=ne(e,U);he()&&!0===t&&x._touchHttpSession();var n=e.error;n&&(N=n),function(e){var t=ne(e,B);t&&t!==S&&(O=!0===ne(e,"glide.amb.login.window.override"),ye(t))}(e);var o=i;i=!0===e.successful,!o&&i?pe():o&&!i&&function(){C.addErrorMessage("Connection broken"),_="broken",M=!0,Ee(m.getEvents().CONNECTION_BROKEN),W=Date.now(),function(){q&&(q.stop(),q=null)}()}(),K=new Date}}function he(){return s.WEBSOCKET_TYPE_NAME===e.getTransport().getType()}function be(){C.debug("Connection initialized"),A=!0,_="initialized",Ee(m.getEvents().CONNECTION_INITIALIZED)}function pe(){C.debug("Connection opened"),H.processConnectionOpened(),M?function(){!function(e){return Object.values(I).includes(e)}(x.getLastError())?C.addWarnMessage("Error connecting to server. Unkown status "+x.getLastError()):(x.setLastError(null),x._sendSessionSetupRequest(function(e){var t=e.status,n=e.response;if(200===t){M=!1;var i=JSON.parse(n)["glide.session.status"];C.debug("/amb_session_setup.do response: "+n),i&&S!==i?(k.initialize(ve),ye(i)):k.initialize(function(){me(!1)})}else C.addWarnMessage("/amb_session_setup.do status: "+t)}))}():k.initialize(function(){me(!0)})}function me(e){C.debug("Resubscribing to all, except channel_redirect");var t=k.getName();for(var i in y)if(i!==t){var o=y[i];o&&o.resubscribeToCometD()}ve(),e&&function(){C.debug("Sending signal to reconnect"),n.emit(F,F)}()}function ve(){_="opened",Ee(m.getEvents().CONNECTION_OPENED)}function _e(){C.debug("Connection closed"),_="closed",Ee(m.getEvents().CONNECTION_CLOSED)}function ye(e){C.debug("session.status - "+e),Te(e)?function(){C.debug("INVALIDATED event fire!"),fe(),Ee(m.getEvents().SESSION_INVALIDATED),function(){return s.default.requestHeaderToClearStickySessionCookie}()&&(void 0!==navigator.locks?navigator.locks.request("lock-set_clear_node_affinity_header",Se):(C.debug("navigator.locks.request not supported"),Se())),Ce()||x.disconnect(function(){x.loginHide(),i=!1,_e(),b=!1,V&&function(e){return void 0!==document.cookie&&(document.cookie=e+"=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/",!0)}(h.NODEID_COOKIE_KEY)&&(Q=setInterval(se,5e3))})}():function(e){return S===v.SESSION_LOGGED_IN&&e===v.SESSION_LOGGED_OUT}(e)?function(){C.debug("LOGGED_OUT event fire!"),fe(),Ee(m.getEvents().SESSION_LOGGED_OUT),w&&!O&&x.loginShow(),Ce()}():function(e){return S===v.SESSION_INVALIDATED&&e===v.SESSION_LOGGED_OUT}(e)?function(){C.debug("REESTABLISHED event fire!"),de(),Ee(m.getEvents().SESSION_REESTABLISHED)}():function(e){return(S===v.SESSION_INVALIDATED||S===v.SESSION_LOGGED_OUT)&&e===v.SESSION_LOGGED_IN}(e)&&function(){C.debug("LOGGED_IN event fire!"),de(),Ee(m.getEvents().SESSION_LOGGED_IN),x.loginHide(),z=!0}(),S=e}function Te(e){return(S===v.SESSION_LOGGED_IN||S===v.SESSION_LOGGED_OUT)&&e===v.SESSION_INVALIDATED}function Ce(){return!!(K&&X&&X>K)&&(C.debug("Either the session is logged out/invalidated from a different tab. Calling reestablishSession as lastReconnectionEventTime "+X+" happened after lastMetaConnectResponseTime "+K),we(!1),!0)}function Se(){z?(C.debug("Sending set_clear_node_affinity_header"),function(){n.emit(G,G)}(),x._sendSetHeaderToClearNodeAffinityCookie(function(e){var t=e.status;200!==t?C.addErrorMessage("Error sending set_clear_node_affinity_header: "+t):z=!1})):C.debug("set_clear_node_affinity_header not sent")}function Ee(e){try{m.publish(e)}catch(t){C.addErrorMessage("error publishing '"+e+"' - "+t)}}function we(e){x._sendSessionSetupRequest(function(e){var t=e.response;t&&ye(JSON.parse(t)["glide.session.status"])}),e&&function(){n.emit(P,P)}()}return x.connect=function(){i?C.debug(">>> connection exists, request satisfied"):(C.debug("Connecting to glide amb server -> "+s.default.servletURI),e.configure({url:x.getURL(s.default.servletPath),logLevel:s.default.logLevel,connectTimeout:s.default.wsConnectTimeout}),e.handshake(),n.on(P,function(){x._reestablishSession(!1)}),n.on(G,function(){z=!1}),n.on(F,function(){C.debug("Received signal to reconnect"),function(){i?S===v.SESSION_LOGGED_OUT?we(!1):S===v.SESSION_LOGGED_IN&&(X=new Date):x.connect()}()}))},x.reload=function(){e.reload()},x.abort=function(){e.getTransport().abort()},x.disconnect=function(t){C.debug("Disconnecting from glide amb server.."),b=!0,e.disconnect(t)},x.getURL=function(e){return J+"/"+e},x.getConnectionBrokenTS=function(){return W},x.unsubscribeAll=function(){fe()},x.resubscribeAll=function(){de()},x.removeChannel=function(e){oe(e)},x.getEvents=function(){return m.getEvents()},x.getConnectionState=function(){return _},x.getLastError=function(){return N},x.setLastError=function(e){N=e},x.getErrorMessages=function(){return I},x.isLoggedIn=function(){return S===v.SESSION_LOGGED_IN},x.isSessionActive=function(){return S!==v.SESSION_INVALIDATED},x.getChannelRedirect=function(){return k},x.getChannel=function(e,t){return ie(e,t)},x.getChannels=function(){return y},x.getRemovedChannels=function(){return T},x.getState=function(){return _},x.getLoginWindowOverlayStyle=function(){return s.default.overlayStyle},x.loginShow=function(){C.debug("Show login window");var e='<iframe src="/amb_login.do" style="border: 0" height="400px" width="405px"></iframe>',t='<div id="amb_disconnect_modal" tabindex="-1" aria-hidden="true" class="modal" role="dialog" style="'.concat(s.default.overlayStyle,'">\n\t\t\t\t<div class="modal-dialog small-modal" style="width:450px">\n\t\t\t\t   <div class="modal-content">\n\t\t\t\t\t  <header class="modal-header">\n\t\t\t\t\t\t <h4 id="small_modal1_title" class="modal-title">Login</h4>\n\t\t\t\t\t  </header>\n\t\t\t\t\t  <div class="modal-body">\n\t\t\t\t\t  </div>\n\t\t\t\t   </div>\n\t\t\t\t</div>\n\t\t\t</div>');try{if(window.NOW&&!0===window.NOW.amb_themed_login){var n=new GlideModal("amb_login_router");n.renderWithContent&&(n.template=t),n.render(),E=n}else{var i=new GlideModal("amb_disconnect_modal");i.renderWithContent?(i.template=t,i.renderWithContent(e)):(i.setBody(e),i.render()),E=i}}catch(e){C.debug(e)}},x.loginHide=function(){E&&(E.destroy(),E=null)},x.loginComplete=function(){x.reestablishSession()},x.reestablishSession=function(){x._reestablishSession(!0)},x.subscribeToEvent=function(e,t){return m.getEvents().CONNECTION_OPENED===e&&i&&t(),m.subscribe(e,t)},x.unsubscribeFromEvent=function(e){m.unsubscribe(e)},x.isLoginWindowEnabled=function(){return w},x.setLoginWindowEnabled=function(e){w=e},x.isLoginWindowOverride=function(){return O},x.getSubscriptionCommandSender=function(){return q},x._metaConnect=ge,x._metaHandshake=te,x._metaSubscribe=ce,x._sendSessionSetupRequest=function(){var t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:function(){},n=function(){C.debug("sending /amb_session_setup.do!");var t=new XMLHttpRequest;return t.withCredentials=!0,t.open("POST",x.getURL("amb_session_setup.do"),!0),t.setRequestHeader("Content-type","application/json;charset=UTF-8"),t.setRequestHeader("X-UserToken",window.g_ck),t.setRequestHeader("X-CometD-SessionID",e.getClientId()),t}();n.onload=function(){return t(n)},n.send()},x._onChannelRedirectSubscriptionComplete=me,x._getChannel=ie,x._removeChannel=oe,x._connectionInitialized=be,x._connectionOpened=pe,x._reestablishSession=we,x._touchHttpSession=function(){var e=new XMLHttpRequest;e.withCredentials=!0,e.open("POST",x.getURL("amb"),!0),e.setRequestHeader("Content-type","application/json"),e.send()},x._sendSetHeaderToClearNodeAffinityCookie=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:function(){},t=function(){var e=new XMLHttpRequest;return e.open("POST",x.getURL("set_clear_node_affinity_header"),!0),e}();t.onload=function(){return e(t)},t.send()},x};t.default=m},function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=r(n(0)),o=r(n(3));function r(e){return e&&e.__esModule?e:{default:e}}var s=function(e,t){var n,r=e,s=new i.default("amb.ChannelRedirect");function a(e){s.debug("_onAdvice:"+e.data.clientId);var n=t.getChannels(),i=null!=n?n[e.data.fromChannel]:null;if(!i){var o=t.getRemovedChannels();i=null!=o?o[e.data.fromChannel]:null}var r=t.getChannel(e.data.toChannel);i&&r?(function(e,t){for(var n=e.getChannelListeners(),i=0;i<n.length;i++)n[i].setNewChannel(t)}(i,r),s.debug("published channel switch event, fromChannel:"+i.getName()+", toChannel:"+r.getName())):s.debug("Could not redirect from "+e.data.fromChannel+" to "+e.data.toChannel)}return{initialize:function(e){var i="/sn/meta/channel_redirect/"+r.getClientId(),u=t.getChannel(i);n&&u===n?n.resubscribeToCometD():(n&&t.removeChannel(n.getName()),n=u,new o.default(n,t,e).subscribe(a)),s.debug("ChannelRedirect initialized: "+i)},_onAdvice:a,getName:function(){return n?n.getName():null}}};t.default=s},function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=c(n(0)),o=n(4),r=c(n(9)),s=c(n(23)),a=c(n(1)),u=n(2);function c(e){return e&&e.__esModule?e:{default:e}}var l=function(e,t,n){var c=arguments.length>3&&void 0!==arguments[3]?arguments[3]:function(){return{}},l=null,d=null,f=[],g=[],h=new i.default("amb.Channel"),b=0,p=n,m=-1,v=null,_="maxSendBayeuxMessageSize "+e.getConfiguration().maxSendBayeuxMessageSize+" exceeded",y=!0,T=new s.default;function C(){return(0,r.default)().getServerConnection().getSubscriptionCommandSender()}function S(e){(0,r.default)().addToBatch(e)}return{subscribe:function(e){if(e.getCallback()){for(var n=0;n<f.length;n++)if(f[n]===e)return h.debug("Channel listener already in the list"),e.getID();f.push(e),h.debug("[AMB Client] Channel ".concat(t," now has ").concat(f.length," listener(s) registered"));var i=e.getSubscriptionCallback();if(i&&(d?i(d):g.push(i)),!l&&p)try{this.subscribeToCometD()}catch(e){return void h.addErrorMessage(e)}return++b}h.addErrorMessage("Cannot subscribe to channel: "+t+", callback not provided")},resubscribe:function(){l=null;for(var e=0;e<f.length;e++)f[e].resubscribe()},_handleResponse:function(e){y?this.processMessageCallback(e):this.processReSubscriptionMessages(e)},processReSubscriptionMessages:function(e){var n=this;T.shouldDeliver(e)?(h.debug(u.CHANNEL_READY_TO_DELIVER+t),y=!0,this.processMessageCallback(e)):T.shouldDeliverPendingMessages()&&T.getAllPendingMessages().forEach(function(e){return n.processMessageCallback(e)})},processMessageCallback:function(e){h.debug("[AMB Client] processMessageCallback called - listeners: ".concat(f.length,", batchLogging.enabled: ").concat(a.default.batchLogging.enabled));for(var t=0;t<f.length;t++){var n=f[t].getID(),i=Date.now();h.debug("[AMB Client] Message delivered to listener "+n+" of channel name "+f[t].getName()+" at "+i);try{f[t].getCallback()(e);var o=Date.now();h.debug("[AMB Client] Listener "+n+" of channel name "+f[t].getName()+" callback completed at "+o+" (duration: "+(o-i)+"ms)"),S({channelName:f[t].getName(),duration:o-i,error:null})}catch(e){var r=Date.now();h.addErrorMessage("[AMB Client] Listener "+n+" of channel name "+f[t].getName()+" callback failed at "+r+" (duration: "+(r-i)+"ms): "+e),S({channelName:f[t].getName(),duration:r-i,error:e.length>100?e.substring(0,100)+"...":e})}}T.containsMetaInfo(e)&&(m=e.ext[u.MSG_NUM],v=e.ext[u.MSG_SHARD])},unsubscribe:function(n){if(n){for(var i=0;i<f.length;i++)if(f[i].getID()===n.getID()){f.splice(i,1);break}h.debug("[AMB Client] Channel ".concat(t," now has ").concat(f.length," listener(s) registered after unsubscribe")),(0,r.default)().getBatchSize()>0&&(h.debug("[AMB Client] Flushing batch on listener unsubscribe for ".concat(t," - ").concat((0,r.default)().getBatchSize()," pending entries")),(0,r.default)().flushBatch()),f.length<1&&l&&!function(){var t=e.getStatus();return"disconnecting"===t||"disconnected"===t}()&&this.unsubscribeFromCometD()}else h.addErrorMessage("Cannot unsubscribe from channel: "+t+", listener argument does not exist")},publish:function(n,i){e.publish(t,n,function(e){i&&i(e),void 0!==e.failure&&e.failure.exception===_&&h.addErrorMessage(_+" - use publishAsync() to send large messages via REST automatically")})},publishAsync:function(n,i){var o=this;e.publish(t,n,function(e){if(i&&i(e),h.debug("CometD publish response "+JSON.stringify(e)),void 0!==e.failure){var t=e.failure.exception,n=e.failure.message;t===_&&JSON.stringify(n).length<=1048576&&(h.debug("Message size exceeded, publish message via REST"),o._publishViaRest(n,i))}})},_publishViaRest:function(e,n){var i=new XMLHttpRequest;i.withCredentials=!0,i.open("POST",(0,r.default)().getServerConnection().getURL("api/now/amb/publish/"+t.split("/")[1]),!0),i.setRequestHeader("Content-type","application/json;charset=UTF-8"),i.setRequestHeader("X-UserToken",window.g_ck),i.onload=function(){200===i.status?h.debug("Message publish request sent successfully via REST"):h.addErrorMessage("Error sending message publish request via REST - "+i.responseText),n&&n(i.response)},i.send(JSON.stringify(e))},subscribeToCometD:function(){h.debug("subscribeToCometD channelName : "+t+", subscription : "+l),C()?C().subscribeToChannel(this):this._subscribeToCometD(this.subscriptionCallback)},_subscribeToCometD:function(n){h.debug("_subscribeToCometD channelName : "+t);var i=this._populateSubscriptionOptions();if((0,o.isNil)(i)||(0,o.isEmptyObject)(i))l=e.subscribe(t,this._handleResponse.bind(this),n);else{var r={subscribeOptions:i};l=e.subscribe(t,this._handleResponse.bind(this),r,n)}h.debug("Successfully subscribed to channel: "+t+", subscribeOptions: "+JSON.stringify(i))},_populateSubscriptionOptions:function(){var e=c(),n=Date.now()-this.fetchDisconnectionTS();return this._shouldRedeliveryBeRequested(n)&&((0,o.isNil)(e)&&(e={}),e[u.MESSAGE_REDELIVERY_OPTIONS]={},e[u.MESSAGE_REDELIVERY_OPTIONS].last_msg_num=m,e[u.MESSAGE_REDELIVERY_OPTIONS].last_msg_shard=v,e[u.MESSAGE_REDELIVERY_OPTIONS].request_duration=n,h.debug(u.CHANNEL_NOT_READY_TO_DELIVER+t),y=!1,T.resetState()),e},_shouldRedeliveryBeRequested:function(e){return e<=6e4*a.default.redeliveryDisconnectTimeoutInMins&&-1!=m&&!(0,o.isNil)(v)},subscriptionCallback:function(e){h.debug("Cometd subscription callback completed for channel: "+t),h.debug("Listener callback queue size: "+g.length),d=e,g.map(function(e){e(d)}),g=[]},unsubscribeFromCometD:function(){h.debug("unsubscribeFromCometD  from : "+t+", subscription : "+l),null!==l&&(C()?C().unsubscribeToChannel(this):this._unsubscribeFromCometD())},_unsubscribeFromCometD:function(){h.debug("_unsubscribeFromCometD  from : "+t+", subscription : "+l),null!==l&&(e.unsubscribe(l),l=null,d=null,h.debug("Successfully unsubscribed from channel: "+t))},resubscribeToCometD:function(){h.debug("Resubscribe to "+t),null!==l&&e.removeListener(l),C()?C().subscribeToChannel(this):this._subscribeToCometD(this.subscriptionCallback)},getSubscribeOptionsCallback:function(){return c},getName:function(){return t},getChannelListeners:function(){return f},getLastMessageShard:function(){return v},getLastMessageNumber:function(){return m},fetchDisconnectionTS:function(){var e=(0,r.default)().getServerConnection().getConnectionBrokenTS();return h.debug("Client Disconnect Time in ms:"+e),e||0},getRedeliveryManager:function(){return T},isReadyToDeliver:function(){return y},getListenerCallbackQueue:function(){return g},setSubscriptionCallbackResponse:function(e){d=e}}};t.default=l},function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=s(n(10)),o=s(n(19)),r=s(n(22));function s(e){return e&&e.__esModule?e:{default:e}}var a=new(s(n(0)).default)("amb.MessageClientBuilder");function u(e){return e.MSInputMethodContext&&e.document.documentMode}function c(e,t){if(void 0!==e.getClientWindow&&e.getClientWindow()===t)return e;var n=function(e,t){for(var n in t)Object.prototype.hasOwnProperty.call(t,n)&&(e[n]=t[n]);return e}({},e);return n.getChannel=function(n,i,o){return e.getChannel(n,i,o||t)},n.getRecordWatcherChannel=function(n,i,o,r,s){return e.getRecordWatcherChannel(n,i,o,r,s||t)},n.subscribeToEvent=function(n,i,o){return e.subscribeToEvent(n,i,o||t)},n.unsubscribeFromEvent=function(n,i){return e.unsubscribeFromEvent(n,i||t)},n.getClientWindow=function(){return t},n}var l=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:null,t=function(e){try{if(!u(e))for(;e!==e.parent&&!e.g_ambClient;)e=e.parent;if(e.g_ambClient)return e.g_ambClient}catch(e){console.log("AMB getClient() tried to access parent from an iFrame. Caught error: "+e)}return null}(window);if(t){if(e&&e!==t.getBaseURL())throw a.addErrorMessage("Client already set up to connect to "+t.getBaseURL()),new Error("Client already set up to connect to "+t.getBaseURL())}else{var n=u(window)&&null!==window.frameElement;e||(e=window.location.protocol+"//"+window.location.host),function(e){var t=window.self;t.g_ambClient=e,t.addEventListener("unload",function(){t.g_ambClient.disconnect()});var n=!(!t.NOW||!t.NOW.hasOwnProperty("deferAmbConnection"))&&t.NOW.deferAmbConnection,i=t.NOW&&t.NOW.hasOwnProperty("deferredAmbConnectionTimeout")&&function(e){return function(e){return parseInt(e,10)===e}(e)&&e>0}(t.NOW.deferredAmbConnectionTimeout)?t.NOW.deferredAmbConnectionTimeout:1e4;if(n)t.setTimeout(s,i);else{var o=t.document?t.document.readyState:null;"complete"===o?s():t.addEventListener("load",s),t.setTimeout(s,1e4)}var r=!1;function s(){r||(r=!0,t.g_ambClient.connect())}}(t=c(function(e,t){return function(){var n=new i.default(t),s=function(){var e=[];function t(e,t,i){if(e&&i){var o=n(e);if(o)for(var r=o.subscriptions,s=r.length-1;s>=0;s--)r[s].id===t&&r[s].callback===i&&r.splice(s,1)}}function n(t){for(var n=0,i=e.length;n<i;n++)if(e[n].window===t)return e[n];return null}function i(t){var n={window:t,onUnload:function(){n.unloading=!0;for(var t,i=n.subscriptions;t=i.pop();)t.unsubscribe();!function(t){for(var n=0,i=e.length;n<i;n++)if(e[n].window===t.window){e.splice(n,1);break}t.subscriptions=[],t.window.removeEventListener("unload",t.onUnload),t.onUnload=null,t.window=null}(n)},unloading:!1,subscriptions:[]};return t.addEventListener("unload",n.onUnload),e.push(n),n}return{add:function(e,o,r,s){if(e&&r&&s){t(e,o,r);var a=n(e);a||(a=i(e)),a.unloading||a.subscriptions.push({id:o,callback:r,unsubscribe:s})}},remove:t}}(),a=n.getServerConnection();return e&&a.setLoginWindowEnabled(!1),{getServerConnection:function(){return a},connect:function(){n.connect()},abort:function(){n.abort()},disconnect:function(){n.disconnect()},getConnectionState:function(){return n.getConnectionState()},getState:function(){return n.getConnectionState()},cancelTransaction:function(e){n.cancelTransaction(e)},getClientId:function(){return n.getClientId()},getChannel:function(e,t,i){var o=n.getChannel(e,t),r=o.subscribe,u=o.unsubscribe;return i=i||window,o.subscribe=function(e){return s.add(i,o,e,function(){o.unsubscribe(e)}),r.call(o,e),o},o.unsubscribe=function(t){s.remove(i,o,t);var r=u.call(o,t);return 0===a.getChannel(e).getChannelListeners().length&&n.removeChannel(e),r},o},getChannel0:function(e,t){return n.getChannel(e,t)},getRecordWatcherChannel:function(e,t,n,i,s){var a=o.default.stringify(r.default.parse(t)).replace(/=/g,"-");return n=n||"default",this.getChannel("/rw/"+n+"/"+e+"/"+a,i,s)},registerExtension:function(e,t){n.registerExtension(e,t)},unregisterExtension:function(e){n.unregisterExtension(e)},batch:function(e){n.batch(e)},subscribeToEvent:function(e,t,i){i=i||window;var o=n.subscribeToEvent(e,t);return s.add(i,o,!0,function(){n.unsubscribeFromEvent(o)}),o},unsubscribeFromEvent:function(e,t){t=t||window,s.remove(t,e,!0),n.unsubscribeFromEvent(e)},isLoggedIn:function(){return n.isLoggedIn()},getConnectionEvents:function(){return n.getConnectionEvents()},getEvents:function(){return n.getConnectionEvents()},reestablishSession:function(){n.reestablishSession()},loginComplete:function(){n.loginComplete()},getChannels:function(){return n.getChannels()},extendSession:function(){return n.extendSession()},getTokenManagementExtension:function(){return n.getTokenManagementExtension()},getBaseURL:function(){return t},addToBatch:function(e){return n.addToBatch(e)},flushBatch:function(){return n.flushBatch()},getBatchSize:function(){return n.getBatchSize()},addAllowedChannels:function(e){return n.addAllowedChannels(e)},setBatchLoggingStartTime:function(e){return n.setBatchLoggingStartTime(e)},setBatchLogEnabled:function(e){return n.setBatchLogEnabled(e)}}}()}(n,e),window))}return c(t,window)};t.default=l},function(e,t,n){"use strict";function i(e){"@babel/helpers - typeof";return(i="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e})(e)}Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var o=h(n(14)),r=h(n(6)),s=h(n(0)),a=h(n(3)),u=h(n(15)),c=function(e,t){if(!t&&e&&e.__esModule)return e;if(null===e||"object"!==i(e)&&"function"!=typeof e)return{default:e};var n=g(t);if(n&&n.has(e))return n.get(e);var o={},r=Object.defineProperty&&Object.getOwnPropertyDescriptor;for(var s in e)if("default"!==s&&Object.prototype.hasOwnProperty.call(e,s)){var a=r?Object.getOwnPropertyDescriptor(e,s):null;a&&(a.get||a.set)?Object.defineProperty(o,s,a):o[s]=e[s]}o.default=e,n&&n.set(e,o);return o}(n(1)),l=h(n(16)),d=h(n(17)),f=h(n(18));function g(e){if("function"!=typeof WeakMap)return null;var t=new WeakMap,n=new WeakMap;return(g=function(e){return e?n:t})(e)}function h(e){return e&&e.__esModule?e:{default:e}}function b(e){return function(e){if(Array.isArray(e))return p(e)}(e)||function(e){if("undefined"!=typeof Symbol&&null!=e[Symbol.iterator]||null!=e["@@iterator"])return Array.from(e)}(e)||function(e,t){if(!e)return;if("string"==typeof e)return p(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);"Object"===n&&e.constructor&&(n=e.constructor.name);if("Map"===n||"Set"===n)return Array.from(e);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return p(e,t)}(e)||function(){throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function p(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,i=new Array(t);n<t;n++)i[n]=e[n];return i}var m=function(e){var t=new o.default.CometD;t.registerTransport(c.WEBSOCKET_TYPE_NAME,new o.default.WebSocketTransport,0),t.registerTransport("long-polling",new o.default.LongPollingTransport,1),t.unregisterTransport("callback-polling");var n=[],i=5,g="api/now/amb/log/",h=[],p=new u.default;t.registerExtension("graphQLSubscription",p);var m=new l.default;t.registerExtension("sessionExtension",m);var v=new d.default;t.registerExtension(c.TOKEN_MANAGEMENT_EXTENSION,v);var _=e,y=new r.default(t,_),T=new s.default("amb.MessageClient"),C=new f.default,S=!1;function E(){if(0!==n.length){if(!c.default.batchLogging.enabled)return T.debug("[AMB Client] Batch logging disabled - clearing ".concat(n.length," pending entries")),void(n.length=0);var e=[].concat(n);n.length=0;try{var i=new Map;i.set("clientId",t.getClientId()),i.set("data",e.map(function(e){return{channelName:e.channelName,duration:e.duration,error:e.error||null}})),function(e){var t=new XMLHttpRequest;t.withCredentials=!0,t.open("POST",y.getURL(g+"client"),!0),t.setRequestHeader("Content-type","application/json;charset=UTF-8"),t.setRequestHeader("X-UserToken",window.g_ck),t.onload=function(){200===t.status?T.debug("Global batch logging request sent successfully via REST"):T.addErrorMessage("Error sending global batch logging request via REST - "+t.responseText)};var n=Object.fromEntries(e);t.send(JSON.stringify(n))}(i)}catch(e){T.addErrorMessage("[AMB Client] Error processing global batch: ".concat(e))}}}return{getServerConnection:function(){return y},isLoggedIn:function(){return y.isLoggedIn()},loginComplete:function(){y.loginComplete()},reestablishSession:function(){y.reestablishSession()},connect:function(){S?T.addInfoMessage(">>> connection exists, request satisfied"):(S=!0,y.connect())},reload:function(){S=!1,y.reload()},abort:function(){S=!1,y.abort()},disconnect:function(){S=!1,y.disconnect()},isConnected:function(){return S},getConnectionEvents:function(){return y.getEvents()},subscribeToEvent:function(e,t){return y.subscribeToEvent(e,t)},unsubscribeFromEvent:function(e){y.unsubscribeFromEvent(e)},getConnectionState:function(){return y.getConnectionState()},getClientId:function(){return t.getClientId()},getChannel:function(e,t){var n=t||{},i=n.subscriptionCallback,o=n.serializedGraphQLSubscription,r=n.subscribeOptionsCallback,s=y.getChannel(e,r);return p.isGraphQLChannel(e)&&(o?p.addGraphQLChannel(e,o):T.addErrorMessage("Serialized subscription not present for GraphQL channel "+e)),new a.default(s,y,i)},removeChannel:function(e){y.removeChannel(e),p.isGraphQLChannel(e)&&p.removeGraphQLChannel(e)},getChannels:function(){return y.getChannels()},cancelTransaction:function(e){C.cancelTransaction(e,this)},extendSession:function(){m.extendSession()},getTokenManagementExtension:function(){return v},registerExtension:function(e,n){t.registerExtension(e,n)},unregisterExtension:function(e){t.unregisterExtension(e)},batch:function(e){t.batch(e)},getBaseURL:function(){return _},addToBatch:function(e){return function(e){if(T.debug("[AMB Client] addToBatch called for channel: ".concat(e.channelName,", batchLogging.enabled: ").concat(c.default.batchLogging.enabled)),c.default.batchLogging.enabled){var t=(h=b(new Set([].concat(b(c.default.batchLogging.channels),b(h))))).length>0&&h.includes(e.channelName);if(T.debug("[AMB Client] Currently allowed channels: ".concat(h)),t)if(c.default.batchLogging.startTime){var o=Date.now(),r=c.default.batchLogging.startTime.replace(" ","T"),s=new Date(r).getTime();isNaN(s)?T.debug("[AMB Client] Invalid batch logging start time format: ".concat(c.default.batchLogging.startTime," - skipping entry for channel: ").concat(e.channelName)):o-s<=1728e5?(n.push(e),T.debug("[AMB Client] batch size is: "+n.length),n.length>=i&&(T.debug("[AMB Client] Force flushing global batch - reached max size ".concat(i)),E())):T.debug("[AMB Client] Batch logging start time is older than 48 hours - skipping entry for channel: ".concat(e.channelName))}else T.debug("[AMB Client] Batch logging start time is not set - skipping entry for channel: ".concat(e.channelName));else T.debug("[AMB Client] Channel not allowed for batch logging - skipping entry for channel: ".concat(e.channelName))}else T.debug("[AMB Client] Batch logging disabled - skipping entry for channel: ".concat(e.channelName))}(e)},flushBatch:function(){return E()},getBatchSize:function(){return n.length},addAllowedChannels:function(e){Array.isArray(e)?(e.forEach(function(e){h.includes(e)||h.push(e)}),T.debug("[AMB Client] Added channels to allowed list: ".concat(e,". Current allowed list: ").concat(h))):"string"==typeof e?(h.includes(e)||h.push(e),T.debug("[AMB Client] Added channel to allowed list: ".concat(e,". Current allowed list: ").concat(h))):T.addErrorMessage("[AMB Client] Invalid channels parameter: ".concat(e,". Expected string or array."))},setBatchLoggingStartTime:function(e){"string"==typeof e&&e.length>0?(c.default.batchLogging.startTime=e,T.debug("[AMB Client] Set batch logging start time to: ".concat(e))):null===e||void 0===e?(c.default.batchLogging.startTime=null,T.debug("[AMB Client] Cleared batch logging start time")):T.addErrorMessage("[AMB Client] Invalid startTime parameter: ".concat(e,'. Expected string format "YYYY-MM-DD HH:MM:SS", null, or undefined.'))},setBatchLogEnabled:function(e){"boolean"==typeof e?(c.default.batchLogging.enabled=e,T.debug("[AMB Client] Set batch logging enabled to: ".concat(e))):null===e||void 0===e?(c.default.batchLogging.enabled=!1,T.debug("[AMB Client] Set batch logging enabled to: false (null/undefined provided)")):T.addErrorMessage("[AMB Client] Invalid enabled parameter: ".concat(e,". Expected boolean, null, or undefined."))}}};t.default=m},function(e,t,n){(function(i){!function(n,i){e.exports=t=i()}(0,function(){var e=e||function(e,t){var o;if("undefined"!=typeof window&&window.crypto&&(o=window.crypto),"undefined"!=typeof self&&self.crypto&&(o=self.crypto),"undefined"!=typeof globalThis&&globalThis.crypto&&(o=globalThis.crypto),!o&&"undefined"!=typeof window&&window.msCrypto&&(o=window.msCrypto),!o&&void 0!==i&&i.crypto&&(o=i.crypto),!o)try{o=n(21)}catch(e){}var r=function(){if(o){if("function"==typeof o.getRandomValues)try{return o.getRandomValues(new Uint32Array(1))[0]}catch(e){}if("function"==typeof o.randomBytes)try{return o.randomBytes(4).readInt32LE()}catch(e){}}throw new Error("Native crypto module could not be used to get secure random number.")},s=Object.create||function(){function e(){}return function(t){var n;return e.prototype=t,n=new e,e.prototype=null,n}}(),a={},u=a.lib={},c=u.Base=function(){return{extend:function(e){var t=s(this);return e&&t.mixIn(e),t.hasOwnProperty("init")&&this.init!==t.init||(t.init=function(){t.$super.init.apply(this,arguments)}),t.init.prototype=t,t.$super=this,t},create:function(){var e=this.extend();return e.init.apply(e,arguments),e},init:function(){},mixIn:function(e){for(var t in e)e.hasOwnProperty(t)&&(this[t]=e[t]);e.hasOwnProperty("toString")&&(this.toString=e.toString)},clone:function(){return this.init.prototype.extend(this)}}}(),l=u.WordArray=c.extend({init:function(e,t){e=this.words=e||[],this.sigBytes=void 0!=t?t:4*e.length},toString:function(e){return(e||f).stringify(this)},concat:function(e){var t=this.words,n=e.words,i=this.sigBytes,o=e.sigBytes;if(this.clamp(),i%4)for(var r=0;r<o;r++){var s=n[r>>>2]>>>24-r%4*8&255;t[i+r>>>2]|=s<<24-(i+r)%4*8}else for(var a=0;a<o;a+=4)t[i+a>>>2]=n[a>>>2];return this.sigBytes+=o,this},clamp:function(){var t=this.words,n=this.sigBytes;t[n>>>2]&=4294967295<<32-n%4*8,t.length=e.ceil(n/4)},clone:function(){var e=c.clone.call(this);return e.words=this.words.slice(0),e},random:function(e){for(var t=[],n=0;n<e;n+=4)t.push(r());return new l.init(t,e)}}),d=a.enc={},f=d.Hex={stringify:function(e){for(var t=e.words,n=e.sigBytes,i=[],o=0;o<n;o++){var r=t[o>>>2]>>>24-o%4*8&255;i.push((r>>>4).toString(16)),i.push((15&r).toString(16))}return i.join("")},parse:function(e){for(var t=e.length,n=[],i=0;i<t;i+=2)n[i>>>3]|=parseInt(e.substr(i,2),16)<<24-i%8*4;return new l.init(n,t/2)}},g=d.Latin1={stringify:function(e){for(var t=e.words,n=e.sigBytes,i=[],o=0;o<n;o++){var r=t[o>>>2]>>>24-o%4*8&255;i.push(String.fromCharCode(r))}return i.join("")},parse:function(e){for(var t=e.length,n=[],i=0;i<t;i++)n[i>>>2]|=(255&e.charCodeAt(i))<<24-i%4*8;return new l.init(n,t)}},h=d.Utf8={stringify:function(e){try{return decodeURIComponent(escape(g.stringify(e)))}catch(e){throw new Error("Malformed UTF-8 data")}},parse:function(e){return g.parse(unescape(encodeURIComponent(e)))}},b=u.BufferedBlockAlgorithm=c.extend({reset:function(){this._data=new l.init,this._nDataBytes=0},_append:function(e){"string"==typeof e&&(e=h.parse(e)),this._data.concat(e),this._nDataBytes+=e.sigBytes},_process:function(t){var n,i=this._data,o=i.words,r=i.sigBytes,s=this.blockSize,a=r/(4*s),u=(a=t?e.ceil(a):e.max((0|a)-this._minBufferSize,0))*s,c=e.min(4*u,r);if(u){for(var d=0;d<u;d+=s)this._doProcessBlock(o,d);n=o.splice(0,u),i.sigBytes-=c}return new l.init(n,c)},clone:function(){var e=c.clone.call(this);return e._data=this._data.clone(),e},_minBufferSize:0}),p=(u.Hasher=b.extend({cfg:c.extend(),init:function(e){this.cfg=this.cfg.extend(e),this.reset()},reset:function(){b.reset.call(this),this._doReset()},update:function(e){return this._append(e),this._process(),this},finalize:function(e){return e&&this._append(e),this._doFinalize()},blockSize:16,_createHelper:function(e){return function(t,n){return new e.init(n).finalize(t)}},_createHmacHelper:function(e){return function(t,n){return new p.HMAC.init(e,n).finalize(t)}}}),a.algo={});return a}(Math);return e})}).call(t,n(20))},function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=function(e){return e&&e.__esModule?e:{default:e}}(n(13));window.__TECTONIC__amb_client_js=i.default,window.amb=i.default;t.default=i.default},function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=f(n(1)),o=f(n(0)),r=f(n(5)),s=f(n(6)),a=f(n(7)),u=f(n(3)),c=f(n(8)),l=f(n(10)),d=f(n(9));function f(e){return e&&e.__esModule?e:{default:e}}var g={properties:i.default,Logger:o.default,EventManager:r.default,ServerConnection:s.default,ChannelRedirect:a.default,ChannelListener:u.default,Channel:c.default,MessageClient:l.default,getClient:d.default};t.default=g},function(e,t,n){((t,n)=>{e.exports=n()})(0,()=>{const e={isString:e=>void 0!==e&&null!==e&&("string"==typeof e||e instanceof String)};function t(){let t,n,i;this.registered=((e,i)=>{t=e,n=i}),this.unregistered=(()=>{t=null,n=null}),this._notifyTransportTimeout=function(e){const t=n._getTransportListeners("timeout");if(t)for(let n=0;n<t.length;++n){const i=t[n];try{const t=i.call(this,e);if("number"==typeof t&&t>0)return t}catch(e){this._info("Exception during execution of transport listener",i,e)}}return 0},this._debug=function(){n._debug.apply(n,arguments)},this._info=function(){n._info.apply(n,arguments)},this._mixin=function(){return n._mixin.apply(n,arguments)},this.getConfiguration=(()=>n.getConfiguration()),this.getAdvice=(()=>n.getAdvice()),this.setTimeout=((e,t)=>n.setTimeout(e,t)),this.clearTimeout=(e=>{n.clearTimeout(e)}),this.convertToJSON=function(e){const t=this.getConfiguration().maxSendBayeuxMessageSize;let n="[";for(let i=0;i<e.length;++i){i>0&&(n+=",");const o=e[i],r=JSON.stringify(o);if(r.length>t)throw"maxSendBayeuxMessageSize "+t+" exceeded";n+=r}return n+="]"},this.convertToMessages=function(t){if(e.isString(t))try{return JSON.parse(t)}catch(e){throw this._debug("Could not convert to JSON the following string",'"'+t+'"'),e}if(Array.isArray(t))return t;if(void 0===t||null===t)return[];if(t instanceof Object)return[t];throw"Conversion Error "+t+", typeof "+typeof t},this.accept=((e,t,n)=>{throw"Abstract"}),this.getType=(()=>t),this.getURL=(()=>i),this.setURL=(e=>{i=e}),this.send=((e,t)=>{throw"Abstract"}),this.reset=function(e){this._debug("Transport",t,"reset",e?"initial":"retry")},this.abort=function(){this._debug("Transport",t,"aborted")},this.toString=function(){return this.getType()}}function n(){const e=new t,n=t.derive(e);let i=0,o=null,r=[],s=[];function a(e,t){if(this.transportSend(e,t)&&(t.expired=!1,!e.sync)){let n=this.getConfiguration().maxNetworkDelay;!0===t.metaConnect&&(n+=this.getAdvice().timeout),this._debug("Transport",this.getType(),"started waiting for message replies of request",t.id,":",n,"ms"),t.timeout=this.setTimeout(()=>{(function e(t,n,i){const o=this._notifyTransportTimeout(t.messages);if(o>0)this._debug("Transport",this.getType(),"extended waiting for message replies of request",n.id,":",o,"ms"),n.timeout=this.setTimeout(()=>{e.call(this,t,n,i+o)},o);else{n.expired=!0;const e="Transport "+this.getType()+" expired waiting for message replies of request "+n.id+": "+i+" ms",o={reason:e},r=n.xhr;o.httpCode=this.xhrStatus(r),this.abortXHR(r),this._debug(e),this.complete(n,!1,n.metaConnect),t.onFailure(r,t.messages,o)}}).call(this,e,t,n)},n)}}function u(e){const t=++i,n={id:t,metaConnect:!1,envelope:e};r.length<this.getConfiguration().maxConnections-1?(r.push(n),a.call(this,e,n)):(this._debug("Transport",this.getType(),"queueing request",t,"envelope",e),s.push([e,n]))}function c(e,t){const n=r.indexOf(e);if(n>=0&&r.splice(n,1),s.length>0){const n=s.shift(),i=n[0],o=n[1];this._debug("Transport dequeued request",o.id),t?(this.getConfiguration().autoBatch&&function(e){for(;s.length>0;){const t=s[0],n=t[0],i=t[1];if(n.url!==e.url||n.sync!==e.sync)break;s.shift(),e.messages=e.messages.concat(n.messages),this._debug("Coalesced",n.messages.length,"messages from request",i.id)}}.call(this,i),u.call(this,i),this._debug("Transport completed request",e.id,i)):this.setTimeout(()=>{this.complete(o,!1,o.metaConnect);const e={reason:"Previous request failed"},t=o.xhr;e.httpCode=this.xhrStatus(t),i.onFailure(t,i.messages,e)},0)}}return n.complete=function(e,t,n){n?function(e){const t=e.id;if(this._debug("Transport",this.getType(),"/meta/connect complete, request",t),null!==o&&o.id!==t)throw"/meta/connect request mismatch, completing request "+t;o=null}.call(this,e):c.call(this,e,t)},n.transportSend=((e,t)=>{throw"Abstract"}),n.transportSuccess=function(e,t,n){t.expired||(this.clearTimeout(t.timeout),this._debug("Transport",this.getType(),"cancelled waiting for message replies"),this.complete(t,!0,t.metaConnect),n&&n.length>0?e.onSuccess(n):e.onFailure(t.xhr,e.messages,{httpCode:204}))},n.transportFailure=function(e,t,n){t.expired||(this.clearTimeout(t.timeout),this._debug("Transport",this.getType(),"cancelled waiting for failed message replies"),this.complete(t,!1,t.metaConnect),e.onFailure(t.xhr,e.messages,n))},n.send=function(e,t){t?function(e){if(null!==o)throw"Concurrent /meta/connect requests not allowed, request id="+o.id+" not yet completed";const t=++i;this._debug("Transport",this.getType(),"/meta/connect send, request",t,"envelope",e);const n={id:t,metaConnect:!0,envelope:e};a.call(this,e,n),o=n}.call(this,e):u.call(this,e)},n.abort=function(){e.abort();for(let e=0;e<r.length;++e){const t=r[e];t&&(this._debug("Aborting request",t),this.abortXHR(t.xhr)||this.transportFailure(t.envelope,t,{reason:"abort"}))}const t=o;t&&(this._debug("Aborting /meta/connect request",t),this.abortXHR(t.xhr)||this.transportFailure(t.envelope,t,{reason:"abort"})),this.reset(!0)},n.reset=(t=>{e.reset(t),o=null,r=[],s=[]}),n.abortXHR=function(e){if(e)try{const t=e.readyState;return e.abort(),t!==window.XMLHttpRequest.UNSENT}catch(e){this._debug(e)}return!1},n.xhrStatus=function(e){if(e)try{return e.status}catch(e){this._debug(e)}return-1},n}function i(){const e=new n,i=t.derive(e);let o=!0;return i.accept=((e,t,n)=>o||!t),i.newXMLHttpRequest=(()=>new window.XMLHttpRequest),i.xhrSend=(e=>{const t=i.newXMLHttpRequest();!function(e){try{e.context=i.context}catch(e){i._debug("Could not copy transport context into XHR",e)}}(t),t.withCredentials=!0,t.open("POST",e.url,!0!==e.sync);const n=e.headers;if(n)for(let e in n)n.hasOwnProperty(e)&&t.setRequestHeader(e,n[e]);return t.setRequestHeader("Content-Type","application/json;charset=UTF-8"),t.onload=(()=>{200===t.status?e.onSuccess(t.responseText):e.onError(t.statusText)}),t.onabort=t.onerror=(()=>{e.onError(t.statusText)}),t.send(e.body),t}),i.transportSend=function(e,t){this._debug("Transport",this.getType(),"sending request",t.id,"envelope",e);try{let n=!0;return t.xhr=this.xhrSend({transport:this,url:e.url,sync:e.sync,headers:this.getConfiguration().requestHeaders,body:this.convertToJSON(e.messages),onSuccess:n=>{this._debug("Transport",this.getType(),"received response",n);let i=!1;try{const r=this.convertToMessages(n);0===r.length?(o=!1,this.transportFailure(e,t,{httpCode:204})):(i=!0,this.transportSuccess(e,t,r))}catch(n){if(this._debug(n),!i){o=!1;const i={exception:n};i.httpCode=this.xhrStatus(t.xhr),this.transportFailure(e,t,i)}}},onError:(i,r)=>{this._debug("Transport",this.getType(),"received error",i,r),o=!1;const s={reason:i,exception:r};s.httpCode=this.xhrStatus(t.xhr),n?this.setTimeout(()=>{this.transportFailure(e,t,s)},0):this.transportFailure(e,t,s)}}),n=!1,!0}catch(n){return this._debug("Transport",this.getType(),"exception:",n),o=!1,this.setTimeout(()=>{this.transportFailure(e,t,{exception:n})},0),!1}},i.reset=(t=>{e.reset(t),o=!0}),i}function o(){const e=new n,i=t.derive(e);let o=0;function r(e,t,n){return()=>{this.transportFailure(e,t,"error",n)}}return i.accept=((e,t,n)=>!0),i.jsonpSend=(e=>{const t=document.getElementsByTagName("head")[0],n=document.createElement("script"),i="_cometd_jsonp_"+o++;window[i]=(o=>{t.removeChild(n),delete window[i],e.onSuccess(o)});let r=e.url;r+=r.indexOf("?")<0?"?":"&",r+="jsonp="+i,r+="&message="+encodeURIComponent(e.body),n.src=r,n.async=!0!==e.sync,n.type="application/javascript",n.onerror=(t=>{e.onError("jsonp "+t.type)}),t.appendChild(n)}),i.transportSend=function(e,t){let n=0,i=e.messages.length;const o=[];for(;i>0;){const s=JSON.stringify(e.messages.slice(n,n+i)),a=e.url.length+encodeURI(s).length,u=this.getConfiguration().maxURILength;if(a>u){if(1===i){const n="Bayeux message too big ("+a+" bytes, max is "+u+") for transport "+this.getType();return void this.setTimeout(r.call(this,e,t,n),0)}--i}else o.push(i),n+=i,i=e.messages.length-n}let s=e;if(o.length>1){let n=0,i=o[0];this._debug("Transport",this.getType(),"split",e.messages.length,"messages into",o.join(" + ")),(s=this._mixin(!1,{},e)).messages=e.messages.slice(n,i),s.onSuccess=e.onSuccess,s.onFailure=e.onFailure;for(let r=1;r<o.length;++r){const s=this._mixin(!1,{},e);n=i,i+=o[r],s.messages=e.messages.slice(n,i),s.onSuccess=e.onSuccess,s.onFailure=e.onFailure,this.send(s,t.metaConnect)}}this._debug("Transport",this.getType(),"sending request",t.id,"envelope",s);try{let e=!0;return this.jsonpSend({transport:this,url:s.url,sync:s.sync,headers:this.getConfiguration().requestHeaders,body:JSON.stringify(s.messages),onSuccess:e=>{let n=!1;try{const i=this.convertToMessages(e);0===i.length?this.transportFailure(s,t,{httpCode:204}):(n=!0,this.transportSuccess(s,t,i))}catch(e){this._debug(e),n||this.transportFailure(s,t,{exception:e})}},onError:(n,i)=>{const o={reason:n,exception:i};e?this.setTimeout(()=>{this.transportFailure(s,t,o)},0):this.transportFailure(s,t,o)}}),e=!1,!0}catch(e){return this.setTimeout(()=>{this.transportFailure(s,t,{exception:e})},0),!1}},i}function r(){const e=new t,n=t.derive(e);let i,o=!0,r=!1,s=!0,a=null,u=null,c=!1,l=null;function d(e,t){e&&(this.webSocketClose(e,t.code,t.reason),this.onClose(e,t))}function f(e){return e===u||e===a}function g(e,t,n){const i=[];for(let e=0;e<t.messages.length;++e){const n=t.messages[e];n.id&&i.push(n.id)}e.envelopes[i.join(",")]=[t,n],this._debug("Transport",this.getType(),"stored envelope, envelopes",e.envelopes)}function h(e,t){let n=!1;const i=e.envelopes;for(let e=0;e<t.length;++e){const o=t[e];for(let e in i)if(i.hasOwnProperty(e)){const t=e.split(","),r=t.indexOf(o);if(r>=0){n=!0,t.splice(r,1);const o=i[e][0],s=i[e][1];delete i[e],t.length>0&&(i[t.join(",")]=[o,s]);break}}}n&&this._debug("Transport",this.getType(),"removed envelope, envelopes",i)}function b(e,t,n){const i=this._notifyTransportTimeout([t]);i>0?(this._debug("Transport",this.getType(),"extended waiting for message replies:",i,"ms"),e.timeouts[t.id]=this.setTimeout(()=>{b.call(this,e,t,n+i)},i)):(this._debug("Transport",this.getType(),"expired waiting for message reply",t.id,":",n,"ms"),d.call(this,e,{code:1e3,reason:"Message Timeout"}))}function p(e,t,n){let i;try{i=this.convertToJSON(t.messages)}catch(n){this._debug("Transport",this.getType(),"exception:",n);const i=[];for(let e=0;e<t.messages.length;++e){const n=t.messages[e];i.push(n.id)}return h.call(this,e,i),void this.setTimeout(()=>{this._notifyFailure(t.onFailure,e,t.messages,{exception:n})},0)}e.webSocket.send(i),this._debug("Transport",this.getType(),"sent",t,"/meta/connect =",n);let o=this.getConfiguration().maxNetworkDelay;n&&(o+=this.getAdvice().timeout,c=!0);const r=[];for(let n=0;n<t.messages.length;++n){const i=t.messages[n];i.id&&(r.push(i.id),e.timeouts[i.id]=this.setTimeout(()=>{b.call(this,e,i,o)},o))}this._debug("Transport",this.getType(),"started waiting for message replies",o,"ms, messageIds:",r,", timeouts:",e.timeouts)}function m(e,t,n){try{null===e?(e=u||{envelopes:{},timeouts:{}},g.call(this,e,t,n),function(e){if(u)return;const t=i.getURL().replace(/^http/,"ws");this._debug("Transport",this.getType(),"connecting to URL",t);try{const n=i.getConfiguration().protocol;e.webSocket=n?new window.WebSocket(t,n):new window.WebSocket(t),u=e}catch(e){throw o=!1,this._debug("Exception while creating WebSocket object",e),e}s=!1!==i.getConfiguration().stickyReconnect;const n=i.getConfiguration().connectTimeout;n>0&&(e.connectTimer=this.setTimeout(()=>{i._debug("Transport",this.getType(),"timed out while connecting to URL",t,":",n,"ms"),d.call(this,e,{code:1e3,reason:"Connect Timeout"})},n));const c=t=>{t=t||{code:1e3},i._debug("WebSocket onclose",e,t,"connecting",u,"current",a),e.connectTimer&&this.clearTimeout(e.connectTimer),this.onClose(e,t)};e.webSocket.onopen=(()=>{i._debug("WebSocket onopen",e),e.connectTimer&&this.clearTimeout(e.connectTimer),f(e)?(u=null,a=e,r=!0,this.onOpen(e)):(i._warn("Closing extra WebSocket connection",this,"active connection",a),d.call(this,e,{code:1e3,reason:"Extra Connection"}))}),e.webSocket.onclose=c,e.webSocket.onerror=(()=>{c({code:1e3,reason:"Error"})}),e.webSocket.onmessage=(t=>{i._debug("WebSocket onmessage",t,e),this.onMessage(e,t)}),this._debug("Transport",this.getType(),"configured callbacks on",e)}.call(this,e)):(g.call(this,e,t,n),p.call(this,e,t,n))}catch(t){this.setTimeout(()=>{d.call(this,e,{code:1e3,reason:"Exception",exception:t})},0)}}return n.reset=(t=>{e.reset(t),o=!0,t&&(r=!1),s=!0,t&&(a=null),u=null,c=!1}),n._notifySuccess=function(e,t){e.call(this,t)},n._notifyFailure=function(e,t,n,i){e.call(this,t,n,i)},n.onOpen=function(e){const t=e.envelopes;this._debug("Transport",this.getType(),"opened",e,"pending messages",t);for(let n in t)if(t.hasOwnProperty(n)){const i=t[n],o=i[0],r=i[1];l=o.onSuccess,p.call(this,e,o,r)}},n.onMessage=function(e,t){this._debug("Transport",this.getType(),"received websocket message",t,e);let n=!1;const i=this.convertToMessages(t.data),o=[];for(let t=0;t<i.length;++t){const r=i[t];if((/^\/meta\//.test(r.channel)||void 0===r.data)&&r.id){o.push(r.id);const t=e.timeouts[r.id];t&&(this.clearTimeout(t),delete e.timeouts[r.id],this._debug("Transport",this.getType(),"removed timeout for message",r.id,", timeouts",e.timeouts))}"/meta/connect"===r.channel&&(c=!1),"/meta/disconnect"!==r.channel||c||(n=!0)}h.call(this,e,o),this._notifySuccess(l,i),n&&this.webSocketClose(e,1e3,"Disconnect")},n.onClose=function(e,t){this._debug("Transport",this.getType(),"closed",e,t),f(e)&&(o=s&&r,u=null,a=null);const n=e.timeouts;e.timeouts={};for(let e in n)n.hasOwnProperty(e)&&this.clearTimeout(n[e]);const i=e.envelopes;e.envelopes={};for(let n in i)if(i.hasOwnProperty(n)){const o=i[n][0];i[n][1]&&(c=!1);const r={websocketCode:t.code,reason:t.reason};t.exception&&(r.exception=t.exception),this._notifyFailure(o.onFailure,e,o.messages,r)}},n.registered=((t,n)=>{e.registered(t,n),i=n}),n.accept=function(e,t,n){return this._debug("Transport",this.getType(),"accept, supported:",o),o&&!!window.WebSocket&&!1!==i.websocketEnabled},n.send=function(e,t){this._debug("Transport",this.getType(),"sending",e,"/meta/connect =",t),m.call(this,a,e,t)},n.webSocketClose=function(e,t,n){try{e.webSocket&&e.webSocket.close(t,n)}catch(e){this._debug(e)}},n.abort=function(){e.abort(),d.call(this,a,{code:1e3,reason:"Abort"}),this.reset(!0)},n}t.derive=(e=>{function t(){}return t.prototype=e,new t});const s=["0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z",".","-",":","+","=","^","!","/","*","?","&","<",">","(",")","[","]","{","}","@","%","$","#"],a=[0,68,0,84,83,82,72,0,75,76,70,65,0,63,62,69,0,1,2,3,4,5,6,7,8,9,64,0,73,66,74,71,81,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,77,0,78,67,0,0,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,79,0,80,0,0];return{CometD:function(t){const n=new function(){let e=0;const t={};this.register=(n=>{const i=++e;return t[i]=n,i}),this.unregister=(e=>{const n=t[e];return delete t[e],n}),this.setTimeout=((e,t)=>window.setTimeout(e,t)),this.clearTimeout=(e=>{window.clearTimeout(e)})},s=this,a=t||"default";let u=!1;const c=new function(){let e=[],t={};this.getTransportTypes=(()=>e.slice(0)),this.findTransportTypes=((n,i,o)=>{const r=[];for(let s=0;s<e.length;++s){const a=e[s];!0===t[a].accept(n,i,o)&&r.push(a)}return r}),this.negotiateTransport=((n,i,o,r)=>{for(let s=0;s<e.length;++s){const a=e[s];for(let e=0;e<n.length;++e)if(a===n[e]){const e=t[a];if(!0===e.accept(i,o,r))return e}}return null}),this.add=((n,i,o)=>{let r=!1;for(let t=0;t<e.length;++t)if(e[t]===n){r=!0;break}return r||("number"!=typeof o?e.push(n):e.splice(o,0,n),t[n]=i),!r}),this.find=(n=>{for(let i=0;i<e.length;++i)if(e[i]===n)return t[n];return null}),this.remove=(n=>{for(let i=0;i<e.length;++i)if(e[i]===n){e.splice(i,1);const o=t[n];return delete t[n],o}return null}),this.clear=(()=>{e=[],t={}}),this.reset=(n=>{for(let i=0;i<e.length;++i)t[e[i]].reset(n)})};let l,d="disconnected",f=0,g=null,h=0,b=[],p=!1,m=0,v={};const _={};let y=0,T=null;const C=[];let S,E,w={};const N={},I={};let O,x,M=!1,k=!1,A=0,L=0,R=null,D={useWorkerScheduler:!0,protocol:null,stickyReconnect:!0,connectTimeout:0,maxConnections:2,backoffIncrement:1e3,maxBackoff:6e4,logLevel:"info",maxNetworkDelay:1e4,requestHeaders:{},appendMessageTypeToURL:!0,autoBatch:!1,urls:{},maxURILength:2e3,maxSendBayeuxMessageSize:8192,advice:{timeout:6e4,interval:0,reconnect:void 0,maxInterval:0}};function B(e,t){try{return e[t]}catch(e){return}}function U(t){return e.isString(t)}function P(e){return e>="A"&&e<="Z"||e>="a"&&e<="z"}function G(e){return e>="0"&&e<="9"}function F(e){switch(e){case" ":case"!":case"#":case"$":case"(":case")":case"*":case"+":case"-":case".":case"/":case"@":case"_":case"{":case"~":case"}":return!0;default:return!1}}function j(e){if(!U(e))return!1;if(e.length<2)return!1;if("/"!==e.charAt(0))return!1;for(let t=1;t<e.length;++t){const n=e.charAt(t);if(!(P(n)||G(n)||F(n)))return!1}return!0}function q(e){return void 0!==e&&null!==e&&"function"==typeof e}function H(e,t){let n="";for(;--t>0&&!(e>=Math.pow(10,t));)n+="0";return n+=e}function W(e,t){if(window.console){const n=window.console[e];if(q(n)){const e=new Date;[].splice.call(t,0,0,H(e.getHours(),2)+":"+H(e.getMinutes(),2)+":"+H(e.getSeconds(),2)+"."+H(e.getMilliseconds(),3)),n.apply(window.console,t)}}}function z(e){return new RegExp("(^https?://)?(((\\[[^\\]]+])|([^:/?#]+))(:(\\d+))?)?([^?#]*)(.*)?").exec(e)}function V(e){s._debug("Configuring cometd object with",e),U(e)&&(e={url:e}),e||(e={}),D=s._mixin(!1,D,e);const t=s.getURL();if(!t)throw"Missing required configuration parameter 'url' specifying the Bayeux server URL";const i=z(t),o=i[2],r=i[8],a=i[9];if(u=s._isCrossDomain(o),D.appendMessageTypeToURL)if(void 0!==a&&a.length>0)s._info("Appending message type to URI "+r+a+" is not supported, disabling 'appendMessageTypeToURL' configuration"),D.appendMessageTypeToURL=!1;else{const e=r.split("/");let t=e.length-1;r.match(/\/$/)&&(t-=1),e[t].indexOf(".")>=0&&(s._info("Appending message type to URI "+r+" is not supported, disabling 'appendMessageTypeToURL' configuration"),D.appendMessageTypeToURL=!1)}if(window.Worker&&window.Blob&&window.URL&&D.useWorkerScheduler){let e=function(){const e={};self.onmessage=(t=>{const n=t.data,i=e[n.id];switch(n.type){case"setTimeout":e[n.id]=self.setTimeout(()=>{delete e[n.id],self.postMessage({id:n.id})},n.delay);break;case"clearTimeout":delete e[n.id],i&&self.clearTimeout(i);break;default:throw"Unknown command "+n.type}})}.toString();e=e.substring(e.indexOf("{")+1,e.lastIndexOf("}"));const t=new window.Blob([e],{type:"application/json"}),i=window.URL.createObjectURL(t),o=new window.Worker(i);n.setTimeout=((e,t)=>{const i=n.register(e);return o.postMessage({id:i,type:"setTimeout",delay:t}),i}),n.clearTimeout=(e=>{n.unregister(e),o.postMessage({id:e,type:"clearTimeout"})}),o.onmessage=(e=>{const t=e.data.id,i=n.unregister(t);i&&i()})}}function Q(e){if(e){const t=v[e.channel];t&&t[e.id]&&(delete t[e.id],s._debug("Removed",e.listener?"listener":"subscription",e))}}function Y(e){e&&!e.listener&&Q(e)}function K(){for(let e in v)if(v.hasOwnProperty(e)){const t=v[e];if(t)for(let e in t)t.hasOwnProperty(e)&&Y(t[e])}}function X(e){d!==e&&(s._debug("Status",d,"->",e),d=e)}function J(){return"disconnecting"===d||"disconnected"===d}function $(){return""+ ++f}function Z(e,t,n,i,o){try{return t.call(e,i)}catch(e){const t=s.onExtensionException;if(q(t)){s._debug("Invoking extension exception handler",n,e);try{t.call(s,e,n,o,i)}catch(e){s._info("Exception during execution of extension exception handler",n,e)}}else s._info("Exception during execution of extension",n,e);return i}}function ee(e){for(let t=C.length-1;t>=0&&void 0!==e&&null!==e;--t){const n=C[t],i=n.extension.outgoing;if(q(i)){const t=Z(n.extension,i,n.name,e,!0);e=void 0===t?e:t}}return e}function te(e,t){const n=v[e];if(n)for(let e in n)if(n.hasOwnProperty(e)){const i=n[e];if(i)try{i.callback.call(i.scope,t)}catch(e){const n=s.onListenerException;if(q(n)){s._debug("Invoking listener exception handler",i,e);try{n.call(s,e,i,i.listener,t)}catch(e){s._info("Exception during execution of listener exception handler",i,e)}}else s._info("Exception during execution of listener",i,t,e)}}}function ne(e,t){te(e,t);const n=e.split("/"),i=n.length-1;for(let e=i;e>0;--e){let o=n.slice(0,e).join("/")+"/*";e===i&&te(o,t),te(o+="*",t)}}function ie(){null!==T&&s.clearTimeout(T),T=null}function oe(e,t){ie();const n=w.interval+t;s._debug("Function scheduled in",n,"ms, interval =",w.interval,"backoff =",y,e),T=s.setTimeout(e,n)}function re(e,t,n){for(let t=0;t<e.length;++t){let n=e[t];const i=n.id;g&&(n.clientId=g),void 0!==(n=ee(n))&&null!==n?(n.id=i,e[t]=n):(delete N[i],e.splice(t--,1))}if(0===e.length)return;t&&(R=e[0]);let i=s.getURL();D.appendMessageTypeToURL&&(i.match(/\/$/)||(i+="/"),n&&(i+=n));const o={url:i,sync:!1,messages:e,onSuccess:e=>{try{O.call(s,e)}catch(e){s._info("Exception during handling of messages",e)}},onFailure:(e,t,n)=>{try{const i=s.getTransport();n.connectionType=i?i.getType():"unknown",x.call(s,e,t,n)}catch(e){s._info("Exception during handling of failure",e)}}};s._debug("Send",o),l.send(o,t)}function se(e){h>0||!0===p?b.push(e):re([e],!1)}function ae(){y=0}function ue(){const e=b;b=[],e.length>0&&re(e,!1)}function ce(e){X("connecting"),oe(()=>{!function(){if(!J()){const e={id:$(),channel:"/meta/connect",connectionType:l.getType()};k||(e.advice={timeout:0}),X("connecting"),s._debug("Connect sent",e),re([e],!0,"connect"),X("connected")}}()},e)}function le(e){e&&(w=s._mixin(!1,{},D.advice,e),s._debug("New advice",w))}function de(e){if(ie(),e&&l&&l.abort(),u=!1,l=null,X("disconnected"),g=null,h=0,ae(),M=!1,k=!1,A=0,R=null,b.length>0){const e=b;b=[],x.call(s,void 0,e,{reason:"Disconnected"})}}function fe(e,t,n){const i=s.onTransportException;if(q(i)){s._debug("Invoking transport exception handler",e,t,n);try{i.call(s,n,e,t)}catch(e){s._info("Exception during execution of transport exception handler",e)}}}function ge(e,t){q(e)&&(t=e,e=void 0),g=null,K(),J()&&c.reset(!0),le({}),h=0,p=!0,S=e,E=t;const n=s.getURL(),i=c.findTransportTypes("1.0",u,n),o={id:$(),version:"1.0",minimumVersion:"1.0",channel:"/meta/handshake",supportedConnectionTypes:i,advice:{timeout:w.timeout,interval:w.interval}},r=s._mixin(!1,{},S,o);if(s._putCallback(r.id,t),!l&&!(l=c.negotiateTransport(i,"1.0",u,n))){const e="Could not find initial transport among: "+c.getTransportTypes();throw s._warn(e),e}s._debug("Initial transport is",l.getType()),X("handshaking"),s._debug("Handshake sent",r),re([r],!1,"handshake")}function he(e,t){try{e.call(s,t)}catch(e){const n=s.onCallbackException;if(q(n)){s._debug("Invoking callback exception handler",e);try{n.call(s,e,t)}catch(e){s._info("Exception during execution of callback exception handler",e)}}else s._info("Exception during execution of message callback",e)}}function be(e){const t=s._getCallback([e.id]);q(t)&&(delete N[e.id],he(t,e))}function pe(e){const t=I[e.id];if(delete I[e.id],t){s._debug("Handling remote call response for",e,"with context",t);const n=t.timeout;n&&s.clearTimeout(n);const i=t.callback;if(q(i))return he(i,e),!0}return!1}function me(e){s._debug("Transport failure handling",e),e.transport&&(l=e.transport),e.url&&l.setURL(e.url);const t=e.action,n=e.delay||0;switch(t){case"handshake":!function(e){X("handshaking"),p=!0,oe(()=>{ge(S,E)},e)}(n);break;case"retry":ce(n);break;case"none":de(!0);break;default:throw"Unknown action "+t}}function ve(e,t){be(e),ne("/meta/handshake",e),ne("/meta/unsuccessful",e),J()&&(t.action="none"),s.onTransportFailure.call(s,e,t,me)}function _e(e){ve(e,{cause:"failure",action:"handshake",transport:null})}function ye(e){return"disconnected"===d||!(!R||R.id!==e.id)&&(R=null,!0)}function Te(e,t){ne("/meta/connect",e),ne("/meta/unsuccessful",e),J()&&(t.action="none"),s.onTransportFailure.call(s,e,t,me)}function Ce(e){ye(e)?(k=!1,Te(e,{cause:"failure",action:"retry",transport:null})):s._debug("Mismatched /meta/connect failure",e)}function Se(e){de(!0),be(e),ne("/meta/disconnect",e),ne("/meta/unsuccessful",e)}function Ee(e){Se(e)}function we(e){const t=v[e.subscription];if(t)for(let e in t)if(t.hasOwnProperty(e)){const n=t[e];n&&!n.listener&&(delete t[e],s._debug("Removed failed subscription",n))}be(e),ne("/meta/subscribe",e),ne("/meta/unsuccessful",e)}function Ne(e){we(e)}function Ie(e){be(e),ne("/meta/unsubscribe",e),ne("/meta/unsuccessful",e)}function Oe(e){Ie(e)}function xe(e){pe(e)||(be(e),ne("/meta/publish",e),ne("/meta/unsuccessful",e))}function Me(e){xe(e)}function ke(e){if(A=0,void 0!==(e=function(e){for(let t=0;t<C.length&&void 0!==e&&null!==e;++t){const n=C[t],i=n.extension.incoming;if(q(i)){const t=Z(n.extension,i,n.name,e,!1);e=void 0===t?e:t}}return e}(e))&&null!==e)switch(le(e.advice),e.channel){case"/meta/handshake":!function(e){const t=s.getURL();if(e.successful){const n=s._isCrossDomain(z(t)[2]),i=c.negotiateTransport(e.supportedConnectionTypes,e.version,n,t);if(null===i)return e.successful=!1,void ve(e,{cause:"negotiation",action:"none",transport:null});l!==i&&(s._debug("Transport",l.getType(),"->",i.getType()),l=i),g=e.clientId,p=!1,ue(),e.reestablish=M,M=!0,be(e),ne("/meta/handshake",e),L=e["x-messages"]||0;const o=J()?"none":w.reconnect||"retry";switch(o){case"retry":ae(),0===L?ce(0):s._debug("Processing",L,"handshake-delivered messages");break;case"none":de(!0);break;default:throw"Unrecognized advice action "+o}}else ve(e,{cause:"unsuccessful",action:w.reconnect||"handshake",transport:l})}(e);break;case"/meta/connect":!function(e){if(ye(e))if(k=e.successful){ne("/meta/connect",e);const t=J()?"none":w.reconnect||"retry";switch(t){case"retry":ae(),ce(y);break;case"none":de(!1);break;default:throw"Unrecognized advice action "+t}}else Te(e,{cause:"unsuccessful",action:w.reconnect||"retry",transport:l});else s._debug("Mismatched /meta/connect reply",e)}(e);break;case"/meta/disconnect":!function(e){e.successful?(de(!1),be(e),ne("/meta/disconnect",e)):Se(e)}(e);break;case"/meta/subscribe":!function(e){e.successful?(be(e),ne("/meta/subscribe",e)):we(e)}(e);break;case"/meta/unsubscribe":!function(e){e.successful?(be(e),ne("/meta/unsubscribe",e)):Ie(e)}(e);break;default:!function(e){void 0!==e.data?pe(e)||(ne(e.channel,e),L>0&&0==--L&&(s._debug("Processed last handshake-delivered message"),ce(0))):void 0===e.successful?s._warn("Unknown Bayeux Message",e):e.successful?(be(e),ne("/meta/publish",e)):xe(e)}(e)}}function Ae(e){const t=v[e];if(t)for(let e in t)if(t.hasOwnProperty(e)&&t[e])return!0;return!1}function Le(e,t){const n={scope:e,method:t};if(q(e))n.scope=void 0,n.method=e;else if(U(t)){if(!e)throw"Invalid scope "+e;if(n.method=e[t],!q(n.method))throw"Invalid callback "+t+" for scope "+e}else if(!q(t))throw"Invalid callback "+t;return n}function Re(e,t,n,i){const o=Le(t,n);s._debug("Adding",i?"listener":"subscription","on",e,"with scope",o.scope,"and callback",o.method);const r=++m,a={id:r,channel:e,scope:o.scope,callback:o.method,listener:i};let u=v[e];return u||(u={},v[e]=u),u[r]=a,s._debug("Added",i?"listener":"subscription",a),a}this._mixin=function(e,t,n){const i=t||{};for(let n=2;n<arguments.length;++n){const o=arguments[n];if(void 0!==o&&null!==o)for(let n in o)if(o.hasOwnProperty(n)){const r=B(o,n),s=B(i,n);if(r===t)continue;if(void 0===r)continue;if(e&&"object"==typeof r&&null!==r)if(r instanceof Array)i[n]=this._mixin(e,s instanceof Array?s:[],r);else{const t="object"!=typeof s||s instanceof Array?{}:s;i[n]=this._mixin(e,t,r)}else i[n]=r}}return i},this._warn=function(){W("warn",arguments)},this._info=function(){"warn"!==D.logLevel&&W("info",arguments)},this._debug=function(){"debug"===D.logLevel&&W("debug",arguments)},this._isCrossDomain=(e=>!!(window.location&&window.location.host&&e)&&e!==window.location.host),this.send=se,this._getCallback=(e=>N[e]),this._putCallback=function(e,t){const n=this._getCallback(e);return q(t)&&(N[e]=t),n},this.onTransportFailure=function(e,t,n){this._debug("Transport failure",t,"for",e);const i=this.getTransportRegistry(),o=this.getURL(),r=this._isCrossDomain(z(o)[2]),a=i.findTransportTypes("1.0",r,o);if("none"===t.action){if("/meta/handshake"===e.channel&&!t.transport){const t="Could not negotiate transport, client=["+a+"], server=["+e.supportedConnectionTypes+"]";this._warn(t),fe(l.getType(),null,{reason:t,connectionType:l.getType(),transport:l})}}else if(t.delay=this.getBackoffPeriod(),"/meta/handshake"===e.channel){if(!t.transport){const n=l?l.getType():null,s=i.negotiateTransport(a,"1.0",r,o);if(s){const i=s.getType();this._debug("Transport",n,"->",i),fe(n,i,e.failure),t.action="handshake",t.transport=s}else this._warn("Could not negotiate transport, client=["+a+"]"),fe(n,null,e.failure),t.action="none"}"none"!==t.action&&this.increaseBackoffPeriod()}else{const e=(new Date).getTime();if(0===A&&(A=e),"retry"===t.action){t.delay=this.increaseBackoffPeriod();const n=w.maxInterval;if(n>0){const i=w.timeout+w.interval+n;e-A+y>i&&(t.action="handshake")}}"handshake"===t.action&&(t.delay=0,i.reset(!1),this.resetBackoffPeriod())}n.call(s,t)},this.receive=ke,O=(e=>{s._debug("Received",e);for(let t=0;t<e.length;++t)ke(e[t])}),x=((e,t,n)=>{s._debug("handleFailure",e,t,n),n.transport=e;for(let e=0;e<t.length;++e){const i=t[e],o={id:i.id,successful:!1,channel:i.channel,failure:n};switch(n.message=i,i.channel){case"/meta/handshake":_e(o);break;case"/meta/connect":Ce(o);break;case"/meta/disconnect":Ee(o);break;case"/meta/subscribe":o.subscription=i.subscription,Ne(o);break;case"/meta/unsubscribe":o.subscription=i.subscription,Oe(o);break;default:Me(o)}}}),this.registerTransport=function(e,t,n){const i=c.add(e,t,n);return i&&(this._debug("Registered transport",e),q(t.registered)&&t.registered(e,this)),i},this.unregisterTransport=function(e){const t=c.remove(e);return null!==t&&(this._debug("Unregistered transport",e),q(t.unregistered)&&t.unregistered()),t},this.unregisterTransports=(()=>{c.clear()}),this.getTransportTypes=(()=>c.getTransportTypes()),this.findTransport=(e=>c.find(e)),this.getTransportRegistry=(()=>c),this.configure=function(e){V.call(this,e)},this.init=function(e,t){this.configure(e),this.handshake(t)},this.handshake=((e,t)=>{if("disconnected"!==d)throw"Illegal state: handshaken";ge(e,t)}),this.disconnect=function(e,t){if(J())return;q(e)&&(t=e,e=void 0);const n={id:$(),channel:"/meta/disconnect"},i=this._mixin(!1,{},e,n);s._putCallback(i.id,t),X("disconnecting"),re([i],!1,"disconnect")},this.startBatch=(()=>{!function(){++h,s._debug("Starting batch, depth",h)}()}),this.endBatch=(()=>{!function(){if(--h,s._debug("Ending batch, depth",h),h<0)throw"Calls to startBatch() and endBatch() are not paired";0!==h||J()||p||ue()}()}),this.batch=function(e,t){const n=Le(e,t);this.startBatch();try{n.method.call(n.scope),this.endBatch()}catch(e){throw this._info("Exception during execution of batch",e),this.endBatch(),e}},this.addTransportListener=((e,t)=>{if("timeout"!==e)throw"Unsupported event "+e;let n=_[e];n||(_[e]=n=[]),n.push(t)}),this.removeTransportListener=((e,t)=>{const n=_[e];if(n){const e=n.indexOf(t);if(e>=0)return n.splice(e,1),!0}return!1}),this._getTransportListeners=(e=>_[e]),this.addListener=function(e,t,n){if(arguments.length<2)throw"Illegal arguments number: required 2, got "+arguments.length;if(!U(e))throw"Illegal argument type: channel must be a string";return Re(e,t,n,!0)},this.removeListener=(e=>{if(!(e&&e.channel&&"id"in e))throw"Invalid argument: expected subscription, not "+e;Q(e)}),this.clearListeners=(()=>{v={}}),this.subscribe=function(e,t,n,i,o){if(arguments.length<2)throw"Illegal arguments number: required 2, got "+arguments.length;if(!j(e))throw"Illegal argument: invalid channel "+e;if(J())throw"Illegal state: disconnected";q(t)&&(o=i,i=n,n=t,t=void 0),q(i)&&(o=i,i=void 0);const r=!Ae(e),a=Re(e,t,n,!1);if(r){const t={id:$(),channel:"/meta/subscribe",subscription:e},n=this._mixin(!1,{},i,t);s._putCallback(n.id,o),se(n)}else q(o)&&s.setTimeout(()=>{he(o,{id:$(),successful:!0,channel:"/meta/subscribe",subscription:e})},0);return a},this.unsubscribe=function(e,t,n){if(arguments.length<1)throw"Illegal arguments number: required 1, got "+arguments.length;if(J())throw"Illegal state: disconnected";q(t)&&(n=t,t=void 0),this.removeListener(e);const i=e.channel;if(Ae(i))q(n)&&s.setTimeout(()=>{he(n,{id:$(),successful:!0,channel:"/meta/unsubscribe",subscription:i})},0);else{const e={id:$(),channel:"/meta/unsubscribe",subscription:i},o=this._mixin(!1,{},t,e);s._putCallback(o.id,n),se(o)}},this.resubscribe=function(e,t){if(Y(e),e)return this.subscribe(e.channel,e.scope,e.callback,t)},this.clearSubscriptions=(()=>{K()}),this.publish=function(e,t,n,i){if(arguments.length<1)throw"Illegal arguments number: required 1, got "+arguments.length;if(!j(e))throw"Illegal argument: invalid channel "+e;if(/^\/meta\//.test(e))throw"Illegal argument: cannot publish to meta channels";if(J())throw"Illegal state: disconnected";q(t)?(i=t,t={},n=void 0):q(n)&&(i=n,n=void 0);const o={id:$(),channel:e,data:t},r=this._mixin(!1,{},n,o);s._putCallback(r.id,i),se(r)},this.publishBinary=function(e,t,n,i,o,r){q(t)?(r=t,t=new ArrayBuffer(0),n=!0,i=void 0,o=void 0):q(n)?(r=n,n=!0,i=void 0,o=void 0):q(i)?(r=i,i=void 0,o=void 0):q(o)&&(r=o,o=void 0);const s={meta:i,data:t,last:n},a=this._mixin(!1,o,{ext:{binary:{}}});this.publish(e,s,a,r)},this.remoteCall=function(e,t,n,i,o){if(arguments.length<1)throw"Illegal arguments number: required 1, got "+arguments.length;if(!U(e))throw"Illegal argument type: target must be a string";if(J())throw"Illegal state: disconnected";if(q(t)?(o=t,t={},n=D.maxNetworkDelay,i=void 0):q(n)?(o=n,n=D.maxNetworkDelay,i=void 0):q(i)&&(o=i,i=void 0),"number"!=typeof n)throw"Illegal argument type: timeout must be a number";e.match(/^\//)||(e="/"+e);const r="/service"+e;if(!j(r))throw"Illegal argument: invalid target "+e;const a={id:$(),channel:r,data:t},u=this._mixin(!1,{},i,a),c={callback:o};n>0&&(c.timeout=s.setTimeout(()=>{s._debug("Timing out remote call",u,"after",n,"ms"),xe({id:u.id,error:"406::timeout",successful:!1,failure:{message:u,reason:"Remote Call Timeout"}})},n),s._debug("Scheduled remote call timeout",u,"in",n,"ms")),I[u.id]=c,se(u)},this.remoteCallBinary=function(e,t,n,i,o,r,s){q(t)?(s=t,t=new ArrayBuffer(0),n=!0,i=void 0,o=D.maxNetworkDelay,r=void 0):q(n)?(s=n,n=!0,i=void 0,o=D.maxNetworkDelay,r=void 0):q(i)?(s=i,i=void 0,o=D.maxNetworkDelay,r=void 0):q(o)?(s=o,o=D.maxNetworkDelay,r=void 0):q(r)&&(s=r,r=void 0);const a={meta:i,data:t,last:n},u=this._mixin(!1,r,{ext:{binary:{}}});this.remoteCall(e,a,o,u,s)},this.getStatus=(()=>d),this.isDisconnected=J,this.setBackoffIncrement=(e=>{D.backoffIncrement=e}),this.getBackoffIncrement=(()=>D.backoffIncrement),this.getBackoffPeriod=(()=>y),this.increaseBackoffPeriod=(()=>(function(){return y<D.maxBackoff&&(y+=D.backoffIncrement),y})()),this.resetBackoffPeriod=(()=>{ae()}),this.setLogLevel=(e=>{D.logLevel=e}),this.registerExtension=function(e,t){if(arguments.length<2)throw"Illegal arguments number: required 2, got "+arguments.length;if(!U(e))throw"Illegal argument type: extension name must be a string";let n=!1;for(let t=0;t<C.length;++t)if(C[t].name===e){n=!0;break}return n?(this._info("Could not register extension with name",e,"since another extension with the same name already exists"),!1):(C.push({name:e,extension:t}),this._debug("Registered extension",e),q(t.registered)&&t.registered(e,this),!0)},this.unregisterExtension=function(e){if(!U(e))throw"Illegal argument type: extension name must be a string";let t=!1;for(let n=0;n<C.length;++n){const i=C[n];if(i.name===e){C.splice(n,1),t=!0,this._debug("Unregistered extension",e);const o=i.extension;q(o.unregistered)&&o.unregistered();break}}return t},this.getExtension=(e=>{for(let t=0;t<C.length;++t){const n=C[t];if(n.name===e)return n.extension}return null}),this.getName=(()=>a),this.getClientId=(()=>g),this.getURL=(()=>{if(l){let e=l.getURL();if(e)return e;if(e=D.urls[l.getType()])return e}return D.url}),this.getTransport=(()=>l),this.getConfiguration=function(){return this._mixin(!0,{},D)},this.getAdvice=function(){return this._mixin(!0,{},w)},this.setTimeout=((e,t)=>n.setTimeout(()=>{try{s._debug("Invoking timed function",e),e()}catch(t){s._debug("Exception invoking timed function",e,t)}},t)),this.clearTimeout=(e=>{n.clearTimeout(e)}),window.WebSocket&&this.registerTransport("websocket",new r),this.registerTransport("long-polling",new i),this.registerTransport("callback-polling",new o)},Transport:t,RequestTransport:n,LongPollingTransport:i,CallbackPollingTransport:o,WebSocketTransport:r,Utils:e,Z85:{encode:e=>{let t=null;if(e instanceof ArrayBuffer?t=e:e.buffer instanceof ArrayBuffer?t=e.buffer:Array.isArray(e)&&(t=new Uint8Array(e).buffer),null==t)throw"Cannot Z85 encode "+e;const n=t.byteLength,i=n%4,o=4-(0===i?4:i),r=new DataView(t);let a="",u=0;for(let e=0;e<n+o;++e){const t=e>=n;if(u=256*u+(t?0:r.getUint8(e)),(e+1)%4==0){let e=52200625;for(let n=5;n>0;--n){if(!t||n>o){const t=Math.floor(u/e)%85;a+=s[t]}e/=85}u=0}}return a},decode:e=>{const t=e.length%5,n=5-(0===t?5:t);for(let t=0;t<n;++t)e+=s[s.length-1];const i=e.length,o=new ArrayBuffer(4*i/5-n),r=new DataView(o);let u=0,c=0,l=0;for(let t=0;t<i;++t){const t=e.charCodeAt(c++)-32;if(u=85*u+a[t],c%5==0){let e=16777216;for(;e>=1;)l<r.byteLength&&r.setUint8(l++,Math.floor(u/e)%256),e/=256;u=0}}return o}}}})},function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=function(e){return e&&e.__esModule?e:{default:e}}(n(0));var o=function(){var e=new i.default("amb.GraphQLSubscriptionExtension"),t={};this.isGraphQLChannel=function(e){return e&&e.startsWith("/rw/graphql")},this.addGraphQLChannel=function(e,n){t[e]=n},this.removeGraphQLChannel=function(e){delete t[e]},this.getGraphQLSubscriptions=function(){return t},this.outgoing=function(n){return"/meta/subscribe"===n.channel&&this.isGraphQLChannel(n.subscription)&&(n.ext||(n.ext={}),t[n.subscription]&&(e.debug("Subscribing with GraphQL subscription:"+t[n.subscription]),n.ext.serializedGraphQLSubscription=t[n.subscription])),n}};t.default=o},function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=function(e){return e&&e.__esModule?e:{default:e}}(n(0));var o=function(){var e=new i.default("amb.SessionExtension"),t=!1;this.extendSession=function(){t=!0},this.outgoing=function(n){return"/meta/connect"===n.channel&&t&&(n.ext||(n.ext={}),e.debug("extendSession"),n.ext.extendSession=!0,t=!1),n}};t.default=o},function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=r(n(0)),o=r(n(1));function r(e){return e&&e.__esModule?e:{default:e}}var s=function(){var e=new i.default("amb.TokenManagementExtension"),t="/meta/subscribe",n="/meta/unsubscribe",r="/meta/handshake",s=o.default.subscribeCommandsFlow.maxInflight,a=[];function u(e){return e.channel==t||e.channel==n}function c(){e.debug("notifyOnAvailabilityOfToken - current tokenCount: "+s);try{a.forEach(function(e){e()})}catch(t){e.addErrorMessage("notifyOnAvailabilityOfToken - failed to call tokenEventListeners. Error Details : "+t)}}this.updateTokenCount=function(e){s=e},this.refillTokens=function(){s=o.default.subscribeCommandsFlow.maxInflight,c(),e.debug("refillTokens -- tokenCount : "+s)},this.outgoing=function(e){return function(e){return e.channel===r}(e)&&(e.ext||(e.ext={}),e.ext.supportsSubscribeCommandFlow=!0),o.default.subscribeCommandsFlow.enable?(u(e)&&s>0&&s--,e):e},this.incoming=function(e){return o.default.subscribeCommandsFlow.enable?(u(e)?(s<o.default.subscribeCommandsFlow.maxInflight&&s++,c()):function(e){if(!e.ext)return!1;var t=e.ext.received_by_glide;return!!t&&t&&u(t)}(e)&&(e=null),e):e},this.getTokenCount=function(){return s},this.addTokenAvailabilityListener=function(t){t&&(e.debug("addTokenAvailabilityListener - tokenEventListener : "+t),a.push(t))},this.removeTokenAvailabilityListener=function(t){if(t){e.debug("removeTokenAvailabilityListener - tokenEventListener : "+t);var n=a.findIndex(function(e){return t===e});-1!==n&&(e.debug("removeTokenAvailabilityListener - removing listener at index : "+n),a.splice(n,1))}}};t.default=s},function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=function(e){return e&&e.__esModule?e:{default:e}}(n(0)),o=n(2),r=["callback"];function s(e,t){if(null==e)return{};var n,i,o=function(e,t){if(null==e)return{};var n,i,o={},r=Object.keys(e);for(i=0;i<r.length;i++)n=r[i],t.indexOf(n)>=0||(o[n]=e[n]);return o}(e,t);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);for(i=0;i<r.length;i++)n=r[i],t.indexOf(n)>=0||Object.prototype.propertyIsEnumerable.call(e,n)&&(o[n]=e[n])}return o}var a=function(){var e=new i.default("amb.CancelTransactionSender"),t={},n=new Map,a=null,u=!1;function c(e,t){var n={};return n.request=e,n.request.action=o.CANCEL_TRANSACTION_ACTION,n.response=t,n}function l(e,t){n.has(e)&&(n.get(e)(t),n.delete(e))}function d(t){var n;t?t.data&&t.ext&&t.ext.status?t.ext.status!==o.REQUEST_ACCEPTED?t.ext.status!==o.REQUEST_SUCCESS||(null===(n=t.ext.result)||void 0===n?void 0:n.length)===t.data.length?t.data.forEach(function(e,n){if(e.hasOwnProperty("nowUiInteraction")){var i=c(e,t.ext.status===o.REQUEST_SUCCESS?t.ext.result[n]:t.ext);l(e.nowUiInteraction,i)}}):e.addWarnMessage("Invalid response for cancel request"):e.debug("Batch Cancel Request accepted"):e.addWarnMessage("Invalid response for cancel request"):e.addWarnMessage("Empty response for cancel request")}return t.cancelTransaction=function(t,i){if(e.debug("cancelTransaction"),u||function(e){(a=e.getChannel(o.CANCEL_TRANSACTION_CHANNEL)).subscribe(d),u=!0}(i),t&&0!==t.length){var f=[];if(t.forEach(function(t){var i=function(t){var i={isValid:!0,error:null};return t?t.hasOwnProperty("nowUiInteraction")&&"string"==typeof t.nowUiInteraction?n.has(t.nowUiInteraction)?(e.debug("Transaction has already been submitted for cancellation. nowUiInteraction: "+t.nowUiInteraction),i.isValid=!1,i.error=o.TRANSACTION_ALREADY_SUBMITTED,i):i:(e.debug("nowUiInteraction is unavailable or invalid"),i.isValid=!1,i.error=o.MISSING_INTERACTION_ID,i):(e.debug("empty cancel request"),i.isValid=!1,i.error=o.MISSING_REQUEST_DATA,i)}(t);if(i.isValid){var a=t.nowUiInteraction,u=t.callback;f.push({nowUiInteraction:a}),u&&n.set(t.nowUiInteraction,u)}else!function(e,t){null!==e&&void 0!==e&&e.callback&&(0,e.callback)(c(s(e,r),{successful:!1,status:t}))}(t,i.error)}),0!==f.length)for(var g=function(e){var t=f.slice(e,e+10);a.publish(t,function(e){return function(e,t){if(!t.successful){var n={successful:!1,status:o.PUBLISH_FAILURE};e.forEach(function(e){l(e.nowUiInteraction,c(e,n))})}}(t,e)})},h=0;h<f.length;h+=10)g(h);else e.debug("All requests filtered due to invalid inputs")}else e.addWarnMessage("Request array is empty or not defined")},t};t.default=a},function(e,t,n){!function(t,i){e.exports=i(n(11))}(0,function(e){return function(){var t=e,n=t.lib.WordArray;t.enc.Base64={stringify:function(e){var t=e.words,n=e.sigBytes,i=this._map;e.clamp();for(var o=[],r=0;r<n;r+=3)for(var s=(t[r>>>2]>>>24-r%4*8&255)<<16|(t[r+1>>>2]>>>24-(r+1)%4*8&255)<<8|t[r+2>>>2]>>>24-(r+2)%4*8&255,a=0;a<4&&r+.75*a<n;a++)o.push(i.charAt(s>>>6*(3-a)&63));var u=i.charAt(64);if(u)for(;o.length%4;)o.push(u);return o.join("")},parse:function(e){var t=e.length,i=this._map,o=this._reverseMap;if(!o){o=this._reverseMap=[];for(var r=0;r<i.length;r++)o[i.charCodeAt(r)]=r}var s=i.charAt(64);if(s){var a=e.indexOf(s);-1!==a&&(t=a)}return function(e,t,i){for(var o=[],r=0,s=0;s<t;s++)if(s%4){var a=i[e.charCodeAt(s-1)]<<s%4*2,u=i[e.charCodeAt(s)]>>>6-s%4*2,c=a|u;o[r>>>2]|=c<<24-r%4*8,r++}return n.create(o,r)}(e,t,o)},_map:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="}}(),e.enc.Base64})},function(e,t){var n;n=function(){return this}();try{n=n||Function("return this")()||(0,eval)("this")}catch(e){"object"==typeof window&&(n=window)}e.exports=n},function(e,t){},function(e,t,n){!function(t,i){e.exports=i(n(11))}(0,function(e){return e.enc.Utf8})},function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=function(e){return e&&e.__esModule?e:{default:e}}(n(0)),o=n(2);function r(e,t){var n="undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(!n){if(Array.isArray(e)||(n=function(e,t){if(!e)return;if("string"==typeof e)return s(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);"Object"===n&&e.constructor&&(n=e.constructor.name);if("Map"===n||"Set"===n)return Array.from(e);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return s(e,t)}(e))||t&&e&&"number"==typeof e.length){n&&(e=n);var i=0,o=function(){};return{s:o,n:function(){return i>=e.length?{done:!0}:{done:!1,value:e[i++]}},e:function(e){throw e},f:o}}throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}var r,a=!0,u=!1;return{s:function(){n=n.call(e)},n:function(){var e=n.next();return a=e.done,e},e:function(e){u=!0,r=e},f:function(){try{a||null==n.return||n.return()}finally{if(u)throw r}}}}function s(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,i=new Array(t);n<t;n++)i[n]=e[n];return i}var a=function(){var e,t,n=new i.default("amb.MessagesRedeliveryManager"),s=[],a=[],u=function(e){return e.ext.redelivery_message},c=function(e){return!0!==e.ext.redelivery_message.redelivery_not_authorized},l=function(e,t){return e.find(function(e){return function(e,t){return e.ext[o.MSG_SHARD]===t.ext[o.MSG_SHARD]&&e.ext[o.MSG_NUM]===t.ext[o.MSG_NUM]}(e,t)})},d=function(e){return o.MSG_NUM+":"+e.ext[o.MSG_NUM]+","+o.MSG_SHARD+":"+e.ext[o.MSG_SHARD]};function f(){n.debug("Clearing all messages"),s=[],a=[]}return{resetState:function(){f(),e=!0,t=!1},containsMetaInfo:function(e){return e.ext&&e.ext[o.MSG_NUM]&&e.ext[o.MSG_SHARD]},shouldDeliver:function(i){return e?function(e){return e.ext.redelivery_notification&&!1===e.ext.redelivery_notification.can_redeliver}(i)?(n.debug("No messages to redeliver"),e=!1,!1):!!this.containsMetaInfo(i)&&(u(i)&&c(i)?(n.debug("Processing redelivered - "+d(i)),s.push(i)):u(i)&&!c(i)?n.debug("Not Processing unauthorized redelivery message - "+d(i)):(a.push(i),n.debug("Processing original - "+d(i))),function(e){return u(e)&&!0===e.ext.redelivery_message.is_last_redelivery}(i)&&function(){n.debug("Redelivery over"),e=!1,t=!0}(),!1):l(s,i)?(n.debug("Dropping duplicate: "+d(i)),!1):(n.debug("Out of redelivery. New message received: "+d(i)),f(),!0)},shouldDeliverPendingMessages:function(){return t},getAllPendingMessages:function(){var e=[];if(function(){return s.length>0||a.length>0}()){var i=function(e,t){return t.filter(function(t){return!l(e,t)})}(s,a);e=s.concat(i)}return n.debug("Flushing: "+function(e){var t,n="",i=r(e);try{for(i.s();!(t=i.n()).done;){var o=t.value;n=n.concat("<"+d(o)+">")}}catch(e){i.e(e)}finally{i.f()}return n}(e)),s=e,a=[],t=!1,e},getMissedMessagesSize:function(){return s.length},getOriginalMessagesSize:function(){return a.length}}};t.default=a},function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=function(e){return e&&e.__esModule?e:{default:e}}(n(0));function o(e,t){for(var n=0;n<t.length;n++){var i=t[n];i.enumerable=i.enumerable||!1,i.configurable=!0,"value"in i&&(i.writable=!0),Object.defineProperty(e,i.key,i)}}function r(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var s=function(e,t,n){return t&&o(e.prototype,t),n&&o(e,n),Object.defineProperty(e,"prototype",{writable:!1}),e}(function e(){var t=this;!function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,e),r(this,"emit",function(e,t){window.localStorage.setItem(e,JSON.stringify(t)),window.localStorage.removeItem(e)}),r(this,"on",function(e,n){if(t.registeredListeners.has(e)){var i=t.registeredListeners.get(e);window.removeEventListener("storage",i),t.LOGGER.debug("Removed storage event listener "+e)}var o=function(t){var i=t.key,o=t.newValue;i===e&&o&&n(JSON.parse(o))};window.addEventListener("storage",o),t.LOGGER.debug("Registered storage event listener "+e),t.registeredListeners.set(e,o)}),this.registeredListeners=new Map,this.LOGGER=new i.default("amb.CrossClientChannel")});t.default=s},function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:134217727,t=[],n=Math.max(1,Math.floor(e));return{enqueue:function(e){return this.getAvailableSpace()>0&&(t.push(e),!0)},enqueueMultiple:function(e){return this.getAvailableSpace()>=e.length&&(t=t.concat(e),!0)},dequeue:function(){var e;return t.length>0&&(e=t.shift()),e},dequeueMultiple:function(e){var n;return e>=0&&t.length>=e&&(n=[],e>0&&(n=t.slice(0,e),t=t.slice(e))),n},clear:function(){t=[]},getSize:function(){return t.length},getCapacity:function(){return n},getAvailableSpace:function(){return n-t.length},getQueueBuffer:function(){return t}}};t.default=i},function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=s(n(1)),o=n(4),r=s(n(0));function s(e){return e&&e.__esModule?e:{default:e}}var a=function(e,t){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],s={SUBSCRIBE:"subscribe",UNSUBSCRIBE:"unsubscribe"},a=202,u=429,c=1003,l=1004,d=3e5,f=new r.default("amb.SubscriptionCommandSender");!function(){t.addTokenAvailabilityListener(function(){N()})}();var g=!i.default.subscribeCommandsFlow.enable,h=null;function b(e,t,n){return Math.min(n,Math.max(t,e))}function p(){return t.getTokenCount()>=i.default.subscribeCommandsFlow.maxInflight}function m(){var e=!(arguments.length>0&&void 0!==arguments[0])||arguments[0];if(e||(0,o.isNil)(h)){var n=b(i.default.subscribeCommandsFlow.maxWait,0,d);f.debug("restartTimer - force: "+e+", timerObject : "+h+", timeInterval : "+n),v(),h=setTimeout(function(){!function(){h=null,f.debug("onTimer - stopping : "+g),g||(t.refillTokens(),N())}()},n)}}function v(){(0,o.isNil)(h)||(f.debug("stopTimer"),clearTimeout(h),h=null)}function _(){var e=parseInt(i.default.subscribeCommandsFlow.retryDelay.min);return e=b(e,0,d)}function y(e,t,n,r){var a;f.debug("scheduleRetry - channel : "+e.getName()+", triesLeft : "+t+", mode : "+n);var u=function(e){return b(i.default.subscribeCommandsFlow.retryDelay.increaseFactor*e,i.default.subscribeCommandsFlow.retryDelay.min,i.default.subscribeCommandsFlow.retryDelay.max)}(r);switch(n){case s.SUBSCRIBE:a=function(){return S(e,t,u)};break;case s.UNSUBSCRIBE:a=function(){return E(e,t,u)}}(0,o.isNil)(a)||setTimeout(a,r)}function T(e,n,i,o,r){f.debug("onResponse - response ".concat(JSON.stringify(e),", channel ").concat(JSON.stringify(n),", mode : ").concat(i,", \n\t\t\ttriesLeft ").concat(o,", stopping : ").concat(g,", tokenCount : ").concat(t.getTokenCount(),", isBucketFull - ").concat(p(),", retryDelay - ").concat(r)),g?n.subscriptionCallback(e):(o-=1,p()&&v(),o>0&&w(e)?y(n,o,i,r):n.subscriptionCallback(e),N())}function C(t){return f.debug("addItemToQueue - item : "+t),!!e.enqueue(t)&&(N(),!0)}function S(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:null,n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:_();return f.debug("enqueueSubscribe - channel: "+e.getName()+", triesLeft : "+t+", stopping : "+g+", retryDelay : "+n),!!(!g&&(0,o.isObject)(e)&&((0,o.isNil)(t)&&(t=1+Math.floor(i.default.subscribeCommandsFlow.retries)),t>0))&&C(function(){f.debug("enqueueSubscribe - inside the item execution. Calling channel._subscribeToCometD - channel: "+e.getName()+", triesLeft : "+t),e._subscribeToCometD(function(i){return T(i,e,s.SUBSCRIBE,t,n)})})}function E(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:null,n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:_();return f.debug("enqueueUnsubscribe - channel: "+e.getName()+", triesLeft : "+t+", stopping : "+g+", retryDelay : "+n),!!(!g&&(0,o.isObject)(e)&&((0,o.isNil)(t)&&(t=1+Math.floor(i.default.subscribeCommandsFlow.retries)),t>0))&&C(function(){e._unsubscribeFromCometD(function(i){return T(i,e,s.UNSUBSCRIBE,t,n)})})}function w(e){if(f.debug("isRetriable - response : "+JSON.stringify(e)),e&&e.ext){var t=parseInt(e.ext["glide.amb.reply.status.code"]);if(n&&!isNaN(t)&&(t===c||t===l))return f.debug("isRetriable - custom baseURL with status code: "+t+", isRetriable - true"),!0;var i=e.ext.rejected_by_glide;if(i&&(f.addWarnMessage("isRetriable - rejected_by_glide : "+i+", glide.amb.reply.status.code : "+t),!isNaN(t)))return t==u||t==a}return f.debug("isRetriable -  "+!1),!1}function N(){var n=Math.min(e.getSize(),function(){return b(t.getTokenCount(),0,i.default.subscribeCommandsFlow.maxInflight)}());f.debug("processQueue - numberToProcess : "+n),n>0&&(e.dequeueMultiple(n).forEach(function(e){return(0,o.isNil)(e)||e()}),m(!1))}return{subscribeToChannel:function(e){return f.debug("subscribeToChannel - to : "+e.getName()),S(e)},unsubscribeToChannel:function(e){return f.debug("unsubscribeToChannel - from : "+e.getName()),E(e)},stop:function(){f.debug("stop"),function(){f.debug("signalStop - stopping : "+g),g||(g=!0,v(),e.clear())}()},isStopping:function(){return g},getQueue:function(){return e},isBucketEmpty:function(){return!p()},getTimerObject:function(){return h},getTokenCountFromTokenManager:function(){return t.getTokenCount()},isRetriable:w}};t.default=a},function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i=r(n(0)),o=r(n(1));function r(e){return e&&e.__esModule?e:{default:e}}function s(e,t){var n="undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(!n){if(Array.isArray(e)||(n=function(e,t){if(!e)return;if("string"==typeof e)return a(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);"Object"===n&&e.constructor&&(n=e.constructor.name);if("Map"===n||"Set"===n)return Array.from(e);if("Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return a(e,t)}(e))||t&&e&&"number"==typeof e.length){n&&(e=n);var i=0,o=function(){};return{s:o,n:function(){return i>=e.length?{done:!0}:{done:!1,value:e[i++]}},e:function(e){throw e},f:o}}throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}var r,s=!0,u=!1;return{s:function(){n=n.call(e)},n:function(){var e=n.next();return s=e.done,e},e:function(e){u=!0,r=e},f:function(){try{s||null==n.return||n.return()}finally{if(u)throw r}}}}function a(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,i=new Array(t);n<t;n++)i[n]=e[n];return i}var u=function(e){var t={},n=new i.default("amb.TransportManagement");return t.isPruningEnabled=function(){return"false"!==o.default.pruneFailedTransports},t.processConnectionOpened=function(){this.isPruningEnabled()&&(n.debug("Processing connection opened"),this.removeSkippedTransportsInConnect())},t.removeSkippedTransportsInConnect=function(){var t=null===e.getTransport()?null:e.getTransport().getType();if(n.addInfoMessage("Connected using transport "+t),n.debug("Purging failed transports from registry..."),null!==t){var i,o=[],r=s(e.getTransportTypes());try{for(r.s();!(i=r.n()).done;){var a=i.value;if(a==t)break;e.unregisterTransport(a),o.push(a)}}catch(e){r.e(e)}finally{r.f()}n.addInfoMessage("Removed failed registry transports after connect: {"+o+"}")}},t};t.default=u}]);
/*! RESOURCE: /scripts/glide_amb_get_client.js */
amb.getClient();
;
;
/*! RESOURCE: /scripts/js_includes_amb.js */
/*! RESOURCE: /scripts/app.ng.amb/app.ng.amb.js */
angular.module("ng.amb", ['sn.common.presence', 'sn.common.util'])
	.value("ambLogLevel", 'info')
.value("ambServletURI", '/amb')
	.value("cometd", angular.element.cometd)
	.value("ambLoginWindow", 'true');
;
/*! RESOURCE: /scripts/app.ng.amb/service.AMB.js */
angular.module("ng.amb").service("amb", function (AMBOverlay, $window, $q, $log, $rootScope, $timeout) {
  "use strict";
  var ambClient = null;
  var _window = $window.self;
  var loginWindow = null;
	var sameScope = false;
	ambClient = amb.getClient();
	if (_window.g_ambClient) {
		sameScope = true;
	}
	if (sameScope) {
	  var serverConnection = ambClient.getServerConnection();
	  serverConnection.loginShow = function() {
	    if (!serverConnection.isLoginWindowEnabled())
	      return;
	    if (loginWindow && loginWindow.isVisible())
	      return;
	    if (serverConnection.isLoginWindowOverride())
	      return;
	  	var modalConfig = {
	  		onBeforeShow: addOverrideStyles
		};
	    loginWindow = new AMBOverlay(modalConfig);
	    loginWindow.render();
	    loginWindow.show();
	  };
	  serverConnection.loginHide = function() {
	    if (!loginWindow)
	      return;
	    loginWindow.hide();
	    loginWindow.destroy();
	    loginWindow = null;
	  }
	}
	function addOverrideStyles(el) {
		var parent = angular.element(el.target).parent();
		var backdrop = parent.find('.modal-backdrop').last().get(0);
		if (backdrop !== undefined)
			backdrop.style.cssText = [backdrop.style.cssText, serverConnection.getLoginWindowOverlayStyle()].join('; ');
	}
	var AUTO_CONNECT_TIMEOUT = 20 * 1000;
	var connected = $q.defer();
	var connectionInterrupted = false;
	var monitorAMB = false;
	$timeout(startMonitoringAMB, AUTO_CONNECT_TIMEOUT);
	connected.promise.then(startMonitoringAMB);
	function startMonitoringAMB() {
		monitorAMB = true;
	}
	function ambInterrupted() {
		var state = ambClient.getState();
		return monitorAMB && state !== "opened" && state !== "initialized"
	}
	var interruptionTimeout;
	var extendedInterruption = false;
	function setInterrupted(eventName) {
		connectionInterrupted = true;
		$rootScope.$broadcast(eventName);
		if (!interruptionTimeout) {
			interruptionTimeout = $timeout(function () {
				extendedInterruption = true;
			}, 30 * 1000)
		}
		connected = $q.defer();
	}
  var connectOpenedEventId = ambClient.subscribeToEvent("connection.opened", function () {
		$rootScope.$broadcast("amb.connection.opened");
		if (interruptionTimeout) {
			$timeout.cancel(interruptionTimeout);
			interruptionTimeout = null;
		}
		extendedInterruption = false;
		if(connectionInterrupted) {
			connectionInterrupted = false;
			$rootScope.$broadcast("amb.connection.recovered");
		}
		connected.resolve();
  });
  var connectClosedEventId = ambClient.subscribeToEvent("connection.closed", function () {
		setInterrupted("amb.connection.closed");
  });
  var connectBrokenEventId = ambClient.subscribeToEvent("connection.broken", function () {
		setInterrupted("amb.connection.broken");
  });
  var connectSessionLoggedin = ambClient.subscribeToEvent("session.logged.in", function () {
	  $rootScope.$broadcast("amb.session.logged.in");
  });
  var connectSessionReestablished = ambClient.subscribeToEvent("session.reestablished", function () {
	  $rootScope.$broadcast("amb.session.reestablished");
  });
	var onUnloadWindow = function() {
		ambClient.unsubscribeFromEvent(connectOpenedEventId);
		ambClient.unsubscribeFromEvent(connectClosedEventId);
		ambClient.unsubscribeFromEvent(connectBrokenEventId);
		angular.element($window).off('unload', onUnloadWindow);
	};
	angular.element($window).on('unload', onUnloadWindow);
	var defaultAmbConnectionTimeout = 10000;
	var shouldDeferAmbConnection = _window.NOW && _window.NOW.hasOwnProperty('deferAmbConnection') ?
		_window.NOW.deferAmbConnection : false;
	var deferredAmbConnectionTimeout = _window.NOW && _window.NOW.hasOwnProperty('deferredAmbConnectionTimeout') &&
		isValidAmbConnectionTimeout(_window.NOW.deferredAmbConnectionTimeout) ?
		_window.NOW.deferredAmbConnectionTimeout :
		defaultAmbConnectionTimeout;
	if (shouldDeferAmbConnection) {
		$timeout(autoConnect, deferredAmbConnectionTimeout);
	} else {
		var documentReadyState = _window.document ? _window.document.readyState : null;
		if (documentReadyState === 'complete')
			autoConnect();
		else
			_window.addEventListener('load', autoConnect);
		$timeout(autoConnect, defaultAmbConnectionTimeout);
	}
	function isInteger(num) {
		return parseInt(num, 10) === num;
	}
	function isValidAmbConnectionTimeout(timeout) {
		return isInteger(timeout) && timeout > 0;
	}
	var initiatedConnection = false;
	function autoConnect() {
		if (!initiatedConnection) {
			initiatedConnection = true;
			ambClient.connect();
		}
	}
	return {
		getServerConnection: function() {
			return ambClient.getServerConnection();
		},
		connect: function() {
			if (initiatedConnection) {
				ambClient.connect();
			}
			return connected.promise;
		},
		get interrupted() {
			return ambInterrupted();
		},
		get extendedInterruption() {
			return extendedInterruption;
		},
		get connected() {
			return connected.promise;
		},
		abort: function() {
			ambClient.abort();
		},
		disconnect: function() {
			ambClient.disconnect();
		},
		getConnectionState: function () {
			return ambClient.getConnectionState();
		},
		getClientId: function () {
			return ambClient.getClientId();
		},
		getChannel: function(channelName) {
			return ambClient.getChannel(channelName);
		},
		registerExtension: function(extensionName, extension) {
			ambClient.registerExtension(extensionName, extension);
		},
		unregisterExtension: function(extensionName) {
			ambClient.unregisterExtension(extensionName);
		},
		batch: function(batch) {
			ambClient.batch(batch);
		},
		getState: function() {
			return ambClient.getState();
		},
		getFilterString: function(filter) {
			filter = filter.
replace(/\^EQ/g, '').
replace(/\^ORDERBY(?:DESC)?[^^]*/g, '').
replace(/^GOTO/, '');
return btoa(unescape(encodeURIComponent(filter))).replace(/=/g, '-');
		},
		getChannelRW: function(table, filter) {
var t = '/rw/default/' + table + '/' + this.getFilterString(filter);
			return this.getChannel(t);
		},
		isLoggedIn: function() {
			return ambClient.isLoggedIn();
		},
		subscribeToEvent: function(event, callback) {
			return ambClient.subscribeToEvent(event, callback);
		},
		getConnectionEvents: function() {
			return ambClient.getConnectionEvents();
		},
		getEvents: function() {
			return ambClient.getConnectionEvents();
		},
		loginComplete: function() {
			ambClient.loginComplete();
		}
	};
});
;
/*! RESOURCE: /scripts/app.ng.amb/controller.AMBRecordWatcher.js */
angular.module("ng.amb").controller("AMBRecordWatcher", function($scope, $timeout, $window) {
	"use strict";
	var amb = $window.top.g_ambClient;
	$scope.messages = [];
	var lastFilter;
	var watcherChannel;
	var watcher;
	function onMessage(message) {
		$scope.messages.push(message.data);
	}
	$scope.getState = function() {
		return amb.getState();
	};
	$scope.initWatcher = function() {
		angular.element(":focus").blur();
		if(!$scope.filter || $scope.filter === lastFilter)
			return;
		lastFilter = $scope.filter;
		console.log("initiating watcher on " + $scope.filter);
		$scope.messages = [];
		if(watcher) {
			watcher.unsubscribe();
		}
var base64EncodeQuery = btoa($scope.filter).replace(/=/g, '-');
var channelId = '/rw/' + base64EncodeQuery;
		watcherChannel = amb.getChannel(channelId)
		watcher = watcherChannel.subscribe(onMessage);
	};
	amb.connect();
})
;
/*! RESOURCE: /scripts/app.ng.amb/factory.snRecordWatcher.js */
angular.module("ng.amb").factory('snRecordWatcher', function($rootScope, amb, $timeout, snPresence, $log, urlTools) {
	"use strict";
var diagnosticLog = true;
	function initWatcher(table, sys_id, query) {
		if (!table)
			return;
		if (sys_id)
			var filter = "sys_id=" + sys_id;
		else
			filter = query;
		if (!filter)
			return;
		return initChannel(table, filter);
	}
	function initList(table, query) {
		if (!table)
			return;
		query = query || "sys_idISNOTEMPTY";
		return initChannel(table, query);
	}
	function initTaskList(list, prevChannel) {
		if (prevChannel)
			prevChannel.unsubscribe();
		var sys_ids = list.toString();
		var filter = "sys_idIN" + sys_ids;
		return initChannel("task", filter);
	}
	function initChannel(table, filter, callbackFn) {
		if (isBlockedTable(table)) {
			$log.log("Blocked from watching", table);
			return null;
		}
		if (diagnosticLog)
			log(">>> init " + table + "?" + filter);
		var watcherChannel = amb.getChannelRW(table, filter);
		watcherChannel.subscribe(callbackFn || onMessage);
		amb.connect();
		return watcherChannel;
	}
	function onMessage(message) {
		var r = message.data;
		var c = message.channel;
		if (diagnosticLog)
			log(">>> record " + r.operation + ": " + r.table_name + "." + r.sys_id + " " + r.display_value);
		$rootScope.$broadcast('record.updated', r);
		$rootScope.$broadcast('list.updated', r, c);
	}
	function log(message) {
		$log.log(message);
	}
	function isBlockedTable(table) {
		return table == 'sys_amb_message' || table.startsWith('sys_rw');
	}
	return {
		initTaskList: initTaskList,
		initChannel: initChannel,
		init: function () {
			var location = urlTools.parseQueryString(window.location.search);
			var table = location['table'] || location['sysparm_table'];
			var sys_id = location['sys_id'] || location['sysparm_sys_id'];
			var query = location['sysparm_query'];
			initWatcher(table, sys_id, query);
			snPresence.init(table, sys_id, query);
		},
		initList:  initList,
		initRecord: function(table, sysId) {
			initWatcher(table, sysId, null);
			snPresence.initPresence(table, sysId);
		},
		_initWatcher: initWatcher
	}
});
;
/*! RESOURCE: /scripts/app.ng.amb/factory.AMBOverlay.js */
angular.module("ng.amb").factory("AMBOverlay", function($templateCache, $compile, $rootScope, i18n) {
	"use strict";
	var showCallbacks = [],
		beforeShowCallbacks = [],
		hideCallbacks = [],
		isRendered = false,
		modal,
		modalScope,
		modalOptions;
	var defaults = {
backdrop: 'static',
keyboard: false,
show: true
		};
	function AMBOverlay(config) {
		config = config || {};
		if(angular.isFunction(config.onBeforeShow))
			beforeShowCallbacks.push(config.onBeforeShow);
		if(angular.isFunction(config.onShow))
			showCallbacks.push(config.onShow);
		if(angular.isFunction(config.onHide))
			hideCallbacks.push(config.onHide);
		i18n.getMessage("Login", function(msg) {
			config.loginMessage = msg;
		});
		function lazyRender() {
			if(!angular.element('html')['modal']) {
var bootstrapInclude = "/scripts/bootstrap3/bootstrap.js";
				ScriptLoader.getScripts([bootstrapInclude], renderModal);
			} else
				renderModal();
		}
		function renderModal() {
			if(isRendered)
				return;
			modalScope = angular.extend($rootScope.$new(), config);
			modal = $compile($templateCache.get("amb_disconnect_modal.xml"))(modalScope);
			angular.element("body").append(modal);
			modal.on("show.bs.modal", function (e) {
				for(var i = 0, len = beforeShowCallbacks.length; i < len; i++)
					beforeShowCallbacks[i](e);
			});
			modal.on("shown.bs.modal", function(e) {
				for(var i = 0, len = showCallbacks.length; i < len; i++)
					showCallbacks[i](e);
			});
			modal.on("hidden.bs.modal", function(e) {
				for(var i = 0, len = hideCallbacks.length; i < len; i++)
					hideCallbacks[i](e);
			});
			modalOptions = angular.extend({}, defaults, config);
			modal.modal(modalOptions);
			isRendered = true;
		}
		function showModal() {
			if(isRendered)
				modal.modal('show');
		}
		function hideModal() {
			if(isRendered)
				modal.modal('hide');
		}
		function destroyModal() {
			if(!isRendered)
				return;
			modal.modal('hide');
			modal.remove();
			modalScope.$destroy();
			modalScope = void(0);
			isRendered = false;
			var pos = showCallbacks.indexOf(config.onShow);
			if(pos >= 0)
				showCallbacks.splice(pos, 1);
			pos = hideCallbacks.indexOf(config.onShow);
			if(pos >= 0)
				hideCallbacks.splice(pos, 1);
		}
		return {
			render: lazyRender,
			destroy: destroyModal,
			show: showModal,
			hide: hideModal,
			isVisible: function() {
				if(!isRendered)
					return false;
				return modal.visible();
			}
		}
	}
	$templateCache.put('amb_disconnect_modal.xml',
		'<div id="amb_disconnect_modal" tabindex="-1" aria-hidden="true" class="modal" role="dialog">' +
		'	<div class="modal-dialog small-modal" style="width:450px">' +
		'		<div class="modal-content">' +
		'			<header class="modal-header">' +
'				<h4 id="small_modal1_title" class="modal-title">{{loginMessage}}</h4>' +
'			</header>' +
		'			<div class="modal-body">' +
'			<iframe class="concourse_modal" ng-src=\'{{iframe || "/amb_login.do"}}\' frameborder="0" height="400px" width="405px"></iframe>' +
'			</div>' +
'		</div>' +
'	</div>' +
'</div>'
	);
	return AMBOverlay;
});
;
;
/*! RESOURCE: /scripts/js_includes_ng_amb.js */
/*! RESOURCE: /scripts/sn/common/presence/snPresenceLite.js */
(function(exports, $) {
	'use strict';
	var PRESENCE_DISABLED = "false" === "true";
	if (PRESENCE_DISABLED) {
		return;
	}
	if (typeof $.Deferred === "undefined") {
		return;
	}
	var USER_KEY = '{{SYSID}}';
	var REPLACE_REGEX = new RegExp(USER_KEY, 'g');
	var COLOR_ONLINE = '#71e279';
	var COLOR_AWAY = '#fc8a3d';
	var COLOR_OFFLINE = 'transparent';
	var BASE_STYLES = [
		'.sn-presence-lite { display: inline-block; width: 1rem; height: 1rem; border-radius: 50%; }'
	];
	var USER_STYLES = [
		'.sn-presence-'+ USER_KEY +'-online [data-presence-id="'+ USER_KEY +'"] { background-color: '+ COLOR_ONLINE +'; }',
		'.sn-presence-'+ USER_KEY +'-away [data-presence-id="'+ USER_KEY +'"] { background-color: '+ COLOR_AWAY +'; }',
		'.sn-presence-'+ USER_KEY +'-offline [data-presence-id="'+ USER_KEY +'"] { background-color: '+ COLOR_OFFLINE +'; }'
	];
	var $head = $('head');
	var stylesheet = $.Deferred();
	var registeredUsers = {};
	var registeredUsersLength = 0;
	$(function() {
		updateRegisteredUsers();
	});
	$head.ready(function() {
	    var styleElement = document.createElement('style');
	    $head.append(styleElement);
		var $styleElement = $(styleElement);
	    stylesheet.resolve($styleElement);
	});
	function updateStyles(styles) {
	    stylesheet.done(function($styleElement) {
	        $styleElement.empty();
	        BASE_STYLES.forEach(function(baseStyle) {
	            $styleElement.append(baseStyle);
	        });
	        $styleElement.append(styles);
	    });
	}
	function getUserStyles(sysId) {
		var newStyles = '';
		for (var i = 0, iM = USER_STYLES.length; i < iM; i++) {
			newStyles += USER_STYLES[i].replace(REPLACE_REGEX, sysId);
		}
		return newStyles;
	}
	function updateUserStyles() {
		var userKeys = Object.keys(registeredUsers);
		var userStyles = "";
		userKeys.forEach(function(userKey) {
			userStyles += getUserStyles(userKey);
		});
		updateStyles(userStyles);
	}
	exports.applyPresenceArray = applyPresenceArray;
	function applyPresenceArray(presenceArray) {
		if (!presenceArray || !presenceArray.length) {
			return;
		}
		var users = presenceArray.filter(function(presence) {
			return typeof registeredUsers[presence.user] !== "undefined";
		});
		updateUserPresenceStatus(users);
	}
	function updateUserPresenceStatus(users) {
		var presenceStatus = getBaseCSSClasses();
		for (var i = 0, iM = users.length; i < iM; i++) {
			var presence = users[i];
			var status = getNormalizedStatus(presence.status);
			if (status === 'offline') {
				continue;
			}
			presenceStatus.push('sn-presence-' + presence.user + '-' + status);
		}
		setCSSClasses(presenceStatus.join(' '));
	}
	function getNormalizedStatus(status) {
		switch (status) {
			case 'probably offline':
			case 'maybe offline':
				return 'away';
			default:
				return 'offline';
			case 'online':
			case 'offline':
				return status;
		}
	}
	function updateRegisteredUsers() {
		var presenceIndicators = document.querySelectorAll('[data-presence-id]');
		var obj = {};
		for (var i = 0, iM = presenceIndicators.length; i < iM; i++) {
			var uid = presenceIndicators[i].getAttribute('data-presence-id');
			obj[uid] = true;
		}
		if (Object.keys(obj).length === registeredUsersLength){
			return;
		}
		registeredUsers = obj;
		registeredUsersLength = Object.keys(registeredUsers).length;
		updateUserStyles();
	}
	function setCSSClasses(classes) {
		$('html')[0].className = classes;
	}
	function getBaseCSSClasses() {
		return $('html')[0].className.split(' ').filter(function(item){
			return item.indexOf('sn-presence-') !== 0;
		});
	}
})(window, window.jQuery || window.Zepto);
;
/*! RESOURCE: /scripts/sn/common/presence/_module.js */
angular.module('sn.common.presence', ['ng.amb', 'sn.common.glide', 'sn.common.auth']).config(function($provide) {
	"use strict";
	$provide.constant("PRESENCE_DISABLED", "false" === "true");
});
;
/*! RESOURCE: /scripts/sn/common/presence/factory.snPresence.js */
angular.module("sn.common.presence").factory('snPresence', function($rootScope, $window, $log, amb, $timeout, $http, snRecordPresence, snTabActivity, urlTools, PRESENCE_DISABLED) {
	"use strict";
	var REST = {
PRESENCE: "/api/now/ui/presence"
	};
	var RETRY_INTERVAL = ($window.NOW.presence_interval || 60) * 1000;
	var MAX_RETRY_DELAY = RETRY_INTERVAL * 10;
var initialized = false;
var primary = false;
	var presenceArray = [];
	var serverTimeMillis;
	var skew = 0;
var st = 0;
	var _suspendWatch = false;
	function init() {
		var location = urlTools.parseQueryString($window.location.search);
		var table = location['table'] || location['sysparm_table'];
		var sys_id = location['sys_id'] || location['sysparm_sys_id'];
		return initPresence(table, sys_id);
	}
	function initPresence(t, id) {
		if(PRESENCE_DISABLED)
			return;
		if (!initialized) {
			initialized = true;
initRootScopes();
			if (!primary) {
				CustomEvent.observe('sn.presence', onPresenceEvent);
				CustomEvent.fireTop('sn.presence.ping');
			} else {
				presenceArray = getLocalPresence($window.localStorage.getItem('snPresence'));
				if (presenceArray)
$timeout(schedulePresence, 100);
	 			else
					updatePresence();
			}
		}
		return snRecordPresence.initPresence(t, id);
	}
	function isTopWindow() {
		var topWindow = window.self;
		try {
			while (topWindow.CustomEvent.fireEvent
				&& topWindow !== topWindow.parent
				&& !topWindow.parent.NOW.isPolarisWrapper
				&& topWindow.parent.CustomEvent.fireEvent) {
					topWindow = topWindow.parent;
				}
		} catch (e) {}
		return topWindow == window.self;
	}
	function onPresenceEvent(parms) {
		presenceArray = parms;
		$timeout(broadcastPresence);
	}
	function initRootScopes() {
		if ($window.NOW.presence_scopes) {
			var ps = $window.NOW.presence_scopes;
			if (ps.indexOf($rootScope) == -1)
				ps.push($rootScope);
		} else {
			$window.NOW.presence_scopes = [$rootScope];
			primary = isTopWindow();
		}
	}
	function setPresence(data, st) {
var rt = new Date().getTime() - st;
		if (rt > 500)
			console.log("snPresence response time " + rt + "ms");
		if (data.result && data.result.presenceArray) {
			presenceArray = data.result.presenceArray;
			setLocalPresence(presenceArray);
			serverTimeMillis = data.result.serverTimeMillis;
			skew = new Date().getTime() - serverTimeMillis;
var t  = Math.floor(skew / 1000);
			if (t < -15 )
				console.log(">>>>> server ahead " + Math.abs(t) + " seconds");
			else if (t > 15)
				console.log(">>>>> browser time ahead " + t + " seconds");
		}
		schedulePresence();
	}
	function updatePresence(numAttempts) {
		presenceArray = getLocalPresence($window.localStorage.getItem('snPresence'));
		if (presenceArray) {
			determineStatus(presenceArray);
$timeout(schedulePresence);
			return;
		}
		if (!amb.isLoggedIn() || !snTabActivity.isPrimary) {
			$timeout(schedulePresence);
			return;
		}
		var p = {
				user_agent: navigator.userAgent,
				ua_time: new Date().toISOString(),
				href: window.location.href,
				pathname: window.location.pathname,
				search: window.location.search,
				path: window.location.pathname + window.location.search
			};
		st = new Date().getTime();
		$http.post(REST.PRESENCE + '?sysparm_auto_request=true&cd=' + st, p).success(function(data) {
			setPresence(data, st);
		}).error(function(response, status) {
			console.log("snPresence " + status);
			schedulePresence(numAttempts);
		})
	}
	function schedulePresence(numAttempts) {
		numAttempts = isFinite(numAttempts) ? numAttempts + 1 : 0;
		var interval = getDecayingRetryInterval(numAttempts);
		$timeout(function() {
			updatePresence(numAttempts)
		}, interval);
		determineStatus(presenceArray);
		broadcastPresence();
	}
	function broadcastPresence() {
		if (angular.isDefined($window.applyPresenceArray)) {
			$window.applyPresenceArray(presenceArray);
		}
		$rootScope.$emit("sn.presence", presenceArray);
		if (!primary)
			return;
		CustomEvent.fireAll('sn.presence', presenceArray);
	}
	function determineStatus(presenceArray) {
		if (!presenceArray || !presenceArray.forEach)
			return;
		var t = new Date().getTime();
		t -= skew;
		presenceArray.forEach(function (p) {
			var x = 0 + p.last_on;
			var y = t - x;
			p.status = "online";
			if (y > (5 * RETRY_INTERVAL))
				p.status = "offline";
			else if (y > (3 * RETRY_INTERVAL))
				p.status = "probably offline";
			else if (y > (2.5 * RETRY_INTERVAL))
				p.status = "maybe offline";
		})
	}
	function setLocalPresence(value) {
		var p = {
			saved: new $window.Date().getTime(),
			presenceArray: value
		};
		$window.localStorage.setItem('snPresence', angular.toJson(p));
	}
	function suspendWatch(flag) {
		if (flag !== undefined)
			_suspendWatch = flag;
		return _suspendWatch;
	}
	function getLocalPresence(p) {
		if (!p)
			return null;
		try {
			p = angular.fromJson(p);
		} catch (e) {
			p = {};
		}
		if (!p.presenceArray)
			return null;
		var now = new Date().getTime();
		if (now - p.saved >= RETRY_INTERVAL)
			return null;
		return p.presenceArray;
	}
	function getDecayingRetryInterval(numAttempts) {
		return Math.min(RETRY_INTERVAL * Math.pow(2, numAttempts), MAX_RETRY_DELAY);
	}
	return {
		init: init,
		initPresence: initPresence,
		suspendWatch: suspendWatch,
		_getLocalPresence: getLocalPresence,
		_setLocalPresence: setLocalPresence,
		_determineStatus: determineStatus
	}
});
;
/*! RESOURCE: /scripts/sn/common/presence/factory.snRecordPresence.js */
angular.module("sn.common.presence").factory('snRecordPresence', function($rootScope, $location, amb, $timeout, $window, PRESENCE_DISABLED, snTabActivity) {
	"use strict";
	var statChannel;
var interval = ($window.NOW.record_presence_interval || 20) * 1000;
	var sessions = {};
	var primary = false;
	var currentJournalFieldName = "";
	var prevJournalFieldName = "";
	
	var table;
	var sys_id;
	
	function initPresence(t, id) {
		if(PRESENCE_DISABLED)
			return;
		if (!t || !id)
			return;
		if (t == table && id == sys_id)
			return;  
		initRootScopes();
		if (!primary) 
			return; 
		
		termPresence();
		table = t;
		sys_id = id;
var recordPresence = "/sn/rp/" + table + "/" + sys_id;
		$rootScope.me = NOW.session_id;
		statChannel = amb.getChannel(recordPresence);
		statChannel.subscribe(onStatus);
		amb.connected.then(function() {
			setStatus("entered");
			$rootScope.status = "viewing";
		});
		return statChannel;
	}
	
	function initRootScopes() {
		if ($window.NOW.record_presence_scopes) {
			var ps = $window.NOW.record_presence_scopes;
			if (ps.indexOf($rootScope) == -1) {
				ps.push($rootScope);
				CustomEvent.observe('sn.sessions', onPresenceEvent);
			}
		} else {
			$window.NOW.record_presence_scopes = [$rootScope];
			primary = true;
		}
	}
	
	function onPresenceEvent(sessionsToSend) {
		$rootScope.$emit("sn.sessions", sessionsToSend);
		$rootScope.$emit("sp.sessions", sessionsToSend);
	}
	
	function termPresence() {
		if (!statChannel)
			return; 
		
		statChannel.unsubscribe();
		statChannel = table = sys_id = null;
	}
	function setStatus(status) {
		if (status == $rootScope.status && prevJournalFieldName === currentJournalFieldName) 
			return;
		
prevJournalFieldName = currentJournalFieldName;
		$rootScope.status = status;
		if (Object.keys(sessions).length == 0)
			return;
		if (getStatusPrecedence(status) > 1)
			return;
		publish($rootScope.status);
	}
	function publish(status) {
		if (!statChannel)
			return;
		if (amb.getState() !== "opened")
			return;
			
		statChannel.publish({ presences: [{
			status : status,
			session_id : NOW.session_id,
			user_name : NOW.user_name,
			user_id: NOW.user_id,
			user_display_name : NOW.user_display_name,
			user_initials : NOW.user_initials,
			user_avatar: NOW.user_avatar,
			ua : navigator.userAgent,
			table: table,
			sys_id: sys_id,
			field_type: currentJournalFieldName,
			time: new Date().toString().substring(0,24)
		}]});
	}
	function onStatus(message) {
		message.data.presences.forEach(function(d){
if (!d.session_id || d.session_id == NOW.session_id)
				return;
			var s = sessions[d.session_id];
			if (s)
				angular.extend(s, d);
			else
				s = sessions[d.session_id] = d;
			s.lastUpdated = new Date();
			if (s.status == 'exited')
delete sessions[d.session_id];
		});
		broadcastSessions();
	}
	function broadcastSessions() {
		var sessionsToSend = getUniqueSessions();
		$rootScope.$emit("sn.sessions", sessionsToSend);
		$rootScope.$emit("sp.sessions", sessionsToSend);
if (primary)
			$timeout(function() {CustomEvent.fire('sn.sessions', sessionsToSend);})
	}
	function getUniqueSessions() {
		var uniqueSessionsByUser = {};
		var sessionKeys = Object.keys(sessions);
		sessionKeys.forEach(function(key) {
			var session = sessions[key];
			if (session.user_id == NOW.user_id)
				return;
			if (session.user_id in uniqueSessionsByUser) {
				var otherSession = uniqueSessionsByUser[session.user_id];
				var thisPrecedence = getStatusPrecedence(session.status);
				var otherPrecedence = getStatusPrecedence(otherSession.status);
				uniqueSessionsByUser[session.user_id] = thisPrecedence < otherPrecedence ? session : otherSession;
				return
			}
			uniqueSessionsByUser[session.user_id] = session;
		});
		var uniqueSessions = {};
		angular.forEach(uniqueSessionsByUser, function(item) {
			uniqueSessions[item.session_id] = item;
		});
		return uniqueSessions;
	}
	function getStatusPrecedence(status) {
		switch (status) {
			case 'typing':
				return 0;
			case 'viewing':
				return 1;
			case 'entered':
				return 2;
			case 'exited':
			case 'probably left':
				return 4;
			case 'offline':
				return 5;
			default:
				return 3;
		}
	}
	
	$rootScope.$on("record.typing", function(evt, data) {
		currentJournalFieldName = data.field_type;
		setStatus(data.status);
	});
	var idleTable, idleSysID;
	snTabActivity.onIdle({
		onIdle: function RecordPresenceTabIdle() {
			idleTable = table;
			idleSysID = sys_id;
			sessions = {};
			termPresence();
			broadcastSessions();
		},
		onReturn: function RecordPresenceTabActive() {
			initPresence(idleTable, idleSysID, true);
			idleTable = idleSysID = void(0);
		},
		delay: interval * 4
	});
	
	return {
		initPresence: initPresence,
		termPresence: termPresence
	}
});
;
/*! RESOURCE: /scripts/sn/common/presence/directive.snPresence.js */
angular.module('sn.common.presence').directive('snPresence', function(snPresence, $rootScope, $timeout, i18n) {
	'use strict';
	if (!snPresence.suspendWatch())
$timeout(snPresence.init, 100);
var presenceStatus = {};
	i18n.getMessages(['maybe offline', 'probably offline', 'offline', 'online', 'entered', 'viewing'], function (results) {
		presenceStatus.maybe_offline = results['maybe offline'];
		presenceStatus.probably_offline = results['probably offline'];
		presenceStatus.offline = results['offline'];
		presenceStatus.online = results['online'];
		presenceStatus.entered = results['entered'];
		presenceStatus.viewing = results['viewing'];
	});
	var presences = {};
	$rootScope.$on('sn.presence', function (event, presenceArray) {
		angular.forEach(presences, function (p) {
			p.status = "offline";
		});
if (!presenceArray) {
			return;
		}
		presenceArray.forEach(function (presence) {
			presences[presence.user] = presence;
		});
	});
	return {
		restrict: 'EA',
		replace: false,
		scope: {
			userId: '@?',
			snPresence: '=?',
			user: '=?',
			profile: '=?',
			displayName: '=?',
			onPresenceChange: '&'
		},
		link: function (scope, element) {
			if (scope.profile) {
				scope.user = scope.profile.userID;
				scope.profile.tabIndex = -1;
				if (scope.profile.isAccessible)
					scope.profile.tabIndex = 0;
			}
			if (!element.hasClass('presence'))
				element.addClass('presence');
			function updatePresence () {
				var id = scope.snPresence || scope.user;
				if (!angular.isDefined(id) && angular.isDefined(scope.userId)) {
					id = scope.userId;
				}
				if (presences[id]) {
					var status = presences[id].status;
					if (status === 'maybe offline' || status === 'probably offline') {
						element.removeClass('presence-online presence-offline presence-away');
						element.addClass('presence-away');
						scope.onPresenceChange({"status": presenceStatus.away});
					} else if (status == "offline" && !element.hasClass('presence-offline')) {
						element.removeClass('presence-online presence-away');
						element.addClass('presence-offline');
						scope.onPresenceChange({"status": presenceStatus.offline});
					} else if ( (status == "online" || status == "entered" || status == "viewing") && !element.hasClass('presence-online')) {
						element.removeClass('presence-offline presence-away');
						element.addClass('presence-online');
						scope.onPresenceChange({"status": presenceStatus.online});
					}
status = status.replace(/ /g,"_");
					if (scope.profile)
						angular.element('div[user-avatar-id="' + id + '"]').attr("aria-label", scope.profile.userName + ' ' + presenceStatus[status]);
					else
						angular.element('div[user-avatar-id="' + id + '"]').attr("aria-label", scope.displayName + ' ' + presenceStatus[status]);
				} else {
					if (!element.hasClass('presence-offline'))
						element.addClass('presence-offline');
					    scope.onPresenceChange({"status": presenceStatus.offline});
				}
			}
			var unbind = $rootScope.$on('sn.presence', updatePresence);
			scope.$on('$destroy', unbind);
			updatePresence();
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/presence/directive.snComposing.js */
angular.module('sn.common.presence').directive('snComposing', function(getTemplateUrl, snComposingPresence) {
	"use strict";
	return {
		restrict: 'E',
		templateUrl: getTemplateUrl("snComposing.xml"),
		replace: true,
		scope: {
			conversation: "="
		},
		controller: function($scope, $element) {
			var child = $element.children();
			if (child && child.tooltip)
				child.tooltip({
'template':	'<div class="tooltip" style="white-space: pre-wrap" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',
					'placement': 'top',
					'container': 'body'
					});
			$scope.snComposingPresence = snComposingPresence;
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/presence/service.snComposingPresence.js */
angular.module('sn.common.presence').service('snComposingPresence', function(i18n) {
	"use strict";
	var viewing = {};
	var typing = {};
	var allStrings = {};
	var shortStrings = {};
	var typing1="{0} is typing", typing2="{0} and {1} are typing", typingMore="{0}, {1}, and {2} more are typing", viewing1="{0} is viewing",viewing2="{0} and {1} are viewing",viewingMore="{0}, {1}, and {2} more are viewing";
	i18n.getMessages(
		[
			typing1,
			typing2,
			typingMore,
			viewing1,
			viewing2,
			viewingMore
			],
		function (results) {
			typing1=results[typing1];
			typing2=results[typing2];
			typingMore=results[typingMore];
			viewing1=results[viewing1];
			viewing2=results[viewing2];
			viewingMore=results[viewingMore];
		});
	function set(conversationID, newPresenceValues) {
		if (newPresenceValues.viewing)
			viewing[conversationID] = newPresenceValues.viewing;
		if (newPresenceValues.typing)
			typing[conversationID] = newPresenceValues.typing;
		generateAllString(conversationID, {viewing: viewing[conversationID],typing: typing[conversationID]});
		generateShortString(conversationID, {viewing: viewing[conversationID],typing: typing[conversationID]});
		return {
			viewing: viewing[conversationID],
			typing: typing[conversationID]
		}
	}
	function get(conversationID) {
		return {
			viewing: viewing[conversationID] || [],
			typing: typing[conversationID] || []
		}
	}
	function generateAllString(conversationID, members) {
		var result = "";
		var typingLength = members.typing.length;
		var viewingLength = members.viewing.length;
		if (typingLength < 4 && viewingLength < 4)
			return "";
		switch (typingLength) {
			case 0:
				break;
			case 1:
				result += i18n.format(typing1, members.typing[0].name); break;
			case 2:
				result += i18n.format(typing2, members.typing[0].name, members.typing[1].name); break;
			default:
				var allButLastTyper = "";
				for (var i = 0; i < typingLength; i++) {
					if (i < typingLength -2)
						allButLastTyper += members.typing[i].name + ", ";
					else if (i === typingLength-2)
						allButLastTyper += members.typing[i].name + ",";
					else
						result += i18n.format(typing2, allButLastTyper, members.typing[i].name);
				}
		}
		if (viewingLength > 0 && typingLength > 0)
			result += "\n\n";
		switch (viewingLength) {
			case 0:
				break;
			case 1:
				result += i18n.format(viewing1, members.viewing[0].name); break;
			case 2:
				result += i18n.format(viewing2, members.viewing[0].name, members.viewing[1].name); break;
			default:
				var allButLastViewer = "";
				for (var i = 0; i < viewingLength; i++) {
					if (i < viewingLength -2)
						allButLastViewer += members.viewing[i].name + ", ";
					else if (i === viewingLength - 2)
						allButLastViewer += members.viewing[i].name + ",";
					else
						result += i18n.format(viewing2, allButLastViewer, members.viewing[i].name);
				}
		}
		allStrings[conversationID] = result;
	}
	function generateShortString(conversationID, members) {
		var typingLength = members.typing.length;
		var viewingLength = members.viewing.length;
		var typingString = "", viewingString = "";
		var inBetween = " ";
		switch (typingLength ) {
			case 0:
				break;
			case 1:
				typingString = i18n.format(typing1, members.typing[0].name); break;
			case 2:
				typingString = i18n.format(typing2, members.typing[0].name, members.typing[1].name); break;
			case 3:
				typingString = i18n.format(typing2, members.typing[0].name + ", " + members.typing[1].name + ",",members.typing[2].name); break;
			default:
				typingString = i18n.format(typingMore, members.typing[0].name, members.typing[1].name, (typingLength - 2));
		}
		if (viewingLength > 0 && typingLength > 0)
			 inBetween = ". ";
		switch (viewingLength) {
			case 0:
				break;
			case 1:
				viewingString = i18n.format(viewing1,  members.viewing[0].name); break;
			case 2:
				viewingString = i18n.format(viewing2, members.viewing[0].name, members.viewing[1].name); break;
			case 3:
				viewingString = i18n.format(viewing2, members.viewing[0].name + ", " + members.viewing[1].name + ",", members.viewing[2].name); break;
			default:
				viewingString = i18n.format(viewingMore, members.viewing[0].name, members.viewing[1].name, (viewingLength - 2));
		}
		shortStrings[conversationID] = typingString + inBetween + viewingString;
	}
	function getAllString(conversationID) {
		if ((viewing[conversationID] && viewing[conversationID].length > 3)
			|| (typing[conversationID] && typing[conversationID].length > 3))
			return allStrings[conversationID];
		return "";
	}
	function getShortString(conversationID) {
		return shortStrings[conversationID];
	}
	function remove(conversationID) {
		delete viewing[conversationID];
	}
	return {
		set: set,
		get: get,
		generateAllString: generateAllString,
		getAllString: getAllString,
		generateShortString: generateShortString,
		getShortString: getShortString,
		remove: remove
	}
});
;
;
/*! RESOURCE: /scripts/sn/common/presence/js_includes_presence.js */
/*! RESOURCE: /scripts/sn/common/user_profile/_module.js */
angular.module("sn.common.user_profile", ['sn.common.ui']);
;
/*! RESOURCE: /scripts/sn/common/user_profile/directive.snUserProfile.js */
angular.module('sn.common.user_profile').directive('snUserProfile', function(getTemplateUrl, snCustomEvent, $window, avatarProfilePersister, $timeout, $http, $injector) {
	"use strict";
	return {
		replace: true,
		restrict: 'E',
		templateUrl: getTemplateUrl('snUserProfile.xml'),
		scope: {
			profile: "=",
			showDirectMessagePrompt: "="
		},
		link: function(scope, element) {
			scope.showDirectMessagePromptFn = function() {
				if ($injector.has('inSupportClient') && $injector.get('inSupportClient'))
					return false;
				if (scope.showDirectMessagePrompt) {
					var activeUserID = $window.NOW.user_id || "";
					return !(!scope.profile
						|| activeUserID === scope.profile.sysID
						|| !scope.profile.hasConnectRoles
						|| (scope.profile.document && activeUserID === scope.profile.document));
				} else {
					return false;
				}
			};
		},
		controller: function($scope, snConnectService) {
			if ($scope.profile && $scope.profile.userID && avatarProfilePersister.getAvatar($scope.profile.userID)) {
				$scope.profile = avatarProfilePersister.getAvatar($scope.profile.userID);
				$scope.$emit("sn-user-profile.ready");
			} else {
$http.get('/api/now/live/profiles/sys_user.' + $scope.profile.userID).then(function (response) {
					angular.merge($scope.profile, response.data.result);
					avatarProfilePersister.setAvatar($scope.profile.userID, $scope.profile);
					$scope.$emit("sn-user-profile.ready");
				})
			}
$http.get('/api/now/live/profiles/' + $scope.profile.userID + '/has_connect_roles').then(function(response) {
				$scope.profile.hasConnectRoles = response.data.result.hasConnectRoles;
			});
			$scope.openDirectMessageConversation = function(evt) {
				if (evt && evt.keyCode === 9)
					return;
				$timeout(function () {
					snConnectService.openWithProfile($scope.profile);
				}, 0, false);
				angular.element('.popover').each(function() {
					angular.element('body').off('click.snUserAvatarPopoverClose');
					angular.element(this).popover('hide');
				});
			};
		}
	};
});
;
;
/*! RESOURCE: /scripts/sn/common/user_profile/js_includes_user_profile.js */
/*! RESOURCE: /scripts/sn/common/avatar/_module.js */
angular.module('sn.common.avatar', ['sn.common.presence', 'sn.common.messaging', 'sn.common.user_profile']).config(function($provide) {
	$provide.value("liveProfileID", '');
});
;
/*! RESOURCE: /scripts/sn/common/avatar/directive.snAvatarPopover.js */
angular.module('sn.common.avatar').directive('snAvatarPopover', function($http, $compile, getTemplateUrl, avatarProfilePersister, $injector) {
	'use strict';
	return {
		restrict : 'E',
		templateUrl: getTemplateUrl('sn_avatar_popover.xml'),
		replace: true,
		transclude: true,
		scope : {
			members: '=',
			primary: '=?',
			showPresence: '=?',
			enableContextMenu: '=?',
			enableTooltip: '=?',
			enableBindOnce: '@',
			displayMemberCount: "=?",
			groupAvatar: "@",
			nopopover: "=",
			directconversation: '@',
			conversation: '=',
			primaryNonAssign: '=?'
		},
		compile: function(tElement) {
			var template = tElement.html();
			return function (scope, element, attrs, controller, transcludeFn) {
				if (scope.directconversation) {
					if (scope.directconversation === "true")
						scope.directconversation = true;
					else
						scope.directconversation = false;
					scope.showdirectconversation = !scope.directconversation;
				} else {
					scope.showdirectconversation = true;
				}
				if ($injector.has('inSupportClient') && $injector.get('inSupportClient'))
					scope.showdirectconversation = false;
				if (scope.primaryNonAssign) {
					scope.primary = angular.extend({}, scope.primary, scope.primaryNonAssign);
					if (scope.users && scope.users[0])
						scope.users[0] = scope.primary;
				}
				function recompile () {
					if (scope.primaryNonAssign) {
						scope.primary = angular.extend({}, scope.primary, scope.primaryNonAssign);
						if (scope.users && scope.users[0])
							scope.users[0] = scope.primary;
					}
					var newElement = $compile(template, transcludeFn)(scope);
					element.html(newElement);
					if (scope.enableTooltip) {
						element.tooltip({
							placement: 'auto top',
							container: 'body'
						}).attr('data-original-title', scope.users[0].name).tooltip('fixTitle');
						if (element.hideFix)
							element.hideFix();
					}
				}
				if (attrs.enableBindOnce === 'false') {
					scope.$watch('primary', recompile);
					scope.$watch('primaryNonAssign', recompile);
					scope.$watch('members', recompile);
				}
				if (scope.enableTooltip && scope.nopopover) {
					var usersWatch = scope.$watch('users', function () {
						if (scope.users && scope.users.length === 1 && scope.users[0] && scope.users[0].name) {
							element.tooltip({
								placement: 'auto top',
								container: 'body'
							}).attr('data-original-title', scope.users[0].name).tooltip('fixTitle');
							if (element.hideFix)
								element.hideFix();
							usersWatch();
						}
					});
				}
			};
		},
		controller: function($scope, liveProfileID, $timeout, $element, $document, snCustomEvent) {
			$scope.randId = Math.random();
			$scope.loadEvent = 'sn-user-profile.ready';
			$scope.closeEvent = ['chat:open_conversation', 'snAvatar.closePopover', 'body_clicked'];
			$scope.popoverConfig = {
template: '<div class="popover" role="tooltip"><div class="arrow"></div><div class="popover-content"></div></div>'
			};
			$scope.displayMemberCount = $scope.displayMemberCount || false;
			$scope.liveProfileID = liveProfileID;
			if ($scope.primaryNonAssign) {
				$scope.primary =  angular.extend({}, $scope.primary, $scope.primaryNonAssign);
				if ($scope.users && $scope.users[0])
					$scope.users[0] = $scope.primary;
			}
			$scope.$watch('members', function(newVal, oldVal) {
				if(newVal === oldVal)
					return;
				if ($scope.members)
					buildAvatar();
			});
			$scope.noPopover = function () {
				$scope.popoverCursor = ($scope.nopopover || ($scope.members && $scope.members.length > 2) ) ? "default" : "pointer";
				return ($scope.nopopover || ($scope.members && $scope.members.length > 2));
			}
			$scope.avatarType = function() {
				var result = [];
				if($scope.groupAvatar || !$scope.users)
					return result;
				if ($scope.users.length > 1)
					result.push("group")
				if ($scope.users.length === 2)
					result.push("avatar-duo")
				if ($scope.users.length === 3)
					result.push("avatar-trio")
				if ($scope.users.length >= 4)
					result.push("avatar-quad")
				if ($scope.users.length === 1 && !$scope.users[0].avatar)
					result.push("initials");
				return result;
			}
			$scope.getBackgroundStyle = function(user) {
				var avatar = (user ? user.avatar  : '');
				if ($scope.groupAvatar)
					avatar = $scope.groupAvatar;
				if (avatar && avatar !== '')
					return { 'background-image' : 'url(' + avatar + ')' };
				if (user && user.name)
return '';
				return void(0);
			};
			$scope.stopPropCheck = function (evt) {
				$scope.$broadcast("snAvatar.closeOtherPopovers", $scope.randId);
				if (!$scope.nopopover) {
					evt.stopPropagation();
				}
			};
			$scope.$on("snAvatar.closeOtherPopovers", function (id) {
				if (id !== $scope.randId)
					snCustomEvent.fireTop('snAvatar.closePopover');
			});
			$scope.maxStringWidth = function() {
				var paddedWidth = parseInt($scope.avatarWidth * 0.8, 10);
return $scope.users.length === 1 ? paddedWidth : paddedWidth / 2;
			};
			function buildInitials(name) {
				if (!name)
					return "--";
				var initials = name.split(" ").map(function(word) {
					return word.toUpperCase();
				}).filter(function(word) {
return word.match(/^[A-Z]/);
				}).map(function(word) {
					return word.substring(0,1);
				}).join("");
				return (initials.length > 3)
					? initials.substr(0, 3)
					: initials;
			}
			$scope.avatartooltip = function() {
				if (!$scope.enableTooltip) {
					return '';
				}
				if (!$scope.users) {
					return '';
				}
				var names = [];
				$scope.users.forEach(function(user) {
					if(!user) { return; }
					names.push(user.name);
				});
				return names.join(', ');
			};
			function buildAvatar() {
				if (typeof $scope.primary === 'string') {
$http.get('/api/now/live/profiles/sys_user.' + $scope.primary).then(function (response) {
						$scope.users = [{
							userID: $scope.primary,
							name: response.data.result.name,
							initials: buildInitials(response.data.result.name),
							avatar: response.data.result.avatar
						}];
					});
					return;
				}
				if ($scope.primary) {
					if ($scope.primary.userImage)
						$scope.primary.avatar = $scope.primary.userImage;
					if (!$scope.primary.userID && $scope.primary.sys_id)
						$scope.primary.userID = $scope.primary.sys_id;
				}
				$scope.isGroup = $scope.conversation && $scope.conversation.isGroup;
				$scope.users = [$scope.primary];
				if ($scope.primary && (!$scope.members || $scope.members.length <= 0) && ($scope.primary.avatar || $scope.primary.initials) && $scope.isDocument) {
					$scope.users = [$scope.primary];
				} else if ($scope.members && $scope.members.length > 0) {
					$scope.users = buildCompositeAvatar($scope.members);
				}
				$scope.presenceEnabled = $scope.showPresence && !$scope.isGroup && $scope.users.length === 1;
			}
			function buildCompositeAvatar(members) {
				var currentUser = window.NOW.user ? window.NOW.user.userID : window.NOW.user_id;
				var users = angular.isArray(members) ? members.slice() : [members];
				users = users.sort(function(a, b) {
					var aID = a.userID || a.document;
					var bID = b.userID || b.document;
					if (a.table === "chat_queue_entry")
						return 1;
					if (aID === currentUser)
						return 1;
					else if (bID === currentUser)
						return -1;
					return 0;
				});
				if (users.length === 2)
					users = [users[0]];
				if (users.length > 2 && $scope.primary && $scope.primary.name && $scope.primary.table === "sys_user") {
					var index = -1;
					angular.forEach(users, function(user, i) {
						if (user.sys_id === $scope.primary.sys_id) {
							index = i;
						}
					});
					if (index > -1) {
						users.splice(index, 1);
					}
					users.splice(1, 0, $scope.primary);
				}
				return users;
			}
			buildAvatar();
			$scope.loadFullProfile = function () {
				if ($scope.primary && !$scope.primary.sys_id && !avatarProfilePersister.getAvatar($scope.primary.userID)) {
$http.get('/api/now/live/profiles/' + $scope.primary.userID).then(
						function (response) {
						try{
							angular.extend($scope.primary, response.data.result);
							avatarProfilePersister.setAvatar($scope.primary.userID, $scope.primary);
						}catch(e){}
					});
				}
			}
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/avatar/directive.snAvatar.js */
angular.module('sn.common.avatar')
.factory('snAvatarFactory', function($http, $compile, $templateCache, $q, i18n, snCustomEvent, snConnectService) {
	'use strict';
	return function() {
		var profileMenuText = i18n.getMessage("Open user's profile");
		return {
			restrict : 'E',
			replace: true,
			transclude: true,
			scope : {
				members: '=',
				primary: '=',
				showPresence: '=?',
				enableContextMenu: '=?',
				enableTooltip: '=?',
				enableBindOnce: '@',
				displayMemberCount: "=?",
				groupAvatar: "@"
			},
			compile: function(tElement) {
				var template = tElement.html();
				return function (scope, element, attrs, controller, transcludeFn) {
					var newElement = $compile(template, transcludeFn)(scope);
					element.html(newElement);
					if (scope.enableTooltip) {
						element.tooltip({
							placement: 'auto top',
							container: 'body'
						}).attr('data-original-title', scope.users[0].name).tooltip('fixTitle');
						if (element.hideFix)
							element.hideFix();
					}
					if (attrs.enableBindOnce === 'false') {
						scope.$watch('primary', recompile);
						scope.$watch('members', recompile);
					}
					if (scope.enableTooltip) {
						var usersWatch = scope.$watch('users', function () {
							if (scope.users && scope.users.length === 1 && scope.users[0] && scope.users[0].name) {
								element.tooltip({
									placement: 'auto top',
									container: 'body'
								}).attr('data-original-title', scope.users[0].name).tooltip('fixTitle');
								if (element.hideFix)
									element.hideFix();
								usersWatch();
							}
						});
					}
					if (scope.enableContextMenu !== false) {
						scope.contextOptions = [];
						var gUser = null;
						try { gUser = g_user; } catch (err) {}
						if (scope.users && scope.users.length === 1 && scope.users[0] && (scope.users[0].userID || scope.users[0].sys_id)) {
							scope.contextOptions = [
								[profileMenuText, function () {
									if (scope.users && scope.users.length > 0) {
window.open('/nav_to.do?uri=' + encodeURIComponent('sys_user.do?sys_id=' + scope.users[0].userID), '_blank');
									}
								}]];
							if ((gUser && scope.users[0].userID && scope.users[0].userID !== gUser.userID) ||
								(scope.liveProfileID && scope.users[0] && scope.users[0].sysID !== scope.liveProfileID)) {
								scope.contextOptions.push(["Open a new chat", function () {
									snConnectService.openWithProfile(scope.users[0]);
								}]);
							}
						}
					} else {
						scope.contextOptions = [];
					}
				};
			},
			controller: ['$scope', 'liveProfileID', function($scope, liveProfileID) {
				var firstBuildAvatar = true;
				$scope.displayMemberCount = $scope.displayMemberCount || false;
				$scope.liveProfileID = liveProfileID;
				$scope.$watch('primary', function(newValue, oldValue) {
					if ($scope.primary && newValue !== oldValue) {
						if(!firstBuildAvatar)
							buildAvatar();
						if ($scope.contextOptions.length > 0) {
							$scope.contextOptions = [
								[profileMenuText, function () {
									if ($scope.users && $scope.users.length > 0) {
										window.location.href = 'sys_user.do?sys_id=' + $scope.users[0].userID || $scope.users[0].userID;
									}
								}]];
							var gUser = null;
							try {
								gUser = g_user;
							} catch (err) {
							}
							if ((!gUser && !liveProfileID) || ($scope.users && $scope.users.length === 1 && $scope.users[0])) {
								if ((gUser && $scope.users[0].userID && $scope.users[0].userID !== gUser.userID) ||
									($scope.liveProfileID && $scope.users[0] && $scope.users[0].sysID !== $scope.liveProfileID)) {
									$scope.contextOptions.push(["Open a new chat", function () {
										snConnectService.openWithProfile($scope.users[0]);
									}]);
								}
							}
						}
					}
				});
				$scope.onPresenceChange = function(status) {
					$scope.presenceStatus = status;
				}
				$scope.$watch('members', function() {
					if ($scope.members && !firstBuildAvatar)
						buildAvatar();
				});
				$scope.avatarType = function() {
					var result = [];
					if($scope.groupAvatar || !$scope.users)
						return result;
					if ($scope.users.length > 1)
						result.push("group");
					if ($scope.users.length === 2)
						result.push("avatar-duo");
					if ($scope.users.length === 3)
						result.push("avatar-trio");
					if ($scope.users.length >= 4)
						result.push("avatar-quad");
					return result;
				};
				$scope.getBackgroundStyle = function(user) {
					var avatar = (user ? user.avatar  : '');
					if ($scope.groupAvatar)
						avatar = $scope.groupAvatar;
					if (avatar && avatar !== '')
						return { 'background-image' : 'url(' + avatar + ')' };
					if (user && user.name)
return '';
					return void(0);
				};
				$scope.maxStringWidth = function() {
					var paddedWidth = parseInt($scope.avatarWidth * 0.8, 10);
return $scope.users.length === 1 ? paddedWidth : paddedWidth / 2;
				};
				function buildInitials(name) {
					if (!name)
						return "--";
var initialMatchRegex = /^[A-ZÀ-Ÿ]|^[\u3040-\u309f]|^[\u30a0-\u30ff]|^[\uff66-\uff9f]|^[\u4e00-\u9faf]/;
					var initials = name.split(" ").map(function(word) {
						return word.toUpperCase();
					}).filter(function(word) {
						return word.match(initialMatchRegex);
					}).map(function(word) {
						return word.substring(0,1);
					}).join("");
					return (initials.length > 3)
						? initials.substr(0, 3)
						: initials;
				}
				$scope.avatartooltip = function() {
					if (!$scope.enableTooltip) {
						return '';
					}
					if (!$scope.users) {
						return '';
					}
					var names = [];
					$scope.users.forEach(function(user) {
						if(!user) { return; }
						names.push(user.name);
					});
					return names.join(', ');
				};
				function setPresence(){
					$scope.presenceEnabled = $scope.showPresence && !$scope.isDocument && $scope.users.length === 1;
					return $scope.presenceEnabled;
				}
				function buildAvatar() {
					if(firstBuildAvatar)
						firstBuildAvatar = false;
						if (typeof $scope.primary === 'string') {
return $http.get('/api/now/live/profiles/sys_user.' + $scope.primary).then(function (response) {
								$scope.users = [{
									userID: $scope.primary,
									name: response.data.result.name,
									initials: response.data.result.initials ? response.data.result.initials : buildInitials(response.data.result.name),
									avatar: response.data.result.avatar
								}];
								return setPresence();
							});
						}
						if ($scope.primary) {
							if ($scope.primary.userImage)
								$scope.primary.avatar = $scope.primary.userImage;
							if (!$scope.primary.userID && $scope.primary.sys_id)
								$scope.primary.userID = $scope.primary.sys_id;
						}
						$scope.isDocument = $scope.primary && $scope.primary.table && $scope.primary.table !== "sys_user" && $scope.primary.table !== "chat_queue_entry";
						$scope.users = [$scope.primary];
						if ($scope.primary && (!$scope.members || $scope.members.length <= 0) && ($scope.primary.avatar || $scope.primary.initials) && $scope.isDocument) {
							$scope.users = [$scope.primary];
						} else if ($scope.members && $scope.members.length > 0) {
							$scope.users = buildCompositeAvatar($scope.members);
						}
						return $q.when(setPresence());
				}
				function buildCompositeAvatar(members) {
					var currentUser = window.NOW.user ? window.NOW.user.userID : window.NOW.user_id;
					var users = angular.isArray(members) ? members.slice() : [members];
					users = users.sort(function(a, b) {
						var aID = a.userID || a.document;
						var bID = b.userID || b.document;
						if (a.table === "chat_queue_entry")
							return 1;
						if (aID === currentUser)
							return 1;
						else if (bID === currentUser)
							return -1;
						return 0;
					});
					if (users.length === 2)
						users = [users[0]];
					if (users.length > 2 && $scope.primary && $scope.primary.name && $scope.primary.table === "sys_user") {
						var index = -1;
						angular.forEach(users, function(user, i) {
							if (user.sys_id === $scope.primary.sys_id) {
								index = i;
							}
						});
						if (index > -1) {
							users.splice(index, 1);
						}
						users.splice(1, 0, $scope.primary);
					}
					return users;
				}
				buildAvatar();
			}]
		}
	}
})
.directive('snAvatar', function (snAvatarFactory, getTemplateUrl){
	var directive = snAvatarFactory();
	directive.templateUrl = getTemplateUrl('sn_avatar.xml');
	return directive;
})
.directive('snAvatarOnce', function (snAvatarFactory, getTemplateUrl) {
	var directive = snAvatarFactory();
	directive.templateUrl = getTemplateUrl('sn_avatar_once.xml');
	return directive;
});
;
/*! RESOURCE: /scripts/sn/common/avatar/service.avatarProfilePersister.js */
angular.module('sn.common.avatar').service('avatarProfilePersister', function () {
	"use strict";
	var avatars = {};
	function setAvatar (id, payload) {
		avatars[id] = payload;
	}
	function getAvatar (id) {
		return avatars[id];
	}
	return {
		setAvatar: setAvatar,
		getAvatar: getAvatar
	}
});
;
/*! RESOURCE: /scripts/sn/common/avatar/directive.snUserAvatar.js */
angular.module('sn.common.avatar').directive('snUserAvatar', function(getTemplateUrl) {
	"use strict";
	return {
		restrict: 'E',
		templateUrl: getTemplateUrl('sn_user_avatar.xml'),
		replace: true,
		scope: {
			profile: '=?',
			userId: '=?',
			avatarUrl: '=?',
			initials: '=?',
			enablePresence: '@',
			disablePopover: '=?',
			directConversationButton: '=?',
			userName: '=?',
			isAccessible: '=?'
		},
		link: function (scope, element) {
			scope.evaluatedProfile = undefined;
			scope.backgroundStyle = undefined;
			scope.enablePresence = scope.enablePresence !== 'false';
			if (scope.profile) {
				scope.evaluatedProfile = scope.profile;
				scope.userId = scope.profile.userID || "";
				scope.avatarUrl = scope.profile.avatar || "";
				scope.initials = scope.profile.initials || "";
				scope.backgroundStyle = scope.getBackgroundStyle();
			} else if (scope.userId || scope.avatarUrl || scope.initials || scope.userName) {
				scope.evaluatedProfile = scope.profile = {
					'userID': scope.userId || "",
					'avatar': scope.avatarUrl || "",
					'initials': scope.initials || "",
					'userName': scope.userName || "",
					'isAccessible': scope.isAccessible || false
				};
				scope.backgroundStyle = scope.getBackgroundStyle();
			} else {
				var unwatch = scope.$watch('profile', function (newVal) {
					if (newVal) {
						scope.evaluatedProfile = newVal;
						scope.backgroundStyle = scope.getBackgroundStyle();
						unwatch();
					}
				})
			}
			scope.directConversationButton = scope.directConversationButton !== 'false' && scope.directConversationButton !== false;
scope.template = '<sn-user-profile tabindex="-1" id="sn-bootstrap-popover" profile="evaluatedProfile" show-direct-message-prompt="::directConversationButton" class="avatar-popover avatar-popover-padding"></sn-user-profile>';
			scope.ariaRole = scope.disablePopover ? 'presentation' : 'button';
		},
		controller: function($scope) {
			$scope.getBackgroundStyle = function() {
				if ( ($scope.avatarUrl && $scope.avatarUrl !== '') || $scope.evaluatedProfile && $scope.evaluatedProfile.avatar !== '' )
					return {"background-image": 'url(' + ($scope.avatarUrl || $scope.evaluatedProfile.avatar) + ')'};
				return {"background-image": ""};
			};
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/avatar/directive.snGroupAvatar.js */
angular.module('sn.common.avatar').directive('snGroupAvatar', function($http, $compile, getTemplateUrl, avatarProfilePersister) {
	'use strict';
	return {
		restrict : 'E',
		templateUrl: getTemplateUrl('sn_group_avatar.xml'),
		replace: true,
		transclude: true,
		scope : {
			members: '=',
			primary: '=?',
			groupAvatar: "@"
		},
		controller: function($scope, liveProfileID) {
			$scope.liveProfileID = liveProfileID;
			$scope.$watch('members', function(newVal, oldVal) {
				if(newVal === oldVal)
					return;
				if ($scope.members)
					$scope.users = buildCompositeAvatar($scope.members);
			});
			$scope.avatarType = function() {
				var result = [];
				if($scope.groupAvatar || !$scope.users)
					return result;
				if ($scope.users.length > 1)
					result.push("group")
				if ($scope.users.length === 2)
					result.push("sn-avatar_duo")
				if ($scope.users.length === 3)
					result.push("sn-avatar_trio")
				if ($scope.users.length >= 4)
					result.push("sn-avatar_quad")
				return result;
			};
			$scope.getBackgroundStyle = function(user) {
				var avatar = (user ? user.avatar  : '');
				if ($scope.groupAvatar)
					avatar = $scope.groupAvatar;
				if (avatar && avatar !== '')
					return {"background-image" : "url(" + avatar + ")"};
				return {};
			};
			
			$scope.users = buildCompositeAvatar($scope.members);
			function buildCompositeAvatar(members) {
				var currentUser = window.NOW.user ? window.NOW.user.userID : window.NOW.user_id;
				var users = angular.isArray(members) ? members.slice() : [members];
				users = users.sort(function(a, b) {
					var aID = a.userID || a.document;
					var bID = b.userID || b.document;
					if (a.table === "chat_queue_entry")
						return 1;
					if (aID === currentUser)
						return 1;
					else if (bID === currentUser)
						return -1;
					return 0;
				});
				if (users.length === 2)
					users = [users[0]];
				if (users.length > 2 && $scope.primary && $scope.primary.name && $scope.primary.table === "sys_user") {
					var index = -1;
					angular.forEach(users, function(user, i) {
						if (user.sys_id === $scope.primary.sys_id) {
							index = i;
						}
					});
					if (index > -1) {
						users.splice(index, 1);
					}
					users.splice(1, 0, $scope.primary);
				}
				return users;
			}
		}
	}
});
;
;
/*! RESOURCE: /scripts/sn/common/avatar/js_includes_avatar.js */
/*! RESOURCE: /scripts/sn/common/controls/_module.js */
angular.module('sn.common.controls', ['sn.common.util']);
;
/*! RESOURCE: /scripts/sn/common/controls/directive.snChoiceList.js */
angular.module('sn.common.controls').directive('snChoiceList', function(i18n, $timeout) {
	"use strict";
	return {
		restrict : 'E',
		replace : true,
		scope : {
			snModel: "=",
			snTextField: "@",
			snValueField: "@",
			snOptions: "=?",
			snItems: "=?",
			snOnChange: "&",
			snDisabled: "=",
			snDialogName: "="
		},
		template :
		'<select ng-disabled="snDisabled" ' +
		'        ng-model="model" ' +
		'        ng-options="item[snValueField] as item[snTextField] for item in snItems">' +
'  <option value="" ng-show="snOptions.placeholder">{{snOptions.placeholder}}</option>' +
'</select>',
		link : function (scope, element, attrs) {
			if (scope.snDialogName)
				scope.$on("dialog." + scope.snDialogName + ".close", function() {
					$timeout(function() {
						$(element).select2("destroy");
					})
				});
			
			$(element).css("opacity", 0);
			var config = {
				width: "100%"
			};
			if (angular.isFunction(element.select2)) {			
				i18n.getMessage('No matches found', function(msg) {
					config.formatNoMatches = function() {
						return msg;
					};
				});
			}
			if (scope.snOptions){
				if (scope.snOptions.placeholder){
					config.placeholder = scope.snOptions.placeholder;
					config.placeholderOption = "first";
				}
				if (scope.snOptions.allowClear){
					config.allowClear = scope.snOptions.allowClear;
				}
				if (scope.snOptions.hideSearch && scope.snOptions.hideSearch === true){
					config.minimumResultsForSearch = -1;
				}
			}
			function init(){
				scope.model = scope.snModel;
				render();
			}
			function render(){
				if (!attrs){
					$timeout(function(){render();});
					return;
				}
				$timeout(function(){
					$(element).css("opacity", 1);
					$(element).select2("destroy");
					$(element).select2(config);
					$(".select2-focusser").attr("aria-expanded", "false");
				});
			}
			init();
			scope.$watch("snItems", function(newValue, oldValue){
				if (newValue !== oldValue){
					init();
				}
			}, true);
			scope.$watch("snModel", function(newValue){
				if (newValue !== undefined && newValue !== scope.model){
					init();
				}
			});
			scope.$watch("model", function(newValue, oldValue){
				if (newValue !== oldValue){
					scope.snModel = newValue;
					if (scope.snOnChange)
						scope.snOnChange({selectedValue:newValue});
				}
			});
			scope.$on('$destroy', function() {
				$(element).select2("destroy");
			});
		},
		controller : function($scope) {
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/controls/directive.snHtmlContentWrapper.js */
angular.module('sn.common.controls').directive('snHtmlContentWrapper', function() {
	function link(scope, element, attrs) {
		attrs.$observe("content", function(content) {
			encapsulate(element[0], content, attrs.uniqueId);
		});
	}
	function createDefaultCssLink() {
		var link = document.createElement("link");
link.href = "styles/activity_encapsulated.css";
		link.rel = "stylesheet";
link.type = "text/css";
		return link;
	}
	function createBaseElement() {
		var base = document.createElement("base");
		base.setAttribute("target", "_blank")
		return base;
	}
	function encapsulate(root, content, uniqueId) {
		var defaultCssLink = createDefaultCssLink();
		var style = document.createElement('style');
		style.innerHTML = ':host img {max-width: 100%; height: auto; overflow: hidden;}';
		if (document.head.createShadowRoot || document.head.attachShadow) {
			var shadow = root.shadowRoot || (document.head.attachShadow ?
				root.attachShadow({mode: 'open'}) :
				root.createShadowRoot());
			var contentDiv = document.createElement('div');
			contentDiv.innerHTML = content;
			if (NOW.isUsingPolaris) contentDiv.classList.add('-polaris');
			shadow.innerHTML = contentDiv.outerHTML;
			shadow.appendChild(defaultCssLink);
			shadow.appendChild(style);
		} else {
			var iframeId = "activity-iframe-" + uniqueId;
			var existingIframe = document.getElementById(iframeId);
			if (existingIframe) {
				existingIframe.contentDocument.write(content);
				existingIframe.contentWindow.document.head.appendChild(defaultCssLink);
				existingIframe.setAttribute("height", existingIframe.contentWindow.document.body.scrollHeight + 'px')
			}
			else {
				var rootEl = $j(root);
				var iframe = document.createElement("iframe");
				iframe.setAttribute("id", iframeId);
				iframe.setAttribute("style", "border:none;display:block;width:100%");
				iframe.setAttribute("class", "html-content");
				iframe.setAttribute("scrolling", "no");
				iframe.setAttribute("height", "0");
				iframe.setAttribute("sandbox", "allow-same-origin");
				root.appendChild(iframe);
				var doc = iframe.contentWindow.document;
				doc.open();
				doc.write(content);
				doc.close();
				iframe.contentWindow.document.head.appendChild(defaultCssLink);
				iframe.contentWindow.document.head.appendChild(createBaseElement());
				iframe.height = doc.body.scrollHeight + 'px';
				var parentTab = rootEl.closest(".tabs2_section");
				var parentSectionId = parentTab.attr("data-section-id");
				var setIFrameHeightFn = function(tab) {
					var openedTab = $j(".tabs2_section." + tab);
					if (openedTab.length > 0 && openedTab.attr("data-section-id") === parentSectionId) {
						iframe.contentWindow.document.head.appendChild(defaultCssLink);
						iframe.height = doc.body.scrollHeight + 'px';
						CustomEvent.un("tab.activated", setIFrameHeightFn);
					}
				};
				CustomEvent.observe("tab.activated", setIFrameHeightFn);
			}
		}
	}
	return {
		link: link,
		restrict: 'E',
		replace: true
	};
});
;
/*! RESOURCE: /scripts/sn/common/controls/directive.snReferencePicker.js */
angular.module('sn.common.controls').directive('snReferencePicker', function($timeout, $http, urlTools, filterExpressionParser, escapeHtml, i18n) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		scope: {
			ed: "=?",
			field: "=",
refTable: "=?",
refId: "=?",
			snOptions: "=?",
			atfQualifier: "=?",
			snOnChange: "&",
			snOnBlur: "&",
			snOnClose: "&",
			snOnOpen: '&',
			minimumInputLength : "@",
			snDisabled: "=",
			snPageSize: "@",
			dropdownCssClass: "@",
			formatResultCssClass: "&",
			overlay: "=",
			additionalDisplayColumns: "@",
			displayColumn: "@",
			recordValues: '&',
			getGlideForm: '&glideForm',
			domain: "@",
snSelectWidth: '@',
		},
		template: '<input type="text" name="{{field.name}}" ng-disabled="snDisabled" style="min-width: 150px;" ng-model="field.displayValue" ' +
			'sn-atf-settable="true" sn-atf-component-value="{{field.value}}" sn-atf-data-type="reference"' +
			'sn-atf-data-type-params=\'{"reference" : "{{ed.reference}}", "reference_qual" : "{{atfQualifier || ed.qualifier}}", ' +
'"valueField" : "sys_id", "displayField" : "{{ed.searchField}}"}\' ng-attr-sn-atf-disabled="{{ snDisabled || undefined }}" />',
		link: function(scope, element, attrs, ctrl) {
			scope.ed = scope.ed || scope.field.ed;
			scope.selectWidth = scope.snSelectWidth || '100%';
			element.css("opacity", 0);
			var fireReadyEvent = true;
			var g_form;
			if (angular.isDefined(scope.getGlideForm))
				g_form = scope.getGlideForm();
			var fieldAttributes = {};
			if (angular.isDefined(scope.field) && angular.isDefined(scope.field.attributes) && typeof scope.ed.attributes == 'undefined')
				if (Array.isArray(scope.field.attributes))
					fieldAttributes = scope.field.attributes;
				else
					fieldAttributes = parseAttributes(scope.field.attributes);
			else
				fieldAttributes = parseAttributes(scope.ed.attributes);
			if (!angular.isDefined(scope.additionalDisplayColumns) && angular.isDefined(fieldAttributes['ref_ac_columns']))
				scope.additionalDisplayColumns = fieldAttributes['ref_ac_columns'];
			var atfQualifier = scope.ed.qualifier || '';
			if (scope.ed.dependent_field && scope.ed.dependent_value && scope.ed.dependent_table &&
					!(scope.ed.reference == 'sys_user' && scope.ed.dependent_field.indexOf('group') != -1)) {
				if (atfQualifier)
					atfQualifier += "^";
				atfQualifier += scope.ed.dependent_field + "=" + scope.ed.dependent_value;
			}
			scope.atfQualifier = atfQualifier;
			var select2AjaxHelpers = {
				formatSelection: function(item) {
					return escapeHtml(getDisplayValue(item));
				},
				formatResult: function(item) {
					var displayValues = getDisplayValues(item);
					if (displayValues.length == 1)
						return escapeHtml(displayValues[0]);
					if (displayValues.length > 1) {
var width = 100 / displayValues.length;
						var markup = "";
						for (var i = 0; i < displayValues.length; i++)
markup += "<div style='width: " + width + "%;' class='select2-result-cell'>" + escapeHtml(displayValues[i])  + "</div>";
						return markup;
					}
					return "";
				},
				search: function(queryParams) {
					if ('sysparm_include_variables' in queryParams.data) {
						var url = urlTools.getURL('ref_list_data', queryParams.data);
						return $http.get(url).then(queryParams.success);
					}else {
						var urlQueryParameters = {};
						if (queryParams.data['sysparm_for_impersonation']) {
							urlQueryParameters['sysparm_for_impersonation'] = true;
						}
						var url = urlTools.getURL('ref_list_data', urlQueryParameters);
						return $http.post(url, queryParams.data).then(queryParams.success);
					}
				},
				initSelection: function(elem, callback) {
					if (scope.field && scope.field.displayValue)
						callback({
							sys_id: scope.field.value,
							name: scope.field.displayValue
						});
				}
			};
			var config = {
				i18n: i18n,
				width : scope.selectWidth,
				minimumInputLength: scope.minimumInputLength ? parseInt(scope.minimumInputLength, 10) : 0,
				overlay: scope.overlay,
				containerCssClass : 'select2-reference ng-form-element',
				placeholder : '   ',
				formatSearching: '',
				allowClear: attrs.allowClear !== 'false',
				clearAriaLabel: (scope.snOptions) ? scope.snOptions.clearAriaLabel : "",
				id: function(item) {
					return item.sys_id;
				},
				sortResults: (scope.snOptions && scope.snOptions.sortResults) ? scope.snOptions.sortResults : undefined,
				ajax: {
					quietMillis: NOW.ac_wait_time,
					data: function(filterText, page) {
						var q = _getReferenceQuery(filterText);
						var params = {
							start: (scope.pageSize * (page - 1)),
							count: scope.pageSize,
							sysparm_target_table: scope.refTable,
							sysparm_target_sys_id: scope.refId,
							sysparm_target_field: scope.ed.dependent_field || scope.ed.name,
							table: scope.ed.reference,
							qualifier: scope.ed.qualifier,
							sysparm_for_impersonation: !!scope.ed.for_impersonation,
							data_adapter: scope.ed.data_adapter,
							attributes: scope.ed.attributes,
							dependent_field: scope.ed.dependent_field,
							dependent_table: scope.ed.dependent_table,
							dependent_value: scope.ed.dependent_value,
							p: scope.ed.reference + ';q:' + q + ';r:' + scope.ed.qualifier
						};
						var referenceKey = _getReferenceKey(scope);
						if (referenceKey) {
							params.reference_key = referenceKey;
						}
						if (scope.domain) {
							params.sysparm_domain = scope.domain;
						}
						if (angular.isDefined(scope.field) && scope.field['_cat_variable'] === true){
							delete params['sysparm_target_table'];
							params['sysparm_include_variables'] = true;
							params['variable_ids'] = scope.field.sys_id;
							var getFieldSequence = g_form.$private.options('getFieldSequence');
							if (getFieldSequence) {
								params['variable_sequence1'] = getFieldSequence();
							}
							var itemSysId = g_form.$private.options('itemSysId');
							params['sysparm_id'] = itemSysId;
							var getFieldParams = g_form.$private.options('getFieldParams');
							if (getFieldParams) {
								angular.extend(params, getFieldParams());
							}
						}
						if (scope.recordValues)
							params.sysparm_record_values = scope.recordValues();
						return params;
					},
					results: function(data, page) {
						return ctrl.filterResults(data, page, scope.pageSize);
					},
					transport: select2AjaxHelpers.search
				},
				formatSelection: select2AjaxHelpers.formatSelection,
				formatResult: select2AjaxHelpers.formatResult,
				initSelection: select2AjaxHelpers.initSelection,
				dropdownCssClass: attrs.dropdownCssClass,
				formatResultCssClass: scope.formatResultCssClass || null
			};
			if (scope.snOptions) {
				if (scope.snOptions.placeholder) {
					config.placeholder = scope.snOptions.placeholder;
				}
				if (scope.snOptions.width) {
					config.width = scope.snOptions.width;
				}
			}
			function _getReferenceQuery(filterText) {
				var filterExpression = filterExpressionParser.parse(filterText, scope.ed.defaultOperator);
				var colToSearch = getReferenceColumnsToSearch();
				var excludedValues = getExcludedValues();
				return colToSearch.map(function(column) {
					return column + filterExpression.operator + filterExpression.filterText +
						'^' + column + 'ISNOTEMPTY' + excludedValues;
				}).join("^NQ");
			}
			function _getReferenceKey(scope) {
				if (scope.ed && scope.ed.referenceKey) {
					return scope.ed.referenceKey;
				}
				if (scope.field && scope.field.referenceKey) {
					return scope.field.referenceKey;
				}
				return null;
			}
			function getReferenceColumnsToSearch() {
				var colName = ['name'];
				if (scope.ed.searchField) {
					colName = scope.ed.searchField.split(";");
				} else if (fieldAttributes['ref_ac_columns_search'] == 'true' && 'ref_ac_columns' in fieldAttributes && fieldAttributes['ref_ac_columns'] != '') {
					colName = fieldAttributes['ref_ac_columns'].split(';');
				} else if (fieldAttributes['ref_ac_order_by']) {
					colName = [fieldAttributes['ref_ac_order_by']];
				}
				return colName;
			}
			function getExcludedValues () {
				if (scope.ed.excludeValues && scope.ed.excludeValues != '') {
					return '^sys_idNOT IN' + scope.ed.excludeValues;
				}
				return '';
			}
			function parseAttributes(strAttributes) {
				var attributeArray = (strAttributes && strAttributes.length ? strAttributes.split(',') : []);
				var attributeObj = {};
				for (var i = 0; i < attributeArray.length; i++) {
					if (attributeArray[i].length > 0) {
						var attribute = attributeArray[i].split('=');
						attributeObj[attribute[0]] = attribute.length > 1 ? attribute[1] : '';
					}
				}
				return attributeObj;
			}
			function init() {
				scope.model = scope.snModel;
				render();
			}
			function render() {
				$timeout(function() {
					i18n.getMessage('Searching...', function(searchingMsg) {
						config.formatSearching = function() {
							return searchingMsg;
						};
					});
					element.css("opacity", 1);
					element.select2("destroy");
					var select2 = element.select2(config).select2('val', []);
					select2.bind("change", select2Change);
					select2.bind("select2-removed", select2Change);
					select2.bind("select2-blur", function() {
						scope.$apply(function() {
							scope.snOnBlur();
						});
					});
					select2.bind("select2-close", function() {
						scope.$apply(function() {
							scope.snOnClose();
						});
					});
					select2.bind("select2-open", function() {
						scope.$apply(function() {
							if (scope.snOnOpen)
								scope.snOnOpen();
						});
					});
					select2.bind('select2-focus', function() {
						redirectLabel(element);
					});
					select2.bind('sn-atf-setvalue', setValueATF);
					if (fireReadyEvent) {
						scope.$emit('select2.ready', element);
						fireReadyEvent = false;
					}
				});
			}
			function select2Change(e) {
				e.stopImmediatePropagation();
				if (e.added) {
					if (scope.$$phase || scope.$root.$$phase)
						return;
					var selectedItem = e.added;
					var value = selectedItem.$$referenceKeyValue || selectedItem.sys_id;
					var displayValue = value ? getDisplayValue(selectedItem) : '';
					if (scope.snOptions && scope.snOptions.useGlideForm === true) {
						g_form.setValue(scope.field.name, value, displayValue);
						scope.rowSelected();
						e.displayValue = displayValue;
						triggerSnOnChange();
					} else {
						scope.$apply(function() {
							scope.field.value = value;
							scope.field.displayValue = displayValue;
							scope.rowSelected();
						e.displayValue = displayValue;
							triggerSnOnChange();
						});
					}
				} else if (e.removed) {
					if (scope.snOptions && scope.snOptions.useGlideForm === true) {
						g_form.clearValue(scope.field.name);
						triggerSnOnChange();
					} else {
						scope.$apply(function() {
							scope.field.displayValue = '';
							scope.field.value = '';
							triggerSnOnChange();
						});
					}
				}
				$timeout(function() {
					element.parent().find(".select2-focusser").focus();
				}, 0, false);
				function triggerSnOnChange(){
					if (scope.snOnChange)
						scope.snOnChange(e);
				}
			}
			function redirectLabel($select2) {
				if (NOW.select2LabelWorkaround)
					NOW.select2LabelWorkaround($select2);
			}
			function getDisplayValue(selectedItem) {
				var displayValue = '';
				if (selectedItem && selectedItem.sys_id) {
					if (scope.displayColumn && typeof selectedItem[scope.displayColumn] != "undefined")
						displayValue = selectedItem[scope.displayColumn];
					else if (selectedItem.$$displayValue)
						displayValue = selectedItem.$$displayValue;
					else if (selectedItem.name)
						displayValue = selectedItem.name;
					else if (selectedItem.title)
						displayValue = selectedItem.title;
				}
				return displayValue;
			}
			function getDisplayValues(selectedItem) {
				var displayValues = [];
				if (selectedItem && selectedItem.sys_id) {
					var current = "";
					if (scope.displayColumn && typeof selectedItem[scope.displayColumn] != "undefined")
						current = selectedItem[scope.displayColumn];
					else if (selectedItem.$$displayValue)
						current = selectedItem.$$displayValue;
					else if (selectedItem.name)
						current = selectedItem.name;
					else if (selectedItem.title)
						current = selectedItem.title;
					displayValues.push(current);
				}
				if (scope.additionalDisplayColumns) {
					var columns = scope.additionalDisplayColumns.split(",");
					for (var i = 0; i < columns.length; i++) {
						var column = columns[i];
						if (selectedItem[column])
							displayValues.push(selectedItem[column]);
					}
				}
				return displayValues;
			}
			function setValueATF(e) {
				e.stopImmediatePropagation();
				var changeEventParameters = { type: "change" };
				if (scope.field && scope.field.value)
					changeEventParameters.removed = element.select2("data");
				var newValue = e.detail && e.detail.newValue;
				if (newValue) {
					var params = config.ajax.data('', 1);
					if (params.qualifier)
						params.qualifier += "^";
					else
						params.qualifier = "";
					params.qualifier += "sys_id=" + newValue;
					var data = {
						data: params,
						dataType: "json",
						error: atfHandleNoResults,
						success: function (answer) {
							if (answer.data.items && answer.data.items.length == 1) {
								var valueToSet = answer.data.items[0].sys_id;
								changeEventParameters.added = answer.data.items[0];
								$timeout(function() {
									element.val(valueToSet);
									element.triggerHandler(changeEventParameters);
								}, 0, false);
							} else
								atfHandleNoResults();
						},
					};
					select2AjaxHelpers.search(data);
				} else {
					element.val("");
					element.triggerHandler(changeEventParameters);
				}
				function atfHandleNoResults() {
					i18n.getMessage(
						"Unable to set reference picker to value {0}",
						function(errorMessage) {
							throw new Error(i18n.format(errorMessage, newValue));
						}
					);
				}
			}
			scope.$watch("field.displayValue", function(newValue, oldValue) {
				if (newValue != oldValue && newValue !== scope.model) {
					init();
				}
			});
			scope.$on("snReferencePicker.activate", function(evt, parms) {
				$timeout(function() {
					element.select2("open");
				})
			});
			init();
		},
		controller: function($scope, $rootScope) {
			$scope.pageSize = 20;
			if ($scope.snPageSize)
				$scope.pageSize = parseInt($scope.snPageSize);
			$scope.rowSelected = function() {
				$rootScope.$broadcast("@page.reference.selected", {
					field: $scope.field,
					ed: $scope.ed
				});
			};
			this.filterResults = function(data, page) {
				return {
					results: data.data.items,
					more: (page * $scope.pageSize < data.data.total)
				};
			};
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/controls/directive.snRecordPicker.js */
angular.module('sn.common.controls').directive('snRecordPicker', function($timeout, $http, urlTools, filterExpressionParser, escapeHtml, i18n, select2EventBroker) {
	"use strict";
	var cache = {};
	function cleanLabel(val) {
		if (val && typeof val == "object")
			return typeof val.display_value == "string" ? val.display_value.trim() : "";
		return typeof val == "string" ? val.trim() : val;
	}
	return {
		restrict: 'E',
		replace: true,
		scope: {
field: '=?',
table: '=',
defaultQuery: '=?',
startswith: '=?',
searchFields: '=?',
valueField: '=?',
displayField: '=?',
displayFields: '=?',
			pageSize: '=?',
			onChange: '&',
			snDisabled: '=',
			multiple: '=?',
			options: '=?',
			placeholder: '@',
			snAriaLabel: '=?',
			multipleValueDelimiter: '=?'
		},
		template: '<input type="text" ng-disabled="snDisabled" style="min-width: 150px;" name="{{field.name}}" ng-model="field.value"' +
	' sn-atf-data-type="reference" sn-atf-data-type-params=\'{"reference" : "{{table}}", "reference_qual" : "{{defaultQuery}}",' +
' "valueField" : "{{valueField}}", "displayField" : "{{displayField}}"}\' sn-atf-class="builtin:ATF.BaseSNRecordPicker" aria-hidden="true" sn-atf-component-value="{{field}}"/>',
		controller: function($scope) {
			if (!angular.isNumber($scope.pageSize))
				$scope.pageSize = 20;
			if (!angular.isDefined($scope.valueField))
				$scope.valueField = 'sys_id';
			this.filterResults = function(data, page) {
				return {
					results: data.data.result,
					more: (page * $scope.pageSize < parseInt(data.headers('x-total-count'), 10))
				};
			};
		},
		link: function(scope, element, attrs, ctrl) {
			var TOKENIZER = '####';
			var multipleValueDelimiter = scope.multipleValueDelimiter || ",";
			var isExecuting = false;
			var defaultPlaceholder = '    ';
			var remove = i18n.getMessage("Remove");
function getRemoveItem(label){ return jQuery("<span class='sr-only' />").text(remove + " " + label); };
			var select2Helpers = {
				formatSelection: function(item) {
					return escapeHtml(getDisplayValue(item));
				},
				onOpening: function(e) {
					select2EventBroker.publishSelect2Opening();
				},
				formatResult: function(item) {
					var displayFields = getdisplayFields(item);
					if (displayFields.length == 1)
						return escapeHtml(cleanLabel(displayFields[0]));
					if (displayFields.length > 1) {
						var markup = escapeHtml(cleanLabel(displayFields[0]));
var width = 100 / (displayFields.length - 1);
						markup += "<div>";
						for (var i = 1; i < displayFields.length; i++)
markup += "<div style='width: " + width + "%;' class='select2-additional-display-field'>" + escapeHtml(cleanLabel(displayFields[i]))  + "</div>";
markup += "</div>";
						return markup;
					}
					return "";
				},
				search: function(queryParams) {
var url = '/api/now/table/' + scope.table + '?' + urlTools.encodeURIParameters(queryParams.data);
					if (scope.options && scope.options.cache && cache[url])
						return queryParams.success(cache[url]);
					return $http.get(url).then(function(response) {
						if (scope.options && scope.options.cache) {
							cache[url] = response;
						}
						return queryParams.success(response)
					});
				},
				initSelection: function(elem, callback) {
					if (scope.field.displayValue) {
						if (scope.multiple){
							var items = [], sel;
							var values = scope.field.value.split(',');
							var displayValues = scope.field.displayValue.split(TOKENIZER);
							for(var i=0; i<values.length; i++){
								sel = {};
								sel[scope.valueField] = values[i];
								sel[scope.displayField] = displayValues[i];
								items.push(sel);
							}
							callback(items);
						}
						else {
							var sel = {};
							sel[scope.valueField] = scope.field.value;
							sel[scope.displayField] = scope.field.displayValue;
							callback(sel);
						}
					} else
						callback([]);
				},
				formatSelectionCssClass: function(item, el) {
					var anchorEl = el.parent().find("a");
					if (anchorEl.length) {
						anchorEl.removeAttr("tabindex");
						anchorEl.addClass("fa fa-times");
						anchorEl.append(getRemoveItem(item[scope.displayField]));
					}
				}
			};
			function getPlaceholder() {
				return scope.placeholder || defaultPlaceholder;
			}
var lookupMsg = jQuery("<span class='sr-only' />");
			lookupMsg.text(i18n.getMessage("Lookup using list"));
			function setAccessiblePlaceholder() {
				if (!scope.multiple && !scope.field.value && getPlaceholder() === defaultPlaceholder)
					element.parent().find('.select2-chosen').append(lookupMsg);
			}
			var config = {
				i18n: i18n,
				width : '100%',
				containerCssClass : 'select2-reference ng-form-element',
				placeholder : getPlaceholder(),
				formatSearching: '',
				allowClear: (scope.options && typeof scope.options.allowClear !== "undefined") ? scope.options.allowClear : true,
				id: function(item) {
					return item[scope.valueField];
				},
				ajax: {
					quietMillis: NOW.ac_wait_time,
					data: function(filterText, page) {
						var fields = [scope.valueField, 'name', 'title'];
						if (scope.displayField)
							fields.push(scope.displayField);
						if (scope.displayFields)
							fields.push(scope.displayFields);
						var params = {
							sysparm_offset: (scope.pageSize * (page - 1)),
							sysparm_limit: scope.pageSize,
							sysparm_query: buildQuery(filterText, scope.searchFields, scope.defaultQuery),
							sysparm_fields: fields.join(','),
							sysparm_display_value: true
						};
						return params;
					},
					results: function(data, page) {
						return ctrl.filterResults(data, page, scope.pageSize);
					},
					transport: select2Helpers.search
				},
				formatSelection: select2Helpers.formatSelection,
				formatResult: select2Helpers.formatResult,
				formatResultCssClass: function(){ return ''; },
				initSelection: select2Helpers.initSelection,
				multiple: scope.multiple,
				formatSelectionCssClass: select2Helpers.formatSelectionCssClass
			};
			function buildQuery(filterText, searchFields, defaultQuery) {
				var queryParts = [];
				var operator;
				if (window.g_ref_ac_startswith || scope.startswith)
					operator = "STARTSWITH";
				else
					operator = "CONTAINS";
				if (filterText.startsWith("*")) {
					operator = "CONTAINS";
					filterText = filterText.substring(1);
				}
				if (defaultQuery)
					queryParts.push(defaultQuery);
				var filterExpression = filterExpressionParser.parse(filterText, operator);
				if (searchFields != null) {
					var fields = searchFields.split(',');
					if (filterExpression.filterText != '') {
						var OR = "";
						for (var i = 0; i < fields.length; i++) {
							queryParts.push(OR + fields[i] + filterExpression.operator + filterExpression.filterText);
OR = "OR";
						}
					}
					for (var i = 0; i < fields.length; i++)
						queryParts.push('ORDERBY' + fields[i]);
					queryParts.push('EQ');
				}
				if (defaultQuery && typeof(defaultQuery) == 'string' && defaultQuery.indexOf('ORDERBY') != -1)
					queryParts.push(defaultQuery);
				return queryParts.join('^');
			}
			scope.field = scope.field || {};
			if (scope.field.displayValue && scope.multiple)
				scope.field.displayValue = scope.field.displayValue.replace(new RegExp(multipleValueDelimiter, 'g'), TOKENIZER);
			var initTimeout = null;
			var value = scope.field.value;
			var oldValue = scope.field.value;
			var $select;
			var select2Container;
			var select2Focusser;
			function init() {
				element.css("opacity", 0);
				$timeout.cancel(initTimeout);
				initTimeout = $timeout(function() {
					i18n.getMessage('Searching...', function(searchingMsg) {
						config.formatSearching = function() {
							return searchingMsg;
						};
					});
					i18n.getMessage('Loading more results...', function(msg) {
						config.formatLoadMore = function() {
							return msg;
						};
					});
					i18n.getMessage('No matches found', function(msg) {
						config.formatNoMatches = function() {
							return msg;
						};
					});
					element.css("opacity", 1);
					element.select2("destroy");
					$select = element.select2(config);
					$select.bind("change", onChanged);
					$select.bind("select2-selecting", onSelecting);
					$select.bind("select2-removing", onRemoving);
$select.bind("sn-atf-setvalue", onAtfSetValue);
                    $select.bind("select2-opening", select2Helpers.onOpening);
					scope.$emit('select2.ready', element);
					select2Container = element.data('select2').container;
					select2Container.find(".select2-focusser").attr("aria-label", getAriaLabel()).attr("aria-controls", "select2-drop");
					select2Container.find("ul.select2-results").attr("aria-label", scope.snAriaLabel || scope.field.name || scope.table);
					var select2ResultsId = select2Container.find('ul.select2-results').attr('id');
					select2Container.find(".select2-input").attr("aria-controls", select2ResultsId);
					updateAriaExpanded(false);
					if (!scope.multiple) {
						var closeButton = select2Container.find('.select2-search-choice-close');
						var clearTitle = getAriaClearLabel();
						closeButton.attr({'aria-label': clearTitle, 'title': clearTitle,
						'tabindex': 0, 'role': 'button', 'data-toggle': 'tooltip',  'data-container': 'body'});
						closeButton.parent().attr({'draggable': false});
						closeButton.on('mousedown touchend', function(e) {
							e.stopPropagation();
						});
						closeButton.on('click', function(e) {
							e.stopPropagation();
							element.select2('val', '', true);
						});
						closeButton.on('keydown', function(e) {
							if (e.which === 13 || e.which === 32)
								element.select2('val', '', true);
						});
						select2Focusser = select2Container.find('.select2-focusser')[0];
						var anchorEle = select2Container.find('.select2-choice')[0];
						select2Focusser.parentNode.insertBefore(select2Focusser, anchorEle);
					}
					setAccessiblePlaceholder();
				});
			}
			function getAriaClearLabel() {
				var field = scope.field;
				var label = scope.snAriaLabel || field.name || scope.table;
				return i18n.format(i18n.getMessage('Clear field {0}'), label);
			}
			function getAriaLabel() {
				var label = "", field = scope.field;
				label += scope.snAriaLabel || field.name || scope.table;
				if (field.displayValue || field.value) {
					label += (" " + (field.displayValue || field.value));
				}
				return label || i18n.getMessage("Choose");
			}
			function onAtfSetValue(e) {
				var valueToSet = e.detail ? e.detail.newValue : null;
				if (scope.multiple) {
					var data = element.select2("data");
					for (var i = 0; i < data.length; i++) {
						element.triggerHandler({ type: "select2-removing", choice: data[i] });
					}
					if (!valueToSet)
						return;
					var selected = {};
					selected[scope.valueField] = valueToSet.value;
					if (scope.displayField)
						selected[scope.displayField] = valueToSet.displayValue;
					element.triggerHandler({ type: "select2-selecting", choice: selected });
					return;
				}
				var changeEventParameters = { type: "change" };
				if (scope.field.value)
					changeEventParameters.removed = element.select2("data");
				if (valueToSet) {
					var added = {};
					added[scope.valueField] = valueToSet.value;
					if (scope.displayField)
						added[scope.displayField] = valueToSet.displayValue;
					changeEventParameters.added = added;
					element.val(valueToSet.value);
					scope.field.displayValue = valueToSet.displayValue;
					changeEventParameters.val = valueToSet.value;
				} else
					element.val("");
				element.triggerHandler(changeEventParameters);
			}
			function onSelecting(e) {
				isExecuting = true;
				oldValue = scope.field.value;
				var selectedItem = e.choice;
				if (scope.multiple && selectedItem[scope.valueField] != '') {
					var values = !scope.field.value ? [] : scope.field.value.split(',');
					var displayValues = !scope.field.displayValue ? [] : scope.field.displayValue.split(TOKENIZER);
					values.push(selectedItem[scope.valueField]);
					displayValues.push(getDisplayValue(selectedItem));
					scope.field.value = values.join(',');
					scope.field.displayValue = displayValues.join(TOKENIZER);
					e.preventDefault();
					$select.select2('val', values).select2('close');
					scope.$apply(function() {
						callChange(oldValue, e);
					});
				}
			}
			function onRemoving(e) {
				isExecuting = true;
				oldValue = scope.field.value;
				var removed = e.choice;
				if (scope.multiple){
					var values = scope.field.value.split(',');
					var displayValues = scope.field.displayValue.split(TOKENIZER);
					for(var i = values.length-1; i>=0; i--){
						if (removed[scope.valueField] == values[i]) {
							values.splice(i, 1);
							displayValues.splice(i, 1);
							break;
						}
					}
					scope.field.value = values.join(',');
					scope.field.displayValue = displayValues.join(TOKENIZER);
					e.preventDefault();
					$select.select2('val', scope.field.value.split(','));
					scope.$apply(function() {
						callChange(oldValue, e);
					});
				}
			}
			function callChange(oldValue, e) {
				var f = scope.field;
				var p = {
						field: f,
						newValue: f.value,
						oldValue: oldValue,
						displayValue: f.displayValue
					}
				scope.$emit("field.change", p);
scope.$emit("field.change." + f.name, p);
				if (scope.onChange)
					try {
						scope.onChange(e);
					} catch(ex) {
						console.log("directive.snRecordPicker error in onChange")
						console.log(ex)
					}
				isExecuting = false;
			}
			function onChanged(e) {
				e.stopImmediatePropagation();
				if (scope.$$phase || scope.$root.$$phase) {
					console.warn('in digest, returning early');
					return;
				}
				if (e.added) {
					var selectedItem = e.added;
					if (!scope.multiple){
						scope.field.value = selectedItem[scope.valueField];
						if (scope.field.value) {
							scope.field.displayValue = getDisplayValue(selectedItem);
						} else
							scope.field.displayValue = '';
					}
				} else if (e.removed) {
					 if (!scope.multiple) {
						scope.field.displayValue = '';
						scope.field.value = '';
						setTimeout(function(){
							select2Focusser.focus();
						});
					}
				}
				select2Container.find(".select2-focusser").attr("aria-label", getAriaLabel());
				setAccessiblePlaceholder();
				scope.$apply(function() {
					callChange(oldValue, e);
				});
			}
			function getDisplayValue(selectedItem) {
				var displayValue = selectedItem[scope.valueField];
				if (selectedItem) {
					if (scope.displayField && angular.isDefined(selectedItem[scope.displayField]))
						displayValue = selectedItem[scope.displayField];
					else if (selectedItem.name)
						displayValue = selectedItem.name;
					else if (selectedItem.title)
						displayValue = selectedItem.title;
				}
				return cleanLabel(displayValue);
			}
			function getdisplayFields(selectedItem) {
				var displayFields = [];
				if (selectedItem && selectedItem[scope.valueField]) {
					var current = "";
					if (scope.displayField && angular.isDefined(selectedItem[scope.displayField]))
						current = selectedItem[scope.displayField];
					else if (selectedItem.name)
						current = selectedItem.name;
					else if (selectedItem.title)
						current = selectedItem.title;
					displayFields.push(current);
				}
				if (scope.displayFields) {
					var columns = scope.displayFields.split(",");
					for (var i = 0; i < columns.length; i++) {
						var column = columns[i];
						if (selectedItem[column])
							displayFields.push(selectedItem[column]);
					}
				}
				return displayFields;
			}
			scope.$watch("field.value", function(newValue) {
				if (isExecuting) return;
				if (angular.isDefined(newValue) && $select) {
					if (scope.multiple)
						$select.select2('val', newValue.split(',')).select2('close');
					else
						$select.select2('val', newValue).select2('close');
				}
			});
			function updateAriaExpanded(isOpen) {
				var select2Parent = element.data('select2');
				if (scope.multiple)
					select2Parent.container.find(".select2-choices input[role='combobox']").attr("aria-expanded", isOpen);
				else
					select2Parent.focusser.attr("aria-expanded", isOpen);
			}
			element.bind("select2-open", function() {
				updateAriaExpanded(true);
			});
			element.bind("select2-close", function() {
				updateAriaExpanded(false);
			});
			if (attrs.displayValue) {
				attrs.$observe('displayValue', function(value){
					scope.field.value = value;
				});
			}
			init();
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/controls/directive.snSelectBasic.js */
angular.module('sn.common.controls').directive('snSelectBasic', function($timeout,i18n) {
	return {
		restrict: 'C',
		priority: 1,
		require: '?ngModel',
		scope: {
'snAllowClear': '@',
'snSelectWidth': '@',
			'snChoices': '=?'
		},
		link: function (scope, element, attrs, ngModel) {
			if (angular.isFunction(element.select2)) {
				var config = {
					allowClear: scope.selectAllowClear,
					width: scope.selectWidth
				};
				i18n.getMessage('Searching...', function(searchingMsg) {
					config.formatSearching = function() {
						return searchingMsg;
					};
				});
				i18n.getMessage('No matches found', function(msg) {
					config.formatNoMatches = function() {
						return msg;
					};
				});
				i18n.getMessage('Loading more results...', function(msg) {
					config.formatLoadMore = function() {
						return msg;
					};
				});
				element.css("opacity", 0);
				scope.selectWidth = scope.snSelectWidth || '100%';
				scope.selectAllowClear = scope.snAllowClear === "true";
				$timeout(function(){
					element.css("opacity", 1);
					element.select2(config);
					if (ngModel === null)
						return;
					ngModel.$render = function(){
						element.select2('val', ngModel.$viewValue);
						element.val(ngModel.$viewValue);
					};
					var select2Data = element.data('select2');
					if (select2Data) {
						var select2ResultsId = select2Data.results.attr('id');
						select2Data.focusser.attr("aria-controls", select2ResultsId);
						select2Data.search.attr("aria-controls", select2ResultsId);
					}
					element.parent().find(".select2-focusser").attr("aria-expanded", false);
				});
				element.on('change', function() {
					scope.$evalAsync(setModelValue);
				});
				scope.$watch('snChoices', function(newValue, oldValue){
					if (angular.isDefined(newValue) && newValue != oldValue) {
						$timeout(function(){
							setModelValue();
						});
					}
				}, true);
				function setModelValue(){
					if (ngModel === null)
						return;
					ngModel.$setViewValue(element.val());
				};
				
				element.on("select2-open", function() {
					if (element.data('select2').search.val() === " ")
					    element.select2("search", "");
					element.parent().find(".select2-focusser").attr("aria-expanded", true);
				});
				element.on("select2-close", function() {
					element.parent().find(".select2-focusser").attr("aria-expanded", false);
				});
			}
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/controls/directive.snTableReference.js */
angular.module('sn.common.controls').directive('snTableReference', function($timeout) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		scope: {
			field: "=",
			snChange: "&",
			snDisabled: "="
		},
template: '<select ng-disabled="snDisabled" style="min-width: 150px;" name="{{::field.name}}" ng-model="fieldValue" ng-model-options="{getterSetter: true}" ng-options="choice.value as choice.label for choice in field.choices"></select>',
		controller: function($scope){
			$scope.fieldValue = function(selected){
				if (angular.isDefined(selected)) {
					$scope.snChange({ newValue: selected });
				}
				return $scope.field.value;
			}
		},
		link: function(scope, element) {
			var initTimeout = null;
			var fireReadyEvent = true;
			var field = scope.field;
			var isOpen = false;
			element.css("opacity", 0);
			function render() {
				var select2Focusser = element.parent().find('.select2-focusser');
				$timeout.cancel(initTimeout);
				initTimeout = $timeout(function() {
					element.css("opacity", 1);
					element.select2("destroy");
					element.select2();
					if (select2Focusser.length > 0)
						setAccessibilityRoles();
					if (fireReadyEvent) {
						scope.$emit('select2.ready', element);
						fireReadyEvent = false;
					}
				});
			}
			element.bind("select2-open", function(){
				isOpen = true;
				element.parent().find('.select2-focusser').attr('aria-expanded', isOpen);
			});
			element.bind("select2-close", function(){
				isOpen = false;
				element.parent().find('.select2-focusser').attr('aria-expanded', isOpen);
			});
			scope.$on('select2.ready', function() {
				setAccessibilityRoles();
			});
			function setAccessibilityRoles() {
				var select2Results = element.parent().find('ul.select2-results');
				var select2Focusser = element.parent().find('.select2-focusser');
				var select2Choice = element.parent().find(".select2-choice");
				select2Focusser.removeAttr('aria-labelledby');
				select2Focusser.attr('aria-label', getAriaLabel());
				select2Focusser.attr('aria-required', field.isMandatory());
				select2Focusser.attr('aria-expanded', isOpen);
				select2Focusser.attr('aria-owns', select2Results.attr('id'));
				select2Choice.attr("aria-hidden", true);
			}
			function getAriaLabel() {
				var displayValue = '';
				var label = '';
				label += field.label;
				displayValue = element.parent().find('.select2-choice .select2-chosen').text();
				if (displayValue) {
				label += (" " + displayValue);
				}
				return label;
			}
			scope.$watch("field.displayValue", function(newValue, oldValue) {
				if (newValue !== undefined && newValue != oldValue) {
					render();
				}
			});
			render();
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/controls/directive.snFieldReference.js */
angular.module('sn.common.controls').directive('snFieldReference', function($timeout, $http, nowServer) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
		scope: {
			field: "=",
			snChange: "&",
			snDisabled: "=",
			getGlideForm: '&glideForm'
		},
template: '<select ng-disabled="snDisabled" name="{{field.name}}" style="min-width: 150px;" ng-model="fieldValue" ng-model-options="{getterSetter: true}" ng-options="choice.name as choice.label for choice in field.choices"></select>',
		controller: function($scope){
			$scope.fieldValue = function(selected){
				if (angular.isDefined(selected)) 
					$scope.snChange({ newValue: selected });
				return $scope.field.value;
			}
			$scope.$watch('field.dependentValue', function(newVal, oldVal){
				if (!angular.isDefined(newVal)) 
					return;
				
				var src = nowServer.getURL('table_fields', 'exclude_formatters=true&fd_table=' + newVal);
				$http.post(src).success(function(response) {
					$scope.field.choices = response;
					$scope.render();
				});
			});
		},
		link: function(scope, element) {
			var initTimeout = null;
			var fireReadyEvent = true;
			scope.render = function() {
				$timeout.cancel(initTimeout);
				initTimeout = $timeout(function() {
					element.select2("destroy");
					element.select2();
					if (fireReadyEvent) {
						scope.$emit('select2.ready', element);
						fireReadyEvent = false;
					}
				});
			};
			scope.$watch("field.displayValue", function(newValue, oldValue) {
				if (newValue !== undefined && newValue != oldValue) {
					scope.render();
				}
			});
			scope.render();
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/controls/directive.snSyncWith.js */
angular.module("sn.common.controls").directive('snSyncWith', function() {
	return {
		restrict: 'A',
		require: 'ngModel',
		link: function (scope, elem, attr) {
			var journalField = scope.$eval(attr.snSyncWith);
			var journalValue =  scope.$eval(attr.ngModel);
			if(attr.snSyncWithValueInFn)
				scope.$eval(attr.ngModel + "=" + attr.snSyncWithValueInFn, {text: scope.value});
			scope.$watch(function() {
				return scope.$eval(attr.snSyncWith);
			}, function(nv, ov) {
				if (nv !== journalField)
					journalField = nv;
			});
			scope.$watch(function() {
				return scope.$eval(attr.ngModel);
			}, function(nv, ov) {
				if (nv !== ov)
					journalValue = nv;
			});
			if (!window.g_form)
				return;
			scope.$watch(function(){
				return journalValue;
			}, function (n, o) {
				if (n !== o)
					setFieldValue();
			});
			function setFieldValue() {
				setValue(journalField, journalValue);
			}
			function setValue(field, value) {
				value = !!value ? value : '';
				var control = g_form.getControl(field);
				if(attr.snSyncWithValueOutFn)
					value = scope.$eval(attr.snSyncWithValueOutFn,  {text: value})
				control.value = value;
				onChange(control.id);
			}
			scope.$watch(function(){
				return journalField;
			}, function(newValue, oldValue) {
				if (newValue !== oldValue){
					if (oldValue)
						setValue(oldValue, '');
					if (newValue)
						setFieldValue();
				}
			}, true);
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/controls/directive.contenteditable.js */
angular.module('sn.common.controls').directive('contenteditable', function($timeout, $sanitize) {
	return {
		require: 'ngModel',
		link: function(scope, elem, attrs, ctrl) {
			var changehandler = scope.changehandler;
			scope.usenewline = scope.usenewline + "" != "false";
			var newLine = "\n";
			var nodeBR = "BR";
			var nodeDIV = "DIV";
			var nodeText = "#text";
			var nbspRegExp = new RegExp(String.fromCharCode(160), "g");
			if (!scope.usenewline)
				elem.keypress(function(event) {
					if (event.which == "13") {
						if (scope.entercallback)
							scope.entercallback(elem);
						event.preventDefault();
					}
				});
			function processNodes(nodes) {
				var val = "";
				for (var i = 0; i < nodes.length; i++) {
					var node = nodes[i];
					var follow = true;
					switch (node.nodeName) {
						case nodeText:
							val += node.nodeValue.replace(nbspRegExp, " ");
							break;
						case nodeDIV:
							val += newLine;
							if (node.childNodes.length == 1 && node.childNodes[0].nodeName == nodeBR)
								follow = false;
							break;
						case nodeBR:
							val += scope.usenewline ? newLine : "";
					}
					if (follow)
						val += processNodes(node.childNodes)
				}
				return val;
			}
			function readHtml() {
				var val = processNodes(elem[0].childNodes);
				ctrl.$setViewValue(val);
			}
			function writeHtml() {
				var val = ctrl.$viewValue;
				if (!val || val === null)
					val = "";
val = val.replace(/\n/gi,	scope.usenewline ? "<br/>" : "");
val = val.replace(/  /gi,	" &nbsp;");
				try {
					if (attrs.contenteditableEscapeHtml == "true")
						val = $sanitize(val);
				} catch (err) {
var replacement = {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#x27;', '/': '&#x2F;'};
val = val.replace(/[&<>"'\/]/g, function (pattern) {return replacement[pattern]});
				};
				elem.html(val);
			}
			function processPlaceholder() {
				if (elem[0].dataset) {
					if (elem[0].textContent)
						elem[0].dataset.divPlaceholderContent = 'true';
					else if (elem[0].dataset.divPlaceholderContent)
						delete(elem[0].dataset.divPlaceholderContent);
				}
			}
			elem.bind('keyup', function() {
				scope.$apply(function() {
					readHtml();
					processPlaceholder();
				});
			});
			
			function selectText(elem) {
				var range;
				var selection;
				if (document.body.createTextRange) {
					range = document.body.createTextRange();
					range.moveToElementText(elem);
					range.select();
				} else if (window.getSelection) {
					selection = window.getSelection();
					range = document.createRange();
					range.selectNodeContents(elem);
					selection.removeAllRanges();
					selection.addRange(range);
				}
			}
			
			elem.bind('focus', function() {
				if (scope[attrs.tracker] && scope[attrs.tracker]['isDefault_' + attrs.trackeratt])
					$timeout(function() {
						selectText(elem[0]);
					});
				elem.original = ctrl.$viewValue;
			});
			
			elem.bind('blur', function() {
				scope.$apply(function() {
					readHtml();
					processPlaceholder();
					if (elem.original != ctrl.$viewValue && changehandler) {
						if (scope[attrs.tracker] && typeof scope[attrs.tracker]['isDefault_' + attrs.trackeratt] != "undefined")
							scope[attrs.tracker]['isDefault_' + attrs.trackeratt] = false;
						changehandler(scope[attrs.tracker], attrs.trackeratt);
					}
				});
			});
			elem.bind('paste', function() {
				scope.$apply(function() {
					setTimeout(function() {
						readHtml();
						writeHtml();
					}, 0);
					return false;
				});
			});
			ctrl.$render = function() {
				writeHtml();
			};
			scope.$watch('field.readonly', function(){
				elem[0].contentEditable = !scope.$eval('field.readonly');
			});
			scope.$watch(
				function () {
					return {
						val: elem[0].textContent
					};
				},
				function (newValue, oldValue) {
					if (newValue.val != oldValue.val)
						processPlaceholder();
				},
				true);
			writeHtml();
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/controls/directive.snGlyph.js */
angular.module("sn.common.controls").directive("snGlyph", function() {
	"use strict";
	return {
		restrict : 'E',
		replace : true,
		scope : {
			char : "@",
		},
template : '<span class="glyphicon glyphicon-{{char}}" />',
		link : function(scope) {}
	}
});
angular.module("sn.common.controls").directive('fa', function () {
    return {
      restrict: 'E',
template: '<span class="fa" aria-hidden="true"></span>',
      replace: true,
      link: function (scope, element, attrs) {
        'use strict';
        var currentClasses = {};
        function _observeStringAttr (attr, baseClass) {
          var className;
          attrs.$observe(attr, function () {
            baseClass = baseClass || 'fa-' + attr;
            element.removeClass(currentClasses[attr]);
            if (attrs[attr]) {
              className = [baseClass, attrs[attr]].join('-');
              element.addClass(className);
              currentClasses[attr] = className;
            }
          });
        }
        _observeStringAttr('name', 'fa');
        _observeStringAttr('rotate');
        _observeStringAttr('flip');
        _observeStringAttr('stack');
        attrs.$observe('size', function () {
          var className;
          element.removeClass(currentClasses.size);
          if (attrs.size === 'large') {
            className = 'fa-lg';
          } else if (!isNaN(parseInt(attrs.size, 10))) {
            className = 'fa-' + attrs.size + 'x';
          }
          element.addClass(className);
          currentClasses.size = className;
        });
        attrs.$observe('stack', function () {
          var className;
          element.removeClass(currentClasses.stack);
          if (attrs.stack === 'large') {
            className = 'fa-stack-lg';
          } else if (!isNaN(parseInt(attrs.stack, 10))) {
            className = 'fa-stack-' + attrs.stack + 'x';
          }
          element.addClass(className);
          currentClasses.stack = className;
        });
        function _observeBooleanAttr (attr, className) {
          var value;
          attrs.$observe(attr, function () {
            className = className || 'fa-' + attr;
            value = attr in attrs && attrs[attr] !== 'false' && attrs[attr] !== false;
            element.toggleClass(className, value);
          });
        }
        _observeBooleanAttr('border');
        _observeBooleanAttr('fw');
        _observeBooleanAttr('inverse');
        _observeBooleanAttr('spin');
        element.toggleClass('fa-li',
          element.parent() &&
          element.parent().prop('tagName') === 'LI' &&
          element.parent().parent() &&
          element.parent().parent().hasClass('fa-ul') &&
          element.parent().children()[0] === element[0] &&
          attrs.list !== 'false' &&
          attrs.list !== false
        );
        attrs.$observe('alt', function () {
          var altText = attrs.alt,
              altElem = element.next(),
              altElemClass = 'fa-alt-text';
          if (altText) {
            element.removeAttr('alt');
            if (!altElem || !altElem.hasClass(altElemClass)) {
element.after('<span class="sr-only fa-alt-text"></span>');
              altElem = element.next();
            }
            altElem.text(altText);
          } else if (altElem && altElem.hasClass(altElemClass)) {
            altElem.remove();
          }
        });
      }
    };
  })
  .directive('faStack', function () {
    return {
      restrict: 'E',
      transclude: true,
template: '<span ng-transclude class="fa-stack fa-lg"></span>',
      replace: true,
      link: function (scope, element, attrs) {
        var currentClasses = {};
        function _observeStringAttr (attr, baseClass) {
          var className;
          attrs.$observe(attr, function () {
            baseClass = baseClass || 'fa-' + attr;
            element.removeClass(currentClasses[attr]);
            if (attrs[attr]) {
              className = [baseClass, attrs[attr]].join('-');
              element.addClass(className);
              currentClasses[attr] = className;
            }
          });
        }
        _observeStringAttr('size');
        attrs.$observe('size', function () {
          var className;
          element.removeClass(currentClasses.size);
          if (attrs.size === 'large') {
            className = 'fa-lg';
          } else if (!isNaN(parseInt(attrs.size, 10))) {
            className = 'fa-' + attrs.size + 'x';
          }
          element.addClass(className);
          currentClasses.size = className;
        });
      }
    };
  });
;
/*! RESOURCE: /scripts/sn/common/controls/directive.snImageUploader.js */
angular.module('sn.common.controls').directive('snImageUploader', function($window, $rootScope, $timeout, getTemplateUrl, i18n, snAttachmentHandler) {
	var DRAG_IMAGE_SELECT = i18n.getMessage('Drag image or click to select');
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl('directive.snImageUploader'),
		transclude: true,
		scope: {
			readOnly: '@',
			tableName: '@',
			sysId: '@',
			fieldName: '@',
			fieldLabel: '@',
			onUpload: '&',
			onDelete: '&',
			uploadMessage: '@',
			src: '='
		},
		controller: function($scope) {
			$scope.uploading = false;
			$scope.getTitle = function() {
				if($scope.readOnly !== 'true')
					return DRAG_IMAGE_SELECT;
				return '';
			}
		},
		link: function(scope, element) {
			function isValidImage(file) {
				if (file.type.indexOf('image') != 0) {
					$alert(i18n.getMessage('Please select an image'));
					return false;
				}
				if (file.type.indexOf('tiff') > 0) {
					$alert(i18n.getMessage('Please select a common image format such as gif, jpeg or png'));
					return false;
				}
				return true;
			}
			function $alert(message) {
alert(message);
			}
			scope.onFileSelect = function($files) {
				if (scope.readOnly === 'true')
					return;
				if ($files.length == 0)
					return;
				var file = $files[0];
				if(!isValidImage(file))
					return;
				var uploadParams = {
					sysparm_fieldname: scope.fieldName
				};
				scope.uploading = true;
				snAttachmentHandler.create(scope.tableName, scope.sysId).uploadAttachment(file, uploadParams).then(function(response) {
					$timeout(function() {
						scope.uploading = false;
					});
					if (scope.onUpload)
						scope.onUpload(response);
					$rootScope.$broadcast("snImageUploader:complete", scope.sysId, response);
				});
			}
			scope.openFileSelector = function($event) {
				$event.stopPropagation();
				var input = element.find('input[type=file]');
input.click();
			}
			scope.activateUpload = function($event) {
				if (scope.readOnly !== 'true')
					scope.openFileSelector($event);
				else
					scope.showUpload = !scope.showUpload;
			}
			scope.deleteAttachment = function () {
				var sys_id = scope.src.split(".")[0];
				snAttachmentHandler.deleteAttachment(sys_id).then(function () {
					scope.src = null;
					if (scope.onDelete)
						scope.onDelete();
					$rootScope.$broadcast("snImageUploader:delete", scope.sysId, sys_id);
				});
			}
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/controls/service.select2EventBroker.js */
angular.module('sn.common.controls').factory('select2EventBroker', function() {
	var subscribers = {};
	var uuid = -1;
	function _openSelect2Element() {
		for (var key in subscribers) {
			subscribers[key]();
		}
	}
	function _onSelect2Opening(callback) {
		var subscriptionToken = (++uuid).toString();
		subscribers[subscriptionToken] = callback.bind(this);
		return function unsubscribe() {
			delete subscribers[subscriptionToken];
		}
	}
	
	return {
		publishSelect2Opening: _openSelect2Element,
		subscribeSelect2Opening: _onSelect2Opening
	}
});
;
;
/*! RESOURCE: /scripts/sn/common/controls/js_includes_controls.js */
/*! RESOURCE: /scripts/sn/common/i18n/_module.js */
angular.module('sn.common.i18n', ['sn.common.glide']);
angular.module('sn.i18n', ['sn.common.i18n']);
;
/*! RESOURCE: /scripts/sn/common/i18n/directive.snBindI18n.js */
angular.module('sn.common.i18n').directive('snBindI18n', function(i18n, $sanitize) {
	return {
		restrict: 'A',
		link : function(scope, iElem, iAttrs) {
			i18n.getMessage(iAttrs.snBindI18n, function(translatedValue) {
				var sanitizedValue = $sanitize(translatedValue);
				iElem.append(sanitizedValue);
			});
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/i18n/directive.message.js */
angular.module('sn.common.i18n').directive('nowMessage', function(i18n) {
	return {
		restrict: 'E',
		priority: 0,
		template: '',
		replace: true,
		compile: function(element, attrs, transclude) {
			var value = element.attr('value');
			if (!attrs.key || !value)
				return;
			i18n.loadMessage(attrs.key, value);
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/i18n/service.i18n.js */
angular.module('sn.common.i18n').provider('i18n', function() {
	var messageMap = {};
	function loadMessage(msgKey, msgValue) {
		messageMap[msgKey] = msgValue;
	}
	this.preloadMessages = function(messages) {
		angular.forEach(messages, function(key, val) {
			loadMessage(key, val);
		});
	};
	function interpolate(param) {
return this.replace(/{([^{}]*)}/g,
			function (a, b) {
				var r = param[b];
				return typeof r === 'string' || typeof r === 'number' ? r : a;
			}
		);
	}
	if (!String.prototype.withValues)
		String.prototype.withValues = interpolate;
	this.$get = function(nowServer, $http, $window, $log) {
		var isDebug = $window.NOW ? $window.NOW.i18n_debug : true;
		function debug(msg) {
			if (!isDebug)
				return;
			$log.log('i18n: ' + msg);
		}
function getMessageFromServer( msgKey, callback) {
			getMessagesFromServer([msgKey], function() {
				if (callback)
					callback(messageMap[msgKey]);
			});
		}
function getMessagesFromServer( msgArray, callback,  msgArrayFull) {
			var url = nowServer.getURL('message');
			$http.post(url, { messages: msgArray }).success(function(response) {
				var messages = response.messages;
				for (var i in messages) {
					loadMessage(i, messages[i]);
				}
				var returnMessages = {},
					allMessages = msgArrayFull || msgArray;
				for (var j = 0; j < allMessages.length; j++) {
					var key = allMessages[j];
					returnMessages[key] = messageMap[key];
				}
				if (callback)
					callback(returnMessages);
			});
		}
		return {
getMessage: function( msgKey, callback) {
				debug('getMessage: Checking for ' + msgKey);
				if (messageMap.hasOwnProperty(msgKey)) {
					var message = messageMap[msgKey];
					if (typeof(callback) == 'function')
						callback(message);
					debug('getMessage: Found: ' + msgKey + ', message: ' + message);
					return message;
				}
				debug('getMessage: Not found: ' + msgKey + ', querying server');
				getMessageFromServer(msgKey, callback);
				msgKey.withValues = interpolate;
				if (typeof(callback) != 'function')
					$log.warn('getMessage (key="' + msgKey + '"): synchronous use not supported in Mobile or Service Portal unless message is already cached');
				return msgKey;
			},
			format: function(message) {
				if(arguments.length == 1)
					return message;
				if(arguments.length == 2 && (typeof arguments[1] === 'object'))
					return interpolate.call(message, arguments[1]);
				return interpolate.call(message, [].slice.call(arguments, 1));
			},
getMessages: function( msgArray, callback) {
				debug('getMessages: Checking for ' + msgArray.join(','));
				var results = {},
					needMessage = [],
					needServerRequest = false;
				for (var i = 0; i < msgArray.length; i++) {
					var key = msgArray[i];
					if (!messageMap.hasOwnProperty(key)) {
						debug('getMessages: Did not find ' + key);
						needMessage.push(key);
						needServerRequest = true;
						results[key] = key;
						continue;
					}
					results[key] = messageMap[key];
					debug('getMessages: Found ' + key + ', message: ' + results[key]);
				}
				if (needServerRequest) {
					debug('getMessages: Querying server for ' + needMessage.join(','));
					getMessagesFromServer(needMessage, callback, msgArray);
				} else if (typeof(callback) == 'function') {
					debug('getMessages: Found all messages');
					callback(results);
				}
				return results;
			},
			clearMessages: function() {
				debug('clearMessages: clearing messages');
				messageMap = {};
			},
			loadMessage: function(msgKey, msgValue) {
				loadMessage(msgKey, msgValue);
				debug('loadMessage: loaded key: ' + msgKey + ', value: ' + msgValue);
			},
			preloadMessages: function() {
				var that = this
				angular.element('now-message').each(function() {
					var elem = angular.element(this);
					that.loadMessage(elem.attr('key'), elem.attr('value'));
				})
			}
		};
	};
});
;
;
/*! RESOURCE: /scripts/sn/common/i18n/js_includes_i18n.js */
/*! RESOURCE: /scripts/sn/common/link/_module.js */
angular.module("sn.common.link", []);
;
/*! RESOURCE: /scripts/sn/common/link/directive.snLinkContent.js */
angular.module('sn.common.link').directive('snLinkContent', function($compile, linkContentTypes) {
	'use strict';
	return {
		restrict: 'E',
		replace: true,
template: "<span />",
		scope: {
			link: "="
		},
		link: function(scope, elem) {
			scope.isShowing = function() {
				return (scope.link.isActive || scope.link.isUnauthorized) && !scope.link.isPending;
			};
			var linkDirective = linkContentTypes.forType(scope.link);
			elem.attr(linkDirective, "");
			elem.attr('ng-if', 'isShowing()');
			$compile(elem)(scope);
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/link/directive.snLinkContentYoutube.js */
angular.module('sn.common.link').directive('snLinkContentYoutube', function(getTemplateUrl, $sce, inFrameSet) {
	'use strict';
	return {
		restrict: 'A',
		replace: true,
		templateUrl: getTemplateUrl('snLinkContentYoutube.xml'),
		scope: {
			link: "="
		},
		controller: function($scope) {
			$scope.playerActive = false;
			$scope.width = (inFrameSet) ? '248px' : '500px';
			$scope.height = (inFrameSet) ? '139px' : '281px';
			$scope.showPlayer = function() {
				$scope.playerActive = true;
			};
			$scope.getVideoEmbedLink = function() {
				if ($scope.link.embedLink) {
					var videoLink = $scope.link.embedLink + "?autoplay=1";
return $sce.trustAsHtml("<iframe width='" + $scope.width + "' height='" + $scope.height + "' autoplay='1' frameborder='0' allowfullscreen='' src='" + videoLink + "'></iframe>");
				}
			};
		}
 	}
});
;
/*! RESOURCE: /scripts/sn/common/link/directive.snLinkContentSoundcloud.js */
angular.module('sn.common.link').directive('snLinkContentSoundcloud', function(getTemplateUrl, $sce, inFrameSet) {
	'use strict';
	return {
		restrict: 'A',
		replace: true,
		templateUrl: getTemplateUrl('snLinkContentSoundcloud.xml'),
		scope: {
			link: "="
		},
		controller: function($scope) {
			$scope.playerActive = false;
			$scope.width = (inFrameSet) ? '248px' : '500px';
			$scope.height = (inFrameSet) ? '139px' : '281px';
			$scope.showPlayer = function() {
				$scope.playerActive = true;
			};
			$scope.getVideoEmbedLink = function() {
				if ($scope.link.embedLink) {
					var videoLink = $scope.link.embedLink + "&amp;auto_play=true";
					var width = (inFrameSet) ? 248 : 500;
return $sce.trustAsHtml("<iframe width='" + $scope.width + "' height='" + $scope.height + "' autoplay='1' frameborder='0' allowfullscreen='' src='" + videoLink + "'></iframe>");
				}
			};
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/link/directive.snLinkContentArticle.js */
angular.module('sn.common.link').directive('snLinkContentArticle', function(getTemplateUrl) {
	'use strict';
	return {
		restrict: 'A',
		replace: true,
		templateUrl: getTemplateUrl('snLinkContentArticle.xml'),
		scope: {
			link: "="
		},
		controller: function($scope) {
			$scope.backgroundImageStyle = $scope.link.imageLink
				? {"background-image": 'url(' + $scope.link.imageLink + ')'}
				: {};
			$scope.isVisible = function() {
				var link = $scope.link;
				return !!link.shortDescription || !!link.imageLink;
			};
			$scope.hasDescription = function() {
				var link = $scope.link;
				return link.shortDescription && (link.shortDescription !== link.title);
			};
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/link/directive.snLinkContentError.js */
angular.module('sn.common.link').directive('snLinkContentError', function(getTemplateUrl) {
	'use strict';
	return {
		restrict: 'A',
		replace: true,
		templateUrl: getTemplateUrl('snLinkContentError.xml'),
		scope: {
			link: "="
		},
		controller: function($scope) {
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/link/directive.snLinkContentImage.js */
angular.module('sn.common.link').directive('snLinkContentImage', function(getTemplateUrl) {
	'use strict';
	return {
		restrict: 'A',
		replace: true,
		templateUrl: getTemplateUrl('snLinkContentImage.xml'),
		scope: {
			link: "="
		},
		controller: function($scope) {
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/link/directive.snLinkContentAttachment.js */
angular.module('sn.common.link').directive('snLinkContentAttachment', function(getTemplateUrl) {
	'use strict';
	return {
		restrict: 'EA',
		replace: true,
		templateUrl: getTemplateUrl('snLinkContentAttachment.xml'),
		scope: {
			attachment: '=',
			link: '='
		},
		controller: function($scope, $element, snCustomEvent) {
			$scope.attachmentFile = $scope.attachment || $scope.link.attachment;
			$scope.calcImageSize = function() {
				var imageWidth = $scope.width;
				var imageHeight = $scope.height;
				var MAX_IMAGE_SIZE = $element.width() < 298 ? $element.width() : 298;
				if (imageHeight < 0 || imageWidth < 0)
					return "";
				if (imageHeight > imageWidth) {
					if (imageHeight >= MAX_IMAGE_SIZE) {
imageWidth *= MAX_IMAGE_SIZE / imageHeight;
						imageHeight = MAX_IMAGE_SIZE;
					}
				} else {
					if (imageWidth >= MAX_IMAGE_SIZE) {
imageHeight *= MAX_IMAGE_SIZE / imageWidth;
						imageWidth = MAX_IMAGE_SIZE
					}
				}
				return "height: " + imageHeight + "px; width: " + imageWidth + "px;";
			};
			$scope.aspectRatioClass = function() {
				return ($scope.height > $scope.width) ? 'limit-height' : 'limit-width';
			};
			$scope.showImage = function(event) {
				if (event.keyCode === 9)
					return;
				snCustomEvent.fire('sn.attachment.preview', event, $scope.attachmentFile.rawData);
			};
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/link/directive.snLinkContentRecord.js */
angular.module('sn.common.link').directive('snLinkContentRecord', function(getTemplateUrl) {
	'use strict';
	return {
		restrict: 'A',
		replace: true,
		templateUrl: getTemplateUrl('snLinkContentRecord.xml'),
		scope: {
			link: '='
		},
		controller: function($scope) {
			$scope.isTitleVisible = function() {
				return !$scope.isDescriptionVisible() && $scope.link.title;
			};
			$scope.isDescriptionVisible = function() {
				return $scope.link.shortDescription;
			};
			$scope.hasNoHeader = function() {
				return !$scope.isTitleVisible() && !$scope.isDescriptionVisible();
			};
			$scope.isUnassigned = function() {
				return $scope.link.isTask && !$scope.link.avatarID;
			};
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/link/provider.linkContentTypes.js */
angular.module('sn.common.link').provider('linkContentTypes', function linkContentTypesProvider() {
	"use strict";
	var linkDirectiveMap = {
		'record' : "sn-link-content-record",
		'attachment' : "sn-link-content-attachment",
		'video' : "sn-link-content-youtube",
		'music.song': "sn-link-content-soundcloud",
		'link'   : 'sn-link-content-article',
		'article': 'sn-link-content-article',
		'website': 'sn-link-content-article',
		'image': 'sn-link-content-image'
	};
	this.$get = function linkContentTypesFactory() {
		return {
			forType: function(link) {
				if (link.isUnauthorized)
					return "sn-link-content-error";
				return linkDirectiveMap[link.type] || "no-card";
			}
		}
	};
});
;
;
/*! RESOURCE: /scripts/sn/common/link/js_includes_link.js */
/*! RESOURCE: /scripts/sn/common/mention/_module.js */
angular.module("sn.common.mention", []);
;
/*! RESOURCE: /scripts/sn/common/mention/directive.snMentionPopover.js */
angular.module('sn.common.mention').directive("snMentionPopover", function(getTemplateUrl, $timeout) {
	'use strict';
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl('snMentionPopover.xml'),
		link: function(scope, elem, $attrs) {
			elem.detach().appendTo(document.body);
			scope.dontPositionManually = scope.$eval($attrs.dontpositionmanually) || false;
			scope.onClick = function(event) {
				if (!angular.element(event.target).closest("#mention-popover").length
					|| angular.element(event.target).closest("#direct-message-popover-trigger").length) {
					scope.$evalAsync(function() {
						scope.$parent.showPopover = false;
						scope.$emit("snMentionPopover.showPopoverIsFalse");
						if (scope.dontPositionManually && !(scope.$eval($attrs.snavatarpopover))) {
							elem.remove();
						} else {
							scope.$broadcast("sn-avatar-popover-destroy");
						}
						angular.element('.popover').each(function () {
							var object = angular.element(this);
							if (object.popover) {
								object.popover('hide');
							}
						})
					});
				}
			};
			scope.clickListener = $timeout(function() {
				angular.element('html').on('click.mentionPopover', scope.onClick);
			}, 0, false);
			scope.$on('sn-bootstrap-popover.close-other-popovers', scope.onClick);
			function setPopoverPosition(clickX, clickY) {
				var topPosition;
				var leftPosition;
				var windowHeight = window.innerHeight;
				var windowWidth  = window.innerWidth;
if (((clickY - (elem.height() / 2))) < 10)
					topPosition = 10;
				else
topPosition = ((clickY + (elem.height() / 2)) > windowHeight) ? windowHeight - elem.height() - 15 : clickY - (elem.height() / 2);
				leftPosition = ((clickX + 20 + (elem.width())) > windowWidth) ? windowWidth - elem.width() - 15: clickX  + 20;
				elem.css("top", topPosition + "px").css("left", leftPosition + "px");
			}
			if (!scope.dontPositionManually) {
				$timeout(function () {
					var clickX = (scope.$parent && scope.$parent.clickEvent && scope.$parent.clickEvent.pageX) ? scope.$parent.clickEvent.pageX : clickX || 300;
					var clickY = (scope.$parent && scope.$parent.clickEvent && scope.$parent.clickEvent.pageY) ? scope.$parent.clickEvent.pageY : clickY || 300;
					setPopoverPosition(clickX, clickY);
					elem.velocity({
						opacity: 1
					}, {
						duration: 100,
						easing: "cubic"
					});
				});
			}
		},
		controller: function($scope, $element, $attrs) {
			$scope.profile = $scope.$eval($attrs.profile);
			$scope.$on("$destroy", function() {
				angular.element('html').off('click.mentionPopover', $scope.onClick);
				$element.remove();
			});
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/mention/service.snMention.js */
angular.module("sn.common.mention").factory("snMention", function(liveProfileID, $q, $http) {
	"use strict";
var MENTION_PATH = "/api/now/form/mention/record";
var USER_PATH = '/api/now/ui/user/';
	var avatarCache = {};
	function retrieveMembers(table, document, term) {
		if(!term || !document || !table) {
			var deferred = $q.defer();
			deferred.resolve([]);
			return deferred.promise;
		}
		return $http( {
url: MENTION_PATH + "/" + table + "/" + document,
			method: "GET",
			params: {
				term: term
			}
		}).then(function(response) {
			var members = response.data.result;
			var promises = [];
			angular.forEach(members, function(user) {
				if (avatarCache[user.sys_id]) {
					user.initials = avatarCache[user.sys_id].initials;
					user.avatar = avatarCache[user.sys_id].avatar;
				} else {
					var promise = $http.get(USER_PATH + user.sys_id).success(function(response) {
						user.initials = response.result.user_initials;
						user.avatar = response.result.user_avatar;
						avatarCache[user.sys_id] = {initials: user.initials, avatar: user.avatar};
					});
					promises.push(promise);
				}
			});
			return $q.all(promises).then(function() {
				return members;
			});
		})
	}
	return {
		retrieveMembers: retrieveMembers
	}
});
;
;
/*! RESOURCE: /scripts/sn/common/mention/js_includes_mention.js */
/*! RESOURCE: /scripts/doctype/CustomEventManager.js */
var NOW = NOW || {};
var CustomEventManager = (function (existingCustomEvent) {
	"use strict";
	var events = (existingCustomEvent && existingCustomEvent.events) || {};
	var isFiringFlag = false;
	var trace = false;
	var suppressEvents = false;
	var NOW_MSG = 'NOW.PostMessage';
	var g_concourse_onmessage_enforce_same_origin = 'true'.toLowerCase() === 'true';
	var g_concourse_onmessage_enforce_same_origin_whitelist = '';
	function observe(eventName, fn){
		if (trace)
			jslog("$CustomEventManager observing: " + eventName);
		on(eventName, fn);
	}
	function on(name, func) {
		if (!func || typeof func !== 'function')
			return;
		if (typeof name === 'undefined')
			return;
		if (!events[name])
			events[name] = [];
		events[name].push(func);
	}
	function un(name, func) {
		if (!events[name])
			return;
		var idx = -1;
		for (var i = 0; i < events[name].length; i++) {
			if (events[name][i] === func) {
				idx = i;
				break;
			}
		}
		if (idx >= 0)
			events[name].splice(idx, 1)
	}
	function unAll(name) {
		if (events[name])
			delete events[name];
	}
	function fire(eventName, args){
		if (trace)
			jslog("$CustomEventManager firing: " + eventName + " args: " + arguments.length);
		return fireEvent.apply(null, arguments);
	}
	function fireUp(eventName, args){
		var win = window;
		while (win){
			try {
				if (win.CustomEvent.fireEvent.apply(null, arguments) === false)
					return;
				win = win.parent === win ? null : win.parent;
			}catch(e){
				return;
			}
		}
	}
	function fireEvent() {
		if (suppressEvents)
			return true;
		var args = Array.prototype.slice.apply(arguments);
		var name = args.shift();
		var eventList = events[name];
		if (!eventList)
			return true;
		var event = eventList.slice();
		isFiringFlag = true;
for (var i = 0, l = event.length; i < l; i++) {
			var ev = event[i];
			if (!ev)
				continue;
			if (ev.apply(null, args) === false) {
				isFiringFlag = false;
				return false;
			}
		}
		isFiringFlag = false;
		return true;
	}
	function isFiring() {
		return isFiringFlag;
	}
	function forward(name, element, func) {
		on(name, func);
		element.addEventListener(name, function(e) {
			fireEvent(e.type, this, e);
		}.bind(api));
	}
	function isOriginInWhiteList(origin, whitelistStr) {
		if (!whitelistStr) {
			return false;
		}
var delimiterRegex = /[\n, ]/;
		var whitelist = whitelistStr.split(delimiterRegex)
			.filter(function(whiteListedOrigin) {
				return whiteListedOrigin;
			})
			.map(function(whiteListedOrigin) {
				return whiteListedOrigin.toLowerCase();
			});
		if (~whitelist.indexOf(origin.toLowerCase())) {
			return true;
		}
		return false;
	}
	function shouldProcessMessage(sourceOrigin) {
		if (!g_concourse_onmessage_enforce_same_origin || sourceOrigin === window.location.origin) {
			return true;
		}
		return isOriginInWhiteList(sourceOrigin, g_concourse_onmessage_enforce_same_origin_whitelist);
	}
    function registerPostMessageEvent() {
        if (NOW.registeredPostMessageEvent) {
            return;
        }
        if (!window.postMessage) {
            return;
        }
        window.addEventListener('message', function (event) {
            if (!shouldProcessMessage(event.origin)) {
                console.warn('Incoming message ignored due to origin mismatch.');
                return;
            }
            var nowMessageJSON = event.data;
            var nowMessage;
            try {
                nowMessage = JSON.parse(nowMessageJSON.toString());
            } catch (e) {
                return;
            }
            if (!nowMessage.type == NOW_MSG) {
                return;
            }
            fire(nowMessage.eventName, nowMessage.args);
        }, false);
        NOW.registeredPostMessageEvent = true;
    }
	function doPostMessage(win, event, msg, targetOrigin) {
		var nowMessage = {type: NOW_MSG, eventName: event, args: msg};
		var nowMessageJSON;
		if (!win || !win.postMessage) {
			return
		}
		nowMessageJSON = JSON.stringify(nowMessage);
		win.postMessage(nowMessageJSON, targetOrigin);
	}
	function fireTop(eventName, args){
		if (trace)
			jslog("$CustomEventManager firing: " + eventName + " args: " + arguments.length);
		fireEvent.apply(null, arguments);
		var t = getTopWindow();
		if (t !== null && window !== t)
			t.CustomEvent.fire(eventName, args);
	}
	function fireAll(eventName, args) {
		if (trace)
			jslog("$CustomEventManager firing: " + eventName + " args: " + arguments.length);
		var topWindow = getTopWindow();
		if (topWindow !== window.self)
			CustomEvent.fireEvent(eventName, args);
		notifyAllFrom(topWindow);
		function notifyAllFrom(rootFrame) {
			var childFrame;
			rootFrame.CustomEvent.fireEvent(eventName, args);
			for (var i = 0; i < rootFrame.frames.length; i++) {
				try {
					childFrame = rootFrame.frames[i];
					if (!childFrame)
						continue;
					if (childFrame.CustomEvent && typeof childFrame.CustomEvent.fireEvent === "function") {
						notifyAllFrom(childFrame);
					}
				} catch(e) {
				}
			}
		}
	}
	function fireToWindow(targetWindow, eventName, args, usePostMessage, targetOrigin) {
		if (trace)
			jslog("$CustomEventManager firing: " + eventName + " args: " + args.length);
		if (usePostMessage) {
			doPostMessage(targetWindow, eventName, args, targetOrigin);
		} else {
			targetWindow.CustomEvent.fireEvent(eventName, args);
		}
	}
	function getTopWindow() {
		var topWindow = window.self;
		try {
			while (topWindow.CustomEvent.fireEvent && topWindow !== topWindow.parent && topWindow.parent.CustomEvent.fireEvent) {
				topWindow = topWindow.parent;
			}
		} catch (e) {}
		return topWindow;
	}
	function isTopWindow() {
		return getTopWindow() == window.self;
	}
	function jslog(msg, src, dateTime) {
		try {
			if (!src) {
				var path = window.self.location.pathname;
src = path.substring(path.lastIndexOf('/') + 1);
			}
			if (window.self.opener && window != window.self.opener) {
				if (window.self.opener.jslog) {
					window.self.opener.jslog(msg, src, dateTime);
				}
			} else if (parent && parent.jslog && jslog != parent.jslog) {
				parent.jslog(msg, src, dateTime);
			} else {
				if (window.console && window.console.log)
					console.log(msg);
			}
		} catch (e) {
		}
	}
	var api =  {
		set trace(value) {
			trace = !!value;
		},
		get trace() {
			return trace;
		},
		set suppressEvents(value) {
			suppressEvents = !!value;
		},
		get suppressEvents() {
			return suppressEvents;
		},
		get events() {
			return events;
		},
		set events(value) {
			events = value;
		},
		on: on,
		un: un,
		unAll: unAll,
		forward: forward,
		isFiring: isFiring,
		fireEvent: fireEvent,
		observe: observe,
		fire: fire,
		fireTop: fireTop,
		fireAll: fireAll,
		fireToWindow: fireToWindow,
		isTopWindow: isTopWindow,
		fireUp: fireUp,
		toString: function() { return 'CustomEventManager'; }
	};
	registerPostMessageEvent();
	return api;
})(NOW.CustomEvent);
NOW.CustomEvent = CustomEventManager;
if (typeof CustomEvent !== "undefined") {
	CustomEvent.observe = NOW.CustomEvent.observe.bind(NOW.CustomEvent);
	CustomEvent.fire = NOW.CustomEvent.fire.bind(NOW.CustomEvent);
	CustomEvent.fireUp = NOW.CustomEvent.fireUp.bind(NOW.CustomEvent);
	CustomEvent.fireTop = NOW.CustomEvent.fireTop.bind(NOW.CustomEvent);
	CustomEvent.fireAll = NOW.CustomEvent.fireAll.bind(NOW.CustomEvent);
	CustomEvent.fireToWindow = NOW.CustomEvent.fireToWindow.bind(NOW.CustomEvent);
	CustomEvent.on = NOW.CustomEvent.on.bind(NOW.CustomEvent);
	CustomEvent.un = NOW.CustomEvent.un.bind(NOW.CustomEvent);
	CustomEvent.unAll = NOW.CustomEvent.unAll.bind(NOW.CustomEvent);
	CustomEvent.forward = NOW.CustomEvent.forward.bind(NOW.CustomEvent);
	CustomEvent.isFiring = NOW.CustomEvent.isFiring.bind(NOW.CustomEvent);
	CustomEvent.fireEvent = NOW.CustomEvent.fireEvent.bind(NOW.CustomEvent);
	CustomEvent.events = NOW.CustomEvent.events;
	CustomEvent.isTopWindow = NOW.CustomEvent.isTopWindow.bind(NOW.CustomEvent);
} else {
	window.CustomEvent = NOW.CustomEvent;
}
;
/*! RESOURCE: /scripts/sn/common/messaging/_module.js */
angular.module('sn.common.messaging', []);
angular.module('sn.messaging', ['sn.common.messaging']);
;
/*! RESOURCE: /scripts/sn/common/messaging/service.snCustomEvent.js */
angular.module('sn.common.messaging').factory('snCustomEvent',  function() {
	"use strict";
	if (typeof NOW.CustomEvent === 'undefined')
		throw "CustomEvent not found in NOW global";
	return NOW.CustomEvent;
});
;
;
/*! RESOURCE: /scripts/sn/common/messaging/js_includes_messaging.js */
/*! RESOURCE: /scripts/sn/common/notification/_module.js */
angular.module('sn.common.notification', ['sn.common.util', 'ngSanitize', 'sn.common.i18n']);
;
/*! RESOURCE: /scripts/sn/common/notification/factory.notificationWrapper.js */
angular.module("sn.common.notification").factory("snNotificationWrapper", function($window, $timeout) {
	"use strict";
	function assignHandler(notification, handlerName, options){
		if (typeof options[handlerName] === "function")
			notification[handlerName.toLowerCase()] = options[handlerName];
	}
	return function NotificationWrapper(title, options) {
		var defaults = {
			dir: 'auto',
			lang: 'en_US',
			decay: true,
			lifespan: 4000,
			body: "",
			tag: "",
icon: '/native_notification_icon.png'
		};
		var optionsOnClick = options.onClick;
		options.onClick = function() {
			if(angular.isFunction($window.focus))
				$window.focus();
			if(typeof optionsOnClick === "function")
				optionsOnClick();
		}
		var result = {};
		options = angular.extend(defaults, options);
		var previousOnClose = options.onClose;
		options.onClose = function() {
			if(angular.isFunction(result.onclose))
				result.onclose();
			if(angular.isFunction(previousOnClose))
				previousOnClose();
		}
		var notification = new $window.Notification(title, options);
		assignHandler(notification, "onShow", options);
		assignHandler(notification, "onClick", options);
		assignHandler(notification, "onError", options);
		assignHandler(notification, "onClose", options);
		if (options.decay && options.lifespan > 0)
			$timeout(function() {
				notification.close();
			}, options.lifespan)
		result.close = function() {
			notification.close();
		}
		return result;
	}
})
;
/*! RESOURCE: /scripts/sn/common/notification/service.snNotifier.js */
angular.module("sn.common.notification").factory("snNotifier", function ($window, snNotificationWrapper) {
	"use strict";
	return function(settings) {
		function requestNotificationPermission() {
			if($window.Notification && $window.Notification.permission === "default")
				$window.Notification.requestPermission();
		}
		function canUseNativeNotifications() {
			return ($window.Notification && $window.Notification.permission === "granted");
		}
		var currentNotifications = [];
		settings = angular.extend({
			notifyMethods: ["native", "glide"]
		}, settings);
		var methods = {
			'native': nativeNotify,
			'glide': glideNotify
		};
		function nativeNotify(title, options) {
			if(canUseNativeNotifications()) {
				var newNotification = snNotificationWrapper(title, options);
				newNotification.onclose = function () {
					stopTrackingNotification(newNotification)
				};
				currentNotifications.push(newNotification);
				return true;
			}
			return false;
		}
		function glideNotify(title, options) {
			return false;
		}
		function stopTrackingNotification(newNotification) {
			var index = currentNotifications.indexOf(newNotification);
			if(index > -1)
				currentNotifications.splice(index, 1);
		}
		function notify(title, options) {
			if(typeof options === "string")
				options = {body: options};
			options = options || {};
			for(var i = 0, len = settings.notifyMethods.length; i < len; i++)
				if(typeof settings.notifyMethods[i] == "string") {
					if(methods[settings.notifyMethods[i]](title, options))
						break;
				} else {
					if(settings.notifyMethods[i](title, options))
						break;
				}
		}
		function clearAllNotifications() {
			while(currentNotifications.length > 0)
				currentNotifications.pop().close();
		}
		return {
			notify: notify,
			canUseNativeNotifications: canUseNativeNotifications,
			clearAllNotifications: clearAllNotifications,
			requestNotificationPermission: requestNotificationPermission
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/notification/directive.snNotification.js */
angular.module('sn.common.notification').directive('snNotification', function($timeout, $rootScope) {
	"use strict";
	return {
		restrict: 'E',
		replace: true,
template: '<div class="notification-container"></div>',
		link: function(scope, element) {
			scope.addNotification = function(payload) {
				if (!payload)
					payload = {};
				if (!payload.text)
					payload.text = '';
				if (!payload.classes)
					payload.classes = '';
				if (!payload.duration)
					payload.duration = 5000;
angular.element('<div/>').qtip({
					content: {
						text: payload.text,
						title: {
							button: false
						}
					},
					position: {
						target: [0, 0],
						container: angular.element('.notification-container')
					},
					show: {
						event: false,
						ready: true,
						effect: function () {
							angular.element(this).stop(0, 1).animate({ height: 'toggle' }, 400, 'swing');
						},
						delay: 0,
						persistent: false
					},
					hide: {
						event: false,
						effect: function (api) {
							angular.element(this).stop(0, 1).animate({ height: 'toggle' }, 400, 'swing');
						}
					},
					style: {
						classes: 'jgrowl' + ' ' + payload.classes,
						tip: false
					},
					events: {
						render: function (event, api) {
							if (!api.options.show.persistent) {
								angular.element(this).bind('mouseover mouseout', function(e) {
									clearTimeout(api.timer);
									if (e.type !== 'mouseover') {
										api.timer = setTimeout(function() {
											api.hide(e);
										}, payload.duration);
									}
								})
								.triggerHandler('mouseout');
							}
						}
					}
				});
			},
			scope.$on('notification.notify', function(event, payload) {
				scope.addNotification(payload);
			});
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/notification/service.snNotification.js */
angular.module('sn.common.notification').factory('snNotification', function($document, $templateCache, $compile, $rootScope, $timeout, $q, getTemplateUrl, $http, i18n, $sce) {
	'use strict';
	var openNotifications = [],
		timeouts = {},
		options = {
top: 20,
gap: 10,
duration: 5000
		},
		a11yContainer,
		a11yDuration = 5000;
	return {
		show: function(type, message, duration, onClick, container, sourceElement) {
			return createNotificationElement(type, message).then(function(element) {
				return displayAndDestroyNotification(element, container, duration, sourceElement);
			});
		},
		showScreenReaderOnly: function(type, message, duration, onClick, container) {
			return createNotificationElement(type, message, true).then(function(element) {
				return displayAndDestroyNotification(element, container, duration);
			});
		},
		hide: hide,
		setOptions: function(opts) {
			if (angular.isObject(opts))
				angular.extend(options, opts);
		}
	};
	function displayAndDestroyNotification(element, container, duration, sourceElement) {
		displayNotification(element, container, sourceElement);
		checkAndSetDestroyDuration(element, duration);
		return element;
	}
	function getTemplate() {
		var templateName = 'sn_notification.xml',
			template = $templateCache.get(templateName),
			deferred = $q.defer();
		if (!template) {
			var url = getTemplateUrl(templateName);
			$http.get(url).then(function(result) {
					$templateCache.put(templateName, result.data);
					deferred.resolve(result.data);
				},
				function(reason) {
					return $q.reject(reason);
				});
		} else
			deferred.resolve(template);
		return deferred.promise;
	}
	function createNotificationElement(type, message, screenReaderOnly) {
		var thisScope, thisElement;
		var icon = 'icon-info';
		screenReaderOnly = typeof(screenReaderOnly) === 'undefined' ? false : screenReaderOnly;
		if (type == 'error') {
			icon = 'icon-cross-circle';
		} else if (type == 'warning') {
			icon = 'icon-alert';
		} else if (type == 'success') {
			icon = 'icon-check-circle';
		} else if (type == 'auth') {
			icon = 'icon-alert-triangle';
		}
		return getTemplate().then(function(template) {
			thisScope = $rootScope.$new();
			thisScope.type = type;
			thisScope.message = type == 'auth' ? $sce.trustAsHtml(message) : message;
			thisScope.icon = icon;
			thisScope.screenReaderOnly = screenReaderOnly;
			thisElement = $compile(template)(thisScope);
			return angular.element(thisElement[0]);
		});
	}
	function displayNotification(element, container, sourceElement) {
		if( !a11yContainer ) {
			a11yContainer = angular.element('<div class="notification-a11y-container sr-only" aria-live="assertive">');
			$document.find('body').append(a11yContainer);
		}
		var container = $document.find(container || 'body'),
			id = 'elm' + Date.now(),
			pos;
		container.append(element);
		pos = options.top + openNotifications.length * getElementHeight(element);
		positionElement(element, pos);
		element.addClass('visible');
		element.attr('id', id);
		element.find('button').bind('click', function(e) {
			hideElement(element);
			if (!openNotifications.length && sourceElement)
				sourceElement.focus();
		});
		element.find('button').focus();
		openNotifications.push(element);
		if (options.duration > 0)
			timeouts[id] = $timeout(function () {
				hideNext();
			}, options.duration);
		$timeout(function() {
			var srElement = angular.element('<div>').text(element.text());
			a11yContainer.append(srElement);
			$timeout(function() {
				srElement.remove();
			}, a11yDuration, false);
		}, 0, false)
	}
	function hide(element) {
		$timeout.cancel(timeouts[element.attr('id')]);
		element.removeClass('visible');
		element.addClass('hidden');
		element.find('button').eq(0).unbind();
		element.scope().$destroy();
		element.remove();
		repositionAll();
	}
	function hideElement(element) {
		var index = openNotifications.indexOf(element);
		openNotifications.splice(index, 1);
		hide(element);
	}
	function hideNext() {
		var element = openNotifications.shift();
		if (element)
			hide(element);
	}
	function getElementHeight(element) {
		return element[0].offsetHeight + options.gap;
	}
	function positionElement(element, pos) {
		element[0].style.top = pos + 'px';
	}
	function repositionAll() {
		var pos = options.top;
		openNotifications.forEach(function(element) {
			positionElement(element, pos);
			pos += getElementHeight(element);
		});
	}
	function checkAndSetDestroyDuration(element, duration){
		if (duration){
			timeouts[element.attr('id')] = $timeout(function(){
				hideElement(element);
			}, duration);
		}
	}
});
;
;
/*! RESOURCE: /scripts/sn/common/notification/js_includes_notification.js */
;
/*! RESOURCE: /scripts/js_includes_amb.js */
/*! RESOURCE: /scripts/app.ng.amb/app.ng.amb.js */
angular.module("ng.amb", ['sn.common.presence', 'sn.common.util'])
	.value("ambLogLevel", 'info')
.value("ambServletURI", '/amb')
	.value("cometd", angular.element.cometd)
	.value("ambLoginWindow", 'true');
;
/*! RESOURCE: /scripts/app.ng.amb/service.AMB.js */
angular.module("ng.amb").service("amb", function (AMBOverlay, $window, $q, $log, $rootScope, $timeout) {
  "use strict";
  var ambClient = null;
  var _window = $window.self;
  var loginWindow = null;
	var sameScope = false;
	ambClient = amb.getClient();
	if (_window.g_ambClient) {
		sameScope = true;
	}
	if (sameScope) {
	  var serverConnection = ambClient.getServerConnection();
	  serverConnection.loginShow = function() {
	    if (!serverConnection.isLoginWindowEnabled())
	      return;
	    if (loginWindow && loginWindow.isVisible())
	      return;
	    if (serverConnection.isLoginWindowOverride())
	      return;
	  	var modalConfig = {
	  		onBeforeShow: addOverrideStyles
		};
	    loginWindow = new AMBOverlay(modalConfig);
	    loginWindow.render();
	    loginWindow.show();
	  };
	  serverConnection.loginHide = function() {
	    if (!loginWindow)
	      return;
	    loginWindow.hide();
	    loginWindow.destroy();
	    loginWindow = null;
	  }
	}
	function addOverrideStyles(el) {
		var parent = angular.element(el.target).parent();
		var backdrop = parent.find('.modal-backdrop').last().get(0);
		if (backdrop !== undefined)
			backdrop.style.cssText = [backdrop.style.cssText, serverConnection.getLoginWindowOverlayStyle()].join('; ');
	}
	var AUTO_CONNECT_TIMEOUT = 20 * 1000;
	var connected = $q.defer();
	var connectionInterrupted = false;
	var monitorAMB = false;
	$timeout(startMonitoringAMB, AUTO_CONNECT_TIMEOUT);
	connected.promise.then(startMonitoringAMB);
	function startMonitoringAMB() {
		monitorAMB = true;
	}
	function ambInterrupted() {
		var state = ambClient.getState();
		return monitorAMB && state !== "opened" && state !== "initialized"
	}
	var interruptionTimeout;
	var extendedInterruption = false;
	function setInterrupted(eventName) {
		connectionInterrupted = true;
		$rootScope.$broadcast(eventName);
		if (!interruptionTimeout) {
			interruptionTimeout = $timeout(function () {
				extendedInterruption = true;
			}, 30 * 1000)
		}
		connected = $q.defer();
	}
  var connectOpenedEventId = ambClient.subscribeToEvent("connection.opened", function () {
		$rootScope.$broadcast("amb.connection.opened");
		if (interruptionTimeout) {
			$timeout.cancel(interruptionTimeout);
			interruptionTimeout = null;
		}
		extendedInterruption = false;
		if(connectionInterrupted) {
			connectionInterrupted = false;
			$rootScope.$broadcast("amb.connection.recovered");
		}
		connected.resolve();
  });
  var connectClosedEventId = ambClient.subscribeToEvent("connection.closed", function () {
		setInterrupted("amb.connection.closed");
  });
  var connectBrokenEventId = ambClient.subscribeToEvent("connection.broken", function () {
		setInterrupted("amb.connection.broken");
  });
  var connectSessionLoggedin = ambClient.subscribeToEvent("session.logged.in", function () {
	  $rootScope.$broadcast("amb.session.logged.in");
  });
  var connectSessionReestablished = ambClient.subscribeToEvent("session.reestablished", function () {
	  $rootScope.$broadcast("amb.session.reestablished");
  });
	var onUnloadWindow = function() {
		ambClient.unsubscribeFromEvent(connectOpenedEventId);
		ambClient.unsubscribeFromEvent(connectClosedEventId);
		ambClient.unsubscribeFromEvent(connectBrokenEventId);
		angular.element($window).off('unload', onUnloadWindow);
	};
	angular.element($window).on('unload', onUnloadWindow);
	var defaultAmbConnectionTimeout = 10000;
	var shouldDeferAmbConnection = _window.NOW && _window.NOW.hasOwnProperty('deferAmbConnection') ?
		_window.NOW.deferAmbConnection : false;
	var deferredAmbConnectionTimeout = _window.NOW && _window.NOW.hasOwnProperty('deferredAmbConnectionTimeout') &&
		isValidAmbConnectionTimeout(_window.NOW.deferredAmbConnectionTimeout) ?
		_window.NOW.deferredAmbConnectionTimeout :
		defaultAmbConnectionTimeout;
	if (shouldDeferAmbConnection) {
		$timeout(autoConnect, deferredAmbConnectionTimeout);
	} else {
		var documentReadyState = _window.document ? _window.document.readyState : null;
		if (documentReadyState === 'complete')
			autoConnect();
		else
			_window.addEventListener('load', autoConnect);
		$timeout(autoConnect, defaultAmbConnectionTimeout);
	}
	function isInteger(num) {
		return parseInt(num, 10) === num;
	}
	function isValidAmbConnectionTimeout(timeout) {
		return isInteger(timeout) && timeout > 0;
	}
	var initiatedConnection = false;
	function autoConnect() {
		if (!initiatedConnection) {
			initiatedConnection = true;
			ambClient.connect();
		}
	}
	return {
		getServerConnection: function() {
			return ambClient.getServerConnection();
		},
		connect: function() {
			if (initiatedConnection) {
				ambClient.connect();
			}
			return connected.promise;
		},
		get interrupted() {
			return ambInterrupted();
		},
		get extendedInterruption() {
			return extendedInterruption;
		},
		get connected() {
			return connected.promise;
		},
		abort: function() {
			ambClient.abort();
		},
		disconnect: function() {
			ambClient.disconnect();
		},
		getConnectionState: function () {
			return ambClient.getConnectionState();
		},
		getClientId: function () {
			return ambClient.getClientId();
		},
		getChannel: function(channelName) {
			return ambClient.getChannel(channelName);
		},
		registerExtension: function(extensionName, extension) {
			ambClient.registerExtension(extensionName, extension);
		},
		unregisterExtension: function(extensionName) {
			ambClient.unregisterExtension(extensionName);
		},
		batch: function(batch) {
			ambClient.batch(batch);
		},
		getState: function() {
			return ambClient.getState();
		},
		getFilterString: function(filter) {
			filter = filter.
replace(/\^EQ/g, '').
replace(/\^ORDERBY(?:DESC)?[^^]*/g, '').
replace(/^GOTO/, '');
return btoa(unescape(encodeURIComponent(filter))).replace(/=/g, '-');
		},
		getChannelRW: function(table, filter) {
var t = '/rw/default/' + table + '/' + this.getFilterString(filter);
			return this.getChannel(t);
		},
		isLoggedIn: function() {
			return ambClient.isLoggedIn();
		},
		subscribeToEvent: function(event, callback) {
			return ambClient.subscribeToEvent(event, callback);
		},
		getConnectionEvents: function() {
			return ambClient.getConnectionEvents();
		},
		getEvents: function() {
			return ambClient.getConnectionEvents();
		},
		loginComplete: function() {
			ambClient.loginComplete();
		}
	};
});
;
/*! RESOURCE: /scripts/app.ng.amb/controller.AMBRecordWatcher.js */
angular.module("ng.amb").controller("AMBRecordWatcher", function($scope, $timeout, $window) {
	"use strict";
	var amb = $window.top.g_ambClient;
	$scope.messages = [];
	var lastFilter;
	var watcherChannel;
	var watcher;
	function onMessage(message) {
		$scope.messages.push(message.data);
	}
	$scope.getState = function() {
		return amb.getState();
	};
	$scope.initWatcher = function() {
		angular.element(":focus").blur();
		if(!$scope.filter || $scope.filter === lastFilter)
			return;
		lastFilter = $scope.filter;
		console.log("initiating watcher on " + $scope.filter);
		$scope.messages = [];
		if(watcher) {
			watcher.unsubscribe();
		}
var base64EncodeQuery = btoa($scope.filter).replace(/=/g, '-');
var channelId = '/rw/' + base64EncodeQuery;
		watcherChannel = amb.getChannel(channelId)
		watcher = watcherChannel.subscribe(onMessage);
	};
	amb.connect();
})
;
/*! RESOURCE: /scripts/app.ng.amb/factory.snRecordWatcher.js */
angular.module("ng.amb").factory('snRecordWatcher', function($rootScope, amb, $timeout, snPresence, $log, urlTools) {
	"use strict";
var diagnosticLog = true;
	function initWatcher(table, sys_id, query) {
		if (!table)
			return;
		if (sys_id)
			var filter = "sys_id=" + sys_id;
		else
			filter = query;
		if (!filter)
			return;
		return initChannel(table, filter);
	}
	function initList(table, query) {
		if (!table)
			return;
		query = query || "sys_idISNOTEMPTY";
		return initChannel(table, query);
	}
	function initTaskList(list, prevChannel) {
		if (prevChannel)
			prevChannel.unsubscribe();
		var sys_ids = list.toString();
		var filter = "sys_idIN" + sys_ids;
		return initChannel("task", filter);
	}
	function initChannel(table, filter, callbackFn) {
		if (isBlockedTable(table)) {
			$log.log("Blocked from watching", table);
			return null;
		}
		if (diagnosticLog)
			log(">>> init " + table + "?" + filter);
		var watcherChannel = amb.getChannelRW(table, filter);
		watcherChannel.subscribe(callbackFn || onMessage);
		amb.connect();
		return watcherChannel;
	}
	function onMessage(message) {
		var r = message.data;
		var c = message.channel;
		if (diagnosticLog)
			log(">>> record " + r.operation + ": " + r.table_name + "." + r.sys_id + " " + r.display_value);
		$rootScope.$broadcast('record.updated', r);
		$rootScope.$broadcast('list.updated', r, c);
	}
	function log(message) {
		$log.log(message);
	}
	function isBlockedTable(table) {
		return table == 'sys_amb_message' || table.startsWith('sys_rw');
	}
	return {
		initTaskList: initTaskList,
		initChannel: initChannel,
		init: function () {
			var location = urlTools.parseQueryString(window.location.search);
			var table = location['table'] || location['sysparm_table'];
			var sys_id = location['sys_id'] || location['sysparm_sys_id'];
			var query = location['sysparm_query'];
			initWatcher(table, sys_id, query);
			snPresence.init(table, sys_id, query);
		},
		initList:  initList,
		initRecord: function(table, sysId) {
			initWatcher(table, sysId, null);
			snPresence.initPresence(table, sysId);
		},
		_initWatcher: initWatcher
	}
});
;
/*! RESOURCE: /scripts/app.ng.amb/factory.AMBOverlay.js */
angular.module("ng.amb").factory("AMBOverlay", function($templateCache, $compile, $rootScope, i18n) {
	"use strict";
	var showCallbacks = [],
		beforeShowCallbacks = [],
		hideCallbacks = [],
		isRendered = false,
		modal,
		modalScope,
		modalOptions;
	var defaults = {
backdrop: 'static',
keyboard: false,
show: true
		};
	function AMBOverlay(config) {
		config = config || {};
		if(angular.isFunction(config.onBeforeShow))
			beforeShowCallbacks.push(config.onBeforeShow);
		if(angular.isFunction(config.onShow))
			showCallbacks.push(config.onShow);
		if(angular.isFunction(config.onHide))
			hideCallbacks.push(config.onHide);
		i18n.getMessage("Login", function(msg) {
			config.loginMessage = msg;
		});
		function lazyRender() {
			if(!angular.element('html')['modal']) {
var bootstrapInclude = "/scripts/bootstrap3/bootstrap.js";
				ScriptLoader.getScripts([bootstrapInclude], renderModal);
			} else
				renderModal();
		}
		function renderModal() {
			if(isRendered)
				return;
			modalScope = angular.extend($rootScope.$new(), config);
			modal = $compile($templateCache.get("amb_disconnect_modal.xml"))(modalScope);
			angular.element("body").append(modal);
			modal.on("show.bs.modal", function (e) {
				for(var i = 0, len = beforeShowCallbacks.length; i < len; i++)
					beforeShowCallbacks[i](e);
			});
			modal.on("shown.bs.modal", function(e) {
				for(var i = 0, len = showCallbacks.length; i < len; i++)
					showCallbacks[i](e);
			});
			modal.on("hidden.bs.modal", function(e) {
				for(var i = 0, len = hideCallbacks.length; i < len; i++)
					hideCallbacks[i](e);
			});
			modalOptions = angular.extend({}, defaults, config);
			modal.modal(modalOptions);
			isRendered = true;
		}
		function showModal() {
			if(isRendered)
				modal.modal('show');
		}
		function hideModal() {
			if(isRendered)
				modal.modal('hide');
		}
		function destroyModal() {
			if(!isRendered)
				return;
			modal.modal('hide');
			modal.remove();
			modalScope.$destroy();
			modalScope = void(0);
			isRendered = false;
			var pos = showCallbacks.indexOf(config.onShow);
			if(pos >= 0)
				showCallbacks.splice(pos, 1);
			pos = hideCallbacks.indexOf(config.onShow);
			if(pos >= 0)
				hideCallbacks.splice(pos, 1);
		}
		return {
			render: lazyRender,
			destroy: destroyModal,
			show: showModal,
			hide: hideModal,
			isVisible: function() {
				if(!isRendered)
					return false;
				return modal.visible();
			}
		}
	}
	$templateCache.put('amb_disconnect_modal.xml',
		'<div id="amb_disconnect_modal" tabindex="-1" aria-hidden="true" class="modal" role="dialog">' +
		'	<div class="modal-dialog small-modal" style="width:450px">' +
		'		<div class="modal-content">' +
		'			<header class="modal-header">' +
'				<h4 id="small_modal1_title" class="modal-title">{{loginMessage}}</h4>' +
'			</header>' +
		'			<div class="modal-body">' +
'			<iframe class="concourse_modal" ng-src=\'{{iframe || "/amb_login.do"}}\' frameborder="0" height="400px" width="405px"></iframe>' +
'			</div>' +
'		</div>' +
'	</div>' +
'</div>'
	);
	return AMBOverlay;
});
;
;
/*! RESOURCE: /scripts/js_includes_ng_amb.js */
/*! RESOURCE: /scripts/sn/common/presence/snPresenceLite.js */
(function(exports, $) {
	'use strict';
	var PRESENCE_DISABLED = "false" === "true";
	if (PRESENCE_DISABLED) {
		return;
	}
	if (typeof $.Deferred === "undefined") {
		return;
	}
	var USER_KEY = '{{SYSID}}';
	var REPLACE_REGEX = new RegExp(USER_KEY, 'g');
	var COLOR_ONLINE = '#71e279';
	var COLOR_AWAY = '#fc8a3d';
	var COLOR_OFFLINE = 'transparent';
	var BASE_STYLES = [
		'.sn-presence-lite { display: inline-block; width: 1rem; height: 1rem; border-radius: 50%; }'
	];
	var USER_STYLES = [
		'.sn-presence-'+ USER_KEY +'-online [data-presence-id="'+ USER_KEY +'"] { background-color: '+ COLOR_ONLINE +'; }',
		'.sn-presence-'+ USER_KEY +'-away [data-presence-id="'+ USER_KEY +'"] { background-color: '+ COLOR_AWAY +'; }',
		'.sn-presence-'+ USER_KEY +'-offline [data-presence-id="'+ USER_KEY +'"] { background-color: '+ COLOR_OFFLINE +'; }'
	];
	var $head = $('head');
	var stylesheet = $.Deferred();
	var registeredUsers = {};
	var registeredUsersLength = 0;
	$(function() {
		updateRegisteredUsers();
	});
	$head.ready(function() {
	    var styleElement = document.createElement('style');
	    $head.append(styleElement);
		var $styleElement = $(styleElement);
	    stylesheet.resolve($styleElement);
	});
	function updateStyles(styles) {
	    stylesheet.done(function($styleElement) {
	        $styleElement.empty();
	        BASE_STYLES.forEach(function(baseStyle) {
	            $styleElement.append(baseStyle);
	        });
	        $styleElement.append(styles);
	    });
	}
	function getUserStyles(sysId) {
		var newStyles = '';
		for (var i = 0, iM = USER_STYLES.length; i < iM; i++) {
			newStyles += USER_STYLES[i].replace(REPLACE_REGEX, sysId);
		}
		return newStyles;
	}
	function updateUserStyles() {
		var userKeys = Object.keys(registeredUsers);
		var userStyles = "";
		userKeys.forEach(function(userKey) {
			userStyles += getUserStyles(userKey);
		});
		updateStyles(userStyles);
	}
	exports.applyPresenceArray = applyPresenceArray;
	function applyPresenceArray(presenceArray) {
		if (!presenceArray || !presenceArray.length) {
			return;
		}
		var users = presenceArray.filter(function(presence) {
			return typeof registeredUsers[presence.user] !== "undefined";
		});
		updateUserPresenceStatus(users);
	}
	function updateUserPresenceStatus(users) {
		var presenceStatus = getBaseCSSClasses();
		for (var i = 0, iM = users.length; i < iM; i++) {
			var presence = users[i];
			var status = getNormalizedStatus(presence.status);
			if (status === 'offline') {
				continue;
			}
			presenceStatus.push('sn-presence-' + presence.user + '-' + status);
		}
		setCSSClasses(presenceStatus.join(' '));
	}
	function getNormalizedStatus(status) {
		switch (status) {
			case 'probably offline':
			case 'maybe offline':
				return 'away';
			default:
				return 'offline';
			case 'online':
			case 'offline':
				return status;
		}
	}
	function updateRegisteredUsers() {
		var presenceIndicators = document.querySelectorAll('[data-presence-id]');
		var obj = {};
		for (var i = 0, iM = presenceIndicators.length; i < iM; i++) {
			var uid = presenceIndicators[i].getAttribute('data-presence-id');
			obj[uid] = true;
		}
		if (Object.keys(obj).length === registeredUsersLength){
			return;
		}
		registeredUsers = obj;
		registeredUsersLength = Object.keys(registeredUsers).length;
		updateUserStyles();
	}
	function setCSSClasses(classes) {
		$('html')[0].className = classes;
	}
	function getBaseCSSClasses() {
		return $('html')[0].className.split(' ').filter(function(item){
			return item.indexOf('sn-presence-') !== 0;
		});
	}
})(window, window.jQuery || window.Zepto);
;
/*! RESOURCE: /scripts/sn/common/presence/_module.js */
angular.module('sn.common.presence', ['ng.amb', 'sn.common.glide', 'sn.common.auth']).config(function($provide) {
	"use strict";
	$provide.constant("PRESENCE_DISABLED", "false" === "true");
});
;
/*! RESOURCE: /scripts/sn/common/presence/factory.snPresence.js */
angular.module("sn.common.presence").factory('snPresence', function($rootScope, $window, $log, amb, $timeout, $http, snRecordPresence, snTabActivity, urlTools, PRESENCE_DISABLED) {
	"use strict";
	var REST = {
PRESENCE: "/api/now/ui/presence"
	};
	var RETRY_INTERVAL = ($window.NOW.presence_interval || 60) * 1000;
	var MAX_RETRY_DELAY = RETRY_INTERVAL * 10;
var initialized = false;
var primary = false;
	var presenceArray = [];
	var serverTimeMillis;
	var skew = 0;
var st = 0;
	var _suspendWatch = false;
	function init() {
		var location = urlTools.parseQueryString($window.location.search);
		var table = location['table'] || location['sysparm_table'];
		var sys_id = location['sys_id'] || location['sysparm_sys_id'];
		return initPresence(table, sys_id);
	}
	function initPresence(t, id) {
		if(PRESENCE_DISABLED)
			return;
		if (!initialized) {
			initialized = true;
initRootScopes();
			if (!primary) {
				CustomEvent.observe('sn.presence', onPresenceEvent);
				CustomEvent.fireTop('sn.presence.ping');
			} else {
				presenceArray = getLocalPresence($window.localStorage.getItem('snPresence'));
				if (presenceArray)
$timeout(schedulePresence, 100);
	 			else
					updatePresence();
			}
		}
		return snRecordPresence.initPresence(t, id);
	}
	function isTopWindow() {
		var topWindow = window.self;
		try {
			while (topWindow.CustomEvent.fireEvent
				&& topWindow !== topWindow.parent
				&& !topWindow.parent.NOW.isPolarisWrapper
				&& topWindow.parent.CustomEvent.fireEvent) {
					topWindow = topWindow.parent;
				}
		} catch (e) {}
		return topWindow == window.self;
	}
	function onPresenceEvent(parms) {
		presenceArray = parms;
		$timeout(broadcastPresence);
	}
	function initRootScopes() {
		if ($window.NOW.presence_scopes) {
			var ps = $window.NOW.presence_scopes;
			if (ps.indexOf($rootScope) == -1)
				ps.push($rootScope);
		} else {
			$window.NOW.presence_scopes = [$rootScope];
			primary = isTopWindow();
		}
	}
	function setPresence(data, st) {
var rt = new Date().getTime() - st;
		if (rt > 500)
			console.log("snPresence response time " + rt + "ms");
		if (data.result && data.result.presenceArray) {
			presenceArray = data.result.presenceArray;
			setLocalPresence(presenceArray);
			serverTimeMillis = data.result.serverTimeMillis;
			skew = new Date().getTime() - serverTimeMillis;
var t  = Math.floor(skew / 1000);
			if (t < -15 )
				console.log(">>>>> server ahead " + Math.abs(t) + " seconds");
			else if (t > 15)
				console.log(">>>>> browser time ahead " + t + " seconds");
		}
		schedulePresence();
	}
	function updatePresence(numAttempts) {
		presenceArray = getLocalPresence($window.localStorage.getItem('snPresence'));
		if (presenceArray) {
			determineStatus(presenceArray);
$timeout(schedulePresence);
			return;
		}
		if (!amb.isLoggedIn() || !snTabActivity.isPrimary) {
			$timeout(schedulePresence);
			return;
		}
		var p = {
				user_agent: navigator.userAgent,
				ua_time: new Date().toISOString(),
				href: window.location.href,
				pathname: window.location.pathname,
				search: window.location.search,
				path: window.location.pathname + window.location.search
			};
		st = new Date().getTime();
		$http.post(REST.PRESENCE + '?sysparm_auto_request=true&cd=' + st, p).success(function(data) {
			setPresence(data, st);
		}).error(function(response, status) {
			console.log("snPresence " + status);
			schedulePresence(numAttempts);
		})
	}
	function schedulePresence(numAttempts) {
		numAttempts = isFinite(numAttempts) ? numAttempts + 1 : 0;
		var interval = getDecayingRetryInterval(numAttempts);
		$timeout(function() {
			updatePresence(numAttempts)
		}, interval);
		determineStatus(presenceArray);
		broadcastPresence();
	}
	function broadcastPresence() {
		if (angular.isDefined($window.applyPresenceArray)) {
			$window.applyPresenceArray(presenceArray);
		}
		$rootScope.$emit("sn.presence", presenceArray);
		if (!primary)
			return;
		CustomEvent.fireAll('sn.presence', presenceArray);
	}
	function determineStatus(presenceArray) {
		if (!presenceArray || !presenceArray.forEach)
			return;
		var t = new Date().getTime();
		t -= skew;
		presenceArray.forEach(function (p) {
			var x = 0 + p.last_on;
			var y = t - x;
			p.status = "online";
			if (y > (5 * RETRY_INTERVAL))
				p.status = "offline";
			else if (y > (3 * RETRY_INTERVAL))
				p.status = "probably offline";
			else if (y > (2.5 * RETRY_INTERVAL))
				p.status = "maybe offline";
		})
	}
	function setLocalPresence(value) {
		var p = {
			saved: new $window.Date().getTime(),
			presenceArray: value
		};
		$window.localStorage.setItem('snPresence', angular.toJson(p));
	}
	function suspendWatch(flag) {
		if (flag !== undefined)
			_suspendWatch = flag;
		return _suspendWatch;
	}
	function getLocalPresence(p) {
		if (!p)
			return null;
		try {
			p = angular.fromJson(p);
		} catch (e) {
			p = {};
		}
		if (!p.presenceArray)
			return null;
		var now = new Date().getTime();
		if (now - p.saved >= RETRY_INTERVAL)
			return null;
		return p.presenceArray;
	}
	function getDecayingRetryInterval(numAttempts) {
		return Math.min(RETRY_INTERVAL * Math.pow(2, numAttempts), MAX_RETRY_DELAY);
	}
	return {
		init: init,
		initPresence: initPresence,
		suspendWatch: suspendWatch,
		_getLocalPresence: getLocalPresence,
		_setLocalPresence: setLocalPresence,
		_determineStatus: determineStatus
	}
});
;
/*! RESOURCE: /scripts/sn/common/presence/factory.snRecordPresence.js */
angular.module("sn.common.presence").factory('snRecordPresence', function($rootScope, $location, amb, $timeout, $window, PRESENCE_DISABLED, snTabActivity) {
	"use strict";
	var statChannel;
var interval = ($window.NOW.record_presence_interval || 20) * 1000;
	var sessions = {};
	var primary = false;
	var currentJournalFieldName = "";
	var prevJournalFieldName = "";
	
	var table;
	var sys_id;
	
	function initPresence(t, id) {
		if(PRESENCE_DISABLED)
			return;
		if (!t || !id)
			return;
		if (t == table && id == sys_id)
			return;  
		initRootScopes();
		if (!primary) 
			return; 
		
		termPresence();
		table = t;
		sys_id = id;
var recordPresence = "/sn/rp/" + table + "/" + sys_id;
		$rootScope.me = NOW.session_id;
		statChannel = amb.getChannel(recordPresence);
		statChannel.subscribe(onStatus);
		amb.connected.then(function() {
			setStatus("entered");
			$rootScope.status = "viewing";
		});
		return statChannel;
	}
	
	function initRootScopes() {
		if ($window.NOW.record_presence_scopes) {
			var ps = $window.NOW.record_presence_scopes;
			if (ps.indexOf($rootScope) == -1) {
				ps.push($rootScope);
				CustomEvent.observe('sn.sessions', onPresenceEvent);
			}
		} else {
			$window.NOW.record_presence_scopes = [$rootScope];
			primary = true;
		}
	}
	
	function onPresenceEvent(sessionsToSend) {
		$rootScope.$emit("sn.sessions", sessionsToSend);
		$rootScope.$emit("sp.sessions", sessionsToSend);
	}
	
	function termPresence() {
		if (!statChannel)
			return; 
		
		statChannel.unsubscribe();
		statChannel = table = sys_id = null;
	}
	function setStatus(status) {
		if (status == $rootScope.status && prevJournalFieldName === currentJournalFieldName) 
			return;
		
prevJournalFieldName = currentJournalFieldName;
		$rootScope.status = status;
		if (Object.keys(sessions).length == 0)
			return;
		if (getStatusPrecedence(status) > 1)
			return;
		publish($rootScope.status);
	}
	function publish(status) {
		if (!statChannel)
			return;
		if (amb.getState() !== "opened")
			return;
			
		statChannel.publish({ presences: [{
			status : status,
			session_id : NOW.session_id,
			user_name : NOW.user_name,
			user_id: NOW.user_id,
			user_display_name : NOW.user_display_name,
			user_initials : NOW.user_initials,
			user_avatar: NOW.user_avatar,
			ua : navigator.userAgent,
			table: table,
			sys_id: sys_id,
			field_type: currentJournalFieldName,
			time: new Date().toString().substring(0,24)
		}]});
	}
	function onStatus(message) {
		message.data.presences.forEach(function(d){
if (!d.session_id || d.session_id == NOW.session_id)
				return;
			var s = sessions[d.session_id];
			if (s)
				angular.extend(s, d);
			else
				s = sessions[d.session_id] = d;
			s.lastUpdated = new Date();
			if (s.status == 'exited')
delete sessions[d.session_id];
		});
		broadcastSessions();
	}
	function broadcastSessions() {
		var sessionsToSend = getUniqueSessions();
		$rootScope.$emit("sn.sessions", sessionsToSend);
		$rootScope.$emit("sp.sessions", sessionsToSend);
if (primary)
			$timeout(function() {CustomEvent.fire('sn.sessions', sessionsToSend);})
	}
	function getUniqueSessions() {
		var uniqueSessionsByUser = {};
		var sessionKeys = Object.keys(sessions);
		sessionKeys.forEach(function(key) {
			var session = sessions[key];
			if (session.user_id == NOW.user_id)
				return;
			if (session.user_id in uniqueSessionsByUser) {
				var otherSession = uniqueSessionsByUser[session.user_id];
				var thisPrecedence = getStatusPrecedence(session.status);
				var otherPrecedence = getStatusPrecedence(otherSession.status);
				uniqueSessionsByUser[session.user_id] = thisPrecedence < otherPrecedence ? session : otherSession;
				return
			}
			uniqueSessionsByUser[session.user_id] = session;
		});
		var uniqueSessions = {};
		angular.forEach(uniqueSessionsByUser, function(item) {
			uniqueSessions[item.session_id] = item;
		});
		return uniqueSessions;
	}
	function getStatusPrecedence(status) {
		switch (status) {
			case 'typing':
				return 0;
			case 'viewing':
				return 1;
			case 'entered':
				return 2;
			case 'exited':
			case 'probably left':
				return 4;
			case 'offline':
				return 5;
			default:
				return 3;
		}
	}
	
	$rootScope.$on("record.typing", function(evt, data) {
		currentJournalFieldName = data.field_type;
		setStatus(data.status);
	});
	var idleTable, idleSysID;
	snTabActivity.onIdle({
		onIdle: function RecordPresenceTabIdle() {
			idleTable = table;
			idleSysID = sys_id;
			sessions = {};
			termPresence();
			broadcastSessions();
		},
		onReturn: function RecordPresenceTabActive() {
			initPresence(idleTable, idleSysID, true);
			idleTable = idleSysID = void(0);
		},
		delay: interval * 4
	});
	
	return {
		initPresence: initPresence,
		termPresence: termPresence
	}
});
;
/*! RESOURCE: /scripts/sn/common/presence/directive.snPresence.js */
angular.module('sn.common.presence').directive('snPresence', function(snPresence, $rootScope, $timeout, i18n) {
	'use strict';
	if (!snPresence.suspendWatch())
$timeout(snPresence.init, 100);
var presenceStatus = {};
	i18n.getMessages(['maybe offline', 'probably offline', 'offline', 'online', 'entered', 'viewing'], function (results) {
		presenceStatus.maybe_offline = results['maybe offline'];
		presenceStatus.probably_offline = results['probably offline'];
		presenceStatus.offline = results['offline'];
		presenceStatus.online = results['online'];
		presenceStatus.entered = results['entered'];
		presenceStatus.viewing = results['viewing'];
	});
	var presences = {};
	$rootScope.$on('sn.presence', function (event, presenceArray) {
		angular.forEach(presences, function (p) {
			p.status = "offline";
		});
if (!presenceArray) {
			return;
		}
		presenceArray.forEach(function (presence) {
			presences[presence.user] = presence;
		});
	});
	return {
		restrict: 'EA',
		replace: false,
		scope: {
			userId: '@?',
			snPresence: '=?',
			user: '=?',
			profile: '=?',
			displayName: '=?',
			onPresenceChange: '&'
		},
		link: function (scope, element) {
			if (scope.profile) {
				scope.user = scope.profile.userID;
				scope.profile.tabIndex = -1;
				if (scope.profile.isAccessible)
					scope.profile.tabIndex = 0;
			}
			if (!element.hasClass('presence'))
				element.addClass('presence');
			function updatePresence () {
				var id = scope.snPresence || scope.user;
				if (!angular.isDefined(id) && angular.isDefined(scope.userId)) {
					id = scope.userId;
				}
				if (presences[id]) {
					var status = presences[id].status;
					if (status === 'maybe offline' || status === 'probably offline') {
						element.removeClass('presence-online presence-offline presence-away');
						element.addClass('presence-away');
						scope.onPresenceChange({"status": presenceStatus.away});
					} else if (status == "offline" && !element.hasClass('presence-offline')) {
						element.removeClass('presence-online presence-away');
						element.addClass('presence-offline');
						scope.onPresenceChange({"status": presenceStatus.offline});
					} else if ( (status == "online" || status == "entered" || status == "viewing") && !element.hasClass('presence-online')) {
						element.removeClass('presence-offline presence-away');
						element.addClass('presence-online');
						scope.onPresenceChange({"status": presenceStatus.online});
					}
status = status.replace(/ /g,"_");
					if (scope.profile)
						angular.element('div[user-avatar-id="' + id + '"]').attr("aria-label", scope.profile.userName + ' ' + presenceStatus[status]);
					else
						angular.element('div[user-avatar-id="' + id + '"]').attr("aria-label", scope.displayName + ' ' + presenceStatus[status]);
				} else {
					if (!element.hasClass('presence-offline'))
						element.addClass('presence-offline');
					    scope.onPresenceChange({"status": presenceStatus.offline});
				}
			}
			var unbind = $rootScope.$on('sn.presence', updatePresence);
			scope.$on('$destroy', unbind);
			updatePresence();
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/presence/directive.snComposing.js */
angular.module('sn.common.presence').directive('snComposing', function(getTemplateUrl, snComposingPresence) {
	"use strict";
	return {
		restrict: 'E',
		templateUrl: getTemplateUrl("snComposing.xml"),
		replace: true,
		scope: {
			conversation: "="
		},
		controller: function($scope, $element) {
			var child = $element.children();
			if (child && child.tooltip)
				child.tooltip({
'template':	'<div class="tooltip" style="white-space: pre-wrap" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',
					'placement': 'top',
					'container': 'body'
					});
			$scope.snComposingPresence = snComposingPresence;
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/presence/service.snComposingPresence.js */
angular.module('sn.common.presence').service('snComposingPresence', function(i18n) {
	"use strict";
	var viewing = {};
	var typing = {};
	var allStrings = {};
	var shortStrings = {};
	var typing1="{0} is typing", typing2="{0} and {1} are typing", typingMore="{0}, {1}, and {2} more are typing", viewing1="{0} is viewing",viewing2="{0} and {1} are viewing",viewingMore="{0}, {1}, and {2} more are viewing";
	i18n.getMessages(
		[
			typing1,
			typing2,
			typingMore,
			viewing1,
			viewing2,
			viewingMore
			],
		function (results) {
			typing1=results[typing1];
			typing2=results[typing2];
			typingMore=results[typingMore];
			viewing1=results[viewing1];
			viewing2=results[viewing2];
			viewingMore=results[viewingMore];
		});
	function set(conversationID, newPresenceValues) {
		if (newPresenceValues.viewing)
			viewing[conversationID] = newPresenceValues.viewing;
		if (newPresenceValues.typing)
			typing[conversationID] = newPresenceValues.typing;
		generateAllString(conversationID, {viewing: viewing[conversationID],typing: typing[conversationID]});
		generateShortString(conversationID, {viewing: viewing[conversationID],typing: typing[conversationID]});
		return {
			viewing: viewing[conversationID],
			typing: typing[conversationID]
		}
	}
	function get(conversationID) {
		return {
			viewing: viewing[conversationID] || [],
			typing: typing[conversationID] || []
		}
	}
	function generateAllString(conversationID, members) {
		var result = "";
		var typingLength = members.typing.length;
		var viewingLength = members.viewing.length;
		if (typingLength < 4 && viewingLength < 4)
			return "";
		switch (typingLength) {
			case 0:
				break;
			case 1:
				result += i18n.format(typing1, members.typing[0].name); break;
			case 2:
				result += i18n.format(typing2, members.typing[0].name, members.typing[1].name); break;
			default:
				var allButLastTyper = "";
				for (var i = 0; i < typingLength; i++) {
					if (i < typingLength -2)
						allButLastTyper += members.typing[i].name + ", ";
					else if (i === typingLength-2)
						allButLastTyper += members.typing[i].name + ",";
					else
						result += i18n.format(typing2, allButLastTyper, members.typing[i].name);
				}
		}
		if (viewingLength > 0 && typingLength > 0)
			result += "\n\n";
		switch (viewingLength) {
			case 0:
				break;
			case 1:
				result += i18n.format(viewing1, members.viewing[0].name); break;
			case 2:
				result += i18n.format(viewing2, members.viewing[0].name, members.viewing[1].name); break;
			default:
				var allButLastViewer = "";
				for (var i = 0; i < viewingLength; i++) {
					if (i < viewingLength -2)
						allButLastViewer += members.viewing[i].name + ", ";
					else if (i === viewingLength - 2)
						allButLastViewer += members.viewing[i].name + ",";
					else
						result += i18n.format(viewing2, allButLastViewer, members.viewing[i].name);
				}
		}
		allStrings[conversationID] = result;
	}
	function generateShortString(conversationID, members) {
		var typingLength = members.typing.length;
		var viewingLength = members.viewing.length;
		var typingString = "", viewingString = "";
		var inBetween = " ";
		switch (typingLength ) {
			case 0:
				break;
			case 1:
				typingString = i18n.format(typing1, members.typing[0].name); break;
			case 2:
				typingString = i18n.format(typing2, members.typing[0].name, members.typing[1].name); break;
			case 3:
				typingString = i18n.format(typing2, members.typing[0].name + ", " + members.typing[1].name + ",",members.typing[2].name); break;
			default:
				typingString = i18n.format(typingMore, members.typing[0].name, members.typing[1].name, (typingLength - 2));
		}
		if (viewingLength > 0 && typingLength > 0)
			 inBetween = ". ";
		switch (viewingLength) {
			case 0:
				break;
			case 1:
				viewingString = i18n.format(viewing1,  members.viewing[0].name); break;
			case 2:
				viewingString = i18n.format(viewing2, members.viewing[0].name, members.viewing[1].name); break;
			case 3:
				viewingString = i18n.format(viewing2, members.viewing[0].name + ", " + members.viewing[1].name + ",", members.viewing[2].name); break;
			default:
				viewingString = i18n.format(viewingMore, members.viewing[0].name, members.viewing[1].name, (viewingLength - 2));
		}
		shortStrings[conversationID] = typingString + inBetween + viewingString;
	}
	function getAllString(conversationID) {
		if ((viewing[conversationID] && viewing[conversationID].length > 3)
			|| (typing[conversationID] && typing[conversationID].length > 3))
			return allStrings[conversationID];
		return "";
	}
	function getShortString(conversationID) {
		return shortStrings[conversationID];
	}
	function remove(conversationID) {
		delete viewing[conversationID];
	}
	return {
		set: set,
		get: get,
		generateAllString: generateAllString,
		getAllString: getAllString,
		generateShortString: generateShortString,
		getShortString: getShortString,
		remove: remove
	}
});
;
;
/*! RESOURCE: /scripts/sn/common/presence/js_includes_presence.js */
/*! RESOURCE: /scripts/sn/common/user_profile/_module.js */
angular.module("sn.common.user_profile", ['sn.common.ui']);
;
/*! RESOURCE: /scripts/sn/common/user_profile/directive.snUserProfile.js */
angular.module('sn.common.user_profile').directive('snUserProfile', function(getTemplateUrl, snCustomEvent, $window, avatarProfilePersister, $timeout, $http, $injector) {
	"use strict";
	return {
		replace: true,
		restrict: 'E',
		templateUrl: getTemplateUrl('snUserProfile.xml'),
		scope: {
			profile: "=",
			showDirectMessagePrompt: "="
		},
		link: function(scope, element) {
			scope.showDirectMessagePromptFn = function() {
				if ($injector.has('inSupportClient') && $injector.get('inSupportClient'))
					return false;
				if (scope.showDirectMessagePrompt) {
					var activeUserID = $window.NOW.user_id || "";
					return !(!scope.profile
						|| activeUserID === scope.profile.sysID
						|| !scope.profile.hasConnectRoles
						|| (scope.profile.document && activeUserID === scope.profile.document));
				} else {
					return false;
				}
			};
		},
		controller: function($scope, snConnectService) {
			if ($scope.profile && $scope.profile.userID && avatarProfilePersister.getAvatar($scope.profile.userID)) {
				$scope.profile = avatarProfilePersister.getAvatar($scope.profile.userID);
				$scope.$emit("sn-user-profile.ready");
			} else {
$http.get('/api/now/live/profiles/sys_user.' + $scope.profile.userID).then(function (response) {
					angular.merge($scope.profile, response.data.result);
					avatarProfilePersister.setAvatar($scope.profile.userID, $scope.profile);
					$scope.$emit("sn-user-profile.ready");
				})
			}
$http.get('/api/now/live/profiles/' + $scope.profile.userID + '/has_connect_roles').then(function(response) {
				$scope.profile.hasConnectRoles = response.data.result.hasConnectRoles;
			});
			$scope.openDirectMessageConversation = function(evt) {
				if (evt && evt.keyCode === 9)
					return;
				$timeout(function () {
					snConnectService.openWithProfile($scope.profile);
				}, 0, false);
				angular.element('.popover').each(function() {
					angular.element('body').off('click.snUserAvatarPopoverClose');
					angular.element(this).popover('hide');
				});
			};
		}
	};
});
;
;
/*! RESOURCE: /scripts/sn/common/user_profile/js_includes_user_profile.js */
/*! RESOURCE: /scripts/thirdparty/autosizer/autosizer.min.js */
/*!
 Autosize 4.0.0
 license: MIT
 http://www.jacklmoore.com/autosize
 */
!function(e,t){if("function"==typeof define&&define.amd)define(["exports","module"],t);else if("undefined"!=typeof exports&&"undefined"!=typeof module)t(exports,module);else{var n={exports:{}};t(n.exports,n),e.autosize=n.exports}}(this,function(e,t){"use strict";function n(e){function t(){var t=window.getComputedStyle(e,null);"vertical"===t.resize?e.style.resize="none":"both"===t.resize&&(e.style.resize="horizontal"),s="content-box"===t.boxSizing?-(parseFloat(t.paddingTop)+parseFloat(t.paddingBottom)):parseFloat(t.borderTopWidth)+parseFloat(t.borderBottomWidth),isNaN(s)&&(s=0),l()}function n(t){var n=e.style.width;e.style.width="0px",e.offsetWidth,e.style.width=n,e.style.overflowY=t}function o(e){for(var t=[];e&&e.parentNode&&e.parentNode instanceof Element;)e.parentNode.scrollTop&&t.push({node:e.parentNode,scrollTop:e.parentNode.scrollTop}),e=e.parentNode;return t}function r(){var t=e.style.height,n=o(e),r=document.documentElement&&document.documentElement.scrollTop;e.style.height="";var i=e.scrollHeight+s;return 0===e.scrollHeight?void(e.style.height=t):(e.style.height=i+"px",u=e.clientWidth,n.forEach(function(e){e.node.scrollTop=e.scrollTop}),void(r&&(document.documentElement.scrollTop=r)))}function l(){r();var t=Math.round(parseFloat(e.style.height)),o=window.getComputedStyle(e,null),i="content-box"===o.boxSizing?Math.round(parseFloat(o.height)):e.offsetHeight;if(i!==t?"hidden"===o.overflowY&&(n("scroll"),r(),i="content-box"===o.boxSizing?Math.round(parseFloat(window.getComputedStyle(e,null).height)):e.offsetHeight):"hidden"!==o.overflowY&&(n("hidden"),r(),i="content-box"===o.boxSizing?Math.round(parseFloat(window.getComputedStyle(e,null).height)):e.offsetHeight),a!==i){a=i;var l=d("autosize:resized");try{e.dispatchEvent(l)}catch(e){}}}if(e&&e.nodeName&&"TEXTAREA"===e.nodeName&&!i.has(e)){var s=null,u=e.clientWidth,a=null,c=function(){e.clientWidth!==u&&l()},p=function(t){window.removeEventListener("resize",c,!1),e.removeEventListener("input",l,!1),e.removeEventListener("keyup",l,!1),e.removeEventListener("autosize:destroy",p,!1),e.removeEventListener("autosize:update",l,!1),Object.keys(t).forEach(function(n){e.style[n]=t[n]}),i.delete(e)}.bind(e,{height:e.style.height,resize:e.style.resize,overflowY:e.style.overflowY,overflowX:e.style.overflowX,wordWrap:e.style.wordWrap});e.addEventListener("autosize:destroy",p,!1),"onpropertychange"in e&&"oninput"in e&&e.addEventListener("keyup",l,!1),window.addEventListener("resize",c,!1),e.addEventListener("input",l,!1),e.addEventListener("autosize:update",l,!1),e.style.overflowX="hidden",e.style.wordWrap="break-word",i.set(e,{destroy:p,update:l}),t()}}function o(e){var t=i.get(e);t&&t.destroy()}function r(e){var t=i.get(e);t&&t.update()}var i="function"==typeof Map?new Map:function(){var e=[],t=[];return{has:function(t){return e.indexOf(t)>-1},get:function(n){return t[e.indexOf(n)]},set:function(n,o){e.indexOf(n)===-1&&(e.push(n),t.push(o))},delete:function(n){var o=e.indexOf(n);o>-1&&(e.splice(o,1),t.splice(o,1))}}}(),d=function(e){return new Event(e,{bubbles:!0})};try{new Event("test")}catch(e){d=function(e){var t=document.createEvent("Event");return t.initEvent(e,!0,!1),t}}var l=null;"undefined"==typeof window||"function"!=typeof window.getComputedStyle?(l=function(e){return e},l.destroy=function(e){return e},l.update=function(e){return e}):(l=function(e,t){return e&&Array.prototype.forEach.call(e.length?e:[e],function(e){return n(e,t)}),e},l.destroy=function(e){return e&&Array.prototype.forEach.call(e.length?e:[e],o),e},l.update=function(e){return e&&Array.prototype.forEach.call(e.length?e:[e],r),e}),t.exports=l});
/*! RESOURCE: /scripts/sn/common/util/_module.js */
angular.module('sn.common.util', ['sn.common.auth']);
angular.module('sn.util', ['sn.common.util']);
;
/*! RESOURCE: /scripts/sn/common/util/factory.escapeHtml.js */
angular.module('sn.common.util').factory('escapeHtml', function() {
	return function(value) {
		if (typeof value !== 'string') {
			return '';
		}
		return value
.replace(/&/g, '&amp;')
.replace(/</g, '&lt;')
.replace(/>/g, '&gt;')
.replace(/'/g, '&#39;')
.replace(/"/g, '&quot;')
.replace(/\//g, '&#x2F;');
	};
});
;
/*! RESOURCE: /scripts/sn/common/util/service.dateUtils.js */
angular.module('sn.common.util').factory('dateUtils', function(){
	var dateUtils = {
		SYS_DATE_FORMAT: "yyyy-MM-dd",
		SYS_TIME_FORMAT: "HH:mm:ss",
		SYS_DATE_TIME_FORMAT: "yyyy-MM-dd HH:mm:ss",
		MONTH_NAMES: new Array('January','February','March','April','May','June','July','August','September','October','November','December','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'),
		DAY_NAMES: new Array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sun','Mon','Tue','Wed','Thu','Fri','Sat'),
		LZ: function (x) {return(x<0||x>9?"":"0")+x},
		isDate: function (val,format) {
			var date=this.getDateFromFormat(val,format);
			if (date==0) { return false; }
			return true;
		},
		compareDates: function (date1,dateformat1,date2,dateformat2) {
			var d1=this.getDateFromFormat(date1,dateformat1);
			var d2=this.getDateFromFormat(date2,dateformat2);
			if (d1==0 || d2==0) {
				return -1;
				}
			else if (d1 > d2) {
				return 1;
				}
			return 0;
		},
		formatDateServer: function(date, format) {
			var ga = new GlideAjax("DateTimeUtils");
			ga.addParam("sysparm_name", "formatCalendarDate");
			var browserOffset = date.getTimezoneOffset() * 60000;
		    var utcTime = date.getTime() - browserOffset;
		    var userDateTime = utcTime - g_tz_offset;
			ga.addParam("sysparm_value", userDateTime);
			ga.getXMLWait();
			return ga.getAnswer();
		},
		formatDate: function(date,format) {
			if (format.indexOf("z") > 0)
				return this.formatDateServer(date, format);
			format=format+"";
			var result="";
			var i_format=0;
			var c="";
			var token="";
			var y=date.getYear()+"";
			var M=date.getMonth()+1;
			var d=date.getDate();
			var E=date.getDay();
			var H=date.getHours();
			var m=date.getMinutes();
			var s=date.getSeconds();
			var yyyy,yy,MMM,MM,dd,hh,h,mm,ss,ampm,HH,H,KK,K,kk,k;
			var value=new Object();
			value["M"]=M;
			value["MM"]=this.LZ(M);
			value["MMM"]=this.MONTH_NAMES[M+11];
			value["NNN"]=this.MONTH_NAMES[M+11];
			value["MMMM"]=this.MONTH_NAMES[M-1];
			value["d"]=d;
			value["dd"]=this.LZ(d);
			value["E"]=this.DAY_NAMES[E+7];
			value["EE"]=this.DAY_NAMES[E];
			value["H"]=H;
			value["HH"]=this.LZ(H);
			if (format.indexOf('w') != -1) {
				var wk = date.getWeek();
				if (wk >= 52 && M == 1) {
					y = date.getYear();
					y--;
					y = y + "";
				}
				if (wk == 1 && M == 12) {
					y = date.getYear();
					y++;
					y = y + "";
				}
				value["w"] = wk;
				value["ww"] = this.LZ(wk);
			}
			var dayOfWeek = (7 + (E + 1) - (g_first_day_of_week - 1)) % 7;
			if (dayOfWeek == 0)
				dayOfWeek = 7;
			value["D"] = dayOfWeek;
			if (y.length < 4) {
				y=""+(y-0+1900);
			}
			value["y"]=""+y;
			value["yyyy"]=y;
			value["yy"]=y.substring(2,4);
			if (H==0) {
				value["h"]=12;
			} else if (H>12){
				value["h"]=H-12;
			} else {
				value["h"]=H;
			}
			value["hh"]=this.LZ(value["h"]);
			if (H>11) {
				value["K"]=H-12;
			} else {
				value["K"]=H;
			}
			value["k"]=H+1;
			value["KK"]=this.LZ(value["K"]);
			value["kk"]=this.LZ(value["k"]);
			if (H > 11) {
				value["a"]="PM";
			} else {
				value["a"]="AM";
			}
			value["m"]=m;
			value["mm"]=this.LZ(m);
			value["s"]=s;
			value["ss"]=this.LZ(s);
			while (i_format < format.length) {
				c=format.charAt(i_format);
				token="";
				while ((format.charAt(i_format)==c) && (i_format < format.length)) {
					token += format.charAt(i_format++);
					}
				if (value[token] != null) { result=result + value[token]; }
				else { result=result + token; }
				}
			return result;
		},
		_isInteger: function (val) {
			var digits="1234567890";
			for (var i=0; i < val.length; i++) {
				if (digits.indexOf(val.charAt(i))==-1) { return false; }
				}
			return true;
		},
		_getInt: function (str,i,minlength,maxlength) {
			for (var x=maxlength; x>=minlength; x--) {
				var token=str.substring(i,i+x);
				if (token.length < minlength) { return null; }
				if (this._isInteger(token)) { return token; }
				}
			return null;
		},
		getDateFromFormat: function (val,format) {
			val=val+"";
			format=format+"";
			var i_val=0;
			var i_format=0;
			var c="";
			var token="";
			var token2="";
			var x,y;
			var now=new Date();
			var year=now.getYear();
			var month=now.getMonth()+1;
			var date=0;
			var hh=now.getHours();
			var mm=now.getMinutes();
			var ss=now.getSeconds();
			var ampm="";
			var week = false;
			while (i_format < format.length) {
				c=format.charAt(i_format);
				token="";
				while ((format.charAt(i_format)==c) && (i_format < format.length)) {
					token += format.charAt(i_format++);
					}
				if (token=="yyyy" || token=="yy" || token=="y") {
					if (token=="yyyy") { x=4;y=4; }
					if (token=="yy")   { x=2;y=2; }
					if (token=="y")    { x=2;y=4; }
					year=this._getInt(val,i_val,x,y);
					if (year==null) { return 0; }
					i_val += year.length;
					if (year.length==2) {
						if (year > 70) { year=1900+(year-0); }
						else { year=2000+(year-0); }
						}
					}
				else if (token=="MMM"||token=="NNN"){
					month=0;
					for (var i=0; i<this.MONTH_NAMES.length; i++) {
						var month_name=this.MONTH_NAMES[i];
						if (val.substring(i_val,i_val+month_name.length).toLowerCase()==month_name.toLowerCase()) {
							if (token=="MMM"||(token=="NNN"&&i>11)) {
								month=i+1;
								if (month>12) { month -= 12; }
								i_val += month_name.length;
								break;
								}
							}
						}
					if ((month < 1)||(month>12)){return 0;}
					}
				else if (token=="EE"||token=="E") {
					for (var i=0; i<this.DAY_NAMES.length; i++) {
						var day_name=this.DAY_NAMES[i];
						if (val.substring(i_val,i_val+day_name.length).toLowerCase()==day_name.toLowerCase()) {
							if (week) {
if (i==0 || i == 7)
									date+=6;
else if (i== 2 || i == 9)
									date+=1;
else if (i== 3 || i == 10)
									date+=2;
else if (i == 4 || i == 11)
									date+=3;
else if (i == 5 || i == 12)
									date +=4;
else if (i == 6 || i== 13)
									date+=5;
							}
							i_val += day_name.length;
							break;
							}
						}
					}
				else if (token=="MM"||token=="M") {
					month=this._getInt(val,i_val,token.length,2);
					if(month==null||(month<1)||(month>12)){return 0;}
					i_val+=month.length;}
				else if (token=="dd"||token=="d") {
					date=this._getInt(val,i_val,token.length,2);
					if(date==null||(date<1)||(date>31)){return 0;}
					i_val+=date.length;}
				else if (token=="hh"||token=="h") {
					hh=this._getInt(val,i_val,token.length,2);
					if(hh==null||(hh<1)||(hh>12)){return 0;}
					i_val+=hh.length;}
				else if (token=="HH"||token=="H") {
					hh=this._getInt(val,i_val,token.length,2);
					if(hh==null||(hh<0)||(hh>23)){return 0;}
					i_val+=hh.length;}
				else if (token=="KK"||token=="K") {
					hh=this._getInt(val,i_val,token.length,2);
					if(hh==null||(hh<0)||(hh>11)){return 0;}
					i_val+=hh.length;}
				else if (token=="kk"||token=="k") {
					hh=this._getInt(val,i_val,token.length,2);
					if(hh==null||(hh<1)||(hh>24)){return 0;}
					i_val+=hh.length;hh--;}
				else if (token=="mm"||token=="m") {
					mm=this._getInt(val,i_val,token.length,2);
					if(mm==null||(mm<0)||(mm>59)){return 0;}
					i_val+=mm.length;}
				else if (token=="ss"||token=="s") {
					ss=this._getInt(val,i_val,token.length,2);
					if(ss==null||(ss<0)||(ss>59)){return 0;}
					i_val+=ss.length;}
				else if (token=="a") {
					if (val.substring(i_val,i_val+2).toLowerCase()=="am") {ampm="AM";}
					else if (val.substring(i_val,i_val+2).toLowerCase()=="pm") {ampm="PM";}
					else {return 0;}
					i_val+=2;}
else if (token == "w" || token == "ww") {
					var weekNum = this._getInt(val,i_val,token.length, 2);
					week = true;
					if (weekNum != null) {
						var temp = new Date(year, 0, 1, 0, 0, 0);
					    temp.setWeek(parseInt(weekNum, 10));
						year = temp.getFullYear();
						month = temp.getMonth()+1;
						date = temp.getDate();
					}
					weekNum += "";
					i_val += weekNum.length;
				}
				else if (token=="D") {
					if (week) {
						var day = this._getInt(val,i_val,token.length, 1);
						if ((day == null) || (day <= 0) || (day > 7))
							return 0;
						var temp = new Date(year, month-1, date, hh, mm, ss);
						var dayOfWeek = temp.getDay();
						day = parseInt(day, 10);
						day = (day + g_first_day_of_week - 1) % 7;
						if (day == 0)
							day = 7;
						day--;
						if (day < dayOfWeek)
							day = 7 - (dayOfWeek - day);
						else
							day -= dayOfWeek;
						if (day > 0) {
							temp.setDate(temp.getDate() + day);
							year = temp.getFullYear();
							month = temp.getMonth() + 1;
							date = temp.getDate();
						}
						i_val++;
					}
				} else if (token =="z")
					i_val+=3;
				else {
					if (val.substring(i_val,i_val+token.length)!=token) {return 0;}
					else {i_val+=token.length;}
					}
				}
			if (i_val != val.length) { return 0; }
			if (month==2) {
if ( ( (year%4==0)&&(year%100 != 0) ) || (year%400==0) ) {
					if (date > 29){ return 0; }
					}
				else { if (date > 28) { return 0; } }
				}
			if ((month==4)||(month==6)||(month==9)||(month==11)) {
				if (date > 30) { return 0; }
				}
			if (hh<12 && ampm=="PM") { hh=hh-0+12; }
			else if (hh>11 && ampm=="AM") { hh-=12; }
			var newdate=new Date(year,month-1,date,hh,mm,ss);
			return newdate.getTime();
		},
		parseDate: function (val) {
			var preferEuro=(arguments.length==2)?arguments[1]:false;
			generalFormats=new Array('y-M-d','MMM d, y','MMM d,y','y-MMM-d','d-MMM-y','MMM d');
monthFirst=new Array('M/d/y','M-d-y','M.d.y','MMM-d','M/d','M-d');
dateFirst =new Array('d/M/y','d-M-y','d.M.y','d-MMM','d/M','d-M');
			yearFirst =new Array( 'yyyyw.F', 'yyw.F');
			var checkList=new Array('generalFormats',preferEuro?'dateFirst':'monthFirst',preferEuro?'monthFirst':'dateFirst', 'yearFirst');
			var d=null;
			for (var i=0; i<checkList.length; i++) {
				var l=window[checkList[i]];
				for (var j=0; j<l.length; j++) {
					d=this.getDateFromFormat(val,l[j]);
					if (d!=0) { return new Date(d); }
					}
				}
			return null;
		}
	};
	Date.prototype.getWeek = function() {
		var newYear = new Date(this.getFullYear(),0,1);
var day = newYear.getDay() - (g_first_day_of_week - 1);
		day = (day >= 0 ? day : day + 7);
var dayNum = Math.floor((this.getTime() - newYear.getTime() - (this.getTimezoneOffset()-newYear.getTimezoneOffset())*60000)/86400000) + 1;
		var weekNum;
		if (day < 4) {
weekNum = Math.floor((dayNum+day-1)/7) +1;
			if (weekNum > 52)
				weekNum = this._checkNextYear(weekNum);
			return weekNum;
		}
weekNum = Math.floor((dayNum+day-1)/7);
		if (weekNum < 1)
			weekNum = this._lastWeekOfYear();
		else if (weekNum > 52)
			weekNum = this._checkNextYear(weekNum);
		return weekNum;
	};
	Date.prototype._lastWeekOfYear = function() {
		var newYear = new Date(this.getFullYear() - 1,0,1);
		var endOfYear = new Date(this.getFullYear() - 1,11,31);
var day = newYear.getDay() - (g_first_day_of_week - 1);
var dayNum = Math.floor((endOfYear.getTime() - newYear.getTime() - (endOfYear.getTimezoneOffset()-newYear.getTimezoneOffset())*60000)/86400000) + 1;
return day < 4 ? Math.floor((dayNum+day-1)/7) + 1 : Math.floor((dayNum+day-1)/7);
	};
	Date.prototype._checkNextYear = function() {
		var nYear = new Date(this.getFullYear() + 1,0,1);
		var nDay = nYear.getDay() - (g_first_day_of_week-1);
		nDay = nDay >= 0 ? nDay : nDay + 7;
		return nDay < 4 ? 1 : 53;
	};
	Date.prototype.setWeek = function(weekNum) {
		weekNum--;
		var startOfYear = new Date(this.getFullYear(), 0, 1);
var day = startOfYear.getDay() - (g_first_day_of_week - 1);
		if (day > 0 && day < 4) {
			this.setFullYear(startOfYear.getFullYear() - 1);
			this.setDate(31 - day + 1);
			this.setMonth(11);
} else if (day > 3)
this.setDate(startOfYear.getDate() + (7-day));
		this.setDate(this.getDate() + (7 * weekNum));
	};
	return dateUtils;
})
;
/*! RESOURCE: /scripts/sn/common/util/service.debounceFn.js */
angular.module("sn.common.util").service("debounceFn", function () {
	"use strict";
	function debounce(func, wait, immediate) {
		var timeout;
		return function() {
			var context = this, args = arguments;
			var later = function() {
				timeout = null;
				if (!immediate) func.apply(context, args);
			};
			var callNow = immediate && !timeout;
			clearTimeout(timeout);
			timeout = setTimeout(later, wait);
			if (callNow) func.apply(context, args);
		};
	}
	return {
		debounce: debounce
	}
});
;
/*! RESOURCE: /scripts/sn/common/util/factory.unwrappedHTTPPromise.js */
angular.module('sn.common.util').factory("unwrappedHTTPPromise", function ($q) {
	"use strict";
	function isGenericPromise(promise){
		return (typeof promise.then === "function" &&
			promise.success === undefined &&
			promise.error === undefined);
	}
	return function(httpPromise){
		if(isGenericPromise(httpPromise))
			return httpPromise;
		var deferred = $q.defer();
		httpPromise.success(function(data){
			deferred.resolve(data);
		}).error(function(data, status){
			deferred.reject({
				data: data,
				status: status
			})
		});
		return deferred.promise;
	};
});
;
/*! RESOURCE: /scripts/sn/common/util/service.urlTools.js */
angular.module('sn.common.util').constant('angularProcessorUrl', 'angular.do?sysparm_type=');
angular.module('sn.common.util').factory("urlTools", function(getTemplateUrl, angularProcessorUrl) {
	"use strict";
	function getPartialURL(name, parameters) {
		var url = getTemplateUrl(name);
		if (parameters) {
			if (typeof parameters !== 'string') {
				parameters = encodeURIParameters(parameters);
			}
			if (parameters.length) {
				url += "&" + parameters;
			}
		}
		if (window.NOW && window.NOW.ng_cache_defeat)
url += "&t=" + new Date().getTime();
		return url;
	}
	function getURL(name, parameters) {
		if (parameters && typeof parameters === 'object')
			return urlFor(name, parameters);
		var url = angularProcessorUrl;
		url += name;
		if (parameters)
			url += "&" + parameters;
		return url;
	}
	function urlFor(route, parameters) {
		var p = encodeURIParameters(parameters);
		return angularProcessorUrl + route + (p.length ? '&' + p : '');
	}
	function getPropertyURL(name) {
		var url = angularProcessorUrl + "get_property&name=" + name;
url += "&t=" + new Date().getTime();
		return url;
	}
	function encodeURIParameters(parameters) {
		var s = [];
		for (var parameter in parameters) {
			if (parameters.hasOwnProperty(parameter)) {
				var key = encodeURIComponent(parameter);
				var value = parameters[parameter] ? encodeURIComponent(parameters[parameter]) : '';
				s.push(key + "=" + value);
			}
		}
		return s.join('&');
	}
	function parseQueryString(qs) {
		qs = qs || '';
		if (qs.indexOf('http') === 0) {
			var qIndex = qs.indexOf('?');
			if (qIndex > -1) {
				qs = qs.substring(qIndex);
			} else {
				return {};
			}
		}
		var hashIndex = qs.indexOf('#');
		if (hashIndex > -1) {
			qs = qs.substring(0, hashIndex);
		}
		if (qs.charAt(0) === '?')
			qs = qs.substr(1);
		if (qs === '')
			return {};
		var a = qs.split('&');
		var b = {};
		for (var i = 0; i < a.length; i++) {
			var p = a[i].split('=', 2);
			if (p.length == 1) {
				b[p[0]] = "";
			} else {
b[p[0]] = decodeURIComponent(p[1].replace(/\+/g, " "));
			}
		}
		return b;
	}
var urlPattern = /^(([^:/?#]+):)?(\/\/([^/?#]*))?([^?#]*)/;
	var hostnameGroupIndex = 4;
	function isUrlExternal(url) {
		var matchResult = url.match(urlPattern);
		if (matchResult && matchResult[hostnameGroupIndex] && matchResult[hostnameGroupIndex].length > 0)
			return true;
		return false;
	}
	return {
		getPartialURL: getPartialURL,
		getURL: getURL,
		urlFor: urlFor,
		getPropertyURL: getPropertyURL,
		encodeURIParameters: encodeURIParameters,
		parseQueryString: parseQueryString,
		isUrlExternal: isUrlExternal
	};
});
;
/*! RESOURCE: /scripts/sn/common/util/service.getTemplateUrl.js */
angular.module('sn.common.util').provider('getTemplateUrl', function(angularProcessorUrl) {
	'use strict';
	var _handlerId = 0;
	var _handlers = {};
	this.registerHandler = function(handler) {
		var registeredId = _handlerId;
		_handlers[_handlerId] = handler;
		_handlerId++;
		return function() {
			delete _handlers[registeredId];
		};
	};
	this.$get = function() {
		return getTemplateUrl;
	};
	function getTemplateUrl(templatePath) {
		if (_handlerId > 0) {
			var path;
			var handled = false;
			angular.forEach(_handlers, function(handler) {
				if (!handled) {
					var handlerPath = handler(templatePath);
					if (typeof handlerPath !== 'undefined') {
						path = handlerPath;
						handled = true;
					}
				}
			});
			if (handled) {
				return path;
			}
		}
		return angularProcessorUrl + 'get_partial&name=' + templatePath;
	}
});
;
/*! RESOURCE: /scripts/sn/common/util/service.snTabActivity.js */
angular.module("sn.common.util").service("snTabActivity", function ($window, $timeout, $rootElement, $document) {
	"use strict";
	var activeEvents = ["keydown", "DOMMouseScroll", "mousewheel", "mousedown", "touchstart", "mousemove", "mouseenter", "input", "focus", "scroll"],
		defaultIdle = 75000,
		isPrimary = true,
		idleTime = 0,
		isVisible = true,
		idleTimeout = void(0),
		pageIdleTimeout = void(0),
		hasActed = false,
		appName = $rootElement.attr('ng-app') || "",
		storageKey = "sn.tabs." + appName + ".activeTab";
	var callbacks = {
		"tab.primary": [],
		"tab.secondary": [],
		"activity.active": [],
"activity.idle": [{delay: defaultIdle, cb: function(){}}]
	};
	$window.tabGUID = $window.tabGUID || createGUID();
	function getActiveEvents() {
		return activeEvents.join(".snTabActivity ") + ".snTabActivity";
	}
	function setAppName (an) {
		appName = an;
		storageKey = "sn.tabs." + appName + ".activeTab";
		makePrimary(true);
	}
	function createGUID(l) {
		l = l || 32;
		var strResult = '';
		while (strResult.length < l)
			strResult += (((1+Math.random()+new Date().getTime())*0x10000)|0).toString(16).substring(1);
		return strResult.substr(0, l);
	}
	function ngObjectIndexOf(arr, obj) {
		for (var i = 0, len = arr.length; i < len; i++)
			if (angular.equals(arr[i], obj))
				return i;
		return -1;
	}
	var detectedApi,
		apis = [{
			eventName: 'visibilitychange',
			propertyName: 'hidden'
		},{
			eventName: 'mozvisibilitychange',
			propertyName: 'mozHidden'
		},{
			eventName: 'msvisibilitychange',
			propertyName: 'msHidden'
		},{
			eventName: 'webkitvisibilitychange',
			propertyName: 'webkitHidden'
		}];
	apis.some(function(api) {
		if (angular.isDefined($document[0][api.propertyName])) {
			detectedApi = api;
			return true;
		}
	});
	if(detectedApi)
		$document.on(detectedApi.eventName, function() {
			if(!$document[0][detectedApi.propertyName]) {
				makePrimary();
				isVisible = true;
			} else {
				if(!idleTimeout && !idleTime)
					waitForIdle(0);
				isVisible = false;
			}
		});
	angular.element($window).on({
		"mouseleave": function(e) {
			var destination = angular.isUndefined(e.toElement) ? e.relatedTarget : e.toElement;
			if (destination === null && $document[0].hasFocus()) {
				waitForIdle(0);
			}
		},
		"blur": function(e) {
			makePrimary(true);
			isVisible = false;
			resetIdleTime();
		},
		"storage": function(e) {
			if(e.originalEvent.key !== storageKey)
				return;
			if($window.localStorage.getItem(storageKey) !== $window.tabGUID)
				makeSecondary();
		}
	});
	function waitForIdle(index, delayOffset) {
		var callback = callbacks['activity.idle'][index];
		var numCallbacks = callbacks['activity.idle'].length;
		delayOffset = delayOffset || callback.delay;
		angular.element($window).off(getActiveEvents());
		angular.element($window).one(getActiveEvents(), setActive);
		if(index >= numCallbacks)
			return;
		if(idleTimeout)
			$timeout.cancel(idleTimeout);
		idleTimeout = $timeout(function() {
			idleTime = callback.delay;
			callback.cb();
			$timeout.cancel(idleTimeout);
			idleTimeout = void(0);
			angular.element($window).off(getActiveEvents());
			angular.element($window).one(getActiveEvents(), setActive);
			for( var i = index + 1; i < numCallbacks; i++ ) {
				var nextDelay = callbacks['activity.idle'][i].delay;
				if(nextDelay <= callback.delay)
					callbacks['activity.idle'][i].cb();
				else {
					waitForIdle(i, nextDelay - callback.delay);
					break;
				}
			}
		}, delayOffset, false);
	}
	function setActive() {
		angular.element($window).off(getActiveEvents());
		if(idleTimeout) {
			$timeout.cancel(idleTimeout);
			idleTimeout = void(0);
		}
		var activeCallbacks =  callbacks['activity.active'];
		activeCallbacks.some(function(callback) {
			if(callback.delay <= idleTime)
				callback.cb();
			else
				return true;
		});
		idleTime = 0;
		makePrimary();
		if(pageIdleTimeout) {
			$timeout.cancel(pageIdleTimeout);
			pageIdleTimeout = void(0);
		}
		var minDelay = callbacks['activity.idle'][0].delay;
		hasActed = false;
		if(!pageIdleTimeout)
			pageIdleTimeout = $timeout(pageIdleHandler, minDelay, false);
		listenForActivity();
	}
	function pageIdleHandler() {
		if(idleTimeout)
			return;
		var minDelay = callbacks['activity.idle'][0].delay;
		if(hasActed) {
			hasActed = false;
			if(pageIdleTimeout)
				$timeout.cancel(pageIdleTimeout);
			pageIdleTimeout = $timeout(pageIdleHandler, minDelay, false);
			listenForActivity();
			return;
		}
		var delayOffset = minDelay;
		if(callbacks['activity.idle'].length > 1)
			delayOffset = callbacks['activity.idle'][1].delay - minDelay;
		idleTime = minDelay;
		callbacks['activity.idle'][0].cb();
		waitForIdle(1, delayOffset);
		pageIdleTimeout = void(0);
	}
	function listenForActivity() {
		angular.element($window).off(getActiveEvents());
		angular.element($window).one(getActiveEvents(), onActivity);
		angular.element("#gsft_main").on("load.snTabActivity", function() {
			var src = angular.element(this).attr('src');
if(src.indexOf("/") == 0 || src.indexOf($window.location.origin) == 0 || src.indexOf('http') == -1) {
				var iframeWindow = this.contentWindow ? this.contentWindow : this.contentDocument.defaultView;
				angular.element(iframeWindow).off(getActiveEvents());
				angular.element(iframeWindow).one(getActiveEvents(), onActivity);
			}
		});
		angular.element('iframe').each(function(idx, iframe) {
			var src = angular.element(iframe).attr('src');
			if (!src)
				return;
if(src.indexOf("/") == 0 || src.indexOf($window.location.origin) == 0 || src.indexOf('http') == -1) {
				var iframeWindow = iframe.contentWindow ? iframe.contentWindow : iframe.contentDocument.defaultView;
				try {
					angular.element(iframeWindow).off(getActiveEvents());
					angular.element(iframeWindow).one(getActiveEvents(), onActivity);
				} catch(e) {
					return;
				}
			}
		});
	}
	function onActivity() {
		hasActed = true;
		makePrimary();
	}
	function makePrimary(initial) {
		var oldGuid = $window.localStorage.getItem(storageKey);
		isPrimary = true;
		isVisible = true;
		$timeout.cancel(idleTimeout);
		idleTimeout = void(0);
		if(canUseStorage() && oldGuid !== $window.tabGUID && !initial)
			for(var i = 0, len = callbacks["tab.primary"].length; i < len; i++)
				callbacks["tab.primary"][i].cb();
		try {
			$window.localStorage.setItem(storageKey, $window.tabGUID);
		} catch (ignored) {
		}
		if(idleTime && $document[0].hasFocus())
			setActive();
	}
	function makeSecondary() {
		isPrimary = false;
		isVisible = false;
		for(var i = 0, len = callbacks["tab.secondary"].length; i < len; i++)
			callbacks["tab.secondary"][i].cb();
	}
	function registerCallback(event, callback, scope) {
		var cbObject = angular.isObject(callback) ? callback : {delay: defaultIdle, cb: callback};
		if(callbacks[event]) {
			callbacks[event].push(cbObject);
			callbacks[event].sort(function(a, b) {
				return a.delay - b.delay;
			})
		}
		function destroyCallback() {
			if (callbacks[event]) {
				var pos = ngObjectIndexOf(callbacks[event], cbObject);
				if (pos !== -1)
					callbacks[event].splice(pos, 1);
			}
		}
		if(scope)
			scope.$on("$destroy", function() {
				destroyCallback();
			});
		return destroyCallback;
	}
	function registerIdleCallback(options, onIdle, onReturn, scope) {
		var delay = options,
			onIdleDestroy,
			onReturnDestroy;
		if(angular.isObject(options)) {
			delay = options.delay;
			onIdle = options.onIdle || onIdle;
			onReturn = options.onReturn || onReturn;
			scope = options.scope || scope;
		}
		if(angular.isFunction(onIdle))
			onIdleDestroy = registerCallback("activity.idle", {delay: delay, cb: onIdle});
		else if (angular.isFunction(onReturn)) {
			onIdleDestroy = registerCallback("activity.idle", {delay: delay, cb: function(){}});
		}
		if(angular.isFunction(onReturn))
			onReturnDestroy = registerCallback("activity.active", {delay: delay, cb: onReturn});
		function destroyAll() {
			if(angular.isFunction(onIdleDestroy))
				onIdleDestroy();
			if(angular.isFunction(onReturnDestroy))
				onReturnDestroy();
		}
		if(scope)
			scope.$on("$destroy", function() {
				destroyAll();
			});
		return destroyAll;
	}
	function canUseStorage() {
		var canWe = false;
		try {
			$window.localStorage.setItem(storageKey, $window.tabGUID);
			canWe = true;
		} catch (ignored) {
		}
		return canWe;
	}
	function resetIdleTime() {
		if(idleTime > 0) {
			idleTime = 0;
			if(pageIdleTimeout) {
				$timeout.cancel(pageIdleTimeout);
				pageIdleTimeout = void(0);
			}
		}
		waitForIdle(0);
	}
	makePrimary(true);
	listenForActivity();
	pageIdleTimeout = $timeout(pageIdleHandler, defaultIdle, false);
	return {
		on: registerCallback,
		onIdle: registerIdleCallback,
		setAppName: setAppName,
		get isPrimary() { return isPrimary; },
		get isIdle() { return idleTime > 0; },
		get idleTime() { return idleTime; },
		get isVisible() { return isVisible; },
		get appName() { return appName; },
		get defaultIdleTime() { return defaultIdle },
		isActive: function() {
			return this.idleTime < this.defaultIdleTime && this.isVisible;
		},
		resetIdleTime: resetIdleTime
	}
});
;
/*! RESOURCE: /scripts/sn/common/util/factory.ArraySynchronizer.js */
angular.module("sn.common.util").factory("ArraySynchronizer", function() {
	'use strict';
	function ArraySynchronizer(){}
	function index(key, arr) {
		var result = {};
		var keys = [];
		result.orderedKeys = keys;
		angular.forEach(arr, function(item) {
			var keyValue = item[key];
			result[keyValue] = item;
			keys.push(keyValue);
		});
		return result;
	}
	function sortByKeyAndModel(arr, key, model) {
		arr.sort(function(a, b) {
			var aIndex = model.indexOf(a[key]);
			var bIndex = model.indexOf(b[key]);
			if(aIndex > bIndex)
				return 1;
			else if (aIndex < bIndex)
				return -1;
			return 0;
		});
	}
	ArraySynchronizer.prototype = {
		add: function(syncField, dest, source, end) {
			end = end || "bottom";
			var destIndex = index(syncField, dest);
			var sourceIndex = index(syncField, source);
			angular.forEach(sourceIndex.orderedKeys, function(key) {
				if(destIndex.orderedKeys.indexOf(key) === -1) {
					if(end === "bottom") {
						dest.push(sourceIndex[key]);
					} else {
						dest.unshift(sourceIndex[key]);
					}
				}
			});
		},
		synchronize: function(syncField, dest, source, deepKeySyncArray) {
			var destIndex = index(syncField, dest);
			var sourceIndex = index(syncField, source);
			deepKeySyncArray = (typeof deepKeySyncArray === "undefined") ? [] : deepKeySyncArray;
			for(var i = destIndex.orderedKeys.length - 1; i >= 0; i--) {
				var key = destIndex.orderedKeys[i];
				if(sourceIndex.orderedKeys.indexOf(key) === -1) {
					destIndex.orderedKeys.splice(i, 1);
					dest.splice(i, 1);
				}
				if (deepKeySyncArray.length > 0) {
					angular.forEach(deepKeySyncArray, function(deepKey) {
						if (sourceIndex[key] && destIndex[key][deepKey] !== sourceIndex[key][deepKey]) {
							destIndex[key][deepKey] = sourceIndex[key][deepKey];
						}
					});
				}
			}
			angular.forEach(sourceIndex.orderedKeys, function(key) {
				if(destIndex.orderedKeys.indexOf(key) === -1)
					dest.push(sourceIndex[key]);
			});
			sortByKeyAndModel(dest, syncField, sourceIndex.orderedKeys);
		}
	};
	return ArraySynchronizer;
});
;
/*! RESOURCE: /scripts/sn/common/util/directive.snBindOnce.js */
angular.module("sn.common.util").directive("snBindOnce", function($sanitize) {
	"use strict";
	return {
		restrict: "A",
		link: function(scope, element, attrs) {
			var value = scope.$eval(attrs.snBindOnce);
			var sanitizedValue = $sanitize(value);
			element.append(sanitizedValue);
		}
	}
})
;
/*! RESOURCE: /scripts/sn/common/util/directive.snCloak.js */
angular.module("sn.common.util").directive("snCloak", function() {
	"use strict";
	return {
		restrict: "A",
		compile: function(element, attr) {
			return function() {
				attr.$set('snCloak', undefined);
				element.removeClass('sn-cloak');
			}
		}
	};
})
;
/*! RESOURCE: /scripts/sn/common/util/service.md5.js */
angular.module('sn.common.util').factory('md5', function() {
	'use strict';
	var md5cycle = function(x, k) {
		var a = x[0], b = x[1], c = x[2], d = x[3];
		a = ff(a, b, c, d, k[0], 7, -680876936);
		d = ff(d, a, b, c, k[1], 12, -389564586);
		c = ff(c, d, a, b, k[2], 17,  606105819);
		b = ff(b, c, d, a, k[3], 22, -1044525330);
		a = ff(a, b, c, d, k[4], 7, -176418897);
		d = ff(d, a, b, c, k[5], 12,  1200080426);
		c = ff(c, d, a, b, k[6], 17, -1473231341);
		b = ff(b, c, d, a, k[7], 22, -45705983);
		a = ff(a, b, c, d, k[8], 7,  1770035416);
		d = ff(d, a, b, c, k[9], 12, -1958414417);
		c = ff(c, d, a, b, k[10], 17, -42063);
		b = ff(b, c, d, a, k[11], 22, -1990404162);
		a = ff(a, b, c, d, k[12], 7,  1804603682);
		d = ff(d, a, b, c, k[13], 12, -40341101);
		c = ff(c, d, a, b, k[14], 17, -1502002290);
		b = ff(b, c, d, a, k[15], 22,  1236535329);
		a = gg(a, b, c, d, k[1], 5, -165796510);
		d = gg(d, a, b, c, k[6], 9, -1069501632);
		c = gg(c, d, a, b, k[11], 14,  643717713);
		b = gg(b, c, d, a, k[0], 20, -373897302);
		a = gg(a, b, c, d, k[5], 5, -701558691);
		d = gg(d, a, b, c, k[10], 9,  38016083);
		c = gg(c, d, a, b, k[15], 14, -660478335);
		b = gg(b, c, d, a, k[4], 20, -405537848);
		a = gg(a, b, c, d, k[9], 5,  568446438);
		d = gg(d, a, b, c, k[14], 9, -1019803690);
		c = gg(c, d, a, b, k[3], 14, -187363961);
		b = gg(b, c, d, a, k[8], 20,  1163531501);
		a = gg(a, b, c, d, k[13], 5, -1444681467);
		d = gg(d, a, b, c, k[2], 9, -51403784);
		c = gg(c, d, a, b, k[7], 14,  1735328473);
		b = gg(b, c, d, a, k[12], 20, -1926607734);
		a = hh(a, b, c, d, k[5], 4, -378558);
		d = hh(d, a, b, c, k[8], 11, -2022574463);
		c = hh(c, d, a, b, k[11], 16,  1839030562);
		b = hh(b, c, d, a, k[14], 23, -35309556);
		a = hh(a, b, c, d, k[1], 4, -1530992060);
		d = hh(d, a, b, c, k[4], 11,  1272893353);
		c = hh(c, d, a, b, k[7], 16, -155497632);
		b = hh(b, c, d, a, k[10], 23, -1094730640);
		a = hh(a, b, c, d, k[13], 4,  681279174);
		d = hh(d, a, b, c, k[0], 11, -358537222);
		c = hh(c, d, a, b, k[3], 16, -722521979);
		b = hh(b, c, d, a, k[6], 23,  76029189);
		a = hh(a, b, c, d, k[9], 4, -640364487);
		d = hh(d, a, b, c, k[12], 11, -421815835);
		c = hh(c, d, a, b, k[15], 16,  530742520);
		b = hh(b, c, d, a, k[2], 23, -995338651);
		a = ii(a, b, c, d, k[0], 6, -198630844);
		d = ii(d, a, b, c, k[7], 10,  1126891415);
		c = ii(c, d, a, b, k[14], 15, -1416354905);
		b = ii(b, c, d, a, k[5], 21, -57434055);
		a = ii(a, b, c, d, k[12], 6,  1700485571);
		d = ii(d, a, b, c, k[3], 10, -1894986606);
		c = ii(c, d, a, b, k[10], 15, -1051523);
		b = ii(b, c, d, a, k[1], 21, -2054922799);
		a = ii(a, b, c, d, k[8], 6,  1873313359);
		d = ii(d, a, b, c, k[15], 10, -30611744);
		c = ii(c, d, a, b, k[6], 15, -1560198380);
		b = ii(b, c, d, a, k[13], 21,  1309151649);
		a = ii(a, b, c, d, k[4], 6, -145523070);
		d = ii(d, a, b, c, k[11], 10, -1120210379);
		c = ii(c, d, a, b, k[2], 15,  718787259);
		b = ii(b, c, d, a, k[9], 21, -343485551);
		x[0] = add32(a, x[0]);
		x[1] = add32(b, x[1]);
		x[2] = add32(c, x[2]);
		x[3] = add32(d, x[3]);
	};
	var cmn = function(q, a, b, x, s, t) {
		a = add32(add32(a, q), add32(x, t));
		return add32((a << s) | (a >>> (32 - s)), b);
	};
	var ff = function(a, b, c, d, x, s, t) {
		return cmn((b & c) | ((~b) & d), a, b, x, s, t);
	};
	var gg = function(a, b, c, d, x, s, t) {
		return cmn((b & d) | (c & (~d)), a, b, x, s, t);
	};
	var hh = function(a, b, c, d, x, s, t) {
		return cmn(b ^ c ^ d, a, b, x, s, t);
	};
	var ii = function(a, b, c, d, x, s, t) {
		return cmn(c ^ (b | (~d)), a, b, x, s, t);
	};
	var md51 = function(s) {
		var txt = '';
		var n = s.length,
			state = [1732584193, -271733879, -1732584194, 271733878], i;
		for (i=64; i<=s.length; i+=64) {
			md5cycle(state, md5blk(s.substring(i-64, i)));
		}
		s = s.substring(i-64);
		var tail = [0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0];
		for (i=0; i<s.length; i++)
			tail[i>>2] |= s.charCodeAt(i) << ((i%4) << 3);
		tail[i>>2] |= 0x80 << ((i%4) << 3);
		if (i > 55) {
			md5cycle(state, tail);
			for (i=0; i<16; i++) tail[i] = 0;
		}
		tail[14] = n*8;
		md5cycle(state, tail);
		return state;
	};
	var md5blk = function(s) {
		var md5blks = [], i;
		for (i=0; i<64; i+=4) {
			md5blks[i>>2] = s.charCodeAt(i)
				+ (s.charCodeAt(i+1) << 8)
				+ (s.charCodeAt(i+2) << 16)
				+ (s.charCodeAt(i+3) << 24);
		}
		return md5blks;
	};
	var hex_chr = '0123456789abcdef'.split('');
	var rhex = function(n) {
		var s='', j=0;
		for(; j<4; j++)
			s += hex_chr[(n >> (j * 8 + 4)) & 0x0F]
				+ hex_chr[(n >> (j * 8)) & 0x0F];
		return s;
	};
	var hex = function(x) {
		for (var i=0; i<x.length; i++)
			x[i] = rhex(x[i]);
		return x.join('');
	};
	var add32 = function(a, b) {
		return (a + b) & 0xFFFFFFFF;
	};
	return function(s) {
		return hex(md51(s));
	};
});
;
/*! RESOURCE: /scripts/sn/common/util/service.priorityQueue.js */
angular.module('sn.common.util').factory('priorityQueue', function() {
	'use strict';
	return function(comparator) {
		var items = [];
		var compare = comparator || function(a, b) {
			return a - b;
		};
		var swap = function(a, b) {
			var temp = items[a];
			items[a] = items[b];
			items[b] = temp;
		};
		var bubbleUp = function(pos) {
			var parent;
			while (pos > 0) {
				parent = (pos - 1) >> 1;
				if (compare(items[pos], items[parent]) >= 0)
					break;
				swap(parent, pos);
				pos = parent;
			}
		};
		var bubbleDown = function(pos) {
			var left, right, min, last = items.length - 1;
			while (true) {
				left = (pos << 1) + 1;
				right = left + 1;
				min = pos;
				if (left <= last && compare(items[left], items[min]) < 0)
					min = left;
				if (right <= last && compare(items[right], items[min]) < 0)
					min = right;
				if (min === pos)
					break;
				swap(min, pos);
				pos = min;
			}
		};
		return {
			add: function(item) {
				items.push(item);
				bubbleUp(items.length - 1);
			},
			poll: function() {
				var first = items[0],
					last = items.pop();
				if (items.length > 0) {
					items[0] = last;
					bubbleDown(0);
				}
				return first;
			},
			peek: function() {
				return items[0];
			},
			clear: function() {
				items = [];
			},
			inspect: function() {
				return angular.toJson(items, true);
			},
			get size() {
				return items.length;
			},
			get all() {
				return items;
			},
			set comparator(fn) {
				compare = fn;
			}
		};
	};
});
;
/*! RESOURCE: /scripts/sn/common/util/service.snResource.js */
angular.module('sn.common.util').factory('snResource', function($http, $q, priorityQueue, md5) {
	'use strict';
	var methods = ['get', 'post', 'put', 'patch', 'delete', 'head', 'options', 'jsonp', 'trace'],
		queue = priorityQueue(function(a, b) {
			return a.timestamp - b.timestamp;
		}),
		resource = {},
		pendingRequests = [],
		inFlightRequests = [];
	return function() {
		var requestInterceptors = $http.defaults.transformRequest,
			responseInterceptors = $http.defaults.transformResponse;
		var next = function() {
			var request = queue.peek();
			pendingRequests.shift();
			inFlightRequests.push(request.hash);
			$http(request.config).then(function(response) {
				request.deferred.resolve(response);
			}, function(reason) {
				request.deferred.reject(reason);
			}).finally(function() {
				queue.poll();
				inFlightRequests.shift();
				if (queue.size > 0)
					next();
			});
		};
		angular.forEach(methods, function(method) {
			resource[method] = function(url, data) {
				var deferredRequest = $q.defer(),
					promise = deferredRequest.promise,
					deferredAbort = $q.defer(),
					config = {
						method: method,
						url: url,
						data: data,
						transformRequest: requestInterceptors,
						transformResponse: responseInterceptors,
						timeout: deferredAbort.promise
					},
					hash = md5(JSON.stringify(config));
				pendingRequests.push(hash);
				queue.add({
					config: config,
					deferred: deferredRequest,
					timestamp: Date.now(),
					hash: hash
				});
				if (queue.size === 1)
					next();
				promise.abort = function() {
					deferredAbort.resolve('Request cancelled');
				};
				return promise;
			};
		});
		resource.addRequestInterceptor = function(fn) {
			requestInterceptors = requestInterceptors.concat([fn]);
		};
		resource.addResponseInterceptor = function(fn) {
			responseInterceptors = responseInterceptors.concat([fn]);
		};
		resource.queueSize = function() {
			return queue.size;
		};
		resource.queuedRequests = function() {
			return queue.all;
		};
		return resource;
	};
});
;
/*! RESOURCE: /scripts/sn/common/util/service.snConnect.js */
angular.module("sn.common.util").service("snConnectService", function ($http, snCustomEvent) {
	"use strict";
var connectPaths = ["/$c.do", "/$chat.do"];
	function canOpenInFrameset() {
		return window.top.NOW.collaborationFrameset;
	}
	function isInConnect() {
		var parentPath = getParentPath();
		return connectPaths.some(function(path) {
			return parentPath == path;
		});
	}
	function getParentPath() {
		try {
			return window.top.location.pathname;
		} catch(IGNORED) {
			return "";
		}
	}
	function openWithProfile(profile) {
		if (isInConnect() || canOpenInFrameset())
			snCustomEvent.fireTop('chat:open_conversation', profile);
		else
window.open("$c.do#/with/" + profile.sys_id, "_blank");
	}
	return {
		openWithProfile: openWithProfile
	}
});
;
/*! RESOURCE: /scripts/sn/common/util/snPolyfill.js */
(function(){
	"use strict";
	polyfill(String.prototype, 'startsWith', function(prefix) {
		return this.indexOf(prefix) === 0;
	});
	polyfill(String.prototype, 'endsWith', function(suffix) {
		return this.indexOf(suffix, this.length - suffix.length) !== -1;
	});
	polyfill(Number, 'isNaN', function(value) {
return value !== value;
	});
	polyfill(window, 'btoa', function (input) {
		var str = String(input);
var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
		for (
			var block, charCode, idx = 0, map = chars, output = '';
			str.charAt(idx | 0) || (map = '=', idx % 1);
			output += map.charAt(63 & block >> 8 - idx % 1 * 8)
		) {
charCode = str.charCodeAt(idx += 3/4);
			if (charCode > 0xFF) {
				throw new InvalidCharacterError("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
			}
			block = block << 8 | charCode;
		}
		return output;
	});
	function polyfill(obj, slot, fn) {
		if (obj[slot] === void(0)) {
			obj[slot] = fn;
		}
	}
	
	
	window.console = window.console || { log: function(){} };
	
})();
;
/*! RESOURCE: /scripts/sn/common/util/directive.snFocus.js */
angular.module('sn.common.util').directive('snFocus', function($timeout) {
	'use strict';
	return function(scope, element, attrs) {
		scope.$watch(attrs.snFocus, function(value) {
			if (value !== true)
				return;
			$timeout(function() {
				element[0].focus();
			});
		});
	};
});
;
/*! RESOURCE: /scripts/sn/common/util/directive.snResizeHeight.js */
angular.module('sn.common.util').directive('snResizeHeight', function($window) {
	'use strict';
	return {
		restrict : 'A',
		link : function(scope, elem, attrs) {
			if (typeof $window.autosize === 'undefined') {
				return;
			}
			$window.autosize(elem);
			function _update() {
				$window.autosize.update(elem);
			}
			function _destroy() {
				$window.autosize.destroy(elem);
			}
			if (typeof attrs.disableValueWatcher === "undefined") {
				scope.$watch(function() {
					return elem.val();
				}, function valueWatcher(newValue, oldValue) {
					if (newValue === oldValue) {
						return;
					}
					_update();
				});
			}
			elem.on('input.resize', _update);
			scope.$on('$destroy', function() {
				_destroy();
			});
			if (attrs.snTextareaAutosizer === 'trim') {
				elem.on('blur', function() {
					elem.val(elem.val().trim());
					_update();
				})
			}
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/util/directive.snBlurOnEnter.js */
angular.module('sn.common.util').directive('snBlurOnEnter', function() {
	'use strict';
	return function(scope, element) {
		element.bind("keydown keypress", function(event) {
						
			if (event.which !== 13)
				return;
				
			element.blur();
			event.preventDefault();
		});
	};
});
;
/*! RESOURCE: /scripts/sn/common/util/directive.snStickyHeaders.js */
angular.module('sn.common.util').directive('snStickyHeaders', function() {
	"use strict";
	return {
		restrict : 'A',
		transclude: false,
		replace: false,
		link: function (scope, element, attrs) {
			element.addClass('sticky-headers');
			var containers;
			var scrollContainer = element.find('[sn-sticky-scroll-container]');
			scrollContainer.addClass('sticky-scroll-container');
			function refreshHeaders () {
				if (attrs.snStickyHeaders !== 'false') {
					angular.forEach(containers, function (container) {
						var stickyContainer = angular.element(container);
						var stickyHeader = stickyContainer.find('[sn-sticky-header]');
						var stickyOffset = stickyContainer.position().top + stickyContainer.outerHeight();
						stickyContainer.addClass('sticky-container');
						if (stickyOffset < stickyContainer.outerHeight() && stickyOffset > -stickyHeader.outerHeight()) {
							stickyContainer.css('padding-top', stickyHeader.outerHeight());
							stickyHeader.css('width', stickyHeader.outerWidth());
							stickyHeader.removeClass('sticky-header-disabled').addClass('sticky-header-enabled');
						} else {
							stickyContainer.css('padding-top', '');
							stickyHeader.css('width', '');
							stickyHeader.removeClass('sticky-header-enabled').addClass('sticky-header-disabled');
						}
					});
				} else {
					element.find('[sn-sticky-container]').removeClass('sticky-container');
					element.find('[sn-sticky-container]').css('padding-top', '');
					element.find('[sn-sticky-header]').css('width', '');
					element.find('[sn-sticky-header]').removeClass('sticky-header-enabled').addClass('sticky-header-disabled');
				}
			}
			scope.$watch(function () {
				scrollContainer.find('[sn-sticky-header]').addClass('sticky-header');
				containers = element.find('[sn-sticky-container]');
				return attrs.snStickyHeaders;
			}, refreshHeaders);
			scope.$watch(function () {
				return scrollContainer[0].scrollHeight;
			}, refreshHeaders);
			scrollContainer.on('scroll', refreshHeaders);
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/util/directive.snBanner.js */
angular.module('sn.common.util').directive('snBanner', function(getTemplateUrl, $window, $http) {
	'use strict';
	function isIOS () {
var match = navigator.userAgent.match(/iPhone; CPU iPhone OS ([0-9_]*)/);
		return !!match;
	};
	function isNative () {
return (navigator.userAgent.match(/SnMobile/i)
|| navigator.userAgent.match(/ServiceNow/i))
	};
	var isBannerClosed = function() {
		var localStorageTime = $window.localStorage.getItem('mobileBannerDismissed');
		var isBannerClosedFlag = false;
		var SECONDS_IN_A_DAY = 86400000;
		if(localStorageTime) {
if(((Date.now() - localStorageTime)/SECONDS_IN_A_DAY) < 1) {
				isBannerClosedFlag = true;
			} else {
				$window.localStorage.removeItem('mobileBannerDismissed');
			}
		}
		return isBannerClosedFlag;
	};
	var setBannerClosedTime = function() {
		$window.localStorage.setItem('mobileBannerDismissed', Date.now());
	};
	var emitBannerState = function(state, $scope) {
		$scope.$emit(state);
	}
	return {
		restrict: 'E',
		templateUrl: getTemplateUrl('sn_banner.xml'),
		scope: {
			bannerApiUrl: '='
		},
		controller: function($scope) {
			$scope.isIOS = isIOS();
			$scope.closeBanner = function() {
				$scope.banner.show = false;
				setBannerClosedTime();
				emitBannerState('banner.closed', $scope);
			};
			$scope.openUrl = function() {
				$window.open($scope.banner.nativeAppUrl, '_blank');
			};
			$scope.$watch('bannerApiUrl', function(newVal, oldVal) {
				if (newVal && newVal !== oldVal) {
					setBanner(newVal);
				}
			});
			function setBanner(bannerApiUrl) {
				$scope.banner = {};
				if (isBannerClosed()) {
					$scope.banner.show = false;
					return;
				}
				if (isNative()) {
					$scope.banner.show = false;
					return;
				};
				$http.get(bannerApiUrl)
					.then(function(response) {
						var data = response.data;
						if (data.BannerDetails) {
							$scope.banner.show =  true;
							$scope.banner.icon = data.BannerDetails.IconPath;
							$scope.banner.name = data.BannerDetails.Name;
							$scope.banner.description = data.BannerDetails.Description;
							$scope.banner.nativeAppUrl = data.BannerDetails.Ulink;
							emitBannerState('banner.opened', $scope);
						} else {
							$scope.banner.show =  false;
							emitBannerState('banner.closed', $scope);
						}
				});
			}
		}
	}
});
;
;
/*! RESOURCE: /scripts/sn/common/util/js_includes_util.js */
/*! RESOURCE: /scripts/sn/common/ui/_module.js */
angular.module('sn.common.ui', ['sn.common.messaging']);
;
/*! RESOURCE: /scripts/sn/common/ui/popover/_module.js */
angular.module('sn.common.ui.popover', []);
;
/*! RESOURCE: /scripts/sn/common/ui/popover/directive.snBindPopoverSelection.js */
angular.module('sn.common.ui.popover').directive('snBindPopoverSelection', function(snCustomEvent) {
	"use strict";
	return {
		restrict: "A",
		controller: function($scope, $element, $attrs , snCustomEvent) {
			snCustomEvent.observe('list.record_select', recordSelectDataHandler);
			function recordSelectDataHandler(data, event) {
				if (!data || !event)
					return;
				event.stopPropagation();
				var ref = ($scope.field) ? $scope.field.ref : $attrs.ref;
				if (data.ref === ref) {
					if (window.g_form) {
						if ($attrs.addOption) {
							addGlideListChoice('select_0' + $attrs.ref, data.value, data.displayValue);
						} else {
							var fieldValue = typeof $attrs.ref === 'undefined' ? data.ref : $attrs.ref;
							window.g_form._setValue(fieldValue, data.value, data.displayValue);
							clearDerivedFields(data.value);
						}
					}
					if ($scope.field) {
						$scope.field.value = data.value;
						$scope.field.displayValue = data.displayValue;
					}
				}
			}
			function clearDerivedFields(value) {
				if (window.DerivedFields) {
					var df = new DerivedFields($scope.field ? $scope.field.ref : $attrs.ref);
					df.clearRelated();
					df.updateRelated(value);
				}
			}
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/ui/popover/directive.snComplexPopover.js */
angular.module('sn.common.ui.popover').directive('snComplexPopover', function(getTemplateUrl, $q, $http, $templateCache, $compile, $timeout){
	"use strict";
	return {
		restrict: 'E',
		replace:true,
		templateUrl: function(elem, attrs){
			return getTemplateUrl(attrs.buttonTemplate);
		},
		controller: function($scope, $element, $attrs, $q, $document, snCustomEvent, snComplexPopoverService){
			$scope.type = $attrs.complexPopoverType || "complex_popover";
			if ($scope.closeEvent){
				snCustomEvent.observe($scope.closeEvent, destroyPopover);
				$scope.$on($scope.closeEvent, destroyPopover);
			}
			$scope.$parent.$on('$destroy', destroyPopover);
			$scope.$on('$destroy', function() {
				snCustomEvent.un($scope.closeEvent, destroyPopover);
			});
			var newScope;
			var open;
			var popover;
			var content;
			var popoverDefaults = {
				container: 'body',
				html: true,
				placement: 'auto',
				trigger: 'manual',
template: '<div class="complex_popover popover" role="dialog"><div class="arrow"></div><div class="popover-content"></div></div>'
			};
			var popoverConfig = angular.extend(popoverDefaults, $scope.popoverConfig);
			$scope.loading      = false;
			$scope.initialized  = false;
			$scope.popOverDisplaying = false;
			$scope.onDownKey = function(event) {
				if (!event) return;
				var downArrowKey = 40;
				if (event.keyCode === downArrowKey || event.key === 'ArrowDown')
					$scope.togglePopover(event);
			};
			$scope.togglePopover = function(event) {
				if (!open){
					showPopover(event);
				} else {
					destroyPopover();
				}
				$scope.popOverDisplaying = !$scope.popOverDisplaying;
			};
			function showPopover(e) {
				if ($scope.loading)
					return;
				$scope.$toggleButton = angular.element(e.target);
				$scope.loading = true;
				$scope.$emit('list.toggleLoadingState', true);
				_getTemplate()
					.then(_insertTemplate)
					.then(_createPopover)
					.then(_bindHtml)
					.then(function(){
						$scope.initialized = true;
						if (!$scope.loadEvent)
							_openPopover();
					});
			}
			function destroyPopover() {
				if (!newScope)
					return;
				$scope.$toggleButton.on('hidden.bs.popover', function(){
					open = false;
					$scope.$toggleButton.data('bs.popover').$element.removeData('bs.popover').off('.popover');
					$scope.$toggleButton = null;
					snCustomEvent.fire('hidden.complexpopover.' + $scope.ref);
				});
				$scope.$toggleButton.popover('hide');
				snCustomEvent.fire('hide.complexpopover.' + $scope.ref, $scope.$toggleButton);
newScope.$broadcast('$destroy');
				newScope.$destroy();
				newScope = null;
				$scope.initialized = false;
				angular.element(popoverConfig.container).off({
					'keydown': keyDownHandler
				});
				angular.element(window).off({
					'click': complexHtmlHandler
				});
			}
			function _getTemplate() {
				return snComplexPopoverService.getTemplate(getTemplateUrl($attrs.template));
			}
			function _createPopover() {
				$scope.$toggleButton.popover(popoverConfig);
				return $q.when(true);
			}
			function _insertTemplate(response) {
				newScope = $scope.$new();
				if ($scope.loadEvent)
					newScope.$on($scope.loadEvent, _openPopover);
				content = $compile(response.data)(newScope);
				popoverConfig.content = content;
				newScope.open = true;
				snCustomEvent.fire('inserted.complexpopover.' + $scope.ref, $scope.$toggleButton);
				return $q.when(true);
			}
			function _bindHtml() {
				angular.element(popoverConfig.container).on({
					'keydown': keyDownHandler
				});
				angular.element(window).on({
					'click': complexHtmlHandler
				});
				return $q.when(true);
			}
			function complexHtmlHandler(e) {
				var parentComplexPopoverScope = angular.element(e.target).parents('.popover-content').children().scope();
				if (parentComplexPopoverScope && (parentComplexPopoverScope.type = "complex_popover") && $scope.type === "complex_popover")
					return;
				if (!open || angular.element(e.target).parents('html').length === 0)
					return;
				if ($scope.initialized && !$scope.loading && !$scope.$toggleButton.is(e.target) && content.parents('.popover').has(angular.element(e.target)).length === 0) {
					_eventClosePopover(e);
					destroyPopover(e);
				}
				if (e.target.classList.contains(popoverConfig.closeBtnClass) && e.type === 'click') {
					_eventClosePopover(e);
					destroyPopover(e);
				}
			}
			function keyDownHandler(e) {
if (e.keyCode != 27)
					return;
				if (!open || angular.element(e.target).parents('html').length === 0)
					return;
				if ($scope.initialized && !$scope.loading && !$scope.$toggleButton.is(e.target) && content.parents('.popover').has(angular.element(e.target)).length > 0) {
					_eventClosePopover(e);
					destroyPopover();
				}
			}
			function _eventClosePopover(e) {
					e.preventDefault();
					e.stopPropagation();
			}
			function createAndActivateFocusTrap(popover) {
				var deferred = $q.defer();
				if (!window.focusTrap) {
					deferred.reject('Focus trap not found');
				} else {
					if (!$scope.focusTrap) {
						$scope.focusTrap = window.focusTrap(popover, { clickOutsideDeactivates: true });
					}
					try {
						$scope.focusTrap.activate({
							onActivate: function() {
								deferred.resolve();
							}
						});
					} catch(e) {
						console.warn("Unable to activate focus trap", e);
					}
				}
				return deferred.promise;
			}
			function deactivateAndDestroyFocusTrap() {
				var deferred = $q.defer();
				if (!$scope.focusTrap) {
					deferred.reject("Focus trap not found");
				} else {
					try {
						$scope.focusTrap.deactivate({
							returnFocus: false,
							onDeactivate: function () {
								deferred.resolve();
							}
						});
					} catch (e) {
						console.warn("Unable to deactivate focus trap", e);
					}
					$scope.focusTrap = null;
				}
				return deferred.promise;
			}
			function _openPopover() {
				if (open) {
					return;
				}
				open = true;
				$timeout(function() {
					$scope.$toggleButton.popover('show');
					$scope.loading = false;
					snCustomEvent.fire('show.complexpopover.' + $scope.ref, $scope.$toggleButton);
					$scope.$toggleButton.on('shown.bs.popover', function(evt) {
						var popoverObject = angular.element(evt.target).data('bs.popover'),
							$tooltip,
							popover;
						$tooltip = popoverObject && popoverObject.$tip;
						popover = $tooltip && $tooltip[0];
						if (popover) {
							createAndActivateFocusTrap(popover);
						}
						snCustomEvent.fire('shown.complexpopover.' + $scope.ref, $scope.$toggleButton);
						var element = document.querySelector('.filter-accordion-title');
						if (element)
							element.focus();
					});
					$scope.$toggleButton.on('hide.bs.popover', function () {
						deactivateAndDestroyFocusTrap().finally(function() {
							$scope.$toggleButton.focus();
						});
					});
				}, 0 );
			}
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/ui/popover/service.snComplexPopoverService.js */
angular.module('sn.common.ui.popover').service('snComplexPopoverService', function($http, $q, $templateCache){
	"use strict";
	return {
		getTemplate: getTemplate
	};
	function getTemplate(template){
		return $http.get(template, {cache: $templateCache});
	}
});
;
;
/*! RESOURCE: /scripts/sn/common/ui/popover/js_includes_ui_popover.js */
/*! RESOURCE: /scripts/sn/common/ui/directive.snConfirmModal.js */
angular.module('sn.common.ui').directive('snConfirmModal', function(getTemplateUrl) {
	return {
		templateUrl: getTemplateUrl('sn_confirm_modal.xml'),
		restrict: 'E',
		replace: true,
		transclude: true,
		scope: {
			config: '=?',
			modalName: '@',
			title: '@?',
			message: '@?',
			cancelButton:  '@?',
			okButton: '@?',
			alertButton: '@?',
			cancel: '&?',
			ok: '&?',
			alert: '&?'
		},
		link: function (scope, element) {
			element.find('.modal').remove();
		},
		controller: function($scope, $rootScope) {
			$scope.config = $scope.config || {};
			function Button(fn, text) {
				return { fn: fn, text: text }
			}
			var buttons = {
				'cancelButton': new Button('cancel', 'Cancel'),
				'okButton':     new Button('ok',     'OK'),
				'alertButton':  new Button('alert',  'Close'),
				getText: function(type) {
					var button = this[type];
					if (button && $scope.get(button.fn))
						return button.text;
				}
			};
			$scope.get = function(type) {
				if ($scope.config[type])
					return $scope.config[type];
				if (!$scope[type]) {
					var text = buttons.getText(type);
					if (text)
						return $scope.config[type] = text;
				}
				return $scope.config[type] = $scope[type];
			};
			if(!$scope.get('modalName'))
				$scope.config.modalName = 'confirm-modal';
			function call(type) {
				var action = $scope.get(type);
				if (action) {
					if (angular.isFunction(action))
						action();
					return true;
				}
				return !!buttons.getText(type);
			}
			$scope.cancelPressed = close('cancel');
			$scope.okPressed = close('ok');
			$scope.alertPressed = close('alert');
			function close (type) {
				return function () {
					actionClosed = true;
					$rootScope.$broadcast('dialog.' + $scope.config.modalName + '.close');
					call(type);
				}
			}
			var actionClosed;
			$scope.$on('dialog.' + $scope.get('modalName') + '.opened', function() {
				actionClosed = false;
				$scope.isOpen = true;
			});
			$scope.$on('dialog.' + $scope.get('modalName') + '.closed', function() {
				$scope.isOpen = false;
				if (actionClosed)
					return;
				if (call('cancel'))
					return;
				if (call('alert'))
					return;
				call('ok');
			});
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/ui/directive.snContextMenu.js */
angular.module('sn.common.ui').directive('contextMenu', function ($document, $window, snCustomEvent) {
	var $contextMenu, $ul;
	var scrollHeight = angular.element("body").get(0).scrollHeight;
	var contextMenuItemHeight = 0;
	var $triggeringElement;
	var _focusTrap;
	function setContextMenuPosition(event, $ul){
		if (!event.pageX && event.originalEvent.changedTouches)
			event = event.originalEvent.changedTouches[0];
		if (contextMenuItemHeight === 0)
			contextMenuItemHeight = 24;
		var cmWidth = 150;
		var cmHeight = contextMenuItemHeight * $ul.children().length;
		var pageX = event.pageX;
		var pageY = event.pageY;
		if (!pageX) {
			var rect = event.target.getBoundingClientRect();
			pageX = rect.left + angular.element(event.target).width();
			pageY = rect.top + angular.element(event.target).height();
		}
		var startX = pageX + cmWidth >= $window.innerWidth ? pageX - cmWidth : pageX;
		var startY = pageY + cmHeight >= $window.innerHeight ? pageY - cmHeight : pageY;
		$ul.css({
			display: 'block',
			position: 'absolute',
			left: startX,
			top: startY
		});
	}
	function renderContextMenuItems($scope, event, options) {
		$ul.empty();
		angular.forEach(options, function (item) {
			var $li = angular.element('<li role="presentation">');
			if (item === null) {
				$li.addClass('divider');
			} else {
				var $a = angular.element('<a role="menuitem" href="javascript:void(0)">');
				$a.text(typeof item[0] == 'string' ? item[0] : item[0].call($scope, $scope));
				$li.append($a);
				$li.on('click', function ($event) {
					$event.preventDefault();
					$scope.$apply(function () {
						_clearContextMenus(event);
						item[1].call($scope, $scope);
					});
				});
			}
			$ul.append($li);
		});
		setContextMenuPosition(event, $ul);
	}
	var renderContextMenu = function ($scope, event, options) {
		angular.element(event.currentTarget).addClass('context');
		$contextMenu = angular.element('<div>', {
			'class': 'dropdown clearfix context-dropdown open'
		});
		$contextMenu.on('click', function (e) {
			if (angular.element(e.target).hasClass('dropdown')) {
				_clearContextMenus(event);
			}
		});
		$contextMenu.on('contextmenu', function (event) {
			event.preventDefault();
			_clearContextMenus(event);
		});
		$contextMenu.on('keydown', function(event) {
			if (event.keyCode != 27 && event.keyCode != 9)
				return;
			event.preventDefault();
			_clearContextMenus(event);
		});
		$contextMenu.css({
			position: 'absolute',
			top: 0,
			height: angular.element("body").get(0).scrollHeight,
			left: 0,
			right: 0,
			zIndex: 9999
		});
		$document.find('body').append($contextMenu);
		$ul = angular.element('<ul>', {
			'class': 'dropdown-menu',
			'role': 'menu'
		});
		renderContextMenuItems($scope, event, options);
		$contextMenu.append($ul);
		$triggeringElement = document.activeElement;
		activateFocusTrap();
		$contextMenu.data('resizeHandler', function() {
			scrollHeight = angular.element("body").get(0).scrollHeight;
			$contextMenu.css('height', scrollHeight);
		});
		snCustomEvent.observe('partial.page.reload', $contextMenu.data('resizeHandler'));
	};
	function _clearContextMenus(event){
		if (!event)
			return;
		angular.element(event.currentTarget).removeClass('context');
		var els = angular.element(".context-dropdown");
		angular.forEach(els, function(el){
			snCustomEvent.un('partial.page.reload', angular.element(el).data('resizeHandler'));
			angular.element(el).remove();
		});
		deactivateFocusTrap();
	}
	function activateFocusTrap() {
		if (_focusTrap || !window.focusTrap)
			return;
		_focusTrap = focusTrap($contextMenu[0], {
			focusOutsideDeactivates: true,
			clickOutsideDeactivates: true
		});
		_focusTrap.activate();
	}
	function deactivateFocusTrap() {
		if (!_focusTrap || !window.focusTrap)
			return;
		_focusTrap.deactivate();
		_focusTrap = null;
	}
	return function (scope, element, attrs) {
		element.on('contextmenu', function (event) {
			if (event.ctrlKey)
				return;
			if (angular.element(element).attr('context-type'))
				return;
			showMenu(event);
		});
		element.on('click', handleClick);
		element.on('keydown', function(event) {
			if (event.keyCode == 32) {
				handleSpace(event);
			} else if (event.keyCode === 13) {
				handleClick(event);
			}
		});
		var doubleTapTimeout,
			doubleTapActive = false,
			doubleTapStartPosition;
		element.on('touchstart', function(event) {
			doubleTapStartPosition = {
				x: event.originalEvent.changedTouches[0].screenX,
				y: event.originalEvent.changedTouches[0].screenY
			};
		});
		element.on('touchend', function(event) {
			var distX = Math.abs(event.originalEvent.changedTouches[0].screenX - doubleTapStartPosition.x);
			var distY = Math.abs(event.originalEvent.changedTouches[0].screenY - doubleTapStartPosition.y);
			if (distX > 15 || distY > 15) {
				doubleTapStartPosition = null;
return;
			}
			if (doubleTapActive) {
				doubleTapActive = false;
				clearTimeout(doubleTapTimeout);
				showMenu(event);
				event.preventDefault();
				return;
			}
			doubleTapActive = true;
			event.preventDefault();
			doubleTapTimeout = setTimeout(function() {
				doubleTapActive = false;
				if (event.target)
					event.target.click();
			}, 300);
		});
		function handleSpace(evt) {
			var $target = angular.element(evt.target);
			if ($target.is('button, [role=button]')) {
				handleClick(evt);
				return;
			}
			if (!$target.hasClass('list-edit-cursor'))
				return;
			showMenu(evt);
		}
		function handleClick(event) {
			var $el = angular.element(element);
			var $target = angular.element(event.target);
			if (!$el.attr('context-type') && !$target.hasClass('context-menu-click'))
				return;
			showMenu(event);
		}
		function showMenu(evt) {
			scope.$apply(function () {
				applyMenu(evt);
				clearWindowSelection();
			});
		}
		function clearWindowSelection() {
			if (window.getSelection)
				if (window.getSelection().empty)
					window.getSelection().empty();
				else if (window.getSelection().removeAllRanges)
					window.getSelection().removeAllRanges();
				else if (document.selection)
					document.selection.empty();
		}
		function applyMenu(event) {
			var tagName = event.target.tagName;
			if (tagName == 'INPUT' || tagName == 'SELECT' || tagName == 'BUTTON') {
				return;
			}
			var menu = scope.$eval(attrs.contextMenu, { event: event });
			if (menu instanceof Array) {
				if (menu.length > 0) {
					event.stopPropagation();
					event.preventDefault();
					scope.$watch(function(){ return menu; }, function(newValue, oldValue){ if (newValue !== oldValue) renderContextMenuItems(scope, event, menu);}, true);
					renderContextMenu(scope, event, menu);
				}
			} else if (typeof menu !== 'undefined' && typeof menu.then === 'function' ) {
				event.stopPropagation();
				event.preventDefault();
				menu.then(function(response) {
					var contextMenu = response;
					if (contextMenu.length > 0) {
						scope.$watch(function() {
							return contextMenu;
						}, function(newValue, oldValue) {
							if (newValue !== oldValue)
								renderContextMenuItems(scope, event, contextMenu);
						}, true);
						renderContextMenu(scope, event, contextMenu);
					} else {
						throw '"' + attrs.contextMenu + '" is not an array or promise';
					}
				});
			} else {
				throw '"' + attrs.contextMenu + '" is not an array or promise';
			}
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/ui/directive.snDialog.js */
angular.module("sn.common.ui").directive("snDialog", function($timeout, $rootScope, $document) {
	"use strict";
	return {
		restrict: "AE",
		transclude: true,
		scope: {
			modal: "=?",
			disableAutoFocus: "=?",
			classCheck: "="
		},
		replace: true,
template: '<dialog ng-keydown="escape($event)"><div ng-click="onClickClose()" title="Close" class="close-button icon-button icon-cross" tabindex="-1"></div></dialog>',
		link: function(scope, element, attrs, ctrl, transcludeFn) {
			var transcludeScope = {};
			var _focusTrap = null;
			scope.isOpen = function() {
				return element[0].open;
			};
			transcludeFn(element.scope().$new(), function(a, b) {
element.prepend('<i class="sn-dialog-focus-trap-boundary" tabindex="0" ></i>');
				element.append(a);
element.append('<i class="sn-dialog-focus-trap-boundary" tabindex="0" ></i>');
				transcludeScope = b;
			});
			element.click(function(event) {
				event.stopPropagation();
				if (event.offsetX < 0 || event.offsetX > element[0].offsetWidth || event.offsetY < 0 || event.offsetY > element[0].offsetHeight)
					if (!scope.classCheck)
						scope.onClickClose();
					else {
						var classes = scope.classCheck.split(",");
						var found = false;
						for (var i = 0; i < classes.length; i++)
							if (angular.element(event.target).closest(classes[i]).length > 0)
								found = true;
						if (!found)
							scope.onClickClose();
					}
			});
			scope.show = function() {
				var d = element[0];
				if (!d.showModal || true) {
					dialogPolyfill.registerDialog(d);
					d.setDisableAutoFocus(scope.disableAutoFocus);
				}
				if (scope.modal)
					d.showModal();
				else
					d.show();
				if(!angular.element(d).hasClass('sn-alert')) {
					$timeout(function() {
						if (d.dialogPolyfillInfo && d.dialogPolyfillInfo.backdrop) {
							angular.element(d.dialogPolyfillInfo.backdrop).one('click', function(event) {
								if (!scope.classCheck || angular.element(event.srcElement).closest(scope.classCheck).length == 0)
									scope.onClickClose();
							})
						}
						else {
							$document.on('click', function(event) {
								if (!scope.classCheck || angular.element(event.srcElement).closest(scope.classCheck).length == 0)
									scope.onClickClose();
							})
						}
					});
				}
				element.find('.btn-primary').eq(0).focus();
			};
			scope.setPosition = function(data) {
				var contextData = scope.getContextData(data);
				if (contextData && element && element[0]) {
					if (contextData.position) {
						element[0].style.top = contextData.position.top + "px";
						element[0].style.left = contextData.position.left + "px";
						element[0].style.margin = "0px";
					}
					if (contextData.dimensions) {
						element[0].style.width = contextData.dimensions.width + "px";
						element[0].style.height = contextData.dimensions.height + "px";
					}
				}
			}
			scope.$on("dialog." + attrs.name + ".move", function(event, data) {
				scope.setPosition(data);
			})
			scope.$on("dialog." + attrs.name + ".show", function(event, data) {
				scope.setPosition(data);
				scope.setKeyEvents(data);
				if (scope.isOpen() === true)
					scope.close();
				else
					scope.show();
				angular.element(".sn-dialog-menu").each(function(index, value) {
					var name = angular.element(this).attr('name');
					if(name != attrs.name && !angular.element(this).attr('open')) {
						return true;
					}
					if(name != attrs.name  && angular.element(this).attr('open')) {
						$rootScope.$broadcast("dialog." + name + ".close");
					}
				});
				activateFocusTrap();
			})
			scope.onClickClose = function() {
				if (scope.isOpen())
					$rootScope.$broadcast("dialog." + attrs.name + ".close");
			}
			scope.escape = function($event) {
				if ($event.keyCode === 27) {
					scope.onClickClose();
				}
			};
			scope.close = function() {
				var d = element[0];
				d.close();
				scope.removeListeners();
				deactivateFocusTrap();
			}
			scope.ok = function(contextData) {
				contextData.ok();
				scope.removeListeners();
			}
			scope.cancel = function(contextData) {
				contextData.cancel();
				scope.removeListeners();
			}
			scope.removeListeners = function() {
				element[0].removeEventListener("ok", scope.handleContextOk, false);
				element[0].removeEventListener("cancel", scope.handleContextCancel, false);
			}
			scope.setKeyEvents = function(data) {
				var contextData = scope.getContextData(data);
				if (contextData && contextData.cancel) {
					scope.handleContextOk = function() {
						scope.ok(contextData);
					}
					scope.handleContextCancel = function() {
						scope.cancel(contextData);
					}
					element[0].addEventListener("ok", scope.handleContextOk, false);
					element[0].addEventListener("cancel", scope.handleContextCancel, false);
				}
			}
			scope.getContextData = function(data) {
				var context = attrs.context;
				var contextData = null;
				if (context && data && context in data) {
					contextData = data[context];
					transcludeScope[context] = contextData;
				}
				return contextData;
			}
			scope.$on("dialog." + attrs.name + ".close", scope.close);
			function focusTrap(element) {
				
				var getSentinelElements = function() {
					var boundarySelector = '.sn-dialog-focus-trap-boundary';
					var sentinelNodes = element.querySelectorAll(boundarySelector);
					return sentinelNodes;
				}
				var getTabbableElements = function (elm, selector) {
					var tabbables = window.tabbable ? window.tabbable(elm, selector) : [];
					return tabbables;
				};
			
				var focusElement = function (reverse) {
					return function (e) {
						var selectors =
							'iframe, input, select, a[href], textarea, button, [tabindex]:not(.sn-dialog-focus-trap-boundary), [contenteditable]:not([contenteditable="false"])';
						var tabbables = getTabbableElements(element, selectors);
						if (tabbables.length === 0) return;
						var newTarget = reverse
							? tabbables[tabbables.length - 1]
							: tabbables[0];
						if (newTarget.tagName == "IFRAME") {
							var frameElements = getTabbableElements(
								newTarget.contentDocument
							);
							if (frameElements.length > 0)
								newTarget = reverse
									? frameElements[frameElements.length - 1]
									: frameElements[0];
						}
						newTarget.focus();
					};
				};
				var sentinelElements = getSentinelElements();
				var topSentinelElement = sentinelElements[0];
				var bottomSentinelElement = sentinelElements[1];
				var nodeFocusedBeforeActivation = null;
				var forwardTrap = focusElement(true);
				var reverseTrap = focusElement(false);
				var activate = function () {
					nodeFocusedBeforeActivation = document.activeElement;
					topSentinelElement.addEventListener("focusin", forwardTrap);
					bottomSentinelElement.addEventListener("focusin", reverseTrap);
				};
			
				var deactivate = function () {
					if(nodeFocusedBeforeActivation)
						nodeFocusedBeforeActivation.focus();
						
					topSentinelElement.removeEventListener("focusin", forwardTrap);
					bottomSentinelElement.removeEventListener("focusin", reverseTrap);
				};
			
				return {
					activate: activate,
					deactivate: deactivate,
				};
			}
			
			function activateFocusTrap() {
				if (_focusTrap)
				    return;
				_focusTrap = focusTrap(element[0]);
				_focusTrap.activate();
			}
			function deactivateFocusTrap() {
				if (!_focusTrap)
				    return;
					
				_focusTrap.deactivate();
				_focusTrap = null;
			}
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/ui/directive.snFlyout.js */
angular.module('sn.common.ui').directive('snFlyout', function(getTemplateUrl) {
	'use strict';
	return {
		restrict: 'E',
		transclude: true,
		replace: 'true',
		templateUrl: getTemplateUrl('sn_flyout.xml'),
		scope: true,
		link: function($scope, element, attrs) {
			$scope.open = false;
			$scope.more = false;
			$scope.position = attrs.position || 'left';
			$scope.flyoutControl = attrs.control;
			$scope.register = attrs.register;
			var body = angular.element('.flyout-body', element);
			var header = angular.element('.flyout-header', element);
			var tabs = angular.element('.flyout-tabs', element);
			var distance = 0;
			var position = $scope.position;
var options = {duration: 800, easing: 'easeOutBounce'}
			var animation = {};
			if ($scope.flyoutControl) {
				$('.flyout-handle', element).hide();
				var controls = angular.element('#' + $scope.flyoutControl);
				controls.click(function() { angular.element(this).trigger("snFlyout.open"); });
				controls.on('snFlyout.open', function() {
					$scope.$apply(function() { $scope.open = !$scope.open; });
				});
			}
			var animate = function() {
				element.velocity(animation, options);
			}
			var setup = function() {
				animation[position] = -distance;
				if ($scope.open)
					element.css(position, 0);
				else
					element.css(position, -distance);
			}
			var calculatePosition = function() {
				if ($scope.open) {
					animation[position] = 0;
				} else {
					if ($scope.position === 'left' || $scope.position === 'right')
						animation[position] = -body.outerWidth();
					else
						animation[position] = -body.outerHeight();
				}
			}
			$scope.$watch('open', function(newValue, oldValue) {
				if(newValue === oldValue)
					return;
				calculatePosition();
				animate();
			});
			$scope.$watch('more', function(newValue, oldValue) {
				if (newValue === oldValue)
					return;
				var moreAnimation = {};
				if ($scope.more) {
					element.addClass('fly-double');
					moreAnimation = {width: body.outerWidth() * 2};
				}
				else {
					element.removeClass('fly-double');
moreAnimation = {width: body.outerWidth() / 2};
				}
				body.velocity(moreAnimation, options);
				header.velocity(moreAnimation, options);
			});
			if ($scope.position === 'left' || $scope.position === 'right') {
				$scope.$watch(element[0].offsetWidth, function() {
					element.addClass('fly-from-' + $scope.position);
					distance = body.outerWidth();
					setup();
				});
			} else if ($scope.position === 'top' || $scope.position === 'bottom') {
				$scope.$watch(element[0].offsetWidth, function() {
					element.addClass('fly-from-' + $scope.position);
					distance = body.outerHeight() + header.outerHeight();
					setup();
				});
			}
			$scope.$on($scope.register + ".bounceTabByIndex", function(event, index) {
				$scope.bounceTab(index);
			});
			$scope.$on($scope.register + ".bounceTab", function(event, tab) {
				$scope.bounceTab($scope.tabs.indexOf(tab));
			});
			$scope.$on($scope.register + ".selectTabByIndex", function(event, index) {
				$scope.selectTab($scope.tabs[index]);
			});
			$scope.$on($scope.register + ".selectTab", function(event, tab) {
				$scope.selectTab(tab);
			});
		},
		controller: function($scope, $element) {
			$scope.tabs = [];
			var baseColor, highLightColor;
			$scope.selectTab = function(tab) {
				if ($scope.selectedTab)
					$scope.selectedTab.selected = false;
				tab.selected = true;
				$scope.selectedTab = tab;
				normalizeTab($scope.tabs.indexOf(tab));
			}
			function expandTab(tabElem) {
				tabElem.queue("tabBounce", function(next) {
					tabElem.velocity({
						width: ["2.5rem", "2.125rem"],
						backgroundColorRed: [highLightColor[0], baseColor[0]],
						backgroundColorGreen: [highLightColor[1], baseColor[1]],
						backgroundColorBlue: [highLightColor[2], baseColor[2]]
					},{
						easing: "easeInExpo",
						duration: 250
					});
					next();
				});
			}
			function contractTab(tabElem) {
				tabElem.queue("tabBounce", function(next) {
					tabElem.velocity({
						width: ["2.125rem","2.5rem"],
						backgroundColorRed: [baseColor[0], highLightColor[0]],
						backgroundColorGreen: [baseColor[1], highLightColor[1]],
						backgroundColorBlue: [baseColor[2], highLightColor[2]]
					},{
						easing: "easeInExpo",
						duration: 250
					});
					next();
				});
			}
			$scope.bounceTab = function(index) {
				if(index >= $scope.tabs.length || index < 0)
					return;
				var tabScope = $scope.tabs[index];
				if(!tabScope.selected) {
					var tabElem =  $element.find('.flyout-tab').eq(index);
					if(!baseColor) {
baseColor = tabElem.css('backgroundColor').match(/[0-9]+/g);
						for( var i = 0; i < baseColor.length; i++)
							baseColor[i] = parseInt(baseColor[i], 10);
					}
					if(!highLightColor)
						highLightColor = invertColor(baseColor);
					if(tabScope.highlighted)
						contractTab(tabElem);
					for(var i = 0; i < 2; i++) {
						expandTab(tabElem);
						contractTab(tabElem);
					}
					expandTab(tabElem);
					tabElem.dequeue("tabBounce");
					tabScope.highlighted = true;
				}
			}
			$scope.toggleOpen = function() {
				$scope.open = !$scope.open;
			}
			this.addTab = function(tab) {
				$scope.tabs.push(tab);
				if($scope.tabs.length === 1)
					$scope.selectTab(tab)
			}
			function normalizeTab(index) {
				if(index < 0 || index >= $scope.tabs.length || !$scope.tabs[index].highlighted)
					return;
				var tabElem =  $element.find('.flyout-tab').eq(index);
				tabElem.velocity({
					width: ["2.125rem", "2.5rem"]
				},{
					easing: "easeInExpo",
					duration: 250
				});
				tabElem.css('backgroundColor', '');
				$scope.tabs[index].highlighted = false;
			}
			function invertColor(rgb) {
				if(typeof rgb === "string")
var color = rgb.match(/[0-9]+/g);
				else
					var color = rgb.slice(0);
				for(var i = 0; i < color.length; i++)
					color[i] = 255 - parseInt(color[i], 10);
				return color;
			}
		}
	}
}).directive("snFlyoutTab", function() {
	"use strict";
	return {
		restrict: "E",
		require: "^snFlyout",
		replace: true,
		scope: true,
		transclude: true,
template: "<div ng-show='selected' ng-transclude='' style='height: 100%'></div>",
		link: function(scope, element, attrs, flyoutCtrl) {
			flyoutCtrl.addTab(scope);
		}
	}
})
;
/*! RESOURCE: /scripts/sn/common/ui/directive.snModal.js */
angular.module("sn.common.ui").directive("snModal", function($timeout, $rootScope) {
	"use strict";
	return {
		restrict: "AE",
		transclude: true,
		scope: {},
		replace: true,
template: '<div tabindex="-1" aria-modal="true" aria-hidden="true" class="modal" role="dialog"></div>',
		link: function(scope, element, attrs, ctrl, transcludeFn) {
			var transcludeScope = {};
			transcludeFn(element.scope().$new(), function(a, b) {
				element.append(a);
element.append('<i class="focus-trap-boundary-south" tabindex="0"></i>');
				transcludeScope = b;
			});
			scope.$on("dialog." + attrs.name + ".show", function(event, data) {
				if (!isOpen())
					show(data);
			});
			scope.$on("dialog." + attrs.name + ".close", function() {
				if (isOpen())
					close();
			});
			function eventFn(eventName) {
				return function (e) {
					$rootScope.$broadcast("dialog." + attrs.name + "." + eventName, e);
				}
			}
			var events = {
				'shown.bs.modal'  : eventFn("opened"),
				'hide.bs.modal'   : eventFn("hide"),
				'hidden.bs.modal' : eventFn("closed")
			};
			function show(data) {
				var context = attrs.context;
				var contextData = null;
				if (context && data && context in data) {
					contextData = data[context];
					transcludeScope[context] = contextData;
				}
				$timeout(function() {
					angular.element('.sn-popover-basic').each(function () {
						var $this = angular.element(this);
						if (angular.element($this.attr('data-target')).is(':visible')) {
							$this.popover('hide');
						}
					});
				});
				element.modal('show');
element.attr('aria-hidden', 'false');
				for (var event in events)
					if(events.hasOwnProperty(event))
						element.on(event, events[event]);
				if (attrs.moveBackdrop == 'true')
					moveBackdrop(element);
			}
			function close() {
				element.modal('hide');
				element.attr('aria-hidden', 'true');
				for (var event in events)
					if(events.hasOwnProperty(event))
						element.off(event, events[event]);
			}
			function isOpen() {
				return element.hasClass('in');
			}
			function moveBackdrop(element) {
				var backdrop = element.data('bs.modal').$backdrop;
				if (!backdrop)
					return;
				element.after(backdrop.remove());
			}
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/ui/directive.snModalShow.js */
angular.module('sn.common.ui').directive('snModalShow', function() {
	"use strict";
	return {
		restrict: 'A',
		link: function(scope, element, attrs) {
			element.click(function() {
				showDialog();
			});
			function showDialog() {
				scope.$broadcast('dialog.' + attrs.snModalShow + '.show');
			}
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/ui/directive.snTabs.js */
angular.module('sn.common.ui').directive('snTabs', function() {
	'use strict';
	return {
		restrict: 'E',
		transclude: true,
		replace: 'true',
		scope: {
			tabData: '='
		},
		link: function($scope, element, attrs) {
			$scope.tabClass = attrs.tabClass;
			$scope.register = attrs.register;
			attrs.$observe('register', function(value) {
				$scope.register = value;
				$scope.setupListeners();
			});
			$scope.bounceTab = function() {
				angular.element()
			}
		},
		controller: 'snTabs'
	}
}).controller('snTabs', function($scope, $rootScope) {
	$scope.selectedTabIndex = 0;
	$scope.tabData[$scope.selectedTabIndex].selected = true;
	$scope.setupListeners = function() {
		$scope.$on($scope.register + '.selectTabByIndex', function(event, index) {
			$scope.selectTabByIndex(event, index);
		});
	}
	$scope.selectTabByIndex = function(event, index) {
		if (index === $scope.selectedTabIndex)
			return;
		if (event.stopPropagation)
			event.stopPropagation();
		$scope.tabData[$scope.selectedTabIndex].selected = false;
		$scope.tabData[index].selected = true;
		$scope.selectedTabIndex = index;
		$rootScope.$broadcast($scope.register + '.selectTabByIndex', $scope.selectedTabIndex);
	}
}).directive('snTab', function() {
	'use strict';
	return {
		restrict: 'E',
		transclude: true,
		replace: 'true',
		scope: {
			tabData: '=',
			index: '='
		},
		template: '',
		controller: 'snTab',
		link: function($scope, element, attrs) {
			$scope.register = attrs.register;
			attrs.$observe('register', function(value) {
				$scope.register = value;
				$scope.setupListeners();
			});
			$scope.bounceTab = function() {
				alert('Bounce Tab at Index: ' + $scope.index);
			}
		}
	}
}).controller('snTab', function($scope) {
	$scope.selectTabByIndex = function(index) {
		$scope.$emit($scope.register + '.selectTabByIndex', index);
	}
	$scope.setupListeners = function() {
		$scope.$on($scope.register + '.showTabActivity', function(event, index, type) {
			$scope.showTabActivity(index, type);
		});
	}
	$scope.showTabActivity = function(index, type) {
		if ($scope.index !== index)
			return;
		switch (type) {
			case 'message':
				break;
			case 'error':
				break;
			default:
				$scope.bounceTab();
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/ui/directive.snTextExpander.js */
angular.module('sn.common.ui').directive('snTextExpander', function(getTemplateUrl, $timeout) {
	'use strict';
	return {
		restrict: 'E',
		replace: true,
		templateUrl: getTemplateUrl('sn_text_expander.xml'),
		scope: {
			maxHeight: '&',
			value: '='
		},
		link: function compile(scope, element, attrs) {
			var container = angular.element(element).find('.textblock-content-container');
			var content = angular.element(element).find('.textblock-content');
			if (scope.maxHeight() === undefined) {
				scope.maxHeight = function () {
					return 100;
				}
			}
			container.css('overflow-y', 'hidden');
			container.css('max-height', scope.maxHeight() + 'px');
		},
		controller: function ($scope, $element) {
			var container = $element.find('.textblock-content-container');
			var content = $element.find('.textblock-content');
			$scope.value = $scope.value || '';
			$scope.toggleExpand = function () {
				$scope.showMore = !$scope.showMore;
				if ($scope.showMore) {
					container.css('max-height', content.height());
				} else {
					container.css('max-height', $scope.maxHeight());
				}
			};
			$timeout(function () {
				if (content.height() > $scope.maxHeight()) {
					$scope.showToggle = true;
					$scope.showMore = false;
				}
			});
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/ui/directive.snAttachmentPreview.js */
angular.module('sn.common.ui').directive('snAttachmentPreview', function(getTemplateUrl, snCustomEvent) {
	return {
		restrict: 'E',
		templateUrl: getTemplateUrl('sn_attachment_preview.xml'),
		controller: function($scope) {
			snCustomEvent.observe('sn.attachment.preview', function(evt, attachment) {
				if (evt.stopPropagation)
					evt.stopPropagation();
				if (evt.preventDefault)
					evt.preventDefault();
				$scope.image = attachment;
				$scope.$broadcast('dialog.attachment_preview.show');
return false;
			});
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/ui/service.progressDialog.js */
angular.module('sn.common.ui').factory('progressDialog', ['$rootScope', '$compile', '$timeout', '$http', '$templateCache', 'nowServer', 'i18n', function($rootScope, $compile, $timeout, $http, $templateCache, nowServer, i18n) {
	'use strict';
	i18n.getMessages(['Close']);
	return {
		STATES : ["Pending", "Running", "Succeeded", "Failed", "Cancelled" ],
STATUS_IMAGES : ["images/workflow_skipped.gif", "images/loading_anim2.gifx",
"images/progress_success.png", "images/progress_failure.png",
'images/request_cancelled.gif' ],
EXPAND_IMAGE : "images/icons/filter_hide.gif",
COLLAPSE_IMAGE : "images/icons/filter_reveal.gif",
BACK_IMAGE : "images/activity_filter_off.gif",
TIMEOUT_INTERVAL : 750,
		_findChildMessage: function( statusObject ) {
			if ( !statusObject.children ) return null;
			for ( var i = 0; i < statusObject.children.length; i++ ) {
				var child = statusObject.children[i];
				if ( child.state == '1' ) {
					var msg = child.message;
					var submsg = this._findChildMessage( child );
					if ( submsg == null )
						return msg;
					else
						return null;
				} else if ( child.state == '0' ) {
					return null;
				} else {
				}
			}
			return null;
		},
		create: function(scope, elemid, title, startCallback, endCallback, closeCallback) {
			var namespace = this;
			var progressItem = scope.$new(true);
			progressItem.id = elemid + "_progressDialog";
			progressItem.overlayVisible = true;
			progressItem.state = 0;
			progressItem.message = '';
			progressItem.percentComplete = 0;
			progressItem.enableChildMessages = false;
			if (!title) title = '';
			progressItem.title = title;
			progressItem.button_close = i18n.getMessage('Close');
			var overlayElement;
			overlayElement = $compile(
				'<div id="{{id}}" ng-show="overlayVisible" class="modal modal-mask" role="dialog" tabindex="-1">' +
					'<div class="modal-dialog m_progress_overlay_content">' +
						'<div class="modal-content">' +
							'<header class="modal-header">' +
'<h4 class="modal-title">{{title}}</h4>' +
'</header>' +
				        	'<div class="modal-body">' +
			        			'<div class="progress" ng-class="{\'progress-danger\': (state == 3)}">' +
			  						'<div class="progress-bar" ng-class="{\'progress-bar-danger\': (state == 3)}" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="{{percentComplete}}" ng-style="{width: percentComplete + \'%\'}">' +
'</div>' +
'</div>' +
'<div>{{message}}<span style="float: right;" ng-show="state==1 || state == 2">{{percentComplete}}%</span></div>' +
'</div>' +
							'<footer class="modal-footer">' +
'<button class="btn btn-default sn-button sn-button-normal" ng-click="close()" ng-show="state > 1">{{button_close}}</button>' +
'</footer>' +
'</div>' +
'</div>' +
'</div>')(progressItem);
			$("body")[0].appendChild(overlayElement[0]);
			progressItem.setEnableChildMessages = function( enableChildren ) {
				progressItem.enableChildMessages = enableChildren;
			}
			progressItem.start = function( src, dataArray ) {
				$http.post(src, dataArray).success(function(response) {
					progressItem.trackerId = response.sys_id;
					try { if ( startCallback ) startCallback(response); } catch(e) { }
					$timeout(progressItem.checkProgress.bind(progressItem));
				})
				.error(function(response, status, headers, config) {
					progressItem.state = '3';
					if (endCallback) endCallback( response );
				});
			};
			progressItem.checkProgress = function() {
				var src = nowServer.getURL('progress_status', {sysparm_execution_id: this.trackerId});
				$http.post(src).success(function(response) {
					if ( $.isEmptyObject(response) ) {
						progressItem.state = '3';
						if (endCallback) endCallback( response );
						return;
					}
					progressItem.update( response );
					if (response.status == 'error' || response.state == '') {
						progressItem.state = '3';
						if ( response.message )
							progressItem.message = response.message;
						else
							progressItem.message = response;
						if (endCallback) endCallback( response );
						return;
					}
					if ( response.state == '0' || response.state == '1' ) {
						$timeout(progressItem.checkProgress.bind(progressItem), namespace.TIMEOUT_INTERVAL);
					} else {
						if (endCallback) endCallback( response );
					}
				})
				.error(function(response, status, headers, config) {
					progressItem.state = '3';
					progressItem.message = response;
					if (endCallback) endCallback( response );
				});
			};
			progressItem.update = function( statusObject ) {
				var msg = statusObject.message;
				if ( progressItem.enableChildMessages ) {
					var childMsg = namespace._findChildMessage( statusObject );
					if ( childMsg != null )
						msg = childMsg;
				}
				this.message = msg;
				this.state = statusObject.state;
				this.percentComplete = statusObject.percent_complete;
			};
			progressItem.close = function(ev) {
				try { if (closeCallback) closeCallback(); } catch(e) { }
				$("body")[0].removeChild($("#" + this.id)[0]);
				delete namespace.progressItem;
			};
			return progressItem;
		}
	}
}]);
;
/*! RESOURCE: /scripts/sn/common/ui/factory.paneManager.js */
angular.module("sn.common.ui").factory("paneManager", ['$timeout', 'userPreferences', 'snCustomEvent', function($timeout, userPreferences, snCustomEvent) {
	"use strict";
	var paneIndex = {};
	function registerPane(paneName) {
		if (!paneName in paneIndex) {
			paneIndex[paneName] = false;
		}
		userPreferences.getPreference(paneName + '.opened').then(function(value) {
			var isOpen = value !== 'false';
			if (isOpen) {
				togglePane(paneName, false);
			}
		});
	}
	function togglePane(paneName, autoFocusPane) {
		for (var currentPane in paneIndex) {
			if (paneName != currentPane && paneIndex[currentPane]) {
				CustomEvent.fireTop(currentPane + '.toggle');
				saveState(currentPane, false);
			}
		}
		snCustomEvent.fireTop(paneName + '.toggle', false, autoFocusPane);
		saveState(paneName, !paneIndex[paneName]);
	};
	function saveState(paneName, state) {
		paneIndex[paneName] = state;
		userPreferences.setPreference(paneName + '.opened', state);
	}
	return {
		registerPane : registerPane,
		togglePane : togglePane
	};
}]);
;
/*! RESOURCE: /scripts/sn/common/ui/directive.snBootstrapPopover.js */
angular.module('sn.common.ui').directive('snBootstrapPopover', function ($timeout, $compile, $rootScope) {
	'use strict';
	return {
		restrict: 'A',
		link: function (scope, element) {
			element.on('click.snBootstrapPopover', function (event) {
				$rootScope.$broadcast('sn-bootstrap-popover.close-other-popovers');
				createPopover(event);
			});
			element.on('keypress.snBootstrapPopover', function (event) {
if (event.keyCode != 13 && event.keyCode != 32)
					return;
if (event.keyCode ===  32 ) {
					event.preventDefault();
				}
				scope.$broadcast('sn-bootstrap-popover.close-other-popovers');
				createPopover(event);
			});
			var popoverOpen = false;
			function _hidePopover() {
				popoverOpen = false;
				var api = element.data('bs.popover');
				if (api) {
					api.hide();
					element.off('.popover').removeData('bs.popover');
					element.data('bs.popover', void(0));
					element.focus();
				}
			}
			function _openPopover() {
				$timeout(function () {
					popoverOpen = true;
					element.on('hidden.bs.popover', function () {
						_hidePopover();
						popoverOpen = false;
					});
					element.popover('show');
					var popoverBody = angular.element(document.getElementById('sn-bootstrap-popover'));
					popoverBody.focus();
					popoverBody.on('keydown', function (e) {
						if (e.keyCode === 27) {
							popoverBody.off('keydown');
							_hidePopover();
						}
					});
				}, 0, false);
			}
			function createPopover (evt) {
				angular.element('.popover').each(function () {
					var object = angular.element(this);
					if (!object.is(evt.target) && object.has(evt.target).length === 0 && angular.element('.popover').has(evt.target).length === 0) {
						_hidePopover();
						object.popover('hide');
					}
				});
				if (scope.disablePopover || evt.keyCode === 9)
					return;
				if (popoverOpen) {
					_hidePopover();
					return;
				}
				var childScope = scope.$new();
				evt.stopPropagation();
				element.attr('data-toggle', 'popover');
				element.attr('data-trigger','focus');
				element.attr('tabindex',0);
				
				angular.element(element).popover({
					container: 'body',
					placement: 'auto top',
					html: true,
					trigger: 'manual',
					content: $compile(scope.template)(childScope)
				});
				var wait = element.attr('popover-wait-event');
				if (wait)
					scope.$on(wait, _openPopover);
				else
					_openPopover();
				var bodyClickEvent = angular.element('body').on('click.snBootstrapPopover.body', function (evt) {
					angular.element('.popover').each(function () {
						var object = angular.element(this);
						if (!object.is(evt.target) && object.has(evt.target).length === 0 && angular.element('.popover').has(evt.target).length === 0) {
							bodyClickEvent.off();
							_hidePopover();
							childScope.$destroy();
						}
					})
				});
				element.on('$destroy', function () {
					bodyClickEvent.off();
					_hidePopover();
					childScope.$destroy();
				})
			};
		}
	}
});
;
/*! RESOURCE: /scripts/sn/common/ui/directive.snFocusEsc.js */
angular.module('sn.common.ui').directive('snFocusEsc', function($document) {
	'use strict';
	return {
		restrict: 'A',
		scope: false,
		link: function (scope, element, attrs) {
			$document.on('keyup', function($event) {
if ($event.keyCode === 27 ) {
					var focusedElement = $event.target;
					if (focusedElement && element[0].contains(focusedElement)) {
						scope.$eval(attrs.snFocusEsc);
					}
				}
			});
		}
	};
});
;
;
/*! RESOURCE: /scripts/sn/common/ui/js_includes_ui.js */
/*! RESOURCE: /scripts/thirdparty/ment.io/mentio.js */
(function() {
    'use strict';
    angular.module('mentio', [])
        .directive('mentio', ['mentioUtil', '$document', '$compile', '$log', '$timeout',
            function (mentioUtil, $document, $compile, $log, $timeout) {
            return {
                restrict: 'A',
                scope: {
                    macros: '=mentioMacros',
                    search: '&mentioSearch',
                    select: '&mentioSelect',
                    items: '=mentioItems',
                    typedTerm: '=mentioTypedTerm',
                    altId: '=mentioId',
                    iframeElement: '=mentioIframeElement',
                    requireLeadingSpace: '=mentioRequireLeadingSpace',
                    suppressTrailingSpace: '=mentioSuppressTrailingSpace',
                    selectNotFound: '=mentioSelectNotFound',
                    trimTerm: '=mentioTrimTerm',
                    ngModel: '='
                },
                controller: ["$scope", "$timeout", "$attrs", function($scope, $timeout, $attrs) {
                    $scope.query = function (triggerChar, triggerText) {
                        var remoteScope = $scope.triggerCharMap[triggerChar];
                        if ($scope.trimTerm === undefined || $scope.trimTerm) {
                            triggerText = triggerText.trim();
                        }
                        remoteScope.showMenu();
                        remoteScope.search({
                            term: triggerText
                        });
                        remoteScope.typedTerm = triggerText;
                    };
                    $scope.defaultSearch = function(locals) {
                        var results = [];
                        angular.forEach($scope.items, function(item) {
                            if (item.label.toUpperCase().indexOf(locals.term.toUpperCase()) >= 0) {
                                results.push(item);
                            }
                        });
                        $scope.localItems = results;
                    };
                    $scope.bridgeSearch = function(termString) {
                        var searchFn = $attrs.mentioSearch ? $scope.search : $scope.defaultSearch;
                        searchFn({
                            term: termString
                        });
                    };
                    $scope.defaultSelect = function(locals) {
                        return $scope.defaultTriggerChar + locals.item.label;
                    };
                    $scope.bridgeSelect = function(itemVar) {
                        var selectFn = $attrs.mentioSelect ? $scope.select : $scope.defaultSelect;
                        return selectFn({
                            item: itemVar
                        });
                    };
                    $scope.setTriggerText = function(text) {
                        if ($scope.syncTriggerText) {
                            $scope.typedTerm = ($scope.trimTerm === undefined || $scope.trimTerm) ? text.trim() : text;
                        }
                    };
                    $scope.context = function() {
                        if ($scope.iframeElement) {
                            return {iframe: $scope.iframeElement};
                        }
                    };
                    $scope.replaceText = function (text, hasTrailingSpace) {
                        $scope.hideAll();
                        mentioUtil.replaceTriggerText($scope.context(), $scope.targetElement, $scope.targetElementPath,
                            $scope.targetElementSelectedOffset, $scope.triggerCharSet, text, $scope.requireLeadingSpace,
                            hasTrailingSpace, $scope.suppressTrailingSpace);
                        if (!hasTrailingSpace) {
                            $scope.setTriggerText('');
                            angular.element($scope.targetElement).triggerHandler('change');
                            if ($scope.isContentEditable()) {
                                $scope.contentEditableMenuPasted = true;
                                var timer = $timeout(function() {
                                    $scope.contentEditableMenuPasted = false;
                                }, 200);
                                $scope.$on('$destroy', function() {
                                    $timeout.cancel(timer);
                                });
                            }
                        }
                    };
                    $scope.hideAll = function () {
                        for (var key in $scope.triggerCharMap) {
                            if ($scope.triggerCharMap.hasOwnProperty(key)) {
                                $scope.triggerCharMap[key].hideMenu();
                            }
                        }
                    };
                    $scope.getActiveMenuScope = function () {
                        for (var key in $scope.triggerCharMap) {
                            if ($scope.triggerCharMap.hasOwnProperty(key)) {
                                if ($scope.triggerCharMap[key].visible) {
                                    return $scope.triggerCharMap[key];
                                }
                            }
                        }
                        return null;
                    };
                    $scope.selectActive = function () {
                        for (var key in $scope.triggerCharMap) {
                            if ($scope.triggerCharMap.hasOwnProperty(key)) {
                                if ($scope.triggerCharMap[key].visible) {
                                    $scope.triggerCharMap[key].selectActive();
                                }
                            }
                        }
                    };
                    $scope.isActive = function () {
                        for (var key in $scope.triggerCharMap) {
                            if ($scope.triggerCharMap.hasOwnProperty(key)) {
                                if ($scope.triggerCharMap[key].visible) {
                                    return true;
                                }
                            }
                        }
                        return false;
                    };
                    $scope.isContentEditable = function() {
                        return ($scope.targetElement.nodeName !== 'INPUT' && $scope.targetElement.nodeName !== 'TEXTAREA');
                    };
                    $scope.replaceMacro = function(macro, hasTrailingSpace) {
                        if (!hasTrailingSpace) {
                            $scope.replacingMacro = true;
                            $scope.timer = $timeout(function() {
                                mentioUtil.replaceMacroText($scope.context(), $scope.targetElement,
                                    $scope.targetElementPath, $scope.targetElementSelectedOffset,
                                    $scope.macros, $scope.macros[macro]);
                                angular.element($scope.targetElement).triggerHandler('change');
                                $scope.replacingMacro = false;
                            }, 300);
                            $scope.$on('$destroy', function() {
                                $timeout.cancel($scope.timer);
                            });
                        } else {
                            mentioUtil.replaceMacroText($scope.context(), $scope.targetElement, $scope.targetElementPath,
                                $scope.targetElementSelectedOffset, $scope.macros, $scope.macros[macro]);
                        }
                    };
                    $scope.addMenu = function(menuScope) {
                        if (menuScope.parentScope && $scope.triggerCharMap.hasOwnProperty(menuScope.triggerChar)) {
                            return;
                        }
                        $scope.triggerCharMap[menuScope.triggerChar] = menuScope;
                        if ($scope.triggerCharSet === undefined) {
                            $scope.triggerCharSet = [];
                        }
                        $scope.triggerCharSet.push(menuScope.triggerChar);
                        menuScope.setParent($scope);
                    };
                    $scope.$on(
                        'menuCreated', function (event, data) {
                            if (
                                $attrs.id !== undefined ||
                                $attrs.mentioId !== undefined
                            )
                            {
                                if (
                                    $attrs.id === data.targetElement ||
                                    (
                                        $attrs.mentioId !== undefined &&
                                        $scope.altId === data.targetElement
                                    )
                                )
                                {
                                    $scope.addMenu(data.scope);
                                }
                            }
                        }
                    );
                    $document.on(
                        'click', function () {
                            if ($scope.isActive()) {
                                $scope.$apply(function () {
                                    $scope.hideAll();
                                });
                            }
                        }
                    );
                    $document.on(
                        'keydown keypress paste', function (event) {
                            var activeMenuScope = $scope.getActiveMenuScope();
                            if (activeMenuScope) {
                                if (event.key === 'Tab' || event.key === 'Enter') {
                                    event.preventDefault();
                                    activeMenuScope.selectActive();
                                }
                                if (event.key === 'Escape') {
                                    event.preventDefault();
                                    activeMenuScope.$apply(function () {
                                        activeMenuScope.hideMenu();
                                    });
                                }
                                if (event.key === 'ArrowDown') {
                                    event.preventDefault();
                                    activeMenuScope.$apply(function () {
                                        activeMenuScope.activateNextItem();
                                    });
                                    activeMenuScope.adjustScroll(1);
                                }
                                if (event.key === 'ArrowUp') {
                                    event.preventDefault();
                                    activeMenuScope.$apply(function () {
                                        activeMenuScope.activatePreviousItem();
                                    });
                                    activeMenuScope.adjustScroll(-1);
                                }
                                if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
                                    event.preventDefault();
                                 }
                            }
                        }
                    );
                }],
                link: function (scope, element, attrs, $timeout) {
                    element.off('compositionstart').off('compositionend');
                    scope.triggerCharMap = {};
                    scope.targetElement = element;
					scope.scrollBarParents = element.parents().filter(function() {
						var overflow = angular.element(this).css("overflow");
						return this.scrollHeight > this.clientHeight && overflow !== "hidden" && overflow !== "visible";
					});
					scope.scrollPosition = null;
                    attrs.$set('autocomplete','off');
                    if (attrs.mentioItems) {
                        scope.localItems = [];
                        scope.parentScope = scope;
                        var itemsRef = attrs.mentioSearch ? ' mentio-items="items"' : ' mentio-items="localItems"';
                        scope.defaultTriggerChar = attrs.mentioTriggerChar ? scope.$eval(attrs.mentioTriggerChar) : '@';
                        var html = '<mentio-menu' +
                            ' mentio-search="bridgeSearch(term)"' +
                            ' mentio-select="bridgeSelect(item)"' +
                            itemsRef;
                        if (attrs.mentioTemplateUrl) {
                            html = html + ' mentio-template-url="' + attrs.mentioTemplateUrl + '"';
                        }
                        html = html + ' mentio-trigger-char="\'' + scope.defaultTriggerChar + '\'"' +
                            ' mentio-parent-scope="parentScope"' +
'/>';
                        var linkFn = $compile(html);
                        var el = linkFn(scope);
                        element.parent().append(el);
                        scope.$on('$destroy', function() {
                          el.remove();
                        });
                    }
                    if (attrs.mentioTypedTerm) {
                        scope.syncTriggerText = true;
                    }
                    function keyHandler(event) {
                        function stopEvent(event) {
                            event.preventDefault();
                            event.stopPropagation();
                            event.stopImmediatePropagation();
                        }
                        var activeMenuScope = scope.getActiveMenuScope();
                        if (activeMenuScope) {
                            if (event.which === 9 || event.which === 13) {
                                stopEvent(event);
                                activeMenuScope.selectActive();
                                return false;
                            }
                            if (event.which === 27) {
                                stopEvent(event);
                                activeMenuScope.$apply(function () {
                                    activeMenuScope.hideMenu();
                                });
                                return false;
                            }
                            if (event.which === 40) {
                                stopEvent(event);
                                activeMenuScope.$apply(function () {
                                    activeMenuScope.activateNextItem();
                                });
                                activeMenuScope.adjustScroll(1);
                                return false;
                            }
                            if (event.which === 38) {
                                stopEvent(event);
                                activeMenuScope.$apply(function () {
                                    activeMenuScope.activatePreviousItem();
                                });
                                activeMenuScope.adjustScroll(-1);
                                return false;
                            }
                            if (event.which === 37 || event.which === 39) {
                                stopEvent(event);
                                return false;
                            }
                        }
                    }
                    scope.$watch(
                        'iframeElement', function(newValue) {
                            if (newValue) {
                                var iframeDocument = newValue.contentWindow.document;
                                iframeDocument.addEventListener('click',
                                    function () {
                                        if (scope.isActive()) {
                                            scope.$apply(function () {
                                                scope.hideAll();
                                            });
                                        }
                                    }
                                );
iframeDocument.addEventListener('keydown', keyHandler, true );
                                scope.$on ( '$destroy', function() {
                                    iframeDocument.removeEventListener ( 'keydown', keyHandler );
                                });
                            }
                        }
                    );
                    scope.$watch(
                        'ngModel',
                        function (newValue) {
                            if ((!newValue || newValue === '') && !scope.isActive()) {
                                return;
                            }
                            if (scope.triggerCharSet === undefined) {
                                $log.warn('Error, no mentio-items attribute was provided, ' +
                                    'and no separate mentio-menus were specified.  Nothing to do.');
                                return;
                            }
                            if (scope.contentEditableMenuPasted) {
                                scope.contentEditableMenuPasted = false;
                                return;
                            }
                            if (scope.replacingMacro) {
                                $timeout.cancel(scope.timer);
                                scope.replacingMacro = false;
                            }
                            var isActive = scope.isActive();
                            var isContentEditable = scope.isContentEditable();
                            var mentionInfo = mentioUtil.getTriggerInfo(scope.context(), scope.triggerCharSet,
                                scope.requireLeadingSpace, isActive);
                            if (mentionInfo !== undefined &&
                                    (
                                        !isActive ||
                                        (isActive &&
                                            (
                                                (isContentEditable && mentionInfo.mentionTriggerChar ===
                                                    scope.currentMentionTriggerChar) ||
                                                (!isContentEditable && mentionInfo.mentionPosition ===
                                                    scope.currentMentionPosition)
                                            )
                                        )
                                    )
                                )
                            {
                                if (mentionInfo.mentionSelectedElement) {
                                    scope.targetElement = mentionInfo.mentionSelectedElement;
                                    scope.targetElementPath = mentionInfo.mentionSelectedPath;
                                    scope.targetElementSelectedOffset = mentionInfo.mentionSelectedOffset;
                                }
                                scope.setTriggerText(mentionInfo.mentionText);
                                scope.currentMentionPosition = mentionInfo.mentionPosition;
                                scope.currentMentionTriggerChar = mentionInfo.mentionTriggerChar;
                                scope.query(mentionInfo.mentionTriggerChar, mentionInfo.mentionText);
                            } else {
                                var currentTypedTerm = scope.typedTerm;
                                scope.setTriggerText('');
                                scope.hideAll();
                                var macroMatchInfo = mentioUtil.getMacroMatch(scope.context(), scope.macros);
                                if (macroMatchInfo !== undefined) {
                                    scope.targetElement = macroMatchInfo.macroSelectedElement;
                                    scope.targetElementPath = macroMatchInfo.macroSelectedPath;
                                    scope.targetElementSelectedOffset = macroMatchInfo.macroSelectedOffset;
                                    scope.replaceMacro(macroMatchInfo.macroText, macroMatchInfo.macroHasTrailingSpace);
                                } else if (scope.selectNotFound && currentTypedTerm && currentTypedTerm !== '') {
                                    var lastScope = scope.triggerCharMap[scope.currentMentionTriggerChar];
                                    if (lastScope) {
                                        var text = lastScope.select({
                                            item: {label: currentTypedTerm}
                                        });
                                        if (typeof text.then === 'function') {
                                            text.then(scope.replaceText);
                                        } else {
                                            scope.replaceText(text, true);
                                        }
                                    }
                                }
                            }
                        }
                    );
                }
            };
        }])
        .directive('mentioMenu', ['mentioUtil', '$rootScope', '$log', '$window', '$document', '$timeout',
            function (mentioUtil, $rootScope, $log, $window, $document, $timeout) {
            return {
                restrict: 'E',
                scope: {
                    search: '&mentioSearch',
                    select: '&mentioSelect',
                    items: '=mentioItems',
                    triggerChar: '=mentioTriggerChar',
                    forElem: '=mentioFor',
                    parentScope: '=mentioParentScope'
                },
                templateUrl: function(tElement, tAttrs) {
                    return tAttrs.mentioTemplateUrl !== undefined ? tAttrs.mentioTemplateUrl : 'mentio-menu.tpl.html';
                },
                controller: ["$scope", function ($scope) {
                    $scope.visible = false;
                    this.activate = $scope.activate = function (item) {
                        $scope.activeItem = item;
                    };
                    this.isActive = $scope.isActive = function (item) {
                        return $scope.activeItem === item;
                    };
                    this.selectItem = $scope.selectItem = function (item) {
                        if (item.termLengthIsZero) {
                            item.name = $scope.triggerChar + $scope.typedTerm
                        }
                        var text = $scope.select({
                            item: item
                        });
                        if (typeof text.then === 'function') {
                            text.then($scope.parentMentio.replaceText);
                        } else {
                            $scope.parentMentio.replaceText(text);
                        }
                    };
                    $scope.activateNextItem = function () {
                        var index = $scope.items.indexOf($scope.activeItem);
                        this.activate($scope.items[(index + 1) % $scope.items.length]);
                    };
                    $scope.activatePreviousItem = function () {
                        var index = $scope.items.indexOf($scope.activeItem);
                        this.activate($scope.items[index === 0 ? $scope.items.length - 1 : index - 1]);
                    };
                    $scope.isFirstItemActive = function () {
                        var index = $scope.items.indexOf($scope.activeItem);
                        return index === 0;
                    };
                    $scope.isLastItemActive = function () {
                        var index = $scope.items.indexOf($scope.activeItem);
                        return index === ($scope.items.length - 1);
                    };
                    $scope.selectActive = function () {
                        $scope.selectItem($scope.activeItem);
                    };
                    $scope.isVisible = function () {
                        return $scope.visible;
                    };
                    $scope.showMenu = function () {
                        if (!$scope.visible) {
							$scope.menuElement.css("visibility", "visible");
                            $scope.requestVisiblePendingSearch = true;
                        }
                    };
                    $scope.setParent = function (scope) {
                        $scope.parentMentio = scope;
                        $scope.targetElement = scope.targetElement;
                    };
					var scopeDuplicate = $scope;
					$rootScope.$on('mentio.closeMenu', function () {
						scopeDuplicate.hideMenu();
					})
                }],
                link: function (scope, element) {
                    element[0].parentNode.removeChild(element[0]);
                    $document[0].body.appendChild(element[0]);
scope.menuElement = element;
					scope.menuElement.css("visibility", "hidden");
                    if (scope.parentScope) {
                        scope.parentScope.addMenu(scope);
                    } else {
                        if (!scope.forElem) {
                            $log.error('mentio-menu requires a target element in tbe mentio-for attribute');
                            return;
                        }
                        if (!scope.triggerChar) {
                            $log.error('mentio-menu requires a trigger char');
                            return;
                        }
                        $rootScope.$broadcast('menuCreated',
                            {
                                targetElement : scope.forElem,
                                scope : scope
                            });
                    }
                    angular.element($window).bind(
                        'resize', function () {
                            if (scope.isVisible()) {
                                var triggerCharSet = [];
                                triggerCharSet.push(scope.triggerChar);
                                mentioUtil.popUnderMention(scope.parentMentio.context(),
                                    triggerCharSet, element, scope.requireLeadingSpace);
                            }
                        }
                    );
                    scope.$watch('items', function (items) {
                        if (items && items.length > 0) {
                            scope.activate(items[0]);
                            if (!scope.visible && scope.requestVisiblePendingSearch) {
                                scope.visible = true;
                                scope.requestVisiblePendingSearch = false;
                            }
                            $timeout(function() {
                                var menu = element.find(".dropdown-menu");
                                if(menu.length > 0 && menu.offset().top < 0)
                                    menu.addClass("reverse");
                            }, 0, false);
                        } else {
                            scope.activate({
                                termLengthIsZero: true
                            });
                        }
                    });
                    scope.$watch('isVisible()', function (visible) {
                        if (visible) {
                            var triggerCharSet = [];
                            triggerCharSet.push(scope.triggerChar);
                            mentioUtil.popUnderMention(scope.parentMentio.context(),
                                triggerCharSet, element, scope.requireLeadingSpace);
						} else {
                            element.find(".dropdown-menu").removeClass("reverse");
                        }
                    });
					var prevScroll;
					scope.parentMentio.scrollBarParents.each(function() {
						angular.element(this).on("scroll.mentio", function() {
							if (!prevScroll)
								prevScroll = this.scrollTop;
							var scrollDiff = prevScroll - this.scrollTop;
							prevScroll = this.scrollTop;
							if (element[0].style["position"] === "absolute") {
element[0].style["z-index"] = 9;
								element[0].style.top = (parseInt(element[0].style.top) + scrollDiff) + "px";
							}
						});
					});
                    scope.parentMentio.$on('$destroy', function () {
                        element.remove();
                    });
                    scope.hideMenu = function () {
                        scope.visible = false;
                        element.css('display', 'none');
                    };
                    scope.adjustScroll = function (direction) {
                        var menuEl = element[0];
                        var menuItemsList = menuEl.querySelector('ul');
                        var menuItem = menuEl.querySelector('[mentio-menu-item].active');
                        if (scope.isFirstItemActive()) {
                            return menuItemsList.scrollTop = 0;
                        } else if(scope.isLastItemActive()) {
                            return menuItemsList.scrollTop = menuItemsList.scrollHeight;
                        }
                        if (direction === 1) {
                            menuItemsList.scrollTop += menuItem.offsetHeight;
                        } else {
                            menuItemsList.scrollTop -= menuItem.offsetHeight;
                        }
                    };
                }
            };
        }])
        .directive('mentioMenuItem', function () {
            return {
                restrict: 'A',
                scope: {
                    item: '=mentioMenuItem'
                },
                require: '^mentioMenu',
                link: function (scope, element, attrs, controller) {
                    scope.$watch(function () {
                        return controller.isActive(scope.item);
                    }, function (active) {
                        if (active) {
                            element.addClass('active');
                        } else {
                            element.removeClass('active');
                        }
                    });
                    element.bind('mouseenter', function () {
                        scope.$apply(function () {
                            controller.activate(scope.item);
                        });
                    });
                    element.bind('click', function () {
                        controller.selectItem(scope.item);
                        return false;
                    });
                }
            };
        })
        .filter('unsafe', ["$sce", function($sce) {
            return function (val) {
                return $sce.trustAsHtml(val);
            };
        }])
        .filter('mentioHighlight', function() {
            function escapeRegexp (queryToEscape) {
return queryToEscape.replace(/([.?*+^$[\]\\(){}|-])/g, '\\$1');
            }
            return function (matchItem, query, hightlightClass) {
                if (query) {
                    var replaceText = hightlightClass ?
'<span class="' + hightlightClass + '">$&</span>' :
'<strong>$&</strong>';
                    return ('' + matchItem).replace(new RegExp(escapeRegexp(query), 'gi'), replaceText);
                } else {
                    return matchItem;
                }
            };
        });
    'use strict';
    angular.module('mentio')
        .factory('mentioUtil', ["$window", "$location", "$anchorScroll", "$timeout", function ($window, $location, $anchorScroll, $timeout) {
            function popUnderMention (ctx, triggerCharSet, selectionEl, requireLeadingSpace) {
                var coordinates;
                var mentionInfo = getTriggerInfo(ctx, triggerCharSet, requireLeadingSpace, false);
                if (mentionInfo !== undefined) {
                    if (selectedElementIsTextAreaOrInput(ctx)) {
                        coordinates = getTextAreaOrInputUnderlinePosition(ctx, getDocument(ctx).activeElement,
                            mentionInfo.mentionPosition);
                    } else {
                        coordinates = getContentEditableCaretPosition(ctx, mentionInfo.mentionPosition);
                    }
                    selectionEl.css({
                        top: coordinates.top + 'px',
                        left: coordinates.left + 'px',
                        position: 'absolute',
                        zIndex: 5000,
                        display: 'block'
                    });
                    $timeout(function(){
                        scrollIntoView(ctx, selectionEl);
                    },0);
                } else {
                    selectionEl.css({
                        display: 'none'
                    });
                }
            }
            function scrollIntoView(ctx, elem)
            {
                var reasonableBuffer = 20;
                var maxScrollDisplacement = 100;
                var clientRect;
                var e = elem[0];
                while (clientRect === undefined || clientRect.height === 0) {
                    clientRect = e.getBoundingClientRect();
                    if (clientRect.height === 0) {
                        e = e.childNodes[0];
                        if (e === undefined || !e.getBoundingClientRect) {
                            return;
                        }
                    }
                }
                var elemTop = clientRect.top;
                var elemBottom = elemTop + clientRect.height;
                if(elemTop < 0) {
                    $window.scrollTo(0, $window.pageYOffset + clientRect.top - reasonableBuffer);
                } else if (elemBottom > $window.innerHeight) {
                    var maxY = $window.pageYOffset + clientRect.top - reasonableBuffer;
                    if (maxY - $window.pageYOffset > maxScrollDisplacement) {
                        maxY = $window.pageYOffset + maxScrollDisplacement;
                    }
                    var targetY = $window.pageYOffset - ($window.innerHeight - elemBottom);
                    if (targetY > maxY) {
                        targetY = maxY;
                    }
                    $window.scrollTo(0, targetY);
                }
            }
            function selectedElementIsTextAreaOrInput (ctx) {
                var element = getDocument(ctx).activeElement;
                if (element !== null) {
                    var nodeName = element.nodeName;
                    var type = element.getAttribute('type');
                    return (nodeName === 'INPUT' && type === 'text') || nodeName === 'TEXTAREA';
                }
                return false;
            }
            function selectElement (ctx, targetElement, path, offset) {
                var range;
                var elem = targetElement;
                if (path) {
                    for (var i = 0; i < path.length; i++) {
                        elem = elem.childNodes[path[i]];
                        if (elem === undefined) {
                            return;
                        }
                        while (elem.length < offset) {
                            offset -= elem.length;
                            elem = elem.nextSibling;
                        }
                        if (elem.childNodes.length === 0 && !elem.length) {
                            elem = elem.previousSibling;
                        }
                    }
                }
                var sel = getWindowSelection(ctx);
                range = getDocument(ctx).createRange();
                range.setStart(elem, offset);
                range.setEnd(elem, offset);
                range.collapse(true);
                try{sel.removeAllRanges();}catch(error){}
                sel.addRange(range);
                targetElement.focus();
            }
            function pasteHtml (ctx, html, startPos, endPos) {
                var range, sel;
                sel = getWindowSelection(ctx);
                range = getDocument(ctx).createRange();
                range.setStart(sel.anchorNode, startPos);
                range.setEnd(sel.anchorNode, endPos);
                range.deleteContents();
                var el = getDocument(ctx).createElement('div');
                el.innerHTML = html;
                var frag = getDocument(ctx).createDocumentFragment(),
                    node, lastNode;
                while ((node = el.firstChild)) {
                    lastNode = frag.appendChild(node);
                }
                range.insertNode(frag);
                if (lastNode) {
                    range = range.cloneRange();
                    range.setStartAfter(lastNode);
                    range.collapse(true);
                    sel.removeAllRanges();
                    sel.addRange(range);
                }
            }
            function resetSelection (ctx, targetElement, path, offset) {
                var nodeName = targetElement.nodeName;
                if (nodeName === 'INPUT' || nodeName === 'TEXTAREA') {
                    if (targetElement !== getDocument(ctx).activeElement) {
                        targetElement.focus();
                    }
                } else {
                    selectElement(ctx, targetElement, path, offset);
                }
            }
            function replaceMacroText (ctx, targetElement, path, offset, macros, text) {
                resetSelection(ctx, targetElement, path, offset);
                var macroMatchInfo = getMacroMatch(ctx, macros);
                if (macroMatchInfo.macroHasTrailingSpace) {
                    macroMatchInfo.macroText = macroMatchInfo.macroText + '\xA0';
                    text = text + '\xA0';
                }
                if (macroMatchInfo !== undefined) {
                    var element = getDocument(ctx).activeElement;
                    if (selectedElementIsTextAreaOrInput(ctx)) {
                        var startPos = macroMatchInfo.macroPosition;
                        var endPos = macroMatchInfo.macroPosition + macroMatchInfo.macroText.length;
                        element.value = element.value.substring(0, startPos) + text +
                            element.value.substring(endPos, element.value.length);
                        element.selectionStart = startPos + text.length;
                        element.selectionEnd = startPos + text.length;
                    } else {
                        pasteHtml(ctx, text, macroMatchInfo.macroPosition,
                                macroMatchInfo.macroPosition + macroMatchInfo.macroText.length);
                    }
                }
            }
            function replaceTriggerText (ctx, targetElement, path, offset, triggerCharSet,
                    text, requireLeadingSpace, hasTrailingSpace, suppressTrailingSpace) {
                resetSelection(ctx, targetElement, path, offset);
                var mentionInfo = getTriggerInfo(ctx, triggerCharSet, requireLeadingSpace, true, hasTrailingSpace);
                if (mentionInfo !== undefined) {
                    if (selectedElementIsTextAreaOrInput()) {
                        var myField = getDocument(ctx).activeElement;
                        if (!suppressTrailingSpace) {
                            text = text + ' ';
                        }
                        var startPos = mentionInfo.mentionPosition;
                        var endPos = mentionInfo.mentionPosition + mentionInfo.mentionText.length + 1;
                        myField.value = myField.value.substring(0, startPos) + text +
                            myField.value.substring(endPos, myField.value.length);
                        myField.selectionStart = startPos + text.length;
                        myField.selectionEnd = startPos + text.length;
                    } else {
                        if (!suppressTrailingSpace) {
                            text = text + '\xA0';
                        }
                        pasteHtml(ctx, text, mentionInfo.mentionPosition,
                                mentionInfo.mentionPosition + mentionInfo.mentionText.length + 1);
                    }
                }
            }
            function getNodePositionInParent (ctx, elem) {
                if (elem.parentNode === null) {
                    return 0;
                }
                for (var i = 0; i < elem.parentNode.childNodes.length; i++) {
                    var node = elem.parentNode.childNodes[i];
                    if (node === elem) {
                        return i;
                    }
                }
            }
            function getMacroMatch (ctx, macros) {
                var selected, path = [], offset;
                if (selectedElementIsTextAreaOrInput(ctx)) {
                    selected = getDocument(ctx).activeElement;
                } else {
                    var selectionInfo = getContentEditableSelectedPath(ctx);
                    if (selectionInfo) {
                        selected = selectionInfo.selected;
                        path = selectionInfo.path;
                        offset = selectionInfo.offset;
                    }
                }
                var effectiveRange = getTextPrecedingCurrentSelection(ctx);
                if (effectiveRange !== undefined && effectiveRange !== null) {
                    var matchInfo;
                    var hasTrailingSpace = false;
                    if (effectiveRange.length > 0 &&
                        (effectiveRange.charAt(effectiveRange.length - 1) === '\xA0' ||
                            effectiveRange.charAt(effectiveRange.length - 1) === ' ')) {
                        hasTrailingSpace = true;
                        effectiveRange = effectiveRange.substring(0, effectiveRange.length-1);
                    }
                    angular.forEach(macros, function (macro, c) {
                        var idx = effectiveRange.toUpperCase().lastIndexOf(c.toUpperCase());
                        if (idx >= 0 && c.length + idx === effectiveRange.length) {
                            var prevCharPos = idx - 1;
                            if (idx === 0 || effectiveRange.charAt(prevCharPos) === '\xA0' ||
                                effectiveRange.charAt(prevCharPos) === ' ' ) {
                                matchInfo = {
                                    macroPosition: idx,
                                    macroText: c,
                                    macroSelectedElement: selected,
                                    macroSelectedPath: path,
                                    macroSelectedOffset: offset,
                                    macroHasTrailingSpace: hasTrailingSpace
                                };
                            }
                        }
                    });
                    if (matchInfo) {
                        return matchInfo;
                    }
                }
            }
            function getContentEditableSelectedPath(ctx) {
                var sel = getWindowSelection(ctx);
                var selected = sel.anchorNode;
                var path = [];
                var offset;
                if (selected != null) {
                    var i;
                    var ce = selected.contentEditable;
                    while (selected !== null && ce !== 'true') {
                        i = getNodePositionInParent(ctx, selected);
                        path.push(i);
                        selected = selected.parentNode;
                        if (selected !== null) {
                            ce = selected.contentEditable;
                        }
                    }
                    path.reverse();
                    offset = sel.getRangeAt(0).startOffset;
                    return {
                        selected: selected,
                        path: path,
                        offset: offset
                    };
                }
            }
            function getTriggerInfo (ctx, triggerCharSet, requireLeadingSpace, menuAlreadyActive, hasTrailingSpace) {
                var selected, path, offset;
                if (selectedElementIsTextAreaOrInput(ctx)) {
                    selected = getDocument(ctx).activeElement;
                } else {
                    var selectionInfo = getContentEditableSelectedPath(ctx);
                    if (selectionInfo) {
                        selected = selectionInfo.selected;
                        path = selectionInfo.path;
                        offset = selectionInfo.offset;
                    }
                }
                var effectiveRange = getTextPrecedingCurrentSelection(ctx);
                if (effectiveRange !== undefined && effectiveRange !== null) {
                    var mostRecentTriggerCharPos = -1;
                    var triggerChar;
                    triggerCharSet.forEach(function(c) {
                        var idx = effectiveRange.lastIndexOf(c);
                        if (idx > mostRecentTriggerCharPos) {
                            mostRecentTriggerCharPos = idx;
                            triggerChar = c;
                        }
                    });
                    if (mostRecentTriggerCharPos >= 0 &&
                            (
                                mostRecentTriggerCharPos === 0 ||
                                !requireLeadingSpace ||
/[\xA0\s]/g.test
                                (
                                    effectiveRange.substring(
                                        mostRecentTriggerCharPos - 1,
                                        mostRecentTriggerCharPos)
                                )
                            )
                        )
                    {
                        var currentTriggerSnippet = effectiveRange.substring(mostRecentTriggerCharPos + 1,
                            effectiveRange.length);
                        triggerChar = effectiveRange.substring(mostRecentTriggerCharPos, mostRecentTriggerCharPos+1);
                        var firstSnippetChar = currentTriggerSnippet.substring(0,1);
                        var leadingSpace = currentTriggerSnippet.length > 0 &&
                            (
                                firstSnippetChar === ' ' ||
                                firstSnippetChar === '\xA0'
                            );
                        if (hasTrailingSpace) {
                            currentTriggerSnippet = currentTriggerSnippet.trim();
                        }
if (!leadingSpace && (menuAlreadyActive || !(/[\xA0\s]/g.test(currentTriggerSnippet)))) {
                            return {
                                mentionPosition: mostRecentTriggerCharPos,
                                mentionText: currentTriggerSnippet,
                                mentionSelectedElement: selected,
                                mentionSelectedPath: path,
                                mentionSelectedOffset: offset,
                                mentionTriggerChar: triggerChar
                            };
                        }
                    }
                }
            }
            function getWindowSelection(ctx) {
                if (!ctx) {
                    return window.getSelection();
                } else {
                    return ctx.iframe.contentWindow.getSelection();
                }
            }
            function getDocument(ctx) {
                if (!ctx) {
                    return document;
                } else {
                    return ctx.iframe.contentWindow.document;
                }
            }
            function getTextPrecedingCurrentSelection (ctx) {
                var text;
                if (selectedElementIsTextAreaOrInput(ctx)) {
                    var textComponent = getDocument(ctx).activeElement;
                    var startPos = textComponent.selectionStart;
                    text = textComponent.value.substring(0, startPos);
                } else {
                    var selectedElem = getWindowSelection(ctx).anchorNode;
                    if (selectedElem != null) {
                        var workingNodeContent = selectedElem.textContent;
                        var selectStartOffset = getWindowSelection(ctx).getRangeAt(0).startOffset;
                        if (selectStartOffset >= 0) {
                            text = workingNodeContent.substring(0, selectStartOffset);
                        }
                    }
                }
                return text;
            }
            function getContentEditableCaretPosition (ctx, selectedNodePosition) {
                var markerTextChar = '\ufeff';
                var markerEl, markerId = 'sel_' + new Date().getTime() + '_' + Math.random().toString().substr(2);
                var range;
                var sel = getWindowSelection(ctx);
                var prevRange = sel.getRangeAt(0);
                range = getDocument(ctx).createRange();
                range.setStart(sel.anchorNode, selectedNodePosition);
                range.setEnd(sel.anchorNode, selectedNodePosition);
                range.collapse(false);
                markerEl = getDocument(ctx).createElement('span');
                markerEl.id = markerId;
                markerEl.appendChild(getDocument(ctx).createTextNode(markerTextChar));
                range.insertNode(markerEl);
                sel.removeAllRanges();
                sel.addRange(prevRange);
                var coordinates = {
                    left: 0,
                    top: markerEl.offsetHeight
                };
                localToGlobalCoordinates(ctx, markerEl, coordinates);
                markerEl.parentNode.removeChild(markerEl);
                return coordinates;
            }
            function localToGlobalCoordinates(ctx, element, coordinates) {
                var obj = element;
                var iframe = ctx ? ctx.iframe : null;
                while(obj) {
                    coordinates.left += obj.offsetLeft;
                    coordinates.top += obj.offsetTop;
                    if (obj !== getDocument().body) {
                        coordinates.top -= obj.scrollTop;
                        coordinates.left -= obj.scrollLeft;
                    }
                    obj = obj.offsetParent;
                    if (!obj && iframe) {
                        obj = iframe;
                        iframe = null;
                    }
                }
            }
            function getTextAreaOrInputUnderlinePosition (ctx, element, position) {
                var properties = [
                    'direction',
                    'boxSizing',
                    'width',
                    'height',
                    'overflowX',
                    'overflowY',
                    'borderTopWidth',
                    'borderRightWidth',
                    'borderBottomWidth',
                    'borderLeftWidth',
                    'paddingTop',
                    'paddingRight',
                    'paddingBottom',
                    'paddingLeft',
                    'fontStyle',
                    'fontVariant',
                    'fontWeight',
                    'fontStretch',
                    'fontSize',
                    'fontSizeAdjust',
                    'lineHeight',
                    'fontFamily',
                    'textAlign',
                    'textTransform',
                    'textIndent',
                    'textDecoration',
                    'letterSpacing',
                    'wordSpacing'
                ];
                var isFirefox = (window.mozInnerScreenX !== null);
                var div = getDocument(ctx).createElement('div');
                div.id = 'input-textarea-caret-position-mirror-div';
                getDocument(ctx).body.appendChild(div);
                var style = div.style;
                var computed = window.getComputedStyle ? getComputedStyle(element) : element.currentStyle;
                style.whiteSpace = 'pre-wrap';
                if (element.nodeName !== 'INPUT') {
                    style.wordWrap = 'break-word';
                }
                style.position = 'absolute';
                style.visibility = 'hidden';
                properties.forEach(function (prop) {
                    style[prop] = computed[prop];
                });
                if (isFirefox) {
                    style.width = (parseInt(computed.width) - 2) + 'px';
                    if (element.scrollHeight > parseInt(computed.height))
                        style.overflowY = 'scroll';
                } else {
                    style.overflow = 'hidden';
                }
                div.textContent = element.value.substring(0, position);
                if (element.nodeName === 'INPUT') {
div.textContent = div.textContent.replace(/\s/g, '\u00a0');
                }
                var span = getDocument(ctx).createElement('span');
                span.textContent = element.value.substring(position) || '.';
                div.appendChild(span);
                var coordinates = {
                    top: span.offsetTop + parseInt(computed.borderTopWidth) + parseInt(computed.fontSize),
                    left: span.offsetLeft + parseInt(computed.borderLeftWidth)
                };
                localToGlobalCoordinates(ctx, element, coordinates);
                getDocument(ctx).body.removeChild(div);
                return coordinates;
            }
            return {
                popUnderMention: popUnderMention,
                replaceMacroText: replaceMacroText,
                replaceTriggerText: replaceTriggerText,
                getMacroMatch: getMacroMatch,
                getTriggerInfo: getTriggerInfo,
                selectElement: selectElement,
                getTextAreaOrInputUnderlinePosition: getTextAreaOrInputUnderlinePosition,
                getTextPrecedingCurrentSelection: getTextPrecedingCurrentSelection,
                getContentEditableSelectedPath: getContentEditableSelectedPath,
                getNodePositionInParent: getNodePositionInParent,
                getContentEditableCaretPosition: getContentEditableCaretPosition,
                pasteHtml: pasteHtml,
                resetSelection: resetSelection,
                scrollIntoView: scrollIntoView
            };
        }]);
angular.module("mentio").run(["$templateCache", function($templateCache) {$templateCache.put("mentio-menu.tpl.html","<style>\n.scrollable-menu {\n    height: auto;\n    max-height: 300px;\n    overflow: auto;\n}\n\n.menu-highlighted {\n    font-weight: bold;\n}\n</style>\n<ul class=\"dropdown-menu scrollable-menu\" style=\"display:block\">\n    <li mentio-menu-item=\"item\" ng-repeat=\"item in items track by $index\">\n        <a class=\"text-primary\" ng-bind-html=\"item.label | mentioHighlight:typedTerm:\'menu-highlighted\' | unsafe\"></a>\n    </li>\n</ul>");}]);
})();
;
/*! RESOURCE: /scripts/sn/common/stream/_module.js */
(function() {
	var moduleDeps = [ 'sn.base', 'ng.amb', 'sn.messaging', 'sn.common.glide', 'ngSanitize',
		'sn.common.avatar', 'sn.common.ui.popover', 'mentio', 'sn.common.controls', 'sn.common.user_profile',
		'sn.common.datetime', 'sn.common.mention', 'sn.common.ui', 'sn.common.dynamicTranslation'];
	if (angular.version.major == 1 && angular.version.minor >= 3)
		moduleDeps.push('ngAria');
	angular.module("sn.common.stream", moduleDeps);
	angular.module("sn.stream.direct", [ 'sn.common.stream']);
})();
;
/*! RESOURCE: /scripts/sn/common/stream/controller.Stream.js */
angular.module("sn.common.stream").controller("Stream", function($rootScope, $scope, snRecordWatcher, $timeout) {
	var isForm = NOW.sysId.length > 0;
	var recordWatchSubscribed = false;
	$scope.showCommentsAndWorkNotes = isForm;
	$scope.sessions = {};
	$scope.recordStreamOpen = false;
	$scope.streamHidden = true;
	$scope.recordSysId = '';
	$scope.recordDisplayValue = '';
	$rootScope.$on('sn.sessions', onSessions);
	if (isForm) {
		$timeout(function() {
			var formQuery = "sys_id=" + NOW.sysId;
			snRecordWatcher.initChannel(NOW.targetTable, formQuery, function(message) {
				$rootScope.$broadcast("sn.stream.tap", message.data);
				recordWatchSubscribed = true;
			});
		}, 100);
	}
	else {
		$rootScope.$on('sn.stream.entries_change', function(evt, entries) {
			if (recordWatchSubscribed) 
				return; 
			
			var listQuery =  entries
						.filter(function (entry) {return entry.document_id;})
						.map(function (entry) {return entry.document_id;})
						.join(",");
			if (!listQuery)
				return;
			snRecordWatcher.initChannel(NOW.targetTable, "sys_idIN" + listQuery, function(message) {
				$rootScope.$broadcast("sn.stream.tap", message.data);
				recordWatchSubscribed = true;
			});		
		})
	}
	$scope.controls = {
		showRecord : function($event, entry, sysId) {
			if (sysId !== '')
				return;
			if ($event.currentTarget != $event.target && $event.target.tagName == 'A')
				return;
			$scope.recordSysId = entry.document_id;
			$scope.recordDisplayValue = entry.display_value;
			$scope.recordStreamOpen = true;
			$scope.streamHidden = true;
		},
		openRecord : function() {
			var targetFrame = window.self;
			var url = NOW.targetTable + ".do?sys_id=" + $scope.recordSysId;
			if (NOW.linkTarget == 'form_pane') {
				url += "&sysparm_clear_stack=true";
				window.parent.CustomEvent.fireTop(
					"glide:nav_open_url", {
						url : url,
						openInForm : true
					});
				return;
			}
			if (NOW.streamLinkTarget == 'parent' || NOW.concourse == 'true')
				targetFrame = window.parent;
			targetFrame.location = url;
		}
	};
	$scope.sessionCount = function() {
		$scope.sessions.length = Object.keys($scope.sessions.data).length;
		return $scope.sessions.length;
	};
	function onSessions(name, sessions) {
		$scope.sessions.data = sessions;
		$scope.sessionCount();
	}
	$scope.toggleEmailIframe = function(email, event){
		email.expanded = !email.expanded;
		event.preventDefault();
	};
	$scope.showListStream = function () {
		$scope.recordStreamOpen = false;
		$scope.recordHidden = false;
		$scope.streamHidden = false;
		angular.element('div.list-stream-record').velocity('snTransition.streamSlideRight', {
			duration: 400
		});
		angular.element('[streamType="list"]').velocity('snTransition.slideIn', {
			duration: 400,
			complete: function (element) {
				angular.element(element).css({display: 'block'});
			}
		});
	};
	$scope.$watch(function () {
		return angular.element('div.list-stream-record').length
	}, function (newValue, oldValue) {
		if (newValue == 1) {
			angular.element('div.list-stream-record').delay(100).velocity('snTransition.streamSlideLeft', {
				begin: function (element) {
					angular.element(element).css({visibility: 'visible'});
					angular.element('.list-stream-record-header').css({visibility: 'visible'});
				},
				duration: 400,
				complete: function (element) {
					angular.element(element).css({transform: "translateX(0)"});
					angular.element(element).scrollTop(0);
					angular.element(element).css({transform: "initial"});
					angular.element('.return-to-stream').focus();
				}
			});
		}
	});
});
;
/*! RESOURCE: /scripts/sn/common/stream/controller.snStream.js */
angular.module("sn.common.stream").controller("snStream", function($rootScope, $scope, $attrs, $http, nowStream, snRecordPresence, snCustomEvent, userPreferences, $window, $q, $timeout, $sce, snMention, i18n, getTemplateUrl, $injector, dynamicTranslation) {
	"use strict";
	var POLLING_OFF = window.NOW.activity && !(window.NOW.activity.polling && window.NOW.activity.isV0);
	var EDIT_ENABLED = window.NOW.activity && !(window.NOW.activity.editTimeLimit === '0');
	if (angular.isDefined($attrs.isInline)) {
		bindInlineStreamAttributes();
	}
	var globalMembers = NOW.recordMembers || {};
	function putGlobalMember(sysId, name, initials, avatar) {
		if (!sysId || !name || !initials)
			return;
		if (!globalMembers[sysId]) {
			globalMembers[sysId] = {
					"name": name,
					"initials": initials,
					"sys_id": sysId,
					"record_is_visible": true,
					"avatar": avatar
				};
			return;
		}
		if ((globalMembers[sysId].avatar === undefined || globalMembers[sysId].avatar === "") && avatar)
			globalMembers[sysId].avatar = avatar;
	}
	function getMembersFromPageContext(members, term) {
		var matching = [], matchingSysIds = [];
		var memberKeys = Object.keys(globalMembers);
		term = term.toLowerCase().trim();
		memberKeys.forEach(function(sysId) {
			var member = globalMembers[sysId];
			if ((typeof member.name !== "undefined" && member.name.toLowerCase().indexOf(term) == 0) || (typeof member.last_name !== "undefined" && member.last_name.toLowerCase().indexOf(term) == 0)) {
				matching.push(member);
				matchingSysIds.push(sysId);
			}
		});
		members.forEach(function(member) {
			if (globalMembers[member.sys_id] && globalMembers[member.sys_id].avatar === undefined)
				globalMembers[member.sys_id].avatar = member.avatar;
			if (globalMembers[member.sys_id] && globalMembers[member.sys_id].record_is_visible !== member.record_is_visible)
				globalMembers[member.sys_id].record_is_visible = member.record_is_visible;
			if (matchingSysIds.indexOf(member.sys_id) === -1)
				matching.push(member);
		});
		return matching;
	}
	function bindInlineStreamAttributes() {
		var streamAttributes = {};
		if ($attrs.table) {
			streamAttributes.table = $attrs.table;
		}
		if ($attrs.query) {
			streamAttributes.query = $attrs.query;
		}
		if ($attrs.sysId) {
			streamAttributes.sysId = $attrs.sysId;
		}
		if ($attrs.active) {
			streamAttributes.active = ($attrs.active == "true");
		}
		if ($attrs.template) {
			streamAttributes.template = $attrs.template;
		}
		if ($attrs.preferredInput) {
			streamAttributes.preferredInput = $attrs.preferredInput;
		}
		if ($attrs.useMultipleInputs) {
			streamAttributes.useMultipleInputs = ($attrs.useMultipleInputs == "true");
		}
		if ($attrs.expandEntries) {
			streamAttributes.expandEntries = ($attrs.expandEntries == "true");
		}
		if ($attrs.pageSize) {
			streamAttributes.pageSize = parseInt($attrs.pageSize, 10);
		}
		if ($attrs.truncate) {
			streamAttributes.truncate = ($attrs.truncate == "true");
		}
		if ($attrs.attachments) {
			streamAttributes.attachments = ($attrs.attachments == "true");
		}
		if ($attrs.showCommentsAndWorkNotes) {
			streamAttributes.attachments = ($attrs.showCommentsAndWorkNotes == "true");
		}
		angular.extend($scope, streamAttributes)
	}
			var stream;
			var processor = $attrs.processor || "list_history";
			var interval;
			var FROM_LIST = 'from_list';
			var FROM_FORM = 'from_form';
			var source = $scope.sysId ? FROM_FORM : FROM_LIST;
			var _firstPoll = true;
			var _firstPollTimeout;
			var fieldsInitialized = false;
			var primaryJournalFieldOrder = ["comments", "work_notes"];
			var primaryJournalField = null;
			$scope.defaultShowCommentsAndWorkNotes = ($scope.sysId != null && !angular.isUndefined($scope.sysId) && $scope.sysId.length > 0);
			$scope.canWriteWorkNotes = false;
			$scope.inputTypeValue = "";
			$scope.entryTemplate = getTemplateUrl($attrs.template || "list_stream_entry");
			$scope.isFormStream = $attrs.template === "record_stream_entry.xml";
$scope.allFields = null;
			$scope.fields = {};
			$scope.fieldColor = "transparent";
			$scope.multipleInputs = $scope.useMultipleInputs;
			$scope.checkbox = {};
			$scope.attachmentAdviceRequired = $window.NOW.attachmentAdviceRequired;
			$scope.filterModified = false;
			var infectedAttachmnentMsg = "The file {0} did not pass security scan and cannot be downloaded";
			i18n.getMessage(infectedAttachmnentMsg, function(message) {
				infectedAttachmnentMsg = message;
			});
			var typing = '{0} is typing', viewing = '{0} is viewing', entered = '{0} has entered';
			var probablyLeft = '{0} has probably left', exited = '{0} has exited', offline = '{0} is offline', auditMessage = '{0} was {1}', was ="was";
			var emailBodyMsg = "Email body";
			i18n.getMessages(
				[
					typing,
					viewing,
					entered,
					probablyLeft,
					exited,
					offline,
					was,
					auditMessage,
					emailBodyMsg
				],
				function (results) {
					typing = results[typing];
					viewing = results[viewing];
					entered = results[entered];
					probablyLeft = results[probablyLeft];
					exited = results[exited];
					offline = results[offline];
					was = results[was];
					emailBodyMsg = results[emailBodyMsg];
					$scope.auditMessageParts = buildAuditMessageParts(results[auditMessage],was);
				}
			);
			function buildAuditMessageParts(auditMessage, was) {
var tMessagePattern = /^([^{]*)\{([01])\}([^{]*)\{([01])\}(.*)$/;
				var messageParts = tMessagePattern.exec(auditMessage);
				var auditMessageParts = messageParts ?
					{
						prefix: messageParts[1].trim(),
						newValPosition: messageParts[2],
						middle: messageParts[3].trim(),
						oldValPosition: messageParts[4],
						postfix: messageParts[5].trim()
					} :
					{
						prefix: '',
						newValPosition: "0",
						middle: was,
						oldValPosition: "1",
						postfix: ''
					};
				return auditMessageParts;
			}
			$scope.parsePresence = function (sessionData) {
				var status = sessionData.status;
				var name = sessionData.user_display_name;
				switch (status) {
					case 'typing':
						return i18n.format(typing, name);
					case 'viewing':
						return i18n.format(viewing, name);
					case 'entered':
						return i18n.format(entered, name);
					case 'probably left':
						return i18n.format(probablyLeft, name);
					case 'exited':
						return i18n.format(exited, name);
					case 'offline':
						return i18n.format(offline, name);
					default:
						return '';
				}
			};
			$scope.members = [];
			$scope.members.loading = true;
			var mentionMap = {};
			$scope.selectAtMention = function(item) {
				if(item.termLengthIsZero)
					return (item.name || "") + "\n";
				mentionMap[item.name] = item.sys_id;
				return "@[" + item.name + "]";
			};
			var typingTimer;
			$scope.searchMembersAsync = function(term) {
				$scope.members = getMembersFromPageContext([], term);
				$scope.members.loading = true;
				$timeout.cancel(typingTimer);
				if (term.length === 0) {
					$scope.members = [{
						termLengthIsZero: true
					}];
					$scope.members.loading = false;
				} else {
					typingTimer = $timeout(function() {
						snMention.retrieveMembers($scope.table, $scope.sysId, term).then(function(members) {
							$scope.members = getMembersFromPageContext(members, term);
							$scope.members.loading = false;
						}, function () {
							$scope.members = getMembersFromPageContext([{
								termLengthIsZero: true
							}], term);
							$scope.members.loading = false;
						});
					}, 500);
				}
			};
			$scope.expandMentions = function(text) {
				return stream.expandMentions(text, mentionMap)
			};
			$scope.reduceMentions = function(text) {
				if(!text)
					return text;
var regexMentionParts = /[@\w\d\s/\'-]+/gi;
text = text.replace(/@\[[\w\d\s]+:[@\w\d\s/\'-]+\]/gi, function (mention) {
					var mentionParts = mention.match(regexMentionParts);
					if (mentionParts.length === 3) {
						var name = mentionParts[2];
						mentionMap[name] = mentionParts[1];
						return "@[" + name + "]";
					}
					return mentionParts;
				});
				return text;
			};
			$scope.parseMentions = function(entry) {
var regexMentionParts = /[\w\d\s/\'-]+/gi;
entry = entry.replace(/@\[[\w\d\s]+:[\w\d\s/\'-]+\]/gi, function (mention) {
					var mentionParts = mention.match(regexMentionParts);
					if (mentionParts.length === 2) {
return '<a class="at-mention at-mention-user-' + mentionParts[0] + '">@' + mentionParts[1] + '</a>';
					}
					return mentionParts;
				});
				return entry;
			};
			$scope.parseLinks = function(text) {
var regexLinks = /@L\[([^|]+?)\|([^\]]*)]/gi;
return text.replace(regexLinks, "<a href='$1' target='_blank'>$2</a>");
			};
			$scope.trustAsHtml = function(text) {
				return $sce.trustAsHtml(text);
			};
			$scope.parseSpecial = function(text) {
				var parsedText = $scope.parseLinks(text);
				parsedText = $scope.parseMentions(parsedText);
				return $scope.trustAsHtml(parsedText);
			};
			$scope.containsHTML = function(text) {
return /<[a-zA-Z][^>]*\/?>/m.test(text);
			};
			$scope.isHTMLField = function(change) {
				return change.field_type === 'html' || change.field_type === 'translated_html';
			};
			$scope.shouldEncapsulate = function(journal) {
				return $scope.isHTMLField(journal) || $scope.containsHTML(journal.sanitized_new_value)
			};
			$scope.getFullEntryValue = function(entry, event) {
				event.stopPropagation();
				var index = getEntryIndex(entry);
				var journal = $scope.entries[index].entries.journal[0];
				journal.loading = true;
$http.get('/api/now/ui/stream_entry/full_entry', {
					params: {
						sysparm_sys_id: journal.sys_id
					}
				}).then(function (response) {
journal.sanitized_new_value = journal.new_value = response.data.result.replace(/\n/g, '<br/>');
					journal.is_truncated = false;
					journal.loading = false;
					journal.showMore = true;
				});
			};
			function getEntryIndex(entry) {
				for (var i = 0, l = $scope.entries.length; i < l; i++) {
					if (entry === $scope.entries[i]) {
						return i;
					}
				}
			}
			$scope.$watch('active', function(n, o) {
				if (n === o)
					return;
				if ($scope.active)
					startPolling();
				else
					cancelStream();
			});
			$scope.defaultControls = {
				getTitle: function(entry) {
					if(entry && entry.short_description) {
						return entry.short_description;
					} else if(entry && entry.shortDescription) {
						return entry.shortDescription;
					}
				},
				showCreatedBy: function() {
					return true;
				},
				hideCommentLabel: function() {
					return false;
				},
				showRecord: function($event, entry) {
				},
				showRecordLink: function() {
					return true;
				}
			};
			if ($scope.controls) {
				for (var attr in $scope.controls)
					$scope.defaultControls[attr] = $scope.controls[attr];
			}
			$scope.controls = $scope.defaultControls;
			if ($scope.showCommentsAndWorkNotes === undefined) {
				$scope.showCommentsAndWorkNotes = $scope.defaultShowCommentsAndWorkNotes;
			}
			snCustomEvent.observe('sn.stream.change_input_display', function(table, display) {
				if (table != $scope.table)
					return;
				$scope.showCommentsAndWorkNotes = display;
				$scope.$apply();
			});
			snCustomEvent.observe('sn.stream.attachment_state_updated', function(entry) {
				$scope.entries.forEach(function(e) {
					if (e.attachment && e.attachment.sys_id === entry.attachment.sys_id) {
						e.attachment.state = entry.attachment.state;
					}
				});
			});
			$scope.$on("$destroy", function() {
				cancelStream();
				snCustomEvent.un('sn.stream.entries_deleted', entriesDeletedHandler);
				snCustomEvent.un('sn.stream.entries_edited', entriesEditedHandler);
			});
			$scope.$on('sn.stream.interval', function($event, time) {
				interval = time;
				reschedulePoll();
			});
			$scope.$on("sn.stream.tap", function() {
				if (POLLING_OFF) {
					stream.fetchStream(onPoll, beforePoll);
					return;
				}
				if (stream)
					stream.tap();
				else
					startPolling();
			});
			$scope.$on('window_visibility_change', function($event, hidden) {
				interval = (hidden) ? 120000 : undefined;
				reschedulePoll();
			});
			snCustomEvent.observe('sn.stream.clearOnSilentSubmit', function(){
				clearInputs();
			});
			$scope.$on("sn.stream.refresh", function(event, data) {
				stream._successCallback(data.response);
			});
			$scope.$on("sn.stream.reload", function() {
				startPolling();
			});
			snCustomEvent.observe('sn.stream.toggle_multiple_inputs', function() {
				$scope.useMultipleInputs = true;
			});
			$scope.$on('sn.stream.input_value', function(otherScope, type, value) {
				setMultipleInputs();
				if(!$scope.multipleInputs) {
					$scope.inputType = type;
					$scope.inputTypeValue = value;
				}
			});
			$scope.$watchCollection('[table, query, sysId]', startPolling);
			$scope.changeInputType = function(field) {
				if (!primaryJournalField){
					angular.forEach($scope.fields, function(item) {
						if (item.isPrimary)
							primaryJournalField = item.name;
					});
				}
				$scope.inputType = field.checked ? field.name : primaryJournalField;
				userPreferences.setPreference('glide.ui.' + $scope.table + '.stream_input', $scope.inputType);
			};
			$scope.selectedInputType = function(value) {
				if (angular.isDefined(value)) {
					$scope.inputType = value;
					userPreferences.setPreference('glide.ui.' + $scope.table + '.stream_input', $scope.inputType);
				}
				return $scope.inputType;
			};
			$scope.$watch('inputType', function() {
				if (!$scope.inputType || !$scope.preferredInput)
					return;
				$scope.preferredInput = $scope.inputType;
			});
			$scope.submitCheck = function(event){
				var key = event.keyCode || event.which;
				if (key === 13) {
					$scope.postJournalEntryForCurrent(event);
				}
			};
			$scope.postJournalEntry = function(type, entry, event) {
				type = type || primaryJournalFieldOrder[0];
				event.stopPropagation();
				var requestTable = $scope.table || "board:" + $scope.board.sys_id;
				stream.insertForEntry(type, entry.journalText, requestTable, entry.document_id);
				entry.journalText = "";
				entry.commentBoxVisible = false;
				snRecordPresence.termPresence();
			};
			$scope.postJournalEntryForCurrent = function(event) {
				event.stopPropagation();
				var entries = [];
				if ($scope.multipleInputs) {
					angular.forEach($scope.fields, function(item) {
						if (!item.value)
							return;
						entries.push({
							field: item.name,
							text: item.value
						});
					})
				} else {
					entries.push({
						field: $scope.inputType,
						text: $scope.inputTypeValue
					});
					var inputType = ($scope.inputType === 'comments' || $scope.inputType === 'work_notes') ? $scope.inputType : 'custom';
					window.GlideUXMetrics && GlideUXMetrics.track('Post Activity', {
						'type': inputType
					});
				}
				var request = stream.insertEntries(entries, $scope.table, $scope.sysId, mentionMap);
				if (request) {
					request.then(function () {
						for (var i = 0; i < entries.length; i++) {
							fireClearEvent(entries[i].field);
						}
					});
				}
				clearInputs();
				return false;
			};
			$scope.doesFormHasMandatoryJournalFields = function() {
				if (window.g_form) {
					var fields = Object.values($scope.fields);
					for (var index = 0; index < fields.length; index++) {
						if (fields[index].mandatory)
							return true;
					}
				}
				return false;
			};
			function fireInsertEvent(name, value) {
				snCustomEvent.fire('sn.stream.insert', name, value);
			}
			function fireClearEvent(name) {
				snCustomEvent.fire('sn.stream.clear', name);
			}
			function clearInputs() {
				$scope.inputTypeValue = "";
				angular.forEach($scope.fields, function(item) {
					if (item.value)
						item.filled = true;
					item.value = "";
				});
			}
			$scope.showCommentBox = function(entry, event) {
				event.stopPropagation();
				if (entry !== $scope.selectedEntry)
					$scope.closeEntry();
				$scope.selectedEntry = entry;
				entry.commentBoxVisible = !entry.commentBoxVisible;
				if (entry.commentBoxVisible) {
					snRecordPresence.initPresence($scope.table, entry.document_id);
				}
			};
			$scope.showMore = function(journal, event) {
				event.stopPropagation();
				journal.showMore = true;
			};
			$scope.showLess = function(journal, event) {
				event.stopPropagation();
				journal.showMore = false;
			};
			$scope.closeEntry = function() {
				if ($scope.selectedEntry)
					$scope.selectedEntry.commentBoxVisible = false;
			};
			$scope.handleListASAttachmentClick  = function(evt, entry) {
				evt.stopPropagation();
				$scope.handleASAttachmentClick(evt, entry);
			};
			$scope.handleListASAttachmentKeydown = function(evt, entry) {
				if (evt.keyCode === 13 || evt.keyCode === 32) {
					evt.stopPropagation();
					$scope.handleASAttachmentClick(evt, entry);
				}
			}
			$scope.handleASAttachmentClick = function(evt, entry) {
				var attachment = entry.attachment;
				if (attachment.state === 'available' || !$scope.attachmentAdviceRequired) {
					previewOrDownloadAttachment(evt, entry, false);
				} else if (attachment.state === 'not_available') {
					evt.preventDefault();
					$scope.showAttachmentUnAvailabilityMessage(attachment.file_name);
				} else {
					evt.preventDefault();
					getAttachmentAvailability(attachment.sys_id)
						.then(function(res) {
							entry.attachment.state = res.state;
							previewOrDownloadAttachment(evt, entry, true);
						}, function(res) {
							entry.attachment.state = res.state;
							if (res.forceDownload) {
								downloadAttachment(evt.currentTarget);
							} else {
								$scope.showAttachmentUnAvailabilityMessage(attachment.file_name, res.message);
							}
						});
				}
			};
			function getAttachmentAvailability(attachmentSysId) {
				var deferred = $q.defer();
$http.get('/api/now/as_attachment/getAvailability/' + attachmentSysId)
					.then(function (response) {
						var _res = response.data.result;
						if (_res && _res.availability) {
							if (_res.availability === 'available') {
								deferred.resolve({state : _res.availability});
							} else {
								deferred.reject({
									state : _res.availability,
									message : _res.message
								});
							}
						} else {
							deferred.reject({ state: "", forceDownload : true});
						}
					}, function() {
						deferred.reject({ state: "", forceDownload : true});
					});
				return deferred.promise;
			}
			function escapeHtml(unsafe) {
				return unsafe
.replace(/&/g, "&amp;")
.replace(/</g, "&lt;")
.replace(/>/g, "&gt;")
.replace(/"/g, "&quot;")
.replace(/'/g, "&#039;");
			}
			$scope.showAttachmentUnAvailabilityMessage = function(fileName, customMsg) {
				var errMsg = customMsg || i18n.format(infectedAttachmnentMsg, escapeHtml(fileName));
				if (typeof g_form !== "undefined") {
					g_form.addErrorMessage(errMsg);
				} else if (typeof window.parent.GlideUI !== "undefined") {
					var topWindow = window.parent;
					topWindow.CustomEvent.fireTop(topWindow.GlideUI.UI_NOTIFICATION + '.error',
						new topWindow.GlideUINotification({type : 'error',text : errMsg }));
				} else if (window.NOW && window.NOW.CustomEvent) {
					window.NOW.CustomEvent.fire('stream.attachment.unavailable', errMsg);
				}
			};
			function downloadAttachment(ele) {
				var link = document.createElement('a');
				link.href = ele.getAttribute('href');
				link.download = ele.getAttribute('file-name');
				var event = (typeof window.MouseEvent === "function")
								? new MouseEvent("click")
								: document.createEvent('Event');
				event.initEvent('click', true, true);
				link.dispatchEvent(event);
			}
			function previewOrDownloadAttachment(evt, entry, isAsync) {
				if (!$scope.isFormStream) {
					evt.preventDefault();
					if (isAsync && entry.type === 'attachment-image')
						return;
					openAttachment(entry.attachment.sys_id);
					return;
				}
				if (entry.type === 'attachment-image') {
					if (snCustomEvent.events['sn.attachment.preview'] && !isAsync) {
						snCustomEvent.fire('sn.attachment.preview', evt, entry.attachment);
					}
				} else if((entry.attachment.extension === 'mp4' || entry.attachment.extension === 'webm') && typeof GlideVideoPlayer !== "undefined") {
					evt.preventDefault();
					entry.attachment.playVideo = true;
				} else if (isAsync) {
					downloadAttachment(evt.currentTarget);
				}
			}
			function openAttachment(sysId) {
var url = "/sys_attachment.do?view=true&sys_id=" + sysId;
				var newTab = window.open(url, '_blank');
				newTab.focus();
			}
			$rootScope.$on('sn.sessions', function(someOtherScope, sessions) {
				if ($scope.selectedEntry && $scope.selectedEntry.commentBoxVisible)
					$scope.selectedEntry.sessions = sessions;
			});
			$scope.$watch("inputTypeValue", function(n, o) {
				if (n !== o) {
					emitTyping($scope.inputTypeValue);
				}
			});
			$scope.$watch("selectedEntry.journalText", function(newValue) {
				if ($scope.selectedEntry)
					emitTyping(newValue || "");
			});
			var multipleInputWatcher = function(){};
			$scope.$watch('useMultipleInputs', function() {
				if($scope.useMultipleInputs) {
					multipleInputWatcher = $scope.$watch("fields", function(n, o, s) {
                        if (n !== o) {
                            var strVal = "";
                            angular.forEach($scope.fields, function(item) {
                                if (item.value)
                                    strVal = item.value;
                            });
                            emitTyping(strVal);
                        }
                    }, true);
				} else {
					multipleInputWatcher();
				}
				setMultipleInputs();
			});
			function emitTyping(inputValue) {
				if (!angular.isDefined(inputValue)){
					return;
				}
				var status = inputValue.length ? "typing" : "viewing";
				$scope.$emit("record.typing", {status: status, value: inputValue, field_type: $scope.inputType, table: $scope.table, sys_id: $scope.sys_id});
			}
			function putUseEmailAmbInWindow() {
				if (!$scope.isFormStream) {
					window.NOW.activity.useEmailAmb = false;
					return;
				}
				if (!$scope.template || $scope.template !== "record_stream_entry.xml") {
					window.NOW.activity.useEmailAmb = false;
					return;
				}
				window.NOW.activity.useEmailAmb = true;
			}
			function putUseEditAmbChannelInWindow() {
				if (!$scope.isFormStream) {
					window.NOW.activity.useEditAmbWithTable = true;
					if (!$scope.table && $scope.board && $scope.board.table)
						window.NOW.activity.editAmbTable = $scope.board.table;
					return;
				}
				if (!$scope.template || $scope.template !== "record_stream_entry.xml") {
					window.NOW.activity.useEditAmbWithTable = true;
					return;
				}
				window.NOW.activity.useEditAmbWithTable = false;
			}
			var entriesDeletedHandler = function(deletedActivityId) {
				if (!$scope.entries)
					return;
var updateBackgroundColor = false;
				var entryIndexToDelete = -1;
				for (var i = 0; i < $scope.entries.length; i++) {
					var entry = $scope.entries[i];
					if (!entry.entries?.journal)
						continue;
					var journalIndexToDelete = entry.entries.journal.findIndex(journal => journal.sys_id === deletedActivityId);
if (journalIndexToDelete === -1)
						continue;
if (journalIndexToDelete === 0)
						updateBackgroundColor = true;
					entry.entries.journal.splice(journalIndexToDelete, 1);
					var hasContent = [entry.entries.changes, entry.entries.custom, entry.entries.journal]
						.some(arr => arr?.length > 0);
if (!hasContent)
						entryIndexToDelete = i;
					break;
				}
				if (entryIndexToDelete !== -1) {
					$scope.entries.splice(entryIndexToDelete, 1);
					updateBackgroundColor = false;
				}
				if (stream?.lastEntry?.entries?.journal) {
					var lastEntryJournalIndex =
						stream.lastEntry.entries.journal.findIndex(journal => journal.sys_id === deletedActivityId);
					if (lastEntryJournalIndex !== -1) {
						stream.lastEntry.entries.journal.splice(lastEntryJournalIndex, 1);
						var lastEntryHasContent = [stream.lastEntry.entries.changes,
										   stream.lastEntry.entries.custom,
									   stream.lastEntry.entries.journal]
									  .some(arr => arr?.length > 0);
						if (!lastEntryHasContent) {
							stream.lastEntry = $scope.entries.length > 0
								? $scope.entries.reduce((max, curr) =>
									(curr.sys_timestamp || 0) > (max?.sys_timestamp || 0) ? curr : max, $scope.entries[0])
								: null;
						}
					}
				}
				if (updateBackgroundColor && $scope.entryTemplate === "list_stream_entry")
					$scope.$apply();
				$scope.$emit('sn.stream.entries_change', $scope.entries);
			}
			var entriesEditedHandler = function(editedActivityId, newValue, containsCode) {
				if (!$scope.entries)
					return;
				for (var i = 0; i < $scope.entries.length; i++) {
					var entry = $scope.entries[i];
					if (!entry.entries?.journal)
						continue;
					var journalIndexToEdit = entry.entries.journal.findIndex(journal => journal.sys_id === editedActivityId);
					if (journalIndexToEdit === -1)
						continue;
					entry.entries.journal[journalIndexToEdit].contains_code = containsCode;
					entry.entries.journal[journalIndexToEdit].new_value = newValue;
					entry.entries.journal[journalIndexToEdit].sanitized_new_value = newValue;
					break;
				}
				if (stream?.lastEntry?.entries?.journal) {
					var lastEntryJournalToEdit =
						stream.lastEntry.entries.journal.findIndex(journal => journal.sys_id === editedActivityId);
					if (lastEntryJournalToEdit !== -1) {
						stream.lastEntry.entries.journal[lastEntryJournalToEdit].contains_code = containsCode;
						stream.lastEntry.entries.journal[lastEntryJournalToEdit].new_value = newValue;
						stream.lastEntry.entries.journal[lastEntryJournalToEdit].sanitized_new_value = newValue;
					}
				}
			}
			snCustomEvent.observe('sn.stream.entries_deleted', entriesDeletedHandler);
			snCustomEvent.observe('sn.stream.entries_edited', entriesEditedHandler);
			function preloadedData() {
				if (typeof window.NOW.snActivityStreamData === 'object'
					&& window.NOW.snActivityStreamData[$scope.table + '_' + $scope.sysId]) {
					_firstPoll = false;
					var data = window.NOW.snActivityStreamData[$scope.table + '_' + $scope.sysId];
					if (POLLING_OFF)
						putUseEmailAmbInWindow();
					if (EDIT_ENABLED)
						putUseEditAmbChannelInWindow();
					stream = nowStream.create($scope.table, $scope.query, $scope.sysId,
							processor, interval, source, $scope.attachments);
					stream.callback = onPoll;
					stream.preRequestCallback = beforePoll;
					stream.lastTimestamp = data.sys_timestamp;
					if (data.entries && data.entries.length) {
						stream.lastEntry = angular.copy(data.entries[0]);
					}
					_firstPollTimeout = setTimeout(function() {
						if (POLLING_OFF) {
							stream.fetchStream(onPoll, beforePoll);
							return;
						}
						stream.poll(onPoll, beforePoll);
						_firstPollTimeout = false;
					}, 20000);
					beforePoll();
					onPoll(data);
					return true;
				}
				return false;
			}
			function scheduleNewPoll(lastTimestamp) {
				cancelStream();
				if (POLLING_OFF)
					putUseEmailAmbInWindow();
				if (EDIT_ENABLED)
					putUseEditAmbChannelInWindow();
				stream = nowStream.create($scope.table, $scope.query, $scope.sysId,
					processor, interval, source, $scope.attachments);
				stream.lastTimestamp = lastTimestamp;
				if (POLLING_OFF) {
					stream.fetchStream(onPoll, beforePoll);
					return;
				}
				stream.poll(onPoll, beforePoll);
			}
			function reschedulePoll() {
				var lastTimestamp = stream ? stream.lastTimestamp : 0;
				if (cancelStream()) {
					scheduleNewPoll(lastTimestamp);
				}
			}
			function reset() {
				removeInlineStream();
				$scope.loaded = false;
				startPolling();
			}
			function emitFilterChange() {
				$scope.$emit('sn.stream.is_filtered_change', $scope.isFiltered);
			}
			function startPolling() {
				if ($scope.loading && !$scope.loaded)
					return;
				if (!$scope.active)
					return;
				$scope.entries = [];
				$scope.allEntries = [];
				$scope.showAllEntriesButton = false;
				$scope.loaded = false;
				$scope.loading = true;
				if (_firstPoll && preloadedData()) {
					return;
				}
				scheduleNewPoll();
				$scope.$emit('sn.stream.entries_change', $scope.entries);
			}
			function onPoll(response) {
				$scope.loading = false;
				if (response.primary_fields)
					primaryJournalFieldOrder = response.primary_fields;
				if (!fieldsInitialized)
					processFields(response.fields);
				processEntries(response.entries);
				if (response.inlineStreamLoaded) {
					$scope.inlineStreamLoaded = true;
					addInlineStreamEntryClass();
				}
				if (!$scope.loaded) {
					$scope.loaded = true;
					$scope.$emit("sn.stream.loaded", response);
				}
			}
			function beforePoll() {
				$scope.$emit("sn.stream.requested");
			}
			function processFields(fields) {
				if(!fields || !fields.length)
					return;
				fieldsInitialized = true;
$scope.allFields = fields;
				setShowAllFields();
				$scope.fieldsVisible = 0;
				var i = 0;
				angular.forEach(fields, function(field) {
					if (!field.isJournal)
						return;
					if (i==0)
						$scope.firstJournal = field.name;
					i++;
					if ($scope.fields[field.name]) {
						angular.extend($scope.fields[field.name], field);
					} else {
						$scope.fields[field.name] = field;
					}
					$scope.fields[field.name].visible = !$scope.formJournalFields && $scope.fields[field.name].canWrite;
					if ($scope.fields[field.name].visible)
						$scope.fieldsVisible++;
					var fieldColor = field.color;
					if (fieldColor)
fieldColor = field.color.replace(/background-color: /, '');
					if (!fieldColor || fieldColor == 'transparent')
						fieldColor = null;
					$scope.fields[field.name].color = fieldColor;
				});
				setFieldVisibility();
				setPrimaryJournalField();
				setMultipleInputs();
			}
			$scope.$watch('formJournalFields', function() {
				setFieldVisibility();
				setPrimaryJournalField();
				setMultipleInputs();
			}, true);
			function setFieldVisibility() {
				if (!$scope.formJournalFields || !$scope.fields || !$scope.showCommentsAndWorkNotes)
					return;
				$scope.fieldsVisible = 0;
				angular.forEach($scope.formJournalFields, function(formField) {
					if (!$scope.fields[formField.name])
						return;
					var formValue = angular.element('#' + $scope.table + '\\.' + formField.name).val();
if (formValue && formValue.indexOf($window.NOW.STREAM_VALUE_KEY) !== 0) {
						$scope.fields[formField.name].value = $scope.reduceMentions(formField.value);
					} else if (formValue === '') {
						$scope.fields[formField.name].value = '';
					}
					$scope.fields[formField.name].mandatory = formField.mandatory;
					$scope.fields[formField.name].label = formField.label;
					$scope.fields[formField.name].messages = formField.messages;
					$scope.fields[formField.name].visible = formField.visible && !formField.readonly;
					if ($scope.fields[formField.name].visible)
						$scope.fieldsVisible++;
				});
			}
			$scope.getStubbedFieldModel = function(fieldName) {
				if ($scope.fields[fieldName])
					return $scope.fields[fieldName];
				$scope.fields[fieldName] = {
					name: fieldName
				};
				return $scope.fields[fieldName];
			};
			function setPrimaryJournalField() {
				if (!$scope.fields || !$scope.showCommentsAndWorkNotes)
					return;
				angular.forEach($scope.fields, function(item) {
					item.isPrimary = false;
					item.checked = false;
				});
				var visibleFields = Object.keys($scope.fields).filter(function(item) {
					return $scope.fields[item].visible;
				});
				if (visibleFields.indexOf($scope.preferredInput) != -1) {
					var field = $scope.fields[$scope.preferredInput];
					field.checked = true;
					field.isPrimary = true;
					$scope.inputType = $scope.preferredInput;
					primaryJournalField = $scope.preferredInput;
				} else {
					for (var i = 0; i < primaryJournalFieldOrder.length; i++) {
						var fieldName = primaryJournalFieldOrder[i];
						if (visibleFields.indexOf(fieldName) != -1) {
							$scope.fields[fieldName].isPrimary = true;
							primaryJournalField = fieldName;
							$scope.inputType = fieldName;
							$scope.inputTypeValue = $scope.fields[fieldName].value;
							break;
						}
					}
				}
				if(visibleFields.length === 0) {
					primaryJournalField = '';
					$scope.inputType = primaryJournalField;
				} else if (!$scope.inputType && visibleFields.length > 0) {
					primaryJournalField = visibleFields[0];
					$scope.inputType = primaryJournalField;
					$scope.fields[primaryJournalField].isPrimary = true;
				}
				if ($scope.fields && visibleFields.indexOf(primaryJournalField) == -1) {
					var keys = Object.keys($scope.fields);
					if (keys.length)
						$scope.fields[keys[0]].isPrimary = true;
				}
			}
			function safeArialiveAssertive(message) {
				if (window.NOW && window.NOW.accessibility && window.NOW.accessibility.ariaLiveAssertive) {
					window.NOW.accessibility.ariaLiveAssertive(message);
				}
			}
			function setShowAllFields() {
				var ariaLiveAllActivities = '';
				$scope.checkbox.showAllFields = $scope.showAllFields = $scope.allFields && !$scope.allFields.some(function(item) {
					return !item.isActive;
				});
				$scope.hideAllFields = !$scope.allFields || !$scope.allFields.some(function(item) {
					return item.isActive;
				});
				$scope.isFiltered = !$scope.showAllFields || $scope.allFields.some(function(item) {
					return !item.isActive;
				});
				if ($scope.checkbox.showAllFields)
					ariaLiveAllActivities = 'All activities are displayed';
				else if ($scope.hideAllFields)
					ariaLiveAllActivities = 'All activities are hidden';
				safeArialiveAssertive(ariaLiveAllActivities);
			}
			$scope.setPrimary = function(entry) {
				angular.forEach($scope.fields, function(item) {
					item.checked = false;
				});
				for (var i = 0; i < primaryJournalFieldOrder.length; i++) {
					var fieldName = primaryJournalFieldOrder[i];
					if (entry.writable_journal_fields.indexOf(fieldName) != -1) {
						entry.primaryJournalField = fieldName;
						entry.inputType = fieldName;
						return;
					}
				}
				if (!entry.inputType) {
					var primaryField = entry.writable_journal_fields[0];
					entry.primaryJournalField = primaryField;
					entry.inputType = primaryField;
				}
			};
			$scope.updateFieldVisibilityAll = function() {
				$scope.showAllFields = !$scope.showAllFields;
				angular.forEach($scope.allFields, function(item) {
					item.isActive = $scope.showAllFields;
				});
				$scope.updateFieldVisibility();
			};
			$scope.updateFieldVisibility = function() {
				var activeFields = $scope.allFields.map(function(item) {
					return item.name + ',' + item.isActive;
				});
				setShowAllFields();
				emitFilterChange();
				userPreferences
					.setPreference($scope.table + '.activity.filter', activeFields.join(';'))
					.then(function() {
						reset();
						$scope.filterModified = true;
					});
			};
			$scope.configureAvailableFields = function() {
				$window.personalizer($scope.table, 'activity', $scope.sysId);
			};
			function handleFieldInputsOnToggle(){
            	angular.forEach($scope.fields, function(item){
            		var itemIsInput = ($scope.inputType == item.name) ? true : false;
            		if (!itemIsInput)
            			item.value = '';
            		else if ($scope.multipleInputs)
            				item.value = $scope.inputTypeValue;
        			else
        				$scope.inputTypeValue = item.value;
                });
            }
			$scope.isInForm = function() {
				return typeof g_form !== 'undefined';
			}
		   function shouldJournalFieldsToggle(){
			   var toggle = true;
			   if (!$scope.multipleInputs)
				   return toggle;
			   angular.forEach($scope.fields, function(item){
				   if(($scope.inputType != item.name) && item.value)
					  toggle = false;
			   });
			   return toggle;
		   }
		   function focusCollapseButton(val) {
			   var collapseButton = val
				   ? document.querySelector('.sn-stream #multiple-input-journal-entry button.icon-stream-one-input')
				   : document.querySelector('.sn-stream #single-input-journal-entry button.icon-stream-all-input');
			   if (collapseButton) {
				   setTimeout(()=> $(collapseButton).focus(), 0);
			   }
		   }
			$scope.toggleMultipleInputs = function(val, evt) {
				if (evt && evt.type === "keydown" && evt.keyCode !== 13 && evt.keyCode !== 32) return;
				if (!shouldJournalFieldsToggle())
					return;
				userPreferences.setPreference('glide.ui.activity_stream.multiple_inputs', val ? 'true' : 'false')
					.then(function() {
						$scope.useMultipleInputs = val;
						setMultipleInputs();
						if ($scope.multipleInputs === val)
							handleFieldInputsOnToggle();
						focusCollapseButton(val);
					});
			};
			$scope.changeEntryInputType = function(fieldName, entry) {
				var checked = $scope.fields[fieldName].checked;
				entry.inputType = checked ? fieldName : entry.primaryJournalField;
			};
			function processEntries(entries) {
				if (!entries || !entries.length)
					return;
				entries = entries.reverse();
				var newEntries = [];
				angular.forEach(entries, function (entry) {
					var entriesToAdd = [entry];
					if (entry.attachment) {
						entry.type = getAttachmentType(entry.attachment);
						entry.attachment.extension = getAttachmentExt(entry.attachment);
					} else if (entry.is_email === true){
						entry.email = {};
						entry.emailBodyMsg = emailBodyMsg;
						var allFields = entry.entries.custom;
						for(var i = 0; i < allFields.length; i++){
							entry.email[allFields[i].field_name] = {
								label: allFields[i]['field_label'],
								displayValue: allFields[i]['new_value']
							};
							entry.email['is_translation_enabled'] = allFields[i]['is_translation_enabled'];
						}
						entry['entries'].custom = [];
					} else if ($scope.sysId) {
						entriesToAdd = extractJournalEntries(entry);
					} else {
						entriesToAdd = handleJournalEntriesWithoutExtraction(entry);
					}
					putGlobalMember(entry['user_id'], entry['sys_created_by'], entry['initials'], entry['user_image']);
					if (entriesToAdd instanceof Array) {
						entriesToAdd.forEach(function (e) {
							$scope.entries.unshift(e);
							newEntries.unshift(e);
						});
					}
					else {
						$scope.entries.unshift(entriesToAdd);
						newEntries.unshift(entriesToAdd)
					}
					if (source != FROM_FORM)
$scope.entries = $scope.entries.slice(0, 49);
					if ($scope.maxEntries != undefined) {
						var maxNumEntries = parseInt($scope.maxEntries, 10);
$scope.entries = $scope.entries.slice(0, maxNumEntries);
					}
				});
				if ($scope.inlineStreamLoaded) {
					if ($scope.entries.length > 0) {
						removeInlineStreamEntryClass();
					}
				}
				if ($scope.loaded) {
					$scope.$emit("sn.stream.new_entries", newEntries);
					triggerResize();
				}
				else if ($scope.pageSize && $scope.entries.length > $scope.pageSize) {
					setUpPaging();
				}
				$timeout(function() {
					$scope.$emit('sn.stream.entries_change', $scope.entries);
				});
			}
			function removeInlineStream() {
				angular.element(document).find('#sn_form_inline_stream_container').hide().remove();
			}
			function removeInlineStreamEntryClass() {
				angular.element(document).find('#sn_form_inline_stream_entries').removeClass('sn-form-inline-stream-entries-only');
			}
			function addInlineStreamEntryClass() {
				angular.element(document).find('#sn_form_inline_stream_entries').addClass('sn-form-inline-stream-entries-only');
			}
			function setUpPaging() {
				$scope.showAllEntriesButton = true;
				$scope.allEntries = $scope.entries;
				$scope.entries = [];
				loadEntries(0, $scope.pageSize);
			}
			$scope.loadMore = function() {
				if ($scope.entries.length + $scope.pageSize > $scope.allEntries.length) {
					$scope.loadAll();
					return;
				}
				loadEntries($scope.loadedEntries, $scope.loadedEntries + $scope.pageSize);
			};
			$scope.loadAll = function() {
				$scope.showAllEntriesButton = false;
				loadEntries($scope.loadedEntries, $scope.allEntries.length);
			};
			$scope.translateStreamEntryClick = function(entry, isRetry) {
				getTranslationDetails(entry, isRetry);
			};
			$scope.translateStreamEntryKeypress = function(event, entry, isRetry) {
				var key = event.keyCode || event.which;
				if (key === 32) {
					event.preventDefault();
					getTranslationDetails(entry, isRetry);
				}
			};
			function getTranslationDetails(entry, isRetry) {
				if ($injector.has('translateStream')) {
					var handler = $injector.get('translateStream');
					handler.getTranslatedContent(entry, isRetry);
				}
			};
			$scope.translationToggleClick = function(entry) {
				toggleTranslationLink(entry);
			};
			$scope.translationToggleKeypress = function(event, entry) {
				var key = event.keyCode || event.which;
				if (key === 32) {
					event.preventDefault();
					toggleTranslationLink(entry);
				}
			};
			function toggleTranslationLink(entry) {
				if ($injector.has('translateStream')) {
					var handler = $injector.get('translateStream');
					handler.toggleTranslation(entry);
				}
			};
			$scope.$on('sn.stream.translation_successful', function(event, data) {
				data.entry.translatedText = $scope.parseSpecial(data.translatedText);
			});
			function loadEntries(start, end) {
				$scope.entries = $scope.entries.concat($scope.allEntries.slice(start, end));
				$scope.loadedEntries = $scope.entries.length;
				$scope.$emit('sn.stream.entries_change', $scope.entries);
			}
			function getAttachmentType(attachment) {
if (attachment.content_type.startsWith('image/') && attachment.content_type.indexOf("tiff") < 0
					&& attachment.size_bytes < 5 * 1024 * 1024 && attachment.path.indexOf(attachment.sys_id) == 0)
					return 'attachment-image';
				return 'attachment';
			}
			function getAttachmentExt(attachment) {
				var filename = attachment.file_name;
				return filename.substring(filename.lastIndexOf('.') + 1);
			}
			function handleJournalEntriesWithoutExtraction(oneLargeEntry) {
				if (oneLargeEntry.entries.journal.length === 0)
					return oneLargeEntry;
				for (var i = 0; i < oneLargeEntry.entries.journal.length; i++) {
					newLinesToBR(oneLargeEntry.entries.journal);
				}
				return oneLargeEntry;
			}
			function extractJournalEntries(oneLargeEntry) {
				var smallerEntries = [];
				if (oneLargeEntry.entries.journal.length === 0)
					return oneLargeEntry;
				for (var i = 0; i < oneLargeEntry.entries.journal.length; i++) {
					if (verifyDuplicateJournals(oneLargeEntry.entries.journal[i].sys_id))
						continue;
					var journalEntry = angular.copy(oneLargeEntry);
					journalEntry.entries.journal = journalEntry.entries.journal.slice(i, i + 1);
					newLinesToBR(journalEntry.entries.journal);
					journalEntry.entries.changes = [];
					journalEntry.type = 'journal';
					smallerEntries.unshift(journalEntry);
				}
				oneLargeEntry.entries.journal = [];
				oneLargeEntry.type = 'changes';
				if (oneLargeEntry.entries.changes.length > 0)
					smallerEntries.unshift(oneLargeEntry);
				return smallerEntries;
			}
			function verifyDuplicateJournals(journalSysId){
				return $scope.entries.some(function(entry) {
					if (entry.entries.journal)
						return entry.entries.journal.some(function(journal) {
							return journal.sys_id == journalSysId;
						});
				});
			}
			function newLinesToBR(entries) {
				angular.forEach(entries, function(item) {
					if (item.new_value) {
item.new_value = item.new_value.replace(/\n/g, '<br/>');
					}
					if (item.sanitized_new_value) {
item.sanitized_new_value = item.sanitized_new_value.replace(/\n/g, '<br/>');
					}
				});
			}
			function cancelStream() {
				if (_firstPollTimeout) {
					clearTimeout(_firstPollTimeout);
					_firstPollTimeout = false;
				}
				if (!stream)
					return false;
				stream.cancel();
				stream = null;
				return true; 
			}
			function setMultipleInputs() {
				$scope.multipleInputs = $scope.useMultipleInputs;
				if ($scope.useMultipleInputs === true || !$scope.formJournalFields) {
					return;
				}
				var numAffectedFields = 0;
				angular.forEach($scope.formJournalFields, function(item) {
					if (item.mandatory || item.value)
						numAffectedFields++;
				});
				if (numAffectedFields > 0)
					$scope.multipleInputs = true;
			}
			function triggerResize() {
				if (window._frameChanged)
					setTimeout(_frameChanged, 0);
			}
			var filterPopoverButton = angular.element("#activity_field_filter_button");
			var filterPopoverContents = angular.element("#activity_field_filter_popover");
			var filterFocusTrap;
			var scrollingContainer;
			var screenSize;
			$scope.filterOpen = false;
			filterPopoverButton.on("shown.bs.popover", function() {
				$scope.$apply(function () {
					$scope.filterOpen = true;
					filterPopoverContents.parent().parent().attr("role", "presentation");
markListBoxAsFocused('activity_filter_all', false);
				});
				filterFocusTrap = $window.focusTrap(filterPopoverContents[0], {
					clickOutsideDeactivates:true,
					initialFocus: '#activity_filter_all'
				});
				filterFocusTrap.activate();
			});
			filterPopoverButton.on("hidden.bs.popover", function() {
				$scope.$apply(function () {
					$scope.filterOpen = false;
					if ($scope.filterModified) {
						captureFilterMetrics();
						$scope.filterModified = false;
					}
				});
				filterFocusTrap.deactivate();
			});
			filterPopoverButton.on('keydown', function(evt) {
				if (!$scope.filterOpen && evt.keyCode === 13) {
					filterPopoverButton.popover('show');
				}
			});
			filterPopoverContents.on('keydown', function(evt) {
if (evt.keyCode === 38 || (evt.shiftKey && evt.keyCode === 9)) {
					evt.preventDefault();
					var focusedElement = getFocusedElement();
					if (!focusedElement)
						return;
					var previousElementParent = (focusedElement.tagName === 'INPUT') ? focusedElement.parentElement.previousElementSibling : focusedElement.previousElementSibling;
					if (!previousElementParent)
						return;
					focusedElement.removeAttribute('focused');
					var previousElementId = (previousElementParent.tagName === 'SPAN') ? previousElementParent.firstElementChild.id : previousElementParent.id;
					markListBoxAsFocused(previousElementId, true);
} else if (evt.keyCode === 40 || evt.keyCode === 9) {
					evt.preventDefault();
					var focusedElement = getFocusedElement();
					if (!focusedElement)
						return;
					var nextElementParent = (focusedElement.tagName === 'INPUT') ? focusedElement.parentElement.nextElementSibling : focusedElement.nextElementSibling;
					if (!nextElementParent)
						return;
					focusedElement.removeAttribute('focused');
					var nextElementId = (nextElementParent.tagName === 'SPAN') ? nextElementParent.firstElementChild.id : nextElementParent.id;
					markListBoxAsFocused(nextElementId, true);
				}
				if (evt.keyCode !== 27) {
					return;
				}
				filterPopoverButton.popover('hide');
			});
			filterPopoverContents.on("click", "input[type=checkbox]", function() {
				var focusedElement = getFocusedElement();
				if (focusedElement)
					focusedElement.removeAttribute("focused");
				markListBoxAsFocused(this.id, false);
			});
			filterPopoverContents.on("focus", "input[type=checkbox]", function() {
				if (!scrollingContainer) {
					scrollingContainer = filterPopoverContents.parent(".popover-content")[0];
					screenSize = scrollingContainer.offsetHeight;
				}
				var scrollTopPos = scrollingContainer.scrollTop;
				var itemSize = this.parentElement.offsetHeight;
				var offsetTop = this.parentElement.offsetTop;
				var offsetBot = offsetTop + itemSize;
				if (this.id == "activity_filter_all") {
					scrollingContainer.scrollTop = 0;
				}
				else if (scrollTopPos > offsetTop) {
					scrollingContainer.scrollTop = offsetTop;
				}
				else if (offsetBot > screenSize + scrollTopPos) {
					scrollingContainer.scrollTop = offsetBot - screenSize;
				}
			});
			function captureFilterMetrics() {
				if (GlideUXMetrics) {
					var selectedFields = $scope.allFields
						.filter(function(field) {return field.isActive})
						.map(function(field) {return field.name})
						.sort()
						.join();
					var unselectedFields = $scope.allFields
						.filter(function(field) {return !field.isActive})
						.map(function(field) {return field.name})
						.sort()
						.join();
					GlideUXMetrics.track('Filter Activity Selected Fields', {
						table: $scope.table,
						fields: selectedFields
					});
					GlideUXMetrics.track('Filter Activity Unselected Fields', {
						table: $scope.table,
						fields: unselectedFields
					});
				}
			}
			function getFocusedElement() {
				return document.querySelector("#activity_field_filter_listbox [focused]");
			}
			function markListBoxAsFocused(id, setFocus) {
				var filterListBox = document.getElementById('activity_field_filter_listbox');
				if (!filterListBox)
					return;
				filterListBox.setAttribute('aria-activedescendant', id);
				var focusedElement = document.getElementById(id);
				if (!focusedElement)
					return;
				focusedElement.setAttribute('focused', '');
				if (setFocus)
					focusedElement.focus();
			}
			snCustomEvent.fire("sn.stream.loaded");
}).filter('visibleFields', function() {
      return function(fields) {
          var obj = {};
          angular.forEach(fields, function(field) {
              if (field.visible) {
                  obj[field.name] = field;
              }
          });
          return obj;
      }
  });
;
/*! RESOURCE: /scripts/sn/common/stream/directive.snStream.js */
angular.module("sn.common.stream").directive("snStream", function(getTemplateUrl, $http, $sce, $sanitize) {
	"use strict";
	return {
		restrict: "E",
		replace: true,
		scope: {
			table: "=",
			query: "=?",
			sysId: "=?",
			active: "=",
			controls: "=?",
			showCommentsAndWorkNotes: "=?",
			previousActivity: "=?",
			sessions: "=",
			attachments: "=",
board: "=",
formJournalFields: "=",
			useMultipleInputs: "=?",
			preferredInput: "=",
			labels: "=",
			subStream: "=",
			expandEntries: "=",
			scaleAnimatedGifs: "=",
			scaleImages :"=",
			pageSize: "=",
			maxEntries: "@"
		},
		templateUrl: getTemplateUrl("ng_activity_stream.xml"),
		controller: "snStream",
		link: function (scope, element) {
			element.on("click", ".at-mention", function(evt) {
				var userID = angular.element(evt.target).attr('class').substring("at-mention at-mention-user-".length);
				$http({
url: '/api/now/form/mention/user/' + userID,
					method: "GET"
				}).then(function(response) {
					scope.showPopover = true;
					scope.mentionPopoverProfile = response.data.result;
					scope.clickEvent = evt;
				}, function () {
					$http({
url: '/api/now/live/profiles/' + userID,
						method: "GET"
					}).then(function(response) {
						scope.showPopover = true;
						var tempProfile = response.data.result;
						tempProfile.userID = tempProfile.sys_id = response.data.result.document;
						scope.mentionPopoverProfile = tempProfile;
						scope.mentionPopoverProfile.sysID = response.data.result["userID"];
						scope.clickEvent = evt;
					})
				});
			});
			scope.toggleEmailIframe = function(email, event){
				email.expanded = !email.expanded;
				event.preventDefault();
			};
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/stream/directive.formStreamEntry.js */
angular.module('sn.common.stream').directive('formStreamEntry', function(getTemplateUrl) {
	return {
		restrict: 'A',
		templateUrl: getTemplateUrl('record_stream_entry.xml')
	}
});
;
/*! RESOURCE: /scripts/sn/common/stream/directive.snExpandedEmail.js */
angular.module("sn.common.stream").directive("snExpandedEmail", function() {
	"use strict";
	return {
		restrict: "E",
		replace: true,
		scope: {
			email: "="
		},
template: "<iframe style='width: 100%;' class='card activity-stream-email-iframe' src='{{::emailBodySrc}}' title='{{::emailBodyMsg}}'></iframe>",
		controller: function($scope){
			$scope.emailBodySrc = "email_display.do?email_id=" + $scope.email.sys_id.displayValue;
		},
		link: function(scope, element) {
			element.load(function(){
				var bodyHeight = $j(this).get(0).contentWindow.document.body.scrollHeight + "px";
				$j(this).height(bodyHeight);
			});
		}
	};
});
;
/*! RESOURCE: /scripts/app.form_presence/controller.formStream.js */
(function() {
	var journalModel = {};
	window.journalModel = journalModel;
	CustomEvent.observe('sn.form.journal_field.add', function(name, mandatory, readonly, visible, value, label) {
		journalModel[name] = {
			name: name,
			mandatory: mandatory,
			readonly: readonly,
			visible: visible,
			value: value,
			label: label,
			messages: []
		};
	});
	CustomEvent.observe('sn.form.journal_field.readonly', function(name, readonly) {
		modifyJournalAttribute(name, "readonly", readonly);
	});
	CustomEvent.observe('sn.form.journal_field.value', function(name, value) {
		modifyJournalAttribute(name, "value", value);
	});
	CustomEvent.observe('sn.form.journal_field.mandatory', function(name, mandatory) {
		modifyJournalAttribute(name, "mandatory", mandatory);
	});
	CustomEvent.observe('sn.form.journal_field.visible', function(name, visible) {
		modifyJournalAttribute(name, "visible", visible);
	});
	CustomEvent.observe('sn.form.journal_field.label', function(name, visible) {
		modifyJournalAttribute(name, "label", visible);
	});
	CustomEvent.observe('sn.form.journal_field.show_msg', function(name, message, type) {
		var messages = journalModel[name]['messages'].concat([{
			type: type,
			message: message
		}]);
		modifyJournalAttribute(name, 'messages', messages);
	});
	CustomEvent.observe('sn.form.journal_field.hide_msg', function(name, clearAll) {
		if (journalModel[name]['messages'].length == 0)
			return;
		var desiredValue = [];
		if (!clearAll)
			desiredValue = journalModel[name]['messages'].slice(1);
		modifyJournalAttribute(name, 'messages', desiredValue);
	});
	CustomEvent.observe('sn.form.hide_all_field_msg', function(type) {
		var fields = Object.keys(journalModel);
		for (var i = 0; i < fields.length; i++) {
			var f = fields[i];
			if (journalModel[f].messages.length == 0)
				continue;
			var messages = [];
			if (type) {
				var oldMessages = angular.copy(journalModel[f].messages);
				for (var j = 0; j < oldMessages.length; j++) {
					if (oldMessages[j].type != type)
						messages.push(oldMessages[j]);
				}
			}
			modifyJournalAttribute(f, 'messages', messages);
		}
	});
	CustomEvent.observe('sn.stream.insert', function(field, text) {
		if (typeof window.g_form !== "undefined")
			g_form.getControl(field).value = NOW.STREAM_VALUE_KEY + text;
	});
	CustomEvent.observe('sn.stream.clear', function(field) {
		if (window.g_form)
			journalModel[field].value = g_form.getControl(field).value = "";
	});
	function modifyJournalAttribute(field, prop, value) {
		if (journalModel[field][prop] === value)
			return;
		journalModel[field][prop] = value;
		CustomEvent.fire('sn.form.journal_field.changed');
	}
	angular.module('sn.common.stream').controller('formStream', function($scope, snCustomEvent, i18n) {
		var isFiltered = !angular.element('.activity-stream-label-filtered').hasClass('hide');
		var _inlineTemplateCache;
		function renderLabel(count) {
			var processedLabel = _getLabel(count);
			angular.element('.activity-stream-label-counter').html(processedLabel);
			angular.element('.activity-stream-label-filtered').toggleClass('hide', !isFiltered);
		}
		function _getLabel(count) {
			var label = 'Activities: {0}';
			return i18n.getMessage(label).withValues([count]);
		}
		function _getInlineEntries() {
			if (_inlineTemplateCache === 0) {
				return 0;
			}
			_inlineTemplateCache = document.querySelectorAll('#sn_form_inline_stream_container ul.activities-form li.h-card_comments').length;
			return _inlineTemplateCache;
		}
		$scope.$on('sn.stream.entries_change', function(evt, entries) {
			var inlineTemplateCount = _getInlineEntries();
			var count = inlineTemplateCount + entries.length;
			renderLabel(count);
		});
		$scope.$on('sn.stream.is_filtered_change', function(evt, filtered) {
			isFiltered = filtered;
		});
		$scope.formJournalFields = journalModel;
		$scope.formJournalFieldsVisible = false;
		setUp();
		snCustomEvent.observe('sn.form.journal_field.changed', function() {
			setUp();
			if (!$scope.$$phase)
				$scope.$apply();
		});
		function setUp() {
			setInputValue();
		}
		function setInputValue() {
			angular.forEach($scope.formJournalFields, function(item) {
				if (typeof window.g_form === "undefined")
					return;
				item.value = g_form.getValue(item.name);
				if (!item.readonly && item.visible && item.value) {
					$scope.$broadcast('sn.stream.input_value', item.name, item.value);
				}
			});
		}
	})
})();
;
/*! RESOURCE: /scripts/app.form_presence/directive.scroll_form.js */
angular.module('sn.common.stream').directive('scrollFrom', function() {
	"use strict";
	var SCROLL_TOP_PAD = 10;
	return {
		restrict: 'A',
		link: function($scope, $element, $attrs) {
			var target = $attrs.scrollFrom;
			$j(target).click(function(evt) {
				if (window.g_form) {
					var tab = g_form._getTabNameForElement($element);
					if (tab)
						g_form.activateTab(tab);
				}
				$element.find('textarea').filter(':visible:first').focus();
				var $scrollRoot = $element.closest('.form-group');
				if ($scrollRoot.length === 0)
					$scrollRoot = $element;
				var $scrollParent = $scrollRoot.scrollParent();
				var offset = $element.offset().top - $scrollParent.offset().top - SCROLL_TOP_PAD + $scrollParent.scrollTop();
				$scrollParent.animate({
					scrollTop: offset
				}, '500', 'swing');
				evt.stopPropagation();
			})
		}
	}
});
;
;
/*! RESOURCE: /scripts/sn/common/stream/js_includes_stream.js */
/*! RESOURCE: /scripts/sn/common/dynamicTranslation/_module.js */
angular.module('sn.common.dynamicTranslation', ['sn.common.i18n']);
;
/*! RESOURCE: /scripts/sn/common/dynamicTranslation/service.dynamicTranslation.js */
angular.module('sn.common.dynamicTranslation').provider('dynamicTranslation', function () {
    function getDynamicTranslationRequestConfig() {
        return {
            headers: {
'Content-Type': 'application/json',
'Accept': 'application/json'
            }
        };
    }
    function setSourceInParms(parms) {
        parms = parms || {};
        parms.event = parms.event || {};
        parms.event.source = 'portalAPI';
        return parms;
    }
    function isNotValidInputText(msg) {
        return (typeof msg !== 'string');
    }
    function isNotValidString(str) {
        return ((str == null) || (typeof str !== 'string')) ? true : (str.trim().length === 0);
    }
    function isNotValidTranslator(translator) {
        return ((translator != null) && (typeof translator !== 'string'));
    }
    function isNotValidTargetLanguages(targetLanguages) {
        if (!Array.isArray(targetLanguages) || (targetLanguages.length === 0)) {
            return true;
        }
        for (var index = 0; index < targetLanguages.length; index++) {
            if (isNotValidString(targetLanguages[index])) {
                return true;
            }
        }
        return false;
    }
    function isNotValidAdditionalParameters(additionalParameters) {
        if (!Array.isArray(additionalParameters) || (additionalParameters.length === 0)) {
            return true;
        } else {
            for (var index = 0; index < additionalParameters.length; index++) {
                var additionalParameter = additionalParameters[index];
                if (!additionalParameter || (additionalParameter.constructor !== {}.constructor) || (Object.keys(additionalParameter).length !== 2)) {
                    return true;
                }
                for (eachkey in additionalParameter) {
                    if (!(eachkey === 'parameterName' || eachkey === 'parameterValue') || isNotValidString(additionalParameter[eachkey])) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    function isNotValidTexts(texts) {
        if (!Array.isArray(texts) || (texts.length === 0)) {
            return true;
        }
        for (var index = 0; index < texts.length; index++) {
            if (isNotValidInputText(texts[index])) {
                return true;
            }
        }
        return false;
    }
    var errorHandler = {
        rejectErrorMessage: function (response) {
            if (this.hasMultipleTexts) {
                this.defer.reject({
                    'code': this.code,
                    'message': response,
                    'status': 'Error'
                });
            } else {
                this.defer.reject({
                    'code': this.code,
                    'message': response
                });
            }
        }
    };
    function validateOptionalParameters(parms, defer, i18n, isTranslation, hasMultipleTexts) {
        errorHandler['hasMultipleTexts'] = hasMultipleTexts;
        errorHandler['defer'] = defer;
        if (parms.constructor !== {}.constructor) {
            errorHandler['code'] = '40006';
            i18n.getMessage("Additional parameters are invalid", errorHandler.rejectErrorMessage.bind(errorHandler));
            return false;
        }
        if (isNotValidTranslator(parms.translator)) {
            errorHandler['code'] = '40003';
            i18n.getMessage("Translator (\"translator\" field) is invalid", errorHandler.rejectErrorMessage.bind(errorHandler));
            return false;
        }
        if (isTranslation) {
            if ((parms.sourceLanguage != null) && isNotValidString(parms.sourceLanguage)) {
                errorHandler['code'] = '40008';
                i18n.getMessage("Source language (\"sourceLanguage\" field) is invalid", errorHandler.rejectErrorMessage.bind(errorHandler));
                return false;
            }
            if (parms.targetLanguages && isNotValidTargetLanguages(parms.targetLanguages)) {
                errorHandler['code'] = '40007';
                i18n.getMessage("Target languages (\"targetLanguages\" field) are invalid", errorHandler.rejectErrorMessage.bind(errorHandler));
                return false;
            }
        }
        if (parms.additionalParameters && isNotValidAdditionalParameters(parms.additionalParameters)) {
            errorHandler['code'] = '40006';
            i18n.getMessage("Additional parameters are invalid", errorHandler.rejectErrorMessage.bind(errorHandler));
            return false;
        }
        return true;
    }
    function handleErrorResponse(response, defer, i18n, hasMultipleTexts) {
        errorHandler['hasMultipleTexts'] = hasMultipleTexts;
        errorHandler['defer'] = defer;
        if (response === 400) {
            errorHandler['code'] = '40001';
            i18n.getMessage("Dynamic Translation plugin is not installed", errorHandler.rejectErrorMessage.bind(errorHandler));
        } else {
            errorHandler['code'] = '40051';
            i18n.getMessage("Unknown error occurred", errorHandler.rejectErrorMessage.bind(errorHandler));
        }
    }
    this.$get = function ($http, $q, i18n) {
        return {
            getTranslation: function (textToTranslate, parms) {
var GET_DYNAMIC_TRANSLATION = "/api/sn_dt/v1/dynamic_translation/get_dynamic_translation";
                function getOnSuccessResponse(data) {
                    var successResponse = {
                        'translations': data.result.translations,
                        'translator': data.result.translator
                    };
                    if (data.result.detectedLanguage) {
                        successResponse['detectedLanguage'] = data.result.detectedLanguage;
                    }
                    return successResponse;
                }
                function getOnErrorResponse(data) {
                    return JSON.parse(data.result.errorMessage);
                }
                var defer = $q.defer();
                if (isNotValidInputText(textToTranslate)) {
                    errorHandler['defer'] = defer;
                    errorHandler['code'] = '40000';
                    i18n.getMessage("Text is missing or invalid", errorHandler.rejectErrorMessage.bind(errorHandler));
                } else if (!parms || validateOptionalParameters(parms, defer, i18n, true, false)) {
                    var requestBody = {
                        'textToTranslate': textToTranslate,
                        'parms': setSourceInParms(parms)
                    };
                    var config = getDynamicTranslationRequestConfig();
                    $http.post(GET_DYNAMIC_TRANSLATION, requestBody, config).success(function (data) {
                        if (!data.result.isError)
                            defer.resolve(getOnSuccessResponse(data));
                        else
                            defer.reject(getOnErrorResponse(data));
                    }).error(function (error, status) {
                        handleErrorResponse(status, defer, i18n, false);
                    });
                }
                return defer.promise;
            },
            getTranslations: function (textsToTranslate, parms) {
var GET_DYNAMIC_TRANSLATIONS = "/api/sn_dt/v1/dynamic_translation/get_dynamic_translations";
                function getOnSuccessResponse(response) {
                    var successResponse = {
                        'status': response.result.status,
                        'translations': response.result.translations,
                        'translator': response.result.translator
                    };
                    return successResponse;
                }
                function getOnErrorResponse(response) {
                    var errorDetails = JSON.parse(response.result.errorMessage);
                    var errorResponse = {
                        'status': errorDetails.status,
                        'code': errorDetails.code,
                        'message': errorDetails.message
                    };
                    if (errorDetails['translations']) {
                        errorResponse['translations'] = errorDetails['translations'];
                    }
                    return errorDetails;
                }
                var defer = $q.defer();
                if ((!textsToTranslate) || isNotValidTexts(textsToTranslate)) {
                    errorHandler['defer'] = defer;
                    errorHandler['code'] = '40000';
                    errorHandler['hasMultipleTexts'] = true;
                    i18n.getMessage("Text is missing or invalid", errorHandler.rejectErrorMessage.bind(errorHandler));
                } else if (!parms || validateOptionalParameters(parms, defer, i18n, true, true)) {
                    var requestBody = {
                        'textsToTranslate': textsToTranslate,
                        'parms': setSourceInParms(parms)
                    };
                    var config = getDynamicTranslationRequestConfig();
                    $http.post(GET_DYNAMIC_TRANSLATIONS, requestBody, config).success(function (data) {
                        if (!data.result.isError)
                            defer.resolve(getOnSuccessResponse(data));
                        else
                            defer.reject(getOnErrorResponse(data));
                    }).error(function (error, status) {
                        handleErrorResponse(status, defer, i18n, true);
                    });
                }
                return defer.promise;
            },
            isTranslationEnabled: function (translator) {
                var defer = $q.defer();
                if ((translator) && (typeof translator !== 'string')) {
                    i18n.getMessage("Translator (\"translator\" field) is invalid", function (response) {
                        defer.reject({
                            'code': '40003',
                            'message': response
                        });
                    });
                } else {
                    var params = {
                        event: {
                            eventName: 'isTranslationEnabled'
                        },
                        translator: translator
                    };
                    this.isEnabled(params).then(
                        function (data) {
                            defer.resolve(data.translation);
                        },
                        function (data) {
                            defer.reject(false);
                        }
                    );
                }
                return defer.promise;
            },
            getDetectedLanguage: function (text, parms) {
var GET_DETECTED_LANGUAGE = '/api/sn_dt/v1/dynamic_translation/get_detected_language';
                function getOnSuccessResponse(data) {
                    return {
                        'detectedLanguage': data.result.detectedLanguage,
                        'alternatives': data.result.alternatives,
                        'translator': data.result.translator
                    };
                }
                function getOnErrorResponse(data) {
                    return JSON.parse(data.result.errorMessage);
                }
                var defer = $q.defer();
                if (isNotValidInputText(text)) {
                    errorHandler['defer'] = defer;
                    errorHandler['code'] = '40000';
                    i18n.getMessage("Text is missing or invalid", errorHandler.rejectErrorMessage.bind(errorHandler));
                } else if (!parms || validateOptionalParameters(parms, defer, i18n, false, false)) {
                    var requestBody = {
                        'text': text,
                        'parms': setSourceInParms(parms)
                    };
                    var config = getDynamicTranslationRequestConfig();
                    $http.post(GET_DETECTED_LANGUAGE, requestBody, config).success(function (data) {
                        if (!data.result.isError)
                            defer.resolve(getOnSuccessResponse(data));
                        else
                            defer.reject(getOnErrorResponse(data));
                    }).error(function (response, status) {
                        handleErrorResponse(status, defer, i18n, false);
                    });
                }
                return defer.promise;
            },
            getDetectedLanguages: function (texts, parms) {
var GET_DETECTED_LANGUAGES = '/api/sn_dt/v1/dynamic_translation/get_detected_languages';
                function getOnSuccessResponse(response) {
                    var successResponse = {
                        'status': response.result.status,
                        'detections': response.result.detections,
                        'translator': response.result.translator
                    };
                    return successResponse;
                }
                function getOnErrorResponse(response) {
                    var errorDetails = JSON.parse(response.result.errorMessage);
                    var errorResponse = {
                        'status': errorDetails.status,
                        'code': errorDetails.code,
                        'message': errorDetails.message
                    };
                    if (errorDetails['detections']) {
                        errorResponse['detections'] = errorDetails['detections'];
                    }
                    return errorDetails;
                }
                var defer = $q.defer();
                if ((!texts) || isNotValidTexts(texts)) {
                    errorHandler['defer'] = defer;
                    errorHandler['code'] = '40000';
                    errorHandler['hasMultipleTexts'] = true;
                    i18n.getMessage("Text is missing or invalid", errorHandler.rejectErrorMessage.bind(errorHandler));
                } else if (!parms || validateOptionalParameters(parms, defer, i18n, false, true)) {
                    var requestBody = {
                        'texts': texts,
                        'parms': setSourceInParms(parms)
                    };
                    var config = getDynamicTranslationRequestConfig();
                    $http.post(GET_DETECTED_LANGUAGES, requestBody, config).success(function (data) {
                        if (!data.result.isError)
                            defer.resolve(getOnSuccessResponse(data));
                        else
                            defer.reject(getOnErrorResponse(data));
                    }).error(function (response, status) {
                        handleErrorResponse(status, defer, i18n, true);
                    });
                }
                return defer.promise;
            },
            isEnabled: function (parms) {
var IS_ENABLED = "/api/sn_dt/v1/dynamic_translation/is_enabled";
                function isValidTranslator(translator) {
                    return (translator && (typeof translator !== 'string')) ? false : true;
                }
                var defer = $q.defer();
                var translator = (parms && (parms.constructor === {}.constructor)) ? parms.translator : parms;
                if (isValidTranslator(translator)) {
                    parms = (typeof parms === 'string') ? {
                        'translator': translator
                    } : parms;
                    var requestBody = {
                        'parms': setSourceInParms(parms)
                    };
                    var config = getDynamicTranslationRequestConfig();
                    $http.post(IS_ENABLED, requestBody, config).success(function (data) {
                        defer.resolve(data.result);
                    }).error(function (response, status) {
                        defer.resolve({
                            'translation': false,
                            'detection': false,
                            'batchTranslation': false,
                            'batchDetection': false
                        });
                    });
                } else {
                    i18n.getMessage("Translator (\"translator\" field) is invalid", function (response) {
                        defer.reject({
                            'code': '40003',
                            'message': response
                        });
                    });
                }
                return defer.promise;
            }
        };
    };
});
;
;
/*! RESOURCE: /scripts/sn/common/dynamicTranslation/js_includes_dynamicTranslation.js */
/*! RESOURCE: /scripts/doctype/GlideWebAnalytics.js */
var GlideWebAnalytics = (function() {
		function subscribe() {
			
			window.snWebaConfig = window.snWebaConfig || {};
			
			if (window.snWebaConfig.subscribed && window.snWebaConfig.subscribed == true)
				return;
				
			var ambClient = getAMB();
		
			if (ambClient == undefined || ambClient == "")
				return;
			
var webaChannelId = "/weba/config";
			var webaCh = ambClient.getChannel(webaChannelId);
			webaCh.subscribe(function(response) {
	
				if (window.snWebaConfig == undefined || window.snWebaConfig == null)
					window.snWebaConfig = {};
	
				var oldConfig = {
					siteId : (window.snWebaConfig.siteId)? window.snWebaConfig.siteId: "0" ,
					trackerURL : (window.snWebaConfig.trackerURL)? window.snWebaConfig.trackerURL: ""
				};
	
				window.snWebaConfig.siteId = response.data.weba_site_id;
				window.snWebaConfig.trackerURL = response.data.weba_rx_url;
				window.snWebaConfig.webaScriptPath = response.data.weba_script_path;
	
				handleConfigUpdate(oldConfig, window.snWebaConfig);
			});
			ambClient.connect();
			window.snWebaConfig.subscribed = true;
		}
		
	function getAMB(){
		
		var ambClient = window.snWebaConfig.ambClient;
		if (ambClient)
			return ambClient;
		
		window.snWebaConfig.ambClient = (window.g_ambClient) ? window.g_ambClient : ((window.amb)? window.amb.getClient(): "");
		
		return window.snWebaConfig.ambClient;
	}
	
	function handleConfigUpdate(oldConfig, newConfig) {
		
		if (shouldRemoveTracker(oldConfig, newConfig))
			removeTracker();
		
		else if (shouldUpdateTracker(oldConfig, newConfig))
			updateTracker(oldConfig, newConfig);
		
		else if (shouldInsertTracker(oldConfig, newConfig))
			insertTracker(newConfig);
	}
	
	function shouldRemoveTracker(oldConfig, newConfig){
		if (newConfig.siteId == "0" || newConfig.trackerURL == "")
			return true;
		
		return false;
	}
	
	function shouldUpdateTracker(oldConfig, newConfig){
		
		if (oldConfig.siteId && oldConfig.siteId != "0" && oldConfig.siteId != newConfig.siteId)
			return true;
		
		if (oldConfig.trackerURL && oldConfig.trackerURL != newConfig.trackerURL)
			return true;
		
		return false;
	}
	
	function shouldInsertTracker(oldConfig, newConfig){
		
		if (oldConfig.siteId == undefined || oldConfig.siteId == "0")
			return true;
		
		if (oldConfig.trackerURL == undefined || oldConfig.trackerURL == "")
			return true;
		
		return false;
	}
	
	function removeTracker() {
		
		if (!trackerExists())
			return;
		
		removeWebaTracker();
		removeWebaScript();
		removeWebaElements();
	}
	
	function removeWebaTracker() {
		
		var document =  window.parent.document;
		
		var trackerScriptId = "webaTracker";
		var trackEle = document.getElementById(trackerScriptId);
		trackEle.parentNode.removeChild(trackEle);
	}
	
	function removeWebaScript() {
		
		var document =  window.parent.document;
		var asyncTrackEle = document.getElementById('webaScript');
		
		if (asyncTrackEle == undefined)
			return;
		
		var src = asyncTrackEle.src;
		
		if (src != undefined && src.indexOf("piwik") > 0) 
			asyncTrackEle.parentNode.removeChild(asyncTrackEle);
	}
	
	function removeWebaElements() {
		
		var document =  window.parent.document;
		var webaEle = document.getElementsByClassName("weba");
		var webaSize = webaEle.length - 1;
		
		while (webaSize >= 0){
			webaEle[webaSize].parentNode.removeChild(webaEle[webaSize]);
			webaSize--;
		}
	}
	
	function updateTracker(oldConfig, newConfig) {
		
		if (!trackerExists())
			return;
		
		var document =  window.parent.document;
		var head = document.head || document.getElementsByTagName('head')[0];
		
		var updateScript = "_paq.push(['setSiteId', " + newConfig.siteId + "]);" + "_paq.push(['setTrackerUrl', " + "'" + newConfig.trackerURL + "'" + "]);";
		var uEle = window.document.createElement("script");
		uEle.text = updateScript;
		uEle.className = "weba";
		head.appendChild(uEle);
	}
	
	function insertTracker(newConfig, additionalData) {
		
		var document =  window.parent.document;
		var head = document.head || document.getElementsByTagName('head')[0];
		
		if (trackerExists()) 
			return;
		
		if (!isConfigValid(newConfig))
			return;
		
		var trackerScript = generateTrackerScript(newConfig, additionalData);
		
		var trackerElement = getOrCreateTracker();
		trackerElement.text = trackerScript;
		
		head.appendChild(trackerElement);
	}
			
	function applyTracker(additionalData) {
		insertTracker(window.snWebaConfig, additionalData);
		subscribe();
	}
	function applyTrackEvent(category, key, value, additionalValue) {
		
		insertEventTracker(category, key, value, additionalValue);
		subscribe();
	}
	
	function insertEventTracker(category, key, value, additionalValue) {
		
		if (!isConfigValid(window.snWebaConfig))
			return;
		if (!trackerExists())
			insertTracker(window.snWebaConfig);
		
		if (typeof category != "string" || typeof key != "string" || typeof value != "string")
			return;
		
		if (additionalValue)
			additionalValue = (typeof additionalValue == "number")? additionalValue: 0;
		var eventItems = [ "trackEvent", category, key, value, additionalValue ];
		var eventScript = "_paq.push(" + JSON.stringify(eventItems) + ");";
		
		var document =  window.parent.document;
		var head = document.head || document.getElementsByTagName('head')[0];
		var scriptEle = window.document.createElement("script");
		scriptEle.className = "weba";
		scriptEle.text = eventScript;
		
		head.appendChild(scriptEle);
	}
	
	function trackerExists() {
		
		var document =  window.parent.document;
		
		var trackEle = document.getElementById("webaTracker");
		
		if (trackEle)
			return true;
		
		return false;
	}
	
	function isConfigValid(newConfig) {
		
		var zero = "0";		
		var webaSiteId = (newConfig && newConfig.siteId) ? newConfig.siteId : zero;
		var trackerURL = (newConfig && newConfig.trackerURL) ? newConfig.trackerURL : "";
	
		if (webaSiteId == null || webaSiteId == "")
			return false;
		
		if (webaSiteId == zero )
			return false;
		
		if (trackerURL == null || trackerURL == "")
			return false;
		
		return true;
	}
	
	function getOrCreateTracker() {
		
		var trackerScriptId = "webaTracker";
		
		var document = window.parent.document;
		
		var trackEle = document.getElementById(trackerScriptId);
		
		if (trackEle)
			return trackEle;
			
		trackEle = document.createElement("script");
		trackEle.id = trackerScriptId;
trackEle.type = "text/javascript";
		
		return trackEle;	
	}
	
	function getUserId(additionalData) {
		
		if (window.NOW && window.NOW.user_id && window.NOW.user_id != "")
			return window.NOW.user_id;
		
		else if (additionalData && additionalData.userId){
			
			return additionalData.userId;
		}
		
		else if (window.NOW && window.NOW.session_id)
			return window.NOW.session_id;
		
		else {
			
			var userObj = (window.NOW)? window.NOW.user: null;
			
			if (userObj && userObj.userID)
				return userObj.userID;
		}
		
		return "";
	}
	
	function generateTrackerScript(webaConfig, additionalData) {
		
		var trackerURL = webaConfig.trackerURL;
		
if (trackerURL.endsWith("/"))
			trackerURL = webaConfig.trackerURL.substring(0, trackerURL.length - 1);
		
		var userId = getUserId(additionalData);
			
		var script = "var _paq = _paq || [];";	
		
		if (userId && userId != ""){
			script += "_paq.push(['setUserId', '" + userId + "']);";
		}
		
		script += "_paq.push(['trackPageView']); _paq.push(['enableLinkTracking']);";		
		script += "(function() {_paq.push(['setTrackerUrl','" + trackerURL +  "']);" 
				+ "_paq.push(['setSiteId', " + webaConfig.siteId + "]);" 
+ "var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0]; g.type='text/javascript'; g.async=true; "
				+ "g.defer=true; g.src='" + webaConfig.webaScriptPath + "'; " 
				+ "g.id='webaScript';s.parentNode.insertBefore(g,s); })();";
		
		return script;
	}
	
	var api = {	
			
				trackPage: function(additionalData) {
										
					if (window.document.readyState == "complete") 
						applyTracker(additionalData);
					
					else
						window.addEventListener("load", function() {
							applyTracker(additionalData);
						},	false);
					
				},
			
				trackEvent: function(category, key, value, additionalValue, delayInMs) {
					if (delayInMs == undefined)
						delayInMs = 3000;
					
					window.setTimeout(function() {
						applyTrackEvent(category, key, value, additionalValue);
					}, delayInMs);
					
				}
	}
	
	return api;
})();
;
/*! RESOURCE: /scripts/now_ux_metrics.js */
var GlideUXMetrics = (function () {
	function setMetaData(eventName, data) {
		var data = data || {};
		if (eventName == 'USER_NAVIGATE'  || eventName == 'EXPERIENCE_START') {
			var meta = data.meta || {};
			meta.url =  meta.url || (meta.pageTitle ? meta.url : window.location.pathname + window.location.search);
meta.pageTitle = meta.pageTitle || (window.document.title || '').split(/\s\|\s/)[0];
			meta.selectedContent = meta.selectedContent || {};
			if (!meta.selectedContent.isSeismicApp)
				meta.selectedContent.isSeismicApp = false;
		}
		return data;
	}
	function track(eventName, data, config) {
		if (!eventName) return;
		var payload = {
			"eventName": eventName, "data": setMetaData(eventName, data), "config": config
		}
		window.top.dispatchEvent(new CustomEvent('GLIDE_UX_METRICS', {detail: payload}));
	}
	function trackPerformance(key, metrics) {
		if (!isPerformanceMonitoringEnabled()) return;
		if (!key || !metrics) return;
		metrics = metrics instanceof Array? metrics: [metrics];
		var payload = {
			eventName: '$PERF-DATA',
			data: {key, metrics},
			config: {level: 5, type: 'usage'}
		};
		window.top.dispatchEvent(new CustomEvent('GLIDE_UX_METRICS', {detail: payload}));
	}
	function isPerformanceMonitoringEnabled() {
		var isGlobalPerfEnabled = !!('true' === 'true');
		var isUi16PerfEnabled = !!('true' === 'true');
		return isGlobalPerfEnabled && isUi16PerfEnabled;
	}
	return {
		track: track,
		trackPerformance: trackPerformance
	};
})();
;
;
/*! RESOURCE: /scripts/sn/common/js_includes_common.js */

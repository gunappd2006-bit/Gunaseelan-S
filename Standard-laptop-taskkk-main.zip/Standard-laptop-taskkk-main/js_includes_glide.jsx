/*! RESOURCE: /scripts/sn/common/glide/_module.js */
angular.module('sn.common.glide', [
	'sn.common.util'
]);
;
/*! RESOURCE: /scripts/sn/common/glide/factory.glideUrlBuilder.js */
angular.module('sn.common.glide').factory('glideUrlBuilder', ['$window', function($window) {
	"use strict";
	function GlideUrl(contextPath){
		var objDef = {
			contextPath: '',
			params: {},
			encodedString: '',
			encode: true,
			setFromCurrent: function() {
				this.setFromString($window.location.href);
			},
			setFromString:function(href) {
				var pos = href.indexOf('?');
				if (pos < 0) {
					this.contextPath = href;
					return;
				}
				this.contextPath = href.slice(0, pos);
				var hashes = href.slice(pos + 1).split('&');
				var i = hashes.length;
				while (i--) {
					var pos = hashes[i].indexOf('=');
					this.params[hashes[i].substring(0, pos)] = hashes[i].substring(++pos);
				}
			},
			setContextPath: function(c) {
				this.contextPath = c;
			},
			getParam: function(p) {
				return this.params[p];
			},
			getParams: function() {
				return this.params;
			},
			addParam: function(name, value) {
				this.params[name] = value;
				return this;
			},
			addToken: function() {
				if (typeof g_ck != 'undefined' && g_ck != "")
					this.addParam('sysparm_ck', g_ck);
				return this;
			},
			deleteParam: function(name) {
				delete this.params[name];
			},
			addEncodedString: function(s) {
				if (!s)
					return;
				if (s.substr(0, 1) != "&")
					this.encodedString += "&";
				this.encodedString += s;
				return this;
			},
			getQueryString: function(additionalParams) {
				var qs = this._getParamsForURL(this.params);
				qs += this._getParamsForURL(additionalParams);
				qs += this.encodedString;
				if (qs.length == 0)
					return "";
				return qs.substring(1);
			},
			_getParamsForURL: function(params) {
				if (!params)
					return '';
				var url = '';
				for (var n in params) {
					var p = params[n] || '';
					url += '&' + n + '=' + (this.encode ? encodeURIComponent(p + '') : p);
				}
				return url;
			},
			getURL: function(additionalParams) {
				var url = this.contextPath;
				var qs = this.getQueryString(additionalParams);
				if (qs)
					url += "?" + qs;
				return url;
			},
			setEncode: function(b) {
				this.encode = b;
			},
			toString: function() { return 'GlideURL'; }
		}
		return objDef;
	}
	return {
		newGlideUrl: function(contextPath) {
			var glideUrl = new GlideUrl();
			glideUrl.setFromString(contextPath ? contextPath : '');
			return glideUrl;
		},
		refresh: function(){
			$window.location.replace( $window.location.href );
		},
		getCancelableLink: function(link) {
			if ($window.NOW && $window.NOW.g_cancelPreviousTransaction) {
				var nextChar = link.indexOf('?') > -1 ? '&' : '?';
				link += nextChar + "sysparm_cancelable=true";
			}
			return link;
		}
	};
}]);
;
/*! RESOURCE: /scripts/sn/common/glide/service.queryFilter.js */
angular.module('sn.common.glide').factory('queryFilter', function() {
	"use strict";
	return {
		create : function() {
			var that = {};
			that.conditions = [];
			function newCondition(field, operator, value, label, displayValue, type){
				var condition = {
					field: field,
					operator: operator,
					value: value,
					displayValue: displayValue,
					label: label,
					left: null,
					right: null,
					type: null,
					setValue: function(value, displayValue){
						this.value = value;
						this.displayValue = displayValue ? displayValue : value;
					}
				};
				if (type)
					condition.type = type;
				return condition;
			}
			function addCondition(condition) {
				that.conditions.push(condition);
				return condition;
			}
			function removeCondition(condition) {
				for (var i = that.conditions.length-1; i >= 0; i--) {
					if (that.conditions[i] === condition)
						that.conditions.splice(i, 1);
				}
			}
			function getConditionsByField(conditions, field){
				var conditionsToReturn = [];
				for(var condition in conditions){
					if (conditions.hasOwnProperty(condition)){
						if (conditions[condition].field == field)
							conditionsToReturn.push(conditions[condition]);
					}
				}
				return conditionsToReturn;
			}
			function encodeCondition(condition){
				var output = "";
				if (condition.hasOwnProperty("left") && condition.left){
					output += encodeCondition(condition.left);
				}
				if (condition.hasOwnProperty("right") && condition.right){
					var right = encodeCondition(condition.right);
					if (right.length > 0){
						output += "^" + condition.type + right;
					}
				}
				if (condition.field){
					output += condition.field;
					output += condition.operator;
					if (condition.value !== null && typeof condition.value !== "undefined")
						output += condition.value;
				}
				return output;
			}
			function createEncodedQuery() {
				var eq = "";
				var ca = that.conditions;
				for (var i = 0; i < ca.length; i++) {
					var condition = ca[i];
					if (eq.length)
						eq += '^';
					eq += encodeCondition(condition);
				}
				eq += "^EQ";
				return eq;
			}
			that.addCondition = addCondition;
			that.newCondition = newCondition;
			that.createEncodedQuery = createEncodedQuery;
			that.getConditionsByField = getConditionsByField;
			that.removeCondition = removeCondition;
			return that;
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/glide/service.filterExpressionParser.js */
angular.module('sn.common.glide').factory('filterExpressionParser', function() {
	'use strict';
	var operatorExpressions = [{
		wildcardExp: '(.*)',
		operator: 'STARTSWITH',
		toExpression: function(filter) {
			return filter;
		}
	},{
		wildcardExp: '^\\*(.*)',
		operator: 'LIKE',
		toExpression: function(filter) {
			return (filter === '*' ? filter : '*' + filter);
		}
	},{
		wildcardExp: '^\\.(.*)',
		operator: 'LIKE',
		toExpression: function(filter) {
			return '.' + filter;
		}
	},{
		wildcardExp: '^%(.*)',
		operator: 'ENDSWITH',
		toExpression: function(filter) {
			return (filter === '%' ? filter : '%' + filter);
		}
	},{
		wildcardExp: '(.*)%',
		operator: 'LIKE',
		toExpression: function(filter) {
			return filter + '%';
		}
	},{
		wildcardExp: '^=(.*)',
		operator: '=',
		toExpression: function(filter) {
			return (filter === '=' ? filter : '=' + filter);
		}
	},{
		wildcardExp: '^!\\*(.*)',
		operator: 'NOT LIKE',
		toExpression: function(filter) {
			return (filter === '!*' || filter === '!' ? filter : '!*' + filter);
		}
	},{
		wildcardExp: '^!=(.*)',
		operator: '!=',
		toExpression: function(filter) {
			return (filter === '!=' || filter === '!' ? filter : '!=' + filter);
		}
	}, {
		wildcardExp: '^\\*\\*$',
		operator: 'ANYTHING',
		toExpression: function() {
			return "ANYTHING";
		}
	}];
	return {
		getOperatorExpressionForOperator: function(operator) {
			for (var i = 0; i < operatorExpressions.length; i++) {
				var item = operatorExpressions[i];
				if (item.operator === operator)
					return item;
			}
			throw {
				name: 'OperatorNotSupported',
				message: 'The operator ' + operator + ' is not in the list of operatorExpressions.'
			};
		},
		parse: function(val, defaultOperator) {
			var parsedValue = {
				filterText: val,
				operator: defaultOperator || 'STARTSWITH'
			};
			for (var i = 1; i < operatorExpressions.length; i++) {
				var operatorItem = operatorExpressions[i];
				var match = val.match(operatorItem.wildcardExp);
				if (match && match[1] !== '') {
					parsedValue.operator = operatorItem.operator;
					parsedValue.filterText = match[1];
				}
			}
			return parsedValue;
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/glide/service.userPreferences.js */
angular.module('sn.common.glide').factory("userPreferences", function ($http, $q, unwrappedHTTPPromise, urlTools) {
	"use strict";
	var	preferencesCache = {};
	function getPreference(preferenceName) {
		if (preferenceName in preferencesCache)
			return preferencesCache[preferenceName];
		var targetURL = urlTools.getURL('user_preference', {
				"sysparm_pref_name": preferenceName,
				"sysparm_action": "get"
			}),
			deferred = $q.defer();
		$http.get(targetURL).success(function (response) {
			deferred.resolve(response.sysparm_pref_value);
		}).error(function (data, status) {
			deferred.reject("Error getting preference " + preferenceName + ": " + status);
		});
		preferencesCache[preferenceName] = deferred.promise;
		return deferred.promise;
	}
	function setPreference(preferenceName, preferenceValue) {
var preferenceValueString = "" + preferenceValue;
		var parmsObj = {
				"sysparm_pref_name": preferenceName,
				"sysparm_action": "set"
			};
		var useGet = preferenceValueString.length <= 1024;
		if (useGet)
			parmsObj["sysparm_pref_value"] = preferenceValueString;
		var targetURL = urlTools.getURL('user_preference', parmsObj);
		
		var httpPromise = useGet ? $http.get(targetURL) : $http.post(targetURL, {'sysparm_pref_value': preferenceValueString});
		addToCache(preferenceName, preferenceValue);
		return unwrappedHTTPPromise(httpPromise);
	}
	function addToCache(preferenceName, preferenceValue){
		preferencesCache[preferenceName] = $q.when(preferenceValue);
	}
	var userPreferences = {
		getPreference: getPreference,
		setPreference: setPreference,
		addToCache: addToCache
	};
	return userPreferences;
});
;
/*! RESOURCE: /scripts/sn/common/glide/service.nowStream.js */
angular.module('sn.common.glide').constant('nowStreamTimerInterval', 5000);
angular.module('sn.common.glide').factory('nowStream', function($q, amb, $timeout, urlTools, nowStreamTimerInterval, snResource, snCustomEvent, $log) {
	'use strict';
	var POLLING_OFF = window.NOW.activity && !(window.NOW.activity.polling && window.NOW.activity.isV0);
	var EDIT_ENABLED = window.NOW.activity && !(window.NOW.activity.editTimeLimit === '0');
var HISTORY_UPDATE_AMB_CHANNEL = '/history/update';
var V1_EMAIL_CHANNEL = '/activity/ui16';
var V0_EMAIL_CHANNEL = '/activity/email';
var EDIT_CHANNEL = '/activity/ui16/edit';
	amb.connect();
	var Stream = function() {
		this.initialize.apply(this, arguments);
	};
	Stream.prototype = {
		initialize: function(table, query, sys_id, processor, interval, source, includeAttachments) {
			this.table = table;
			this.query = query;
			this.sysparmQuery = null;
			this.sys_id = sys_id;
			this.processor = processor;
			this.lastTimestamp = 0;
			this.inflightRequest = null;
			this.requestImmediateUpdate = false;
			this.interval = interval;
			this.source = source;
			this.includeAttachments = includeAttachments;
			this.stopped = true;
			this.isLoggedIn = true;
			this.ambChannel = null;
			this.editChannel = null;
var meta_connect = '/meta/connect';
			var connectToEmailAmb = window.NOW.activity ? window.NOW.activity.useEmailAmb : false;
			var channelName;
			if (!POLLING_OFF)
channelName = HISTORY_UPDATE_AMB_CHANNEL + '/' + this.table + '/' + this.sys_id;
			else if (connectToEmailAmb)
channelName = (window.NOW.activity.isV0 ? V0_EMAIL_CHANNEL : V1_EMAIL_CHANNEL) + '/' + this.sys_id;
			else
channelName = null;
			if (channelName)
				this.ambChannel = amb.getChannel(channelName).subscribe(POLLING_OFF ? this.fetchStreamForAmb.bind(this) : this.tap.bind(this));
			this.metaConnect = amb.getChannel(meta_connect).subscribe(this.evaluateLoggedIn.bind(this));
			var editChannelName;
			if (EDIT_ENABLED) {
				var connectToEditAmbWithTable = window.NOW.activity ? window.NOW.activity.useEditAmbWithTable : false;
				if (this.sys_id && !connectToEditAmbWithTable)
editChannelName = EDIT_CHANNEL + '/' + this.sys_id;
				if (connectToEditAmbWithTable) {
					if (this.table)
editChannelName = EDIT_CHANNEL + '/' + this.table;
					else if (window.NOW.activity.editAmbTable)
editChannelName = EDIT_CHANNEL + '/' + window.NOW.activity.editAmbTable;
				}
				this.editChannel = amb.getChannel(editChannelName).subscribe(this.getEditMessageAndMakeEdit.bind(this));
			}
		},
		evaluateLoggedIn: function(message) {
			var msg = message.ext || {};
			this.ambConnected = message.successful;
			var SESSION_STATUS = "glide.session.status";
			var SESSION_TIMEOUT = "glide.session.time.remaining.in.seconds";
			var SESSION_LOGGED_IN = "session.logged.in";
			var SESSION_LOGGED_OUT = "session.logged.out";
			var SESSION_INVALIDATED = "session.invalidated";
			if (msg[SESSION_STATUS] === SESSION_LOGGED_IN) {
				if (msg[SESSION_TIMEOUT] && parseInt(msg[SESSION_TIMEOUT]) > 0)
					this.isLoggedIn = true;
			}
			else if (msg[SESSION_STATUS] === SESSION_INVALIDATED || msg[SESSION_STATUS] === SESSION_LOGGED_OUT)
				this.isLoggedIn = false;
		},
		parseEditMessage: function(jsonString) {
			if (!jsonString || typeof jsonString !== 'string')
				return null;
			try {
				var parsed = JSON.parse(jsonString);
				var result = {
					new: parsed.new || '',
					type: parsed.type || '',
					containsCode: parsed.containsCode === 'true',
					historyLineIds: []
				};
				if (parsed.historyLineIds && typeof parsed.historyLineIds === 'string') {
					try {
						result.historyLineIds = JSON.parse(parsed.historyLineIds);
					} catch (e) {
						console.error('History line ids is not a JSON string:', e);
						result.historyLineIds = [parsed.historyLineIds];
					}
				}
				return result;
			} catch (error) {
				console.error('Error parsing edit message data', error);
				return null;
			}
		},
		getEditMessageAndMakeEdit: function(message) {
			var parsedJson = this.parseEditMessage(message.data.data);
			if (!parsedJson)
				return;
			var editType = parsedJson.type;
			var newValue = parsedJson.new;
			var containsCode = parsedJson.containsCode;
			var historyLineIds = parsedJson.historyLineIds;
			var selector = historyLineIds.map(function(id) {
				return '#activity_' + id;
			}).join(', ');
			var textDivElements = document.querySelectorAll(selector);
			if (textDivElements.length === 0)
				return;
			if (editType === 'edited') {
				for (var i = 0; i < textDivElements.length; i++) {
					if(this.handleEdit(textDivElements[i], containsCode, newValue)) {
						snCustomEvent.fire('sn.stream.entries_edited',
							this.getHistoryLineId(textDivElements[i].id), newValue, containsCode);
					}
				}
			}
			if (editType === 'deleted') {
				for (var i = 0; i < textDivElements.length; i++) {
					var liElement = textDivElements[i].closest('li.h-card');
					if (liElement) {
						var historyLineId = this.getHistoryLineId(textDivElements[i].id);
						var widgetDivElements = liElement.querySelectorAll('div.sn-widget');
						if (widgetDivElements.length === 1 || widgetDivElements.length === 0) {
							liElement.remove();
						}
						else {
							textDivElements[i].remove();
						}
						snCustomEvent.fire('sn.stream.entries_deleted', historyLineId);
					}
				}
			}
		},
		getHistoryLineId: function(id) {
			var prefix = 'activity_';
			if (id.startsWith(prefix)) {
				return id.substring(prefix.length);
			}
			return id;
		},
		handleEdit: function(textDivElement, containsCode, newValue, historyLineId) {
			var spanElement = textDivElement.querySelector('span.sn-widget-textblock-body');
			if (!spanElement)
				return false;
			if (containsCode) {
				var targetElement = spanElement.querySelector('sn-html-content-wrapper');
				if (!targetElement)
					targetElement = spanElement;
				var shadowRootElement = targetElement.shadowRoot;
				if (shadowRootElement) {
					var divElement = shadowRootElement.querySelector('div');
					if (divElement) {
						divElement.innerHTML = newValue;
						return true;
					}
				}
				this.encapsulate(targetElement, newValue, historyLineId);
				targetElement.innerHTML = '';
				return true;
			}
			spanElement.innerHTML = newValue;
			return true;
		},
		createDefaultCssLink: function() {
			var link = document.createElement("link");
link.href = "styles/activity_encapsulated.css";
			link.rel = "stylesheet";
link.type = "text/css";
			return link;
		},
		createBaseElement: function() {
			var base = document.createElement("base");
			base.setAttribute("target", "_blank");
			return base;
		},
		encapsulate: function(root, content, uniqueId) {
			var defaultCssLink = this.createDefaultCssLink();
			var style = document.createElement('style');
			style.innerHTML = ':host img {max-width: 100%; height: auto; overflow: hidden;}';
			if (document.head.createShadowRoot || document.head.attachShadow) {
				var shadow = root.shadowRoot || (document.head.attachShadow ?
					root.attachShadow({mode: 'open'}) :
					root.createShadowRoot());
				var contentDiv = document.createElement('div');
				contentDiv.innerHTML = content;
				if (window.NOW && window.NOW.isUsingPolaris) contentDiv.classList.add('-polaris');
				shadow.innerHTML = contentDiv.outerHTML;
				shadow.appendChild(defaultCssLink);
				shadow.appendChild(style);
			} else {
				var iframeId = "activity-iframe-" + uniqueId;
				var existingIframe = document.getElementById(iframeId);
				if (existingIframe) {
					existingIframe.contentDocument.write(content);
					existingIframe.contentWindow.document.head.appendChild(defaultCssLink);
					existingIframe.setAttribute("height", existingIframe.contentWindow.document.body.scrollHeight + 'px');
				}
				else {
					var rootEl = typeof $j !== 'undefined' ? $j(root) : null;
					var iframe = document.createElement("iframe");
					iframe.setAttribute("id", iframeId);
					iframe.setAttribute("style", "border:none;display:block;width:100%");
					iframe.setAttribute("class", "html-content");
					iframe.setAttribute("scrolling", "no");
					iframe.setAttribute("height", "0");
					iframe.setAttribute("sandbox", "allow-same-origin");
					root.appendChild(iframe);
					var doc = iframe.contentWindow.document;
					doc.open();
					doc.write(content);
					doc.close();
					iframe.contentWindow.document.head.appendChild(defaultCssLink);
					iframe.contentWindow.document.head.appendChild(this.createBaseElement());
					iframe.height = doc.body.scrollHeight + 'px';
					if (rootEl && rootEl.closest) {
						var parentTab = rootEl.closest(".tabs2_section");
						var parentSectionId = parentTab.attr ? parentTab.attr("data-section-id") : null;
						var setIFrameHeightFn = function(tab) {
							if (typeof $j !== 'undefined') {
								var openedTab = $j(".tabs2_section." + tab);
								if (openedTab.length > 0 && openedTab.attr("data-section-id") === parentSectionId) {
									iframe.contentWindow.document.head.appendChild(defaultCssLink);
									iframe.height = doc.body.scrollHeight + 'px';
									if (typeof CustomEvent !== 'undefined' && CustomEvent.un) {
										CustomEvent.un("tab.activated", setIFrameHeightFn);
									}
								}
							}
						};
						if (typeof CustomEvent !== 'undefined' && CustomEvent.observe) {
							CustomEvent.observe("tab.activated", setIFrameHeightFn);
						}
					}
				}
			}
		},
		fetchStreamForAmb: function(message) {
			this._executeRequest().then(this._successCallback.bind(this));
		},
		fetchStream: function(callback, preRequestCallback) {
			this.callback = callback;
			this.preRequestCallback = preRequestCallback;
			this._executeRequest().then(this._successCallback.bind(this));
		},
		setQuery: function(sysparmQuery) {
			this.sysparmQuery = sysparmQuery;
		},
		poll: function(callback, preRequestCallback) {
			if (POLLING_OFF)
				return;
			this.callback = callback;
			this.preRequestCallback = preRequestCallback;
			this._stopPolling();
			this._startPolling();
		},
		tap: function() {
			if (POLLING_OFF)
				return;
			if (!this.inflightRequest) {
				this._stopPolling();
				this._startPolling();
			}
			else
				this.requestImmediateUpdate = true;
		},
		insert: function(field, text) {
			this.insertForEntry(field, text, this.table, this.sys_id);
		},
		insertForEntry: function(field, text, table, sys_id) {
			return this.insertEntries([{
				field: field,
				text: text
			}], table, sys_id);
		},
		expandMentions: function (entryText, mentionIDMap) {
			var text = entryText;
			Object.getOwnPropertyNames(mentionIDMap).forEach(function(element) {
var atMention = element.replace(/[.*+\-?^()|[\]\\]/g, '\\$&');
				var search = new RegExp("@\\[" + atMention + "\\]", "gi");
				var sysId = mentionIDMap[element];
				text = text.replace(search, "@[" + sysId + ":" + element + "]");
			});
			return text;
		},
		addCarriageReturns: function(entryText) {
return entryText.replace(/\r*\n/g, '\r\n');
		},
		insertEntries: function(entries, table, sys_id, mentionIDMap) {
			mentionIDMap = mentionIDMap || {};
			var sanitizedEntries = [];
			for (var i = 0; i < entries.length; i++) {
				var entryText = entries[i].text;
				if (entryText && entryText.endsWith('\n'))
					entryText = entryText.substring(0, entryText.length - 1);
				if (!entryText)
					continue;
				entries[i].text = this.addCarriageReturns(this.expandMentions(entryText, mentionIDMap));
				sanitizedEntries.push(entries[i]);
			}
			if (sanitizedEntries.length === 0)
				return;
			this._isInserting = true;
			var url = this._getInsertURL(table, sys_id);
			var that = this;
			return snResource().post(url, {
				entries: sanitizedEntries
			}).then(this._successCallback.bind(this), function() {
				$log.warn('Error submitting entries', sanitizedEntries);
			}).then(function() {
				that._isInserting = false;
			});
		},
		cancel: function() {
			this._stopPolling();
			if (this.ambChannel)
				this.ambChannel.unsubscribe();
			if (this.editChannel)
				this.editChannel.unsubscribe();
		},
		_startPolling : function() {
			var interval = this._getInterval();
			var that = this;
			var successCallback = this._successCallback.bind(this);
			that.stopped = false;
			function runPoll() {
				if (that._isInserting) {
					establishNextRequest();
					return;
				}
				if (that.lastPollFailed) {
					that.stopNextRequest = !that.ambConnected || !that.isLoggedIn;
					establishNextRequest();
				}
				if (!that.inflightRequest && !that.stopNextRequest) {
					that.inflightRequest = that._executeRequest();
					that.inflightRequest.then(successCallback);
					that.inflightRequest.finally(function() {
						that.inflightRequest = null;
						if (that.requestImmediateUpdate) {
							that.requestImmediateUpdate = false;
							establishNextRequest(0);
						}
						else {
							establishNextRequest();
						}
					});
				}
			}
			function establishNextRequest(intervalOverride) {
				if (that.stopped)
return;
				intervalOverride = (parseFloat(intervalOverride) >= 0) ? intervalOverride : interval;
				$timeout.cancel(that.timer);
				that.timer = $timeout(runPoll, intervalOverride);
			}
			runPoll();
		},
		_stopPolling : function() {
			if (this.timer)
				$timeout.cancel(this.timer);
			this.stopped = true;
		},
		_executeRequest: function() {
			var url = this._getURL();
			if (this.preRequestCallback) {
				this.preRequestCallback();
			}
			return snResource().get(url);
		},
		_getURL: function() {
			var params = {
				table: this.table,
				action: this._getAction(),
				sysparm_silent_request: true,
				sysparm_auto_request: true,
				sysparm_timestamp: this.lastTimestamp,
				include_attachments: this.includeAttachments
			};
			if (this.sys_id) {
				params['sys_id'] = this.sys_id;
			} else if (this.sysparmQuery) {
				params['sysparm_query'] = this.sysparmQuery;
			}
			var url = urlTools.getURL(this.processor, params);
			if (!this.sys_id) {
url += "&p=" + this.query;
			}
			if (this.processor === "list_history")
				url = url.replace("angular", "list_history")
			return url;
		},
		_getInsertURL: function(table, sys_id) {
			return urlTools.getURL(this.processor, {
				action: 'insert',
				table: table,
				sys_id: sys_id,
				sysparm_timestamp: this.timestamp || 0,
				sysparm_source: this.source
			});
		},
		_successCallback: function(answer) {
			var response = answer.data;
			if (response.entries && response.entries.length) {
				response.entries = this._filterOld(response.entries);
				if (response.entries.length > 0) {
					this.lastEntry = angular.copy(response.entries[0]);
					this.lastTimestamp = response.sys_timestamp || response.entries[0].sys_timestamp;
				}
			}
			this.lastPollFailed = (response.entries && response.entries.length) == undefined;
			this.callback.call(null, response);
		},
		_filterOld: function(entries) {
			for (var i = 0; i < entries.length; i++) {
				if (entries[i].sys_timestamp === this.lastTimestamp) {
					if (this.lastEntry) {
						if (!angular.equals(this._makeComparable(entries[i]), this._makeComparable(this.lastEntry)))
							continue;
						if (entries[i].attachment)
							snCustomEvent.fire('sn.stream.attachment_state_updated', entries[i]);
					}
				}
				if (entries[i].sys_timestamp <= this.lastTimestamp)
					return entries.slice(0, i);
			}
			return entries;
		},
		_makeComparable: function(entry) {
			if (entry.attachment)
				return entry.attachment.sys_id;
			var copy = angular.copy(entry);
			delete copy.short_description;
			delete copy.display_value;
			if (copy.entries?.journal) {
				for (var i = 0; i < copy.entries.journal.length; i++) {
					var sysId = copy.entries.journal[i].sys_id;
					copy.entries.journal[i] = { sys_id: sysId };
				}
			}
			return copy;
		},
		_getAction: function() {
			return this.sys_id ? 'get_new_entries' : 'get_set_entries';
		},
		_getInterval: function() {
			if (this.interval)
				return this.interval;
			else if (window.NOW && NOW.stream_poll_interval)
				return NOW.stream_poll_interval * 1000;
			else
				return nowStreamTimerInterval;
		}
	};
	return {
		create: function(table, query, sys_id, processor, interval, source) {
			return new Stream(table, query, sys_id, processor, interval, source);
		}
	};
});
;
/*! RESOURCE: /scripts/sn/common/glide/service.nowServer.js */
angular.module('sn.common.glide').factory('nowServer', function($http, $q, userPreferences, angularProcessorUrl, urlTools) {
	return {
		getBaseURL: function () {
			return angularProcessorUrl;
		},
		getPartial: function(scope, partial, parms, callback) {
			var url = this.getPartialURL(partial, parms);
			if (url === scope.url) {
				callback.call();
				return;
			}
			var fn = scope.$on('$includeContentLoaded', function() {
fn.call();
				callback.call();
			});
			scope.url = url;
		},
		replaceView: function($location, newView) {
			var p = $location.path();
var a = p.split("/");
			a[1] = newView;
p = a.join("/");
			return p;
		},
		getPartialURL: urlTools.getPartialURL,
		getURL: urlTools.getURL,
		urlFor : urlTools.urlFor,
		getPropertyURL: urlTools.getPropertyURL,
		setPreference: userPreferences.setPreference,
		getPreference: userPreferences.getPreference
	}
});
;
;
/*! RESOURCE: /scripts/sn/common/glide/js_includes_glide.js */
